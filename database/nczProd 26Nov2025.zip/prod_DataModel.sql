/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [PROD]
 Source Server Type    : SQL Server
 Source Server Version : 12001017 (12.00.1017)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczprod
 Source Schema         : DataModel

 Target Server Type    : SQL Server
 Target Server Version : 12001017 (12.00.1017)
 File Encoding         : 65001

 Date: 26/11/2025 10:33:41
*/

