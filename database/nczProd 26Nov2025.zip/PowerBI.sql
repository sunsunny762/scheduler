/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [PROD]
 Source Server Type    : SQL Server
 Source Server Version : 12001017 (12.00.1017)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczprod
 Source Schema         : PowerBI

 Target Server Type    : SQL Server
 Target Server Version : 12001017 (12.00.1017)
 File Encoding         : 65001

 Date: 26/11/2025 12:06:23
*/


-- ----------------------------
-- Table structure for PowerBIExportLog
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[PowerBIExportLog]') AND type IN ('U'))
	DROP TABLE [PowerBI].[PowerBIExportLog]
GO

CREATE TABLE [PowerBI].[PowerBIExportLog] (
  [Id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [exportId] nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [emailTo] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [resourceLocation] nvarchar(300) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [reportPDFFileName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [status] int DEFAULT 0 NULL,
  [statusUpdatedOn] datetime  NULL,
  [companyName] nvarchar(60) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [productName] nvarchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [hasError] int DEFAULT NULL NULL,
  [errorDetails] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
  [documentId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [customerId] int  NULL
)
GO

ALTER TABLE [PowerBI].[PowerBIExportLog] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of PowerBIExportLog
-- ----------------------------
SET IDENTITY_INSERT [PowerBI].[PowerBIExportLog] ON
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'1', N'6156625755324111391', NULL, N'test@test18feb.com', NULL, NULL, N'0', N'2025-02-18 11:33:40.910', N'TEST 18Feb', N'BLUE', NULL, NULL, NULL, N'299')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'2', N'6156848754939583235', NULL, N'margaret.horton@romionhealth.com', NULL, NULL, N'0', N'2025-02-18 11:34:19.690', N'Romion Health', N'BLUE', NULL, NULL, NULL, N'265')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'3', N'6156917887314603257', NULL, N'patrycja@iabuk.com', NULL, NULL, N'0', N'2025-02-18 13:03:25.223', N'IAB', N'BLUE', NULL, NULL, NULL, N'304')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'4', N'6157080692018168256', NULL, N'alex@foretheplanet.co.uk', NULL, NULL, N'0', N'2025-02-18 17:31:51.483', N'Fore! The Planet Ltd', N'BLUE', NULL, NULL, NULL, N'307')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'5', N'6157690782878999914', NULL, N'gm@intaelectrical.co.uk', NULL, NULL, N'0', N'2025-02-19 10:31:31.813', N'Inta Electrical Services Ltd', N'BLUE', NULL, NULL, NULL, N'309')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'6', N'6156845165321775424', NULL, N'test@test18febrjm.com', NULL, NULL, N'0', N'2025-02-19 11:01:23.060', N'TEST Company 18FEB RJM', N'BLUE', NULL, NULL, NULL, N'310')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'7', N'6157804841518270115', NULL, N'tom@thebasecampco.com', NULL, NULL, N'0', N'2025-02-19 13:31:18.763', N'The Base Camp Co', N'BLUE', NULL, NULL, NULL, N'313')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'8', N'6157848920225719610', NULL, N'sarahl@phwatertechnologies.co.uk', NULL, NULL, N'0', N'2025-02-19 15:01:17.077', N'Ph Water and Air Technologies Ltd', N'BLUE', NULL, NULL, NULL, N'315')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'9', N'6158014398023506927', NULL, N'anguscmunro@btinternet.com', NULL, NULL, N'0', N'2025-02-20 08:01:06.793', N'10 EBOST', N'BLUE', NULL, NULL, NULL, N'316')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'10', N'6158543084856508659', NULL, N'ciara@pv-plus.co.uk', NULL, NULL, N'0', N'2025-02-20 10:00:52.497', N'PV Plus Ltd', N'BLUE', NULL, NULL, NULL, N'317')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'11', N'6158729847123705636', NULL, N'victor.levison@theenergyrevolution.co.uk', NULL, NULL, N'0', N'2025-02-20 15:30:41.557', N'The Energy Revolution Group Limited', N'BLUE', NULL, NULL, NULL, N'321')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'12', N'6162077153613249384', NULL, N'jenny@mercerbuildingsolutions.com', NULL, NULL, N'0', N'2025-02-24 12:32:07.980', N'Mercer Building Solutions Ltd', N'BLUE', NULL, NULL, NULL, N'326')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'13', N'6162191943329225997', NULL, N'anna.worthignton@imtmatcher.com', NULL, NULL, N'0', N'2025-02-24 15:32:14.000', N'Matcher Technologies Limited', N'BLUE', NULL, NULL, NULL, N'328')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'14', N'6163027759158583576', NULL, N'accounts@seldram.co.uk', NULL, NULL, N'0', N'2025-02-25 14:31:15.550', N'Seldram Supplies Camberley Limited', N'BLUE', NULL, NULL, NULL, N'329')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'15', N'6163031949158774127', NULL, N'accounts@seldram.co.uk', NULL, NULL, N'0', N'2025-02-25 15:01:11.640', N'Seldram Supplies (Oxford) Ltd', N'BLUE', NULL, NULL, NULL, N'330')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'16', N'6163051309152471867', NULL, N'accounts@seldram.co.uk', NULL, NULL, N'0', N'2025-02-25 15:31:12.037', N'Seldram Supplies Camberley Limited', N'BLUE', NULL, NULL, NULL, N'331')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'17', N'6163052709153297235', NULL, N'accounts@seldram.co.uk', NULL, NULL, N'0', N'2025-02-25 15:31:23.167', N'Seldram Supplies (Oxford) Ltd', N'BLUE', NULL, NULL, NULL, N'332')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'18', N'6163063889152346943', NULL, N'accounts@seldram.co.uk', NULL, NULL, N'0', N'2025-02-25 15:31:34.127', N'Seldram Supplies Camberley Limited', N'BLUE', NULL, NULL, NULL, N'331')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'19', N'6163066269159237334', NULL, N'accounts@seldram.co.uk', NULL, NULL, N'0', N'2025-02-25 16:01:09.180', N'Seldram Supplies (Oxford) Ltd', N'BLUE', NULL, NULL, NULL, N'332')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'20', N'6163835595326154553', NULL, N'jonathan@davyeng.co.uk', NULL, NULL, N'0', N'2025-02-26 13:01:32.263', N'Davy Engineering Ltd', N'BLUE', NULL, NULL, NULL, N'335')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'21', N'5911249572939002035', NULL, N'ricky.majer@bermiait.co.uk', NULL, NULL, N'0', N'2025-02-27 05:13:17.160', N'Collab FM', N'BLUE', NULL, NULL, NULL, N'337')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'22', N'6150873951518622184', NULL, N'me@douglaskurn.co.uk', NULL, NULL, N'0', N'2025-02-28 08:31:50.010', N'Douglas Kurn', N'BLUE', NULL, NULL, NULL, N'341')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'23', N'6165405366228424627', NULL, N'jgreenwood@ramonhygiene.co.uk', NULL, NULL, N'0', N'2025-02-28 08:32:01.300', N'Ramon Holdings Limited', N'BLUE', NULL, NULL, NULL, N'342')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'24', N'6165417299012843397', NULL, N'seconomides@engagegroup.me', NULL, NULL, N'0', N'2025-02-28 09:02:00.693', N'Engage Me Management Consultancy', N'BLUE', NULL, NULL, NULL, N'343')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'25', N'6165764132712180131', NULL, N'daniel.fletcher@tawt.uk.com', NULL, NULL, N'0', N'2025-02-28 18:31:48.630', N'Thames Air & Water Tech', N'BLUE', NULL, NULL, NULL, N'346')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'26', N'6166353083116391957', NULL, N'SABRINA@GREENPLANIFY.COM', NULL, NULL, N'0', N'2025-03-03 08:01:17.090', N'GREEN PLANIFY', N'BLUE', NULL, NULL, NULL, N'347')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'27', N'6167998204414485700', NULL, N'angel@neutralcarbonzone.com', NULL, NULL, N'0', N'2025-03-03 09:01:19.567', N'Builder Prime', N'BLUE', NULL, NULL, NULL, N'348')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'28', N'6168051270339904401', NULL, N'Ramielle@neutralcarbonzone.com', NULL, NULL, N'0', N'2025-03-03 10:01:17.493', N'Ramielle', N'BLUE', NULL, NULL, NULL, N'349')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'29', N'6168914429191063559', NULL, N'andrew.kennedy@leisurefocus.org.uk', NULL, NULL, N'0', N'2025-03-04 10:01:03.300', N'Leisure Focus', N'BLUE', NULL, NULL, NULL, N'354')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'30', N'6169296152817786438', NULL, N'max@clear-decisions.com', NULL, NULL, N'0', N'2025-03-05 08:01:03.560', N'The Clear Decisions Company Ltd', N'BLUE', NULL, NULL, NULL, N'358')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'31', N'6169381498132979907', NULL, N'info@flashprofessionalservices.co.uk', NULL, NULL, N'0', N'2025-03-05 08:01:14.320', N'FLASH Professional Services Limited', N'BLUE', NULL, NULL, NULL, N'359')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'32', N'6174110340344039622', NULL, N'Info@system2000group.com', NULL, NULL, N'0', N'2025-03-10 10:34:05.637', N'System 2000 Group Ltd', N'BLUE', NULL, NULL, NULL, N'367')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'33', N'6174407757019268320', NULL, N'billy@peakgovernance.co.uk', NULL, NULL, N'0', N'2025-03-11 08:05:13.307', N'Peak Governance Business Advisors Ltd', N'BLUE', NULL, NULL, NULL, N'371')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'34', N'6175944494521484708', NULL, N'nickgillmore@mattisonscaffolding.com', NULL, NULL, N'0', N'2025-03-12 13:40:01.570', N'Mattison Scaffolding LTD', N'BLUE', NULL, NULL, NULL, N'374')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'35', N'6180160055118614026', NULL, N'nici.leonard@lewishickey.com', NULL, NULL, N'0', N'2025-03-17 10:37:42.293', N'Lewis & Hickey Ltd', N'BLUE', NULL, NULL, NULL, N'379')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'36', N'6180400013516540877', NULL, N'owen@meercatassociates.com', NULL, NULL, N'0', N'2025-03-17 17:35:38.850', N'Frameworker', N'BLUE', NULL, NULL, NULL, N'380')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'37', N'6181219893214982319', NULL, N'gavincheckley@no3a.co.uk', NULL, NULL, N'0', N'2025-03-18 16:02:12.167', N'GCCH Holdings Limited T/A NO3a', N'BLUE', NULL, NULL, NULL, N'382')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'38', N'6181932279191235228', NULL, N'emily@plantdesigns.co.uk', NULL, NULL, N'0', N'2025-03-19 12:01:00.837', N'Plant Designs', N'BLUE', NULL, NULL, NULL, N'385')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'39', N'6182094069818210861', NULL, N'matt@nraconstruct.co.uk', NULL, NULL, N'0', N'2025-03-19 16:30:53.830', N'NRA construct', N'BLUE', NULL, NULL, NULL, N'386')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'40', N'6183615949386944153', NULL, N'stuart@cambiumplants.co.uk', NULL, NULL, N'0', N'2025-03-21 10:31:02.850', N'Cambium plants', N'BLUE', NULL, NULL, NULL, N'389')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'41', N'6188173633422169281', NULL, N'robert.kerr@shieldhr.co.uk', NULL, NULL, N'0', N'2025-03-26 17:02:14.447', N'Shield HR Ltd', N'BLUE', NULL, NULL, NULL, N'400')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'42', N'6188736569258854349', NULL, N'aaron@uniteddrains.co.uk', NULL, NULL, N'0', N'2025-03-27 09:02:32.913', N'United Drains', N'BLUE', NULL, NULL, NULL, N'402')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'43', N'6188883367913849159', NULL, N'nifoodequipment@btconnect.com', NULL, NULL, N'0', N'2025-03-27 13:02:23.147', N'Northern Ireland Food Equipment', N'BLUE', NULL, NULL, NULL, N'403')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'44', N'6188983294226423894', NULL, N'sue.norton@qcel.co.uk', NULL, NULL, N'0', N'2025-03-27 15:33:28.927', N'QCEL', N'BLUE', NULL, NULL, NULL, N'404')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'45', N'6188987976211691332', NULL, N'marketing@caterline.ie', NULL, NULL, N'0', N'2025-03-27 16:03:35.363', N'Caterline Catering Equipment Ltd', N'BLUE', NULL, NULL, NULL, N'405')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'46', N'6189700048578521732', NULL, N'richard.mallen@centralpower.co.uk', NULL, NULL, N'0', N'2025-03-28 11:40:11.843', N'Central Power Limited', N'BLUE', NULL, NULL, NULL, N'408')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'47', N'6189856581523061709', NULL, N'aidan@envirofwa.com', NULL, NULL, N'0', N'2025-03-28 16:09:56.320', N'Enviro Fire Water & Air Limited', N'BLUE', NULL, NULL, NULL, N'409')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'48', N'6189905238338717904', NULL, N'wayne.taafe@bladeroofing.co.uk', NULL, NULL, N'0', N'2025-03-28 17:40:03.677', N'Blade Roofing Ltd', N'BLUE', NULL, NULL, NULL, N'410')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'49', N'6194034744214651603', NULL, N'info@johnhunterglazing.co.uk', NULL, NULL, N'0', N'2025-04-02 12:09:38.393', N'John Hunter Glazing Ltd', N'BLUE', NULL, NULL, NULL, N'416')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'50', N'6194041703613715961', NULL, N'trishmcveigh@electroautomation.co.uk', NULL, NULL, N'0', N'2025-04-02 12:09:56.390', N'Electro Automation (NI) Ltd', N'BLUE', NULL, NULL, NULL, N'417')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'51', N'6194956560412405822', NULL, N'james.halls@responsenetwork.group', NULL, NULL, N'0', N'2025-04-03 13:40:16.593', N'Response Restoration Group Limited ', N'BLUE', NULL, NULL, NULL, N'419')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'52', N'6195088759313871182', NULL, N'james.halls@responsenetwork.group', NULL, NULL, N'0', N'2025-04-03 17:38:12.767', N'Response Restoration Group Limited ', N'BLUE', NULL, NULL, NULL, N'420')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'53', N'6195704791227501531', NULL, N'zac@neutralcarbonzone.com', NULL, NULL, N'0', N'2025-04-04 10:33:09.203', N'NCZ', N'BLUE', NULL, NULL, NULL, N'422')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'54', N'6195705512449461194', NULL, N'sophie@aptss.co.uk', NULL, NULL, N'0', N'2025-04-04 10:33:19.280', N'APT Security Shutters Ltd', N'BLUE', NULL, NULL, NULL, N'423')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'55', N'6198280967987192997', NULL, N'tcoad@itsystems.uk.net', NULL, NULL, N'0', N'2025-04-07 10:03:23.087', N'IT Systems & Support Limited', N'BLUE', NULL, NULL, NULL, N'424')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'56', N'6200914491953790991', NULL, N'sue@selectaskip.co.uk', NULL, NULL, N'0', N'2025-04-10 11:01:36.727', N'Select A Skip Uk Ltd', N'BLUE', NULL, NULL, NULL, N'431')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'57', N'6201135307991378187', NULL, N'hotelmanager@citrushoteleastbourne.co.uk', NULL, NULL, N'0', N'2025-04-14 11:01:45.440', N'Best Western Plus Citrus Hotel', N'BLUE', NULL, NULL, NULL, N'432')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'58', N'6204406242444003701', NULL, N'sophie@aptss.co.uk', NULL, NULL, N'0', N'2025-04-14 12:11:47.750', N'APT Security Shutters Ltd', N'BLUE', NULL, NULL, NULL, N'433')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'59', N'6204635486814185429', NULL, N'contact@empoweraiservice.com', NULL, NULL, N'0', N'2025-04-14 18:43:05.150', N'Empower AI Services', N'BLUE', NULL, NULL, NULL, N'434')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'60', N'6211318625144182995', NULL, N'info@living-water.co.uk', NULL, NULL, N'0', N'2025-04-22 12:00:43.320', N'Samantha Price ', N'BLUE', NULL, NULL, NULL, N'438')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'61', N'6212061972844880188', NULL, N'gareth.smith@purifiedair.com', NULL, NULL, N'0', N'2025-04-23 08:55:41.843', N'Purified Air', N'BLUE', NULL, NULL, NULL, N'439')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'62', N'6212093750222692423', NULL, N'lheerey@bridgerecruitment.co.uk', NULL, NULL, N'0', N'2025-04-23 09:57:10.367', N'The Bridge Recruitment Group', N'BLUE', NULL, NULL, NULL, N'440')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'63', N'6206228334331632950', NULL, N'jo.hall@actualservices.co.uk', NULL, NULL, N'0', N'2025-04-23 10:58:25.780', N'Actual Support Services Limited', N'BLUE', NULL, NULL, NULL, N'441')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'64', N'6206201733524365815', NULL, N'sophie.bennett@bdma.org.uk', NULL, NULL, N'0', N'2025-04-23 11:28:08.890', N'British Damage Management Association', N'BLUE', NULL, NULL, NULL, N'442')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'65', N'6205399690812975507', NULL, N'sean@dddlightingdesign.co.uk', NULL, NULL, N'0', N'2025-04-23 11:28:19.390', N'DDD Design Limited', N'BLUE', NULL, NULL, NULL, N'443')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'66', N'6215505322123655458', NULL, N'Ken@chsteelsupply.com', NULL, NULL, N'0', N'2025-04-29 08:03:14.023', N'Qingdao Cahnghui Pipes Co.,Ltd', N'BLUE', NULL, NULL, NULL, N'449')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'67', N'6230152736616287790', NULL, N'c.williams@tgm.co.uk', NULL, NULL, N'0', N'2025-05-14 08:15:08.253', N'TGM (Total Gutter Maintenance Ltd)', N'BLUE', NULL, NULL, NULL, N'460')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'68', N'6230421413412515128', NULL, N'emma@signsdesign.co.uk', NULL, NULL, N'0', N'2025-05-14 14:43:39.160', N'Signs & Design (Kent) Ltd', N'BLUE', NULL, NULL, NULL, N'461')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'69', N'6234725736604419060', NULL, N'chris.berry@tnp.net.uk', NULL, NULL, N'0', N'2025-05-19 14:39:09.397', N'The Networking People', N'BLUE', NULL, NULL, NULL, N'466')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'70', N'6236495726014477567', NULL, N'jim.goodenough@flexitog.com', NULL, NULL, N'0', N'2025-05-21 15:33:58.807', N'FlexiTog UK Ltd', N'BLUE', NULL, NULL, NULL, N'470')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'71', N'6236518286317384163', NULL, N'mike.king@a-ohs.co.uk', NULL, NULL, N'0', N'2025-05-21 16:03:52.353', N'Asclepius OHS Ltd', N'BLUE', NULL, NULL, NULL, N'471')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'72', N'6237288775968528255', NULL, N'mjoffroy@matferbourgeat.com', NULL, NULL, N'0', N'2025-05-22 13:32:41.783', N'MATFER', N'BLUE', NULL, NULL, NULL, N'472')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'73', N'6238061920511511277', NULL, N'DamonMurtisk@morethanstoneservices.com', NULL, NULL, N'0', N'2025-05-23 11:02:34.870', N'Morethan Stone Services Limited ', N'BLUE', NULL, NULL, NULL, N'476')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'74', N'6238192886613077520', NULL, N'chris@mcs-creative.co.uk', NULL, NULL, N'0', N'2025-05-23 14:32:37.450', N'MCS Creative Ltd', N'BLUE', NULL, NULL, NULL, N'477')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'75', N'6238222680617851255', NULL, N'alex@mullettsolutions.co.uk', NULL, NULL, N'0', N'2025-05-23 15:32:26.517', N'Mullett Solutions', N'BLUE', NULL, NULL, NULL, N'478')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'76', N'6243214686811646816', NULL, N'jacob@neutralcarbonzone.com', NULL, NULL, N'0', N'2025-05-29 10:08:29.727', N'Jacobs Jackets ', N'BLUE', NULL, NULL, NULL, N'484')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'77', N'6246727163513640994', NULL, N'stack@planetearthed.com', NULL, NULL, N'0', N'2025-06-02 11:41:35.740', N'PlanetEarthed Ltd', N'BLUE', NULL, NULL, NULL, N'490')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'78', N'6249969002013901567', NULL, N'ram@omegatest.com', NULL, NULL, N'0', N'2025-06-06 08:04:15.910', N'omega RAM TEST', N'BLUE', NULL, NULL, NULL, N'492')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'79', N'6251829638249313445', NULL, N'mary.marshall@greenalchemy.me', NULL, NULL, N'0', N'2025-06-09 08:04:05.990', N'Green Alchemy Project Management', N'BLUE', NULL, NULL, NULL, N'493')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'80', N'6254360356312890112', NULL, N'zac@neutralcarbonzone.com', NULL, NULL, N'0', N'2025-06-11 08:25:59.160', N'LMPC Ltd', N'BLUE', NULL, NULL, NULL, N'497')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'81', N'6255375572121715048', NULL, N'dan@stonebridgefm.co.uk', NULL, NULL, N'0', N'2025-06-12 12:26:23.570', N'Stonebridge FM Consulting Ltd.', N'BLUE', NULL, NULL, NULL, N'501')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'82', N'6255477496427994389', NULL, N'john@proactivegroupuk.com', NULL, NULL, N'0', N'2025-06-12 14:56:52.700', N'Proactive Cleaners Ltd', N'BLUE', NULL, NULL, NULL, N'502')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'83', N'6256226525126533161', NULL, N'info@bkrcleaning.ie', NULL, NULL, N'0', N'2025-06-13 11:57:04.227', N'B.K.R Cleaning', N'BLUE', NULL, NULL, NULL, N'503')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'84', N'6257041746316091121', NULL, N'rajesh@aquaclean-qatar.com', NULL, NULL, N'0', N'2025-06-16 08:29:29.643', N'AQUA CLEAN', N'BLUE', NULL, NULL, NULL, N'504')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'85', N'6259669170015118711', NULL, N'robin@archemicals.co.uk', NULL, NULL, N'0', N'2025-06-17 11:16:24.613', N'A & R Chemicals LTD', N'BLUE', NULL, NULL, NULL, N'505')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'86', N'6260595005714454902', NULL, N'luke@justsaveltd.co.uk', NULL, NULL, N'0', N'2025-06-18 13:52:48.973', N'Just Save Ltd', N'BLUE', NULL, NULL, NULL, N'508')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'87', N'6264900542522165909', NULL, N'dipak@ukmerchandising.co.uk', NULL, NULL, N'0', N'2025-06-23 12:56:59.353', N'UK Merchandising Ltd.', N'BLUE', NULL, NULL, NULL, N'513')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'88', N'6264994938328645568', NULL, N'glenn@grayshottpottery.com', NULL, NULL, N'0', N'2025-06-23 15:27:03.983', N'Surrey Ceramics', N'BLUE', NULL, NULL, NULL, N'514')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'89', N'6265001578129838432', NULL, N'peter.gallimore@grunwerg.co.uk', NULL, NULL, N'0', N'2025-06-23 15:56:50.807', N'Grunwerg', N'BLUE', NULL, NULL, NULL, N'515')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'90', N'6265834248314077382', NULL, N'ian@jdsproducts.co.uk', NULL, NULL, N'0', N'2025-06-24 15:00:53.133', N'JDS Products Ltd', N'BLUE', NULL, NULL, NULL, N'517')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'91', N'6265838208318326502', NULL, N'ian@jdsproducts.co.uk', NULL, NULL, N'0', N'2025-06-24 15:01:27.823', N'JDS Products Ltd', N'BLUE', NULL, NULL, NULL, N'518')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'92', N'6266303336427363207', NULL, N'peter@eaststone.com', NULL, NULL, N'0', N'2025-06-25 08:21:33.087', N'Oriental Raise Stone', N'BLUE', NULL, NULL, NULL, N'519')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'93', N'6268318365115290258', NULL, N'piers@ycf.net', NULL, NULL, N'0', N'2025-06-27 11:52:14.030', N'Yorkshire Cleaning Fabrics Limited', N'BLUE', NULL, NULL, NULL, N'520')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'94', N'6272634872022180565', NULL, N'quality@multy.co.uk', NULL, NULL, N'0', N'2025-07-02 11:37:26.840', N'Multy UK', N'BLUE', NULL, NULL, NULL, N'527')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'95', N'6273804123517168863', NULL, N'tsjgreer@southeasterngas.com', NULL, NULL, N'0', N'2025-07-04 08:05:34.613', N'South eastern Gas Service Ltd', N'BLUE', NULL, NULL, NULL, N'528')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'96', N'6275314597983371042', NULL, N'laban@noblecreations.co.ke', NULL, NULL, N'0', N'2025-07-07 08:05:44.310', N'Noble creations limited', N'BLUE', NULL, NULL, NULL, N'529')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'97', N'6276910596832192626', NULL, N'mirek.nowak@geldbach.co.uk', NULL, NULL, N'0', N'2025-07-07 10:06:10.410', N'Geldbach UK Ltd', N'BLUE', NULL, NULL, NULL, N'531')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'98', N'6277066738323383880', NULL, N'info@badbettypress.com', NULL, NULL, N'0', N'2025-07-07 15:04:00.927', N'Bad Betty Press', N'BLUE', NULL, NULL, NULL, N'534')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'99', N'6277183666603360806', NULL, N'jane.doe@exampledemo.com', NULL, NULL, N'0', N'2025-07-07 17:34:08.947', N'ABC Construction', N'BLUE', NULL, NULL, NULL, N'535')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'100', N'6277196999706081541', NULL, N'fred@forma.be', NULL, NULL, N'0', N'2025-07-07 18:04:08.280', N'Forma. Srl', N'BLUE', NULL, NULL, NULL, N'536')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'101', N'6278586819919708096', NULL, N'j.simon@barre-bouillet.fr', NULL, NULL, N'0', N'2025-07-09 08:32:32.507', N'Barre Bouillet', N'BLUE', NULL, NULL, NULL, N'537')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'102', N'6278690670528642864', NULL, N'darren@twc-services.co.uk', NULL, NULL, N'0', N'2025-07-09 11:32:39.170', N'TWC (services) Ltd', N'BLUE', NULL, NULL, NULL, N'538')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'103', N'6278726196426632178', NULL, N'info@cpinstall.net', NULL, NULL, N'0', N'2025-07-09 12:32:36.113', N'C & P INSTALL LIMITED', N'BLUE', NULL, NULL, NULL, N'539')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'104', N'6280458240425575372', NULL, N'david@capitalwastesolutions.co.uk', NULL, NULL, N'0', N'2025-07-11 12:52:24.930', N'Capital Waste Solutions Ltd', N'BLUE', NULL, NULL, NULL, N'540')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'105', N'6282314041029191236', NULL, N'nataly.hastings@cellestialhealth.com', NULL, NULL, N'0', N'2025-07-14 08:28:29.650', N'Cellestial Health', N'BLUE', NULL, NULL, NULL, N'541')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'106', N'6283160737516122586', NULL, N'sara@gpmlondon.com', NULL, NULL, N'0', N'2025-07-14 16:30:30.633', N'GPM London LTD', N'BLUE', NULL, NULL, NULL, N'542')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'107', N'6283935682024541740', NULL, N'rachael.de-ath@marbas.co.uk', NULL, NULL, N'0', N'2025-07-15 13:41:10.560', N'Marbas Group Limited', N'BLUE', NULL, NULL, NULL, N'543')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'108', N'6283935684517749070', NULL, N'mproudlock@coba.com', NULL, NULL, N'0', N'2025-07-15 13:41:21.890', N'COBA', N'BLUE', NULL, NULL, NULL, N'544')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'109', N'6284627968022835156', NULL, N'wim@is-delta.be', NULL, NULL, N'0', N'2025-07-16 09:33:52.183', N'Integrated Systems BV', N'BLUE', NULL, NULL, NULL, N'547')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'110', N'6284906537941654384', NULL, N'edward.bailey@dkhouseholdbrands.com', NULL, NULL, N'0', N'2025-07-16 16:33:28.923', N'DKB HOUSEHOLD UK LTD', N'BLUE', NULL, NULL, NULL, N'548')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'111', N'6285521111462521840', NULL, N'steve@ecospill.org.uk', NULL, NULL, N'0', N'2025-07-17 10:34:18.517', N'Ecospill Ltd', N'BLUE', NULL, NULL, NULL, N'549')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'112', N'6285639606911472825', NULL, N'office@midlandwiper.uk', NULL, NULL, N'0', N'2025-07-17 13:38:06.790', N'Midland Wiper Manufacturing Co Ltd', N'BLUE', NULL, NULL, NULL, N'550')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'113', N'6286483881324372688', NULL, N'info@jepuk.com', NULL, NULL, N'0', N'2025-07-18 12:12:43.143', N'JEP Industrial Ltd', N'BLUE', NULL, NULL, NULL, N'551')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'114', N'6290650960917480588', NULL, N'cath@northernrestoration.co.uk', NULL, NULL, N'0', N'2025-07-23 08:01:46.780', N'Retailing', N'BLUE', NULL, NULL, NULL, N'553')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'115', N'6290659000915525615', NULL, N'cath@northernrestoration.co.uk', NULL, NULL, N'0', N'2025-07-23 08:02:00.960', N'Northern Restoration Ltd', N'BLUE', NULL, NULL, NULL, N'554')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'116', N'6290807573954193062', NULL, N'e.dirand@dyl-enseignes.com', NULL, NULL, N'0', N'2025-07-23 12:01:21.027', N'DYL ENSEIGNES', N'BLUE', NULL, NULL, NULL, N'555')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'117', N'6290988735517850157', NULL, N'gavin.nobles@egreen.co.uk', NULL, NULL, N'0', N'2025-07-23 17:01:06.067', N'eGreen International Ltd', N'BLUE', NULL, NULL, NULL, N'556')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'118', N'6291607322414872387', NULL, N'jake@evolveadvice.co.uk', NULL, NULL, N'0', N'2025-07-24 10:30:55.767', N'EVOLVE Advice Ltd', N'BLUE', NULL, NULL, NULL, N'557')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'119', N'6295076346028006445', NULL, N'r@test.com', NULL, NULL, N'0', N'2025-07-28 10:32:03.120', N'RAM TEST 28JUl2025', N'BLUE', NULL, NULL, NULL, NULL)
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'120', N'6295822900142305004', NULL, N'nicky.dumbleton@etiltd.co.uk', NULL, NULL, N'0', N'2025-07-29 08:02:08.997', N'Electronic Temperature Instruments Ltd', N'BLUE', NULL, NULL, NULL, N'564')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'121', N'6295851997214162462', NULL, N'19dcad@queensu.ca', NULL, NULL, N'0', N'2025-07-29 08:32:00.217', N'Monkey Business', N'BLUE', NULL, NULL, NULL, N'565')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'122', N'6295957734013444409', NULL, N'helen.colbourne@imperial.co.uk', NULL, NULL, N'0', N'2025-07-29 11:02:09.943', N'Imperial', N'BLUE', NULL, NULL, NULL, N'566')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'123', N'6296726637211531727', NULL, N'19dcad@queensu.ca', NULL, NULL, N'0', N'2025-07-30 08:32:12.470', N'Monkey Business Ltd.', N'BLUE', NULL, NULL, NULL, N'569')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'124', N'6297775468422922688', NULL, N'dee.titley@it4automation.com', NULL, NULL, N'0', N'2025-07-31 13:36:53.540', N'IT4Automation Ltd', N'BLUE', NULL, NULL, NULL, N'571')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'125', N'6298530485614244128', NULL, N'darren@hrfireandsafety.co.uk', NULL, NULL, N'0', N'2025-08-01 10:36:15.457', N'H R Fire and Safety Ltd', N'BLUE', NULL, NULL, NULL, N'572')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'126', N'6301092571615696119', NULL, N'karen@dispo.co.uk', NULL, NULL, N'0', N'2025-08-04 10:01:55.190', N'dispo international', N'BLUE', NULL, NULL, NULL, N'574')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'127', N'6301138719014534559', NULL, N'an@ivo-group.com', NULL, NULL, N'0', N'2025-08-04 11:01:30.147', N'iVO Group Ltd', N'BLUE', NULL, NULL, NULL, N'575')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'128', N'6302091545461007580', NULL, N'gary.hedges@syrclean.com', NULL, NULL, N'0', N'2025-08-05 13:30:56.360', N'Scot Young Research Ltd', N'BLUE', NULL, NULL, NULL, N'576')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'129', N'6304578190987334288', NULL, N'mark@effenberg.co.uk', NULL, NULL, N'0', N'2025-08-08 10:31:04.020', N'Muddy Paws Insurance', N'BLUE', NULL, NULL, NULL, N'580')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'130', N'6304772201881932613', NULL, N'mike.townson@primeguarduk.com', NULL, NULL, N'0', N'2025-08-08 16:01:46.460', N'Prime Guard UK. LTD', N'BLUE', NULL, NULL, NULL, N'581')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'131', N'6304856595311766084', NULL, N'jv.griffin@btinternet.com', NULL, NULL, N'0', N'2025-08-08 18:31:48.630', N'ELG Electrical Services Limited', N'BLUE', NULL, NULL, NULL, N'582')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'132', N'6308088291961782934', NULL, N'info@mullinandsons.co.uk', NULL, NULL, N'0', N'2025-08-12 12:05:04.677', N'Mullin and Sons Ltd', N'BLUE', NULL, NULL, NULL, N'584')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'133', N'6313342545016797513', NULL, N'franklin@supercolor.be', NULL, NULL, N'0', N'2025-08-18 14:01:37.027', N'Supercolor', N'BLUE', NULL, NULL, NULL, N'586')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'134', N'6313431046438474377', NULL, N'paul.owen@rozone.com', NULL, NULL, N'0', N'2025-08-18 16:32:36.260', N'Rozone Limited', N'BLUE', NULL, NULL, NULL, N'588')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'135', N'6313993145221385866', NULL, N'carol@stslimited.co.uk', NULL, NULL, N'0', N'2025-08-19 08:03:10.820', N'STS (Southern Technical Services) Limited', N'BLUE', NULL, NULL, NULL, N'589')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'136', N'6314231281512109440', NULL, N'simon@knightengineers.co.uk', NULL, NULL, N'0', N'2025-08-19 15:02:23.957', N'Knight Engineers Ltd', N'BLUE', NULL, NULL, NULL, N'590')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'137', N'6314586306722625834', NULL, N'kcummins@kendraenergy.co.uk', NULL, NULL, N'0', N'2025-08-20 08:02:20.110', N'KRC Controls ltd', N'BLUE', NULL, NULL, NULL, N'591')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'138', N'6314921261611521555', NULL, N'commercial@lifeenvironmental.com', NULL, NULL, N'0', N'2025-08-20 10:02:41.530', N'Life Environmental Services Ltd', N'BLUE', NULL, NULL, NULL, N'592')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'139', N'6314945918322126442', NULL, N'info@stewartselectrical.co.uk', NULL, NULL, N'0', N'2025-08-20 10:32:31.100', N'Stewarts Electrical Limited', N'BLUE', NULL, NULL, NULL, N'593')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'140', N'6314994488614468303', NULL, N'joe@ambient-engineering.co.uk', NULL, NULL, N'0', N'2025-08-20 12:02:16.220', N'Ambient Engineering Solutions Ltd', N'BLUE', NULL, NULL, NULL, N'594')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'141', N'6316688612617306374', NULL, N'Rebecca@dsemotion.com', NULL, NULL, N'0', N'2025-08-23 06:12:10.960', N'DS.Emotion (Manchester) Ltd', N'BLUE', NULL, NULL, NULL, NULL)
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'142', N'6316683902614054066', NULL, N'Rebecca@dsemotion.com', NULL, NULL, N'0', N'2025-08-23 06:12:11.060', N'DS.Emotion (Manchester) Ltd', N'BLUE', NULL, NULL, NULL, NULL)
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'143', N'6316627696909383320', NULL, N'andy.jackson@covase.co.uk', NULL, NULL, N'0', N'2025-08-23 06:12:11.190', N'Covase Ltd', N'BLUE', NULL, NULL, NULL, NULL)
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'144', N'6316396321581420798', NULL, N'Richard@jnaowei.com', NULL, NULL, N'0', N'2025-08-23 06:12:11.270', N'Jinan  Aowei  Mechanical  Equipment  Co., Ltd', N'BLUE', NULL, NULL, NULL, NULL)
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'145', N'6315987921817709563', NULL, N'orders@indoorsystems.co.uk', NULL, NULL, N'0', N'2025-08-23 06:12:55.003', N'Industrial Door Systems Limited', N'BLUE', NULL, NULL, NULL, NULL)
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'146', N'6315839170914459906', NULL, N'alex.bishop@ggglass.co.uk', NULL, NULL, N'0', N'2025-08-23 06:13:00.290', N'GG GLASS AND GLAZING LTD', N'BLUE', NULL, NULL, NULL, NULL)
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'147', N'6320240360518059452', NULL, N'marija@numai.lt', NULL, NULL, N'0', N'2025-08-26 13:30:42.607', N'NUMAI', N'BLUE', NULL, NULL, NULL, N'604')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'148', N'6321085250124718305', NULL, N'pete@thejslgroup.com', NULL, NULL, N'0', N'2025-08-27 13:01:20.583', N'JSL Property Services Ltd', N'BLUE', NULL, NULL, NULL, N'605')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'149', N'6321877271529005233', NULL, N'zac@neutralcarbonzone.com', NULL, NULL, N'0', N'2025-08-28 11:01:35.543', N'J&P Building Contractors Ltd', N'BLUE', NULL, NULL, NULL, N'607')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'150', N'6320139396014015801', NULL, N'wt@wtflanges.cn', NULL, NULL, N'0', N'2025-08-28 11:57:11.703', N'Shanxi Huashuo Flange Co., Ltd', N'BLUE', NULL, NULL, NULL, N'608')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'151', N'6321061063218757541', NULL, N'swiftelectricalservices@btinternet.com', NULL, NULL, N'0', N'2025-08-28 11:57:32.227', N'Swift electrical services (sw)Ltd', N'BLUE', NULL, NULL, NULL, N'609')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'152', N'6321920692021715580', NULL, N'Simon.darby@edge-equipmenthire.co.uk', NULL, NULL, N'0', N'2025-08-28 12:31:42.947', N'Edge Equipment Hire', N'BLUE', NULL, NULL, NULL, N'610')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'153', N'6322894456639541338', NULL, N'info@tradesupplieshxltd.co.uk', NULL, NULL, N'0', N'2025-08-29 15:31:44.863', N'Trade Supplies HX', N'BLUE', NULL, NULL, NULL, N'613')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'154', N'6325494979124962620', NULL, N'rory@cavalrycare.co.uk', NULL, NULL, N'0', N'2025-09-01 15:32:02.930', N'Cavalry Group', N'BLUE', NULL, NULL, NULL, N'615')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'155', N'6327093921425932238', NULL, N'abbos.azad@siriusnetworks.co.uk', NULL, NULL, N'0', N'2025-09-03 12:00:55.303', N'Sirius Networks Ltd', N'BLUE', NULL, NULL, NULL, N'617')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'156', N'6327939062514496383', NULL, N'peterg@capitalgroup.org.uk', NULL, NULL, N'0', N'2025-09-04 11:30:47.853', N'Capital Staffing Services Limited', N'BLUE', NULL, NULL, NULL, N'618')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'157', N'6328156746619124874', NULL, N'matt@glebe-electrical.co.uk', NULL, NULL, N'0', N'2025-09-04 17:30:59.420', N'Glebe Electrical Installations Ltd', N'BLUE', NULL, NULL, NULL, N'620')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'158', N'6328525141812238429', NULL, N'allan@albltd.co.uk', NULL, NULL, N'0', N'2025-09-05 08:00:52.283', N'Alb Building Services', N'BLUE', NULL, NULL, NULL, N'621')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'159', N'6332395232125058672', NULL, N'gpeters@robiquity.com', NULL, NULL, N'0', N'2025-09-09 15:30:26.467', N'Robiquity Limited', N'BLUE', NULL, NULL, NULL, N'623')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'160', N'6332996080615171447', NULL, N'laura.taylor@hillcrossfurniture.co.uk', NULL, NULL, N'0', N'2025-09-10 08:00:31.387', N'Hill Cross Furniture', N'BLUE', NULL, NULL, NULL, N'625')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'161', N'6338338460124319919', NULL, N'jason@midessexenv.com', NULL, NULL, N'0', N'2025-09-16 12:34:29.083', N'Mid Essex Environmental Ltd', N'BLUE', NULL, NULL, NULL, N'628')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'162', N'6341027866225782570', NULL, N'paule@silverline-oe.com', NULL, NULL, N'0', N'2025-09-19 15:05:37.633', N'Silverline Office Equipment Ltd', N'BLUE', NULL, NULL, NULL, N'629')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'163', N'6345363741517282223', NULL, N'mark.shepherd@t2.co.uk', NULL, NULL, N'0', N'2025-09-24 15:31:02.340', N'T2 TECHNOLOGY LTD', N'BLUE', NULL, NULL, NULL, N'632')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'164', N'6346176254425528597', NULL, N'jashworth@identity-furniture.com', NULL, NULL, N'0', N'2025-09-25 14:00:51.957', N'Identity Furniture Ltd', N'BLUE', NULL, NULL, NULL, N'633')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'165', N'6346209244517121039', NULL, N'Andy@theupsteam.co.uk', NULL, NULL, N'0', N'2025-09-25 15:00:52.380', N'The UPS Team Ltd', N'BLUE', NULL, NULL, NULL, N'634')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'166', N'6346927064812120347', NULL, N'oliver@odmgroup.co.uk', NULL, NULL, N'0', N'2025-09-26 11:00:47.553', N'ODM GROUP', N'BLUE', NULL, NULL, NULL, N'635')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'167', N'6348557930633035968', NULL, N'marcel.horst@ottomater.com', NULL, NULL, N'0', N'2025-09-29 08:00:55.673', N'Ortomater Ltd ', N'BLUE', NULL, NULL, NULL, N'636')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'168', N'6349625089129336386', NULL, N'adam@twfp.co.uk', NULL, NULL, N'0', N'2025-09-29 14:00:53.627', N'Terry Wayters French Polishing', N'BLUE', NULL, NULL, NULL, N'637')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'169', N'6352065471912715059', NULL, N'joshua.lawrence@westofengland-ca.gov.uk', NULL, NULL, N'0', N'2025-10-02 09:31:01.417', N'West of England Combined Authority', N'BLUE', NULL, NULL, NULL, N'638')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'170', N'6352938294914966823', NULL, N'rse@asq.lu', NULL, NULL, N'0', N'2025-10-03 10:01:16.533', N'ASQ', N'BLUE', NULL, NULL, NULL, N'639')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'171', N'6356593316417374594', NULL, N'rory.kendrick@stoneshippers.com', NULL, NULL, N'0', N'2025-10-07 15:30:27.017', N'Stone Shippers India (brand name Stonestry)', N'BLUE', NULL, NULL, NULL, N'640')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'172', N'6357067751116852643', NULL, N'adriaensenss@who.int', NULL, NULL, N'0', N'2025-10-08 08:00:22.370', N'Ministry of Health and Medical Services', N'BLUE', NULL, NULL, NULL, N'641')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'173', N'6358038202028397076', NULL, N'ben@bhpdigital.co.uk', NULL, NULL, N'0', N'2025-10-09 08:01:13.413', N'BHP Digital', N'BLUE', NULL, NULL, NULL, N'642')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'174', N'6358287880529298441', NULL, N'john.barnes@debmat.co.uk', NULL, NULL, N'0', N'2025-10-09 14:31:44.460', N'Debmat Surfacing', N'BLUE', NULL, NULL, NULL, N'643')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'175', N'6359093654611621118', NULL, N'holly.marles@curio.group', NULL, NULL, N'0', N'2025-10-10 13:01:12.203', N'Curio Group', N'BLUE', NULL, NULL, NULL, N'644')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'176', N'6361769964117075861', NULL, N'shaun@tj-ref.co.uk', NULL, NULL, N'0', N'2025-10-13 15:31:35.880', N'TJ Refrigeration Ltd', N'BLUE', NULL, NULL, NULL, N'645')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'177', N'6362393870325105686', NULL, N'daniel.stenmarker@swedese.se', NULL, NULL, N'0', N'2025-10-14 08:31:42.620', N'Swedese Möbler AB', N'BLUE', NULL, NULL, NULL, N'646')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'178', N'6362434183928591701', NULL, N'robbie.carter@ornfurniture.com', NULL, NULL, N'0', N'2025-10-14 10:01:50.230', N'Orn Furniture', N'BLUE', NULL, NULL, NULL, N'647')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'179', N'6362456684118402457', NULL, N'shaun@tj-ref.co.uk', NULL, NULL, N'0', N'2025-10-14 10:31:43.383', N'TJ Refrigeration Ltd', N'BLUE', NULL, NULL, NULL, N'648')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'180', N'6363273030524648662', NULL, N'carole@neuviemesens.com', NULL, NULL, N'0', N'2025-10-15 09:01:40.937', N'Neuvieme Sens ', N'BLUE', NULL, NULL, NULL, N'651')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'181', N'6364132054553201577', NULL, N'awarriner@measurement-solutions.co.uk', NULL, NULL, N'0', N'2025-10-16 09:00:58.400', N'Measurement Solutions Ltd', N'BLUE', NULL, NULL, NULL, N'656')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'182', N'6364223902411248544', NULL, N'admin@pinnacle-elevators.com', NULL, NULL, N'0', N'2025-10-16 11:30:49.180', N'Pinnacle Elevators', N'BLUE', NULL, NULL, NULL, N'657')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'183', N'6364252957219257901', NULL, N'sales@gojumbo.co.uk', NULL, NULL, N'0', N'2025-10-16 12:30:48.797', N'Go Jumbo (Office Refreshments) Ltd', N'BLUE', NULL, NULL, NULL, N'658')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'184', N'6365180412847500169', NULL, N'gareth.smith@purifiedair.com', NULL, NULL, N'0', N'2025-10-17 14:00:45.463', N'Purified Air', N'BLUE', NULL, NULL, NULL, N'668')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'185', N'6375519145528942804', NULL, N'shelleywilcken@maidstone.gov.uk', NULL, NULL, N'0', N'2025-10-29 13:02:18.620', N'Maidstone Borough Council', N'BLUE', NULL, NULL, NULL, N'691')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'186', N'6376353773993102388', NULL, N'peter.cross@aspire-is.com', NULL, NULL, N'0', N'2025-10-30 12:32:19.143', N'Aspire Integrated Services Ltd ', N'BLUE', NULL, NULL, NULL, N'697')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'187', N'6376416721424903029', NULL, N'info@xlprecision.net', NULL, NULL, N'0', N'2025-10-30 14:02:26.360', N'XL PRECISION ENGINEERING LTD', N'BLUE', NULL, NULL, NULL, N'698')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'188', N'6376468178418382986', NULL, N'ben@bhpdigital.co.uk', NULL, NULL, N'0', N'2025-10-30 15:32:27.153', N'BHP Digital', N'BLUE', NULL, NULL, NULL, N'701')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'189', N'6379773442195884130', NULL, N'dave.wright@oakenhurst.com', NULL, NULL, N'0', N'2025-11-03 11:32:14.723', N'Oakenhurst Aircraft Services', N'BLUE', NULL, NULL, NULL, N'702')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'190', N'6380605185418638547', NULL, N'troy@biomelimited.com', NULL, NULL, N'0', N'2025-11-04 10:32:09.243', N'Biome Limited', N'BLUE', NULL, NULL, NULL, N'707')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'191', N'6380617426306845675', NULL, N'sales@tranex.co.uk', NULL, NULL, N'0', N'2025-11-04 11:01:28.647', N'Tranex Telecommunications Ltd', N'BLUE', NULL, NULL, NULL, N'708')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'192', N'6382297144398467610', NULL, N'management@rspcamedway.co.uk', NULL, NULL, N'0', N'2025-11-06 09:30:34.783', N'RSPCA Medway West', N'BLUE', NULL, NULL, NULL, N'709')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'193', N'6383189197818464734', NULL, N'lauren@one2c.com', NULL, NULL, N'0', N'2025-11-07 10:30:27.137', N'One2c Limited', N'BLUE', NULL, NULL, NULL, N'710')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'194', N'6386243718229327477', NULL, N'hassan.javed@maxipower.net', NULL, NULL, N'0', N'2025-11-11 08:00:20.317', N'MAXIPOWER SECURITY AND FACILITIES MANAGEMENT GROUP LIMITED', N'BLUE', NULL, NULL, NULL, N'713')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'195', N'6386707053895498590', NULL, N'lauren@secondnature.io', NULL, NULL, N'0', N'2025-11-11 12:00:20.003', N'Second Nature', N'BLUE', NULL, NULL, NULL, N'714')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'196', N'6390234532217363960', NULL, N'pat@pmlgroup.ie', NULL, NULL, N'0', N'2025-11-17 08:00:22.560', N'Peggy''s Dogfood', N'BLUE', NULL, NULL, NULL, N'718')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'197', N'6391783570457272477', NULL, N'marcus.hardy@cathodic.co.uk', NULL, NULL, N'0', N'2025-11-17 09:00:21.557', N'Cathodic Protection Co Ltd', N'BLUE', NULL, NULL, NULL, N'719')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'198', N'6392910592814150977', NULL, N'mike@ukaircomms.co.uk', NULL, NULL, N'0', N'2025-11-18 16:30:18.587', N'UK Air Comms Ltd', N'BLUE', NULL, NULL, NULL, N'723')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'199', N'6393812606718355977', NULL, N'Andy@theupsteam.co.uk', NULL, NULL, N'0', N'2025-11-19 17:30:15.070', N'The UPS Team Ltd', N'BLUE', NULL, NULL, NULL, N'725')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'200', N'6394563558129640866', NULL, N'design@annamackee.com', NULL, NULL, N'0', N'2025-11-20 14:00:37.287', N'Anna Mackee', N'BLUE', NULL, NULL, NULL, N'726')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'201', N'6394603861146363574', NULL, N'info@boa-training.com', NULL, NULL, N'0', N'2025-11-20 15:30:36.013', N'BOA Training Ltd', N'BLUE', NULL, NULL, NULL, N'727')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'202', N'6397931237512570159', NULL, N'jamie.lees@jl-cc.co.uk', NULL, NULL, N'0', N'2025-11-24 12:03:48.373', N'JL Contracting and Consultancy Ltd', N'BLUE', NULL, NULL, NULL, N'728')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'203', N'6397931904911174384', NULL, N'Kevin.McLean@bold.co.uk', NULL, NULL, N'0', N'2025-11-24 12:04:01.110', N'Bold Security Group (UK) LTD', N'BLUE', NULL, NULL, NULL, N'729')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'204', N'6398038281286279377', NULL, N'gillian.sinclair@glencontracts.co.uk', NULL, NULL, N'0', N'2025-11-24 15:03:48.973', N'Glen Contract Services Ltd', N'BLUE', NULL, NULL, NULL, N'731')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'205', N'6398771416207774183', NULL, N'julia@brittain.co.uk', NULL, NULL, N'0', N'2025-11-25 11:03:47.123', N'Brittain Marketing Services Limited', N'BLUE', NULL, NULL, NULL, N'733')
GO

INSERT INTO [PowerBI].[PowerBIExportLog] ([Id], [submissionId], [exportId], [emailTo], [resourceLocation], [reportPDFFileName], [status], [statusUpdatedOn], [companyName], [productName], [hasError], [errorDetails], [documentId], [customerId]) VALUES (N'206', N'6398775584733904047', NULL, N'sophie@best-inclass.co.uk', NULL, NULL, N'0', N'2025-11-25 11:03:58.917', N'Best in Class Ltd', N'BLUE', NULL, NULL, NULL, N'734')
GO

SET IDENTITY_INSERT [PowerBI].[PowerBIExportLog] OFF
GO


-- ----------------------------
-- View structure for vCertificationTasks
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[vCertificationTasks]') AND type IN ('V'))
	DROP VIEW [PowerBI].[vCertificationTasks]
GO

CREATE VIEW [PowerBI].[vCertificationTasks] AS SELECT t.id
			,t.name
			,ef.id as [emissionProfileId]
			,ef.name as [emissionProfile]
FROM [clickup].[Task] t
JOIN [Emissions].[EmissionProfile] ef on ef.active = 1 and ef.id = 9
WHERE t.listId in ('901200207978','901205502657','901205524266','901206607383','901206788692','901206788699','901206788725','901206501310')
	AND t.parentId IS NULL 
	AND (t.activeTo > [Utilities].[DateToEpoch](GetDate()) OR t.activeTo is NULL);
GO


-- ----------------------------
-- View structure for vCompany
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[vCompany]') AND type IN ('V'))
	DROP VIEW [PowerBI].[vCompany]
GO

CREATE VIEW [PowerBI].[vCompany] AS SELECT 
			submissionId, 
			BAQ_CompanyName,
			IIf (BAQ_CompanyLogo is null, 
            'https://nczdocsprod.blob.core.windows.net/customer-logo/blank_powerbi.png', 
            Concat(BAQ_CompanyLogo, '?apiKey=964f4219f34a79448399110d86da47f4')
          ) as BAQ_CompanyLogo
FROM (
    SELECT submissionid, [key], [value]
    FROM Forms.BlueAwardQuestionnaire
) AS SourceTable
PIVOT (
    MAX([value])
    FOR [key] IN (
			BAQ_CompanyName,
			BAQ_CompanyLogo
	)
) AS PivotTable;
GO


-- ----------------------------
-- View structure for vSilverCertifications_Portal
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[vSilverCertifications_Portal]') AND type IN ('V'))
	DROP VIEW [PowerBI].[vSilverCertifications_Portal]
GO

CREATE VIEW [PowerBI].[vSilverCertifications_Portal] AS Select DISTINCT C.companyName, P.progName, Cert.certId as certificationId, CFS.submissionId,
      CONCAT(
            ProgName, ' (',  ISNULL(Cert.refNumber, CAST(Cert.certYear AS VARCHAR)),  ')'
          ) AS CertificationInfo,
      ef.id as emissionProfileId, ef.name as emissionProfile,
      IIf (C.logo is null, 
            'https://nczdocsprod.blob.core.windows.net/customer-logo/blank_powerbi.png', 
            IIF(C.logo like '%app.neutralcarbonzone.com%',
                Concat(C.logo, '?apiKey=964f4219f34a79448399110d86da47f4'),
                C.logo
               )
          ) as logo
From portal.Certification as Cert 
INNER JOIN portal.Programme as P on (P.progId = Cert.progId and Cert.isDeleted=0 and (Cert.status BETWEEN 2 and 4))
INNER JOIN portal.Company as C on (C.companyId = Cert.companyId and C.status=1 and C.isDeleted=0)
INNER JOIN portal.CertFormSubmissions as CFS on (Cert.certId = CFS.certId and CFS.jotformId='241290444812856' and Cert.progId=2 and CFS.isProcessed=1)
INNER JOIN [Emissions].[EmissionProfile] ef on (ef.active = 1 and ef.id = 9)
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Add
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Add]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [PowerBI].[spPowerBIExportQueue_Add]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Add]
	 @submissionId nvarchar (25)
	,@emailTo nvarchar (255)
	,@companyName nvarchar(60)
	,@productName nvarchar(30)
AS
BEGIN
	SET NOCOUNT ON;

  IF Not Exists (SELECT * FROM PowerBI.PowerBIExportLog where submissionId=@submissionId)
  BEGIN
    Declare @customerId int = (Select  top 1 id from Dimension.Customer where name = @companyName ORDER BY active desc);
    Set @productName = (Select Case @productName When 'Blue Award' then 'BLUE' When 'Silver Certification' then 'SILVER' When 'Gold Certification' then 'GOLD' end);
    
    INSERT into PowerBI.PowerBIExportLog (customerId, submissionId, emailTo, companyName, productName, statusUpdatedOn) 
    VALUES (@customerId, @submissionId, @emailTo, @companyName, @productName, GETDATE());
  END

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Completed
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Completed]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [PowerBI].[spPowerBIExportQueue_Completed]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Completed]
	 @submissionId nvarchar (25)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog set status = 1, statusUpdatedOn = GETDATE(), hasError = 0
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Downloaded
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Downloaded]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [PowerBI].[spPowerBIExportQueue_Downloaded]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Downloaded]
	 @submissionId nvarchar (25)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog set status = 4, statusUpdatedOn = GETDATE(), hasError = 0
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Error
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Error]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [PowerBI].[spPowerBIExportQueue_Error]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Error]
	 @submissionId nvarchar (25),
   @errorDetails nvarchar(500)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog set hasError = 1, errorDetails = @errorDetails
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Generated
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Generated]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [PowerBI].[spPowerBIExportQueue_Generated]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Generated]
	 @submissionId nvarchar (25)
	,@resourceLocation nvarchar (300)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog 
    set resourceLocation = @resourceLocation, 
        reportPDFFileName = concat('BAQ_',FORMAT(GETDATE(), 'dd.MM.yyyy', 'en-UK'),'_',submissionId,'.pdf'),
        -- reportPDFFileName = concat(SUBSTRING(REPLACE(companyName, ' ','_'),0,20), '-', submissionId, '.pdf'),
        status = 3, statusUpdatedOn = GETDATE(), hasError = 0
  WHERE submissionId = @submissionId;
  
  Select * from PowerBI.PowerBIExportLog WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_GetList
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_GetList]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [PowerBI].[spPowerBIExportQueue_GetList]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_GetList]
AS
BEGIN
	SET NOCOUNT ON;
  
      -- Reset Generated(3) reports to Pending(0), if not downloaded(3) within 24 hours
      Update PowerBI.PowerBIExportLog 
        Set status = 0
      Where status = 3 And CAST(statusUpdatedOn as DATE) <= CAST(DATEADD(day, -1, GETDATE()) as DATE);
  
      -- Get List of incomplete export jobs, (Pending(0) requests should have 24 hours passed)
      Select * from PowerBI.PowerBIExportLog 
      Where 
         ((status = 0 and CAST(statusUpdatedOn as DATE) <= CAST(DATEADD(day, -1, GETDATE()) as DATE)) OR (status > 1))
      ORDER BY status, statusUpdatedOn;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Requested
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Requested]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [PowerBI].[spPowerBIExportQueue_Requested]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Requested]
	 @submissionId nvarchar (25)
	,@exportId nvarchar (200)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog set exportId = @exportId, status = 2, statusUpdatedOn = GETDATE(), hasError = 0
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Uploaded
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Uploaded]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [PowerBI].[spPowerBIExportQueue_Uploaded]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Uploaded]
	 @submissionId nvarchar (25),
   @documentId nvarchar(25)
AS
BEGIN
	SET NOCOUNT ON;
	-- File uploaded on storage space
  UPDATE PowerBI.PowerBIExportLog set status = 5, statusUpdatedOn = GETDATE(), hasError = 0,
        documentId = @documentId
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- Auto increment value for PowerBIExportLog
-- ----------------------------
DBCC CHECKIDENT ('[PowerBI].[PowerBIExportLog]', RESEED, 206)
GO


-- ----------------------------
-- Primary Key structure for table PowerBIExportLog
-- ----------------------------
ALTER TABLE [PowerBI].[PowerBIExportLog] ADD CONSTRAINT [PK__PowerBIE__3214EC0771B2CC9B] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

