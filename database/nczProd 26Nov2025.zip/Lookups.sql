/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [PROD]
 Source Server Type    : SQL Server
 Source Server Version : 12001017 (12.00.1017)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczprod
 Source Schema         : Lookups

 Target Server Type    : SQL Server
 Target Server Version : 12001017 (12.00.1017)
 File Encoding         : 65001

 Date: 26/11/2025 11:52:51
*/


-- ----------------------------
-- Table structure for Countries
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[Countries]') AND type IN ('U'))
	DROP TABLE [Lookups].[Countries]
GO

CREATE TABLE [Lookups].[Countries] (
  [countryId] int  IDENTITY(1,1) NOT NULL,
  [countryName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [currency] nvarchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Lookups].[Countries] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Countries
-- ----------------------------
SET IDENTITY_INSERT [Lookups].[Countries] ON
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'32', N'United Kingdom', N'GBP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'33', N'United States', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'34', N'United Arab Emirates', N'AED')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'35', N'India', N'INR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'36', N'Canada', N'CAD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'37', N'Australia', N'AUD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'38', N'Germany', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'39', N'France', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'40', N'China', N'CNY')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'41', N'Japan', N'JPY')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'42', N'Brazil', N'BRL')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'43', N'Mexico', N'MXN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'44', N'South Korea', N'KRW')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'45', N'Italy', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'46', N'Spain', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'47', N'Netherlands', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'48', N'Russia', N'RUB')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'49', N'Singapore', N'SGD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'50', N'South Africa', N'ZAR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'51', N'Switzerland', N'CHF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'52', N'Afghanistan', N'AFN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'53', N'Albania', N'ALL')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'54', N'Algeria', N'DZD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'55', N'American Samoa', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'56', N'Andorra', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'57', N'Angola', N'AOA')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'58', N'Anguilla', N'XCD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'59', N'Antigua and Barbuda', N'XCD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'60', N'Argentina', N'ARS')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'61', N'Armenia', N'AMD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'62', N'Aruba', N'AWG')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'63', N'Austria', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'64', N'Azerbaijan', N'AZN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'65', N'The Bahamas', N'BSD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'66', N'Bahrain', N'BHD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'67', N'Bangladesh', N'BDT')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'68', N'Barbados', N'BBD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'69', N'Belarus', N'BYN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'70', N'Belgium', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'71', N'Belize', N'BZD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'72', N'Benin', N'XOF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'73', N'Bermuda', N'BMD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'74', N'Bhutan', N'BTN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'75', N'Bolivia', N'BOB')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'76', N'Bosnia and Herzegovina', N'BAM')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'77', N'Botswana', N'BWP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'78', N'Brunei', N'BND')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'79', N'Bulgaria', N'BGN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'80', N'Burkina Faso', N'XOF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'81', N'Burundi', N'BIF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'82', N'Cambodia', N'KHR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'83', N'Cameroon', N'XAF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'84', N'Cape Verde', N'CVE')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'85', N'Cayman Islands', N'KYD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'86', N'Central African Republic', N'XAF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'87', N'Chad', N'XAF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'88', N'Chile', N'CLP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'89', N'Christmas Island', N'AUD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'90', N'Cocos (Keeling) Islands', N'AUD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'91', N'Colombia', N'COP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'92', N'Comoros', N'KMF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'93', N'Congo', N'XAF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'94', N'Cook Islands', N'NZD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'95', N'Costa Rica', N'CRC')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'96', N'Cote d''Ivoire', N'XOF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'97', N'Croatia', N'HRK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'98', N'Cuba', N'CUP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'99', N'Curaçao', N'ANG')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'100', N'Cyprus', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'101', N'Czech Republic', N'CZK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'102', N'Democratic Republic of the Congo', N'CDF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'103', N'Denmark', N'DKK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'104', N'Djibouti', N'DJF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'105', N'Dominica', N'XCD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'106', N'Dominican Republic', N'DOP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'107', N'Ecuador', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'108', N'Egypt', N'EGP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'109', N'El Salvador', N'SVC')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'110', N'Equatorial Guinea', N'XAF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'111', N'Eritrea', N'ERN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'112', N'Estonia', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'113', N'Ethiopia', N'ETB')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'114', N'Falkland Islands', N'FKP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'115', N'Faroe Islands', N'DKK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'116', N'Fiji', N'FJD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'117', N'Finland', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'118', N'French Polynesia', N'XPF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'119', N'Gabon', N'XAF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'120', N'The Gambia', N'GMD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'121', N'Georgia', N'GEL')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'122', N'Ghana', N'GHS')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'123', N'Gibraltar', N'GIP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'124', N'Greece', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'125', N'Greenland', N'DKK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'126', N'Grenada', N'XCD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'127', N'Guadeloupe', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'128', N'Guam', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'129', N'Guatemala', N'GTQ')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'130', N'Guernsey', N'GBP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'131', N'Guinea', N'GNF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'132', N'Guinea-Bissau', N'XOF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'133', N'Guyana', N'GYD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'134', N'Haiti', N'HTG')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'135', N'Honduras', N'HNL')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'136', N'Hong Kong', N'HKD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'137', N'Hungary', N'HUF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'138', N'Iceland', N'ISK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'139', N'Indonesia', N'IDR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'140', N'Iran', N'IRR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'141', N'Iraq', N'IQD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'142', N'Ireland', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'143', N'Israel', N'ILS')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'144', N'Jamaica', N'JMD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'145', N'Jersey', N'GBP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'146', N'Jordan', N'JOD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'147', N'Kazakhstan', N'KZT')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'148', N'Kenya', N'KES')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'149', N'Kiribati', N'AUD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'150', N'North Korea', N'KPW')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'151', N'Kosovo', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'152', N'Kuwait', N'KWD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'153', N'Kyrgyzstan', N'KGS')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'154', N'Laos', N'LAK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'155', N'Latvia', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'156', N'Lebanon', N'LBP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'157', N'Lesotho', N'LSL')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'158', N'Liberia', N'LRD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'159', N'Libya', N'LYD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'160', N'Liechtenstein', N'CHF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'161', N'Lithuania', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'162', N'Luxembourg', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'163', N'Macau', N'MOP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'164', N'Macedonia', N'MKD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'165', N'Madagascar', N'MGA')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'166', N'Malawi', N'MWK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'167', N'Malaysia', N'MYR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'168', N'Maldives', N'MVR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'169', N'Mali', N'XOF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'170', N'Malta', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'171', N'Marshall Islands', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'172', N'Martinique', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'173', N'Mauritania', N'MRO')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'174', N'Mauritius', N'MUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'175', N'Mayotte', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'176', N'Micronesia', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'177', N'Moldova', N'MDL')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'178', N'Monaco', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'179', N'Mongolia', N'MNT')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'180', N'Montenegro', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'181', N'Montserrat', N'XCD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'182', N'Morocco', N'MAD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'183', N'Mozambique', N'MZN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'184', N'Myanmar', N'MMK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'185', N'Nagorno-Karabakh', NULL)
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'186', N'Namibia', N'NAD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'187', N'Nauru', N'AUD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'188', N'Nepal', N'NPR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'189', N'Netherlands Antilles', N'ANG')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'190', N'New Caledonia', N'XPF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'191', N'New Zealand', N'NZD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'192', N'Nicaragua', N'NIO')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'193', N'Niger', N'NGN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'194', N'Nigeria', N'NGN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'195', N'Niue', N'NZD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'196', N'Norfolk Island', N'AUD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'250', N'Timor-Leste', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'251', N'Togo', N'XOF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'252', N'Tokelau', N'NZD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'253', N'Tonga', N'TOP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'254', N'Transnistria Pridnestrovie', NULL)
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'255', N'Trinidad and Tobago', N'TTD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'256', N'Tristan da Cunha', N'SHP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'257', N'Tunisia', N'TND')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'258', N'Turkey', N'TRY')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'259', N'Turkmenistan', N'TMT')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'260', N'Turks and Caicos Islands', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'261', N'Tuvalu', N'AUD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'262', N'Uganda', N'UGX')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'263', N'Ukraine', N'UAH')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'264', N'Uruguay', N'UYU')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'265', N'Uzbekistan', N'UZS')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'266', N'Vanuatu', N'VUV')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'267', N'Vatican City', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'268', N'Venezuela', N'VEF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'269', N'Vietnam', N'VND')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'270', N'British Virgin Islands', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'271', N'Isle of Man', N'GBP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'272', N'US Virgin Islands', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'273', N'Wallis and Futuna', N'XPF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'274', N'Western Sahara', N'MAD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'275', N'Yemen', N'YER')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'276', N'Zambia', N'ZMW')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'277', N'Zimbabwe', N'ZWL')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'197', N'Turkish Republic of Northern Cyprus', N'TRY')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'198', N'Northern Mariana', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'199', N'Norway', N'NOK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'200', N'Oman', N'OMR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'201', N'Pakistan', N'PKR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'202', N'Palau', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'203', N'Palestine', NULL)
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'204', N'Panama', N'PAB')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'205', N'Papua New Guinea', N'PGK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'206', N'Paraguay', N'PYG')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'207', N'Peru', N'PEN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'208', N'Philippines', N'PHP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'209', N'Pitcairn Islands', N'NZD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'210', N'Poland', N'PLN')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'211', N'Portugal', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'212', N'Puerto Rico', N'USD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'213', N'Qatar', N'QAR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'214', N'Republic of the Congo', N'XAF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'215', N'Romania', N'RON')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'216', N'Rwanda', N'RWF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'217', N'Saint Barthelemy', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'218', N'Saint Helena', N'SHP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'219', N'Saint Kitts and Nevis', N'XCD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'220', N'Saint Lucia', N'XCD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'221', N'Saint Martin', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'222', N'Saint Pierre and Miquelon', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'223', N'Saint Vincent and the Grenadines', N'XCD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'224', N'Samoa', N'WST')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'225', N'San Marino', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'226', N'Sao Tome and Principe', N'STD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'227', N'Saudi Arabia', N'SAR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'228', N'Senegal', N'XOF')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'229', N'Serbia', N'RSD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'230', N'Seychelles', N'SCR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'231', N'Sierra Leone', N'SLE')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'232', N'Slovakia', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'233', N'Slovenia', N'EUR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'234', N'Solomon Islands', N'SBD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'235', N'Somalia', N'SOS')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'236', N'Somaliland', NULL)
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'237', N'South Ossetia', NULL)
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'238', N'South Sudan', N'SSP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'239', N'Sri Lanka', N'LKR')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'240', N'Sudan', N'SDG')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'241', N'Suriname', N'SRD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'242', N'Svalbard', N'NOK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'243', N'eSwatini', N'SZL')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'244', N'Sweden', N'SEK')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'245', N'Syria', N'SYP')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'246', N'Taiwan', N'TWD')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'247', N'Tajikistan', N'TJS')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'248', N'Tanzania', N'TZS')
GO

INSERT INTO [Lookups].[Countries] ([countryId], [countryName], [currency]) VALUES (N'249', N'Thailand', N'THB')
GO

SET IDENTITY_INSERT [Lookups].[Countries] OFF
GO


-- ----------------------------
-- Table structure for DataSource
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[DataSource]') AND type IN ('U'))
	DROP TABLE [Lookups].[DataSource]
GO

CREATE TABLE [Lookups].[DataSource] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Lookups].[DataSource] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of DataSource
-- ----------------------------
INSERT INTO [Lookups].[DataSource] ([id], [name]) VALUES (N'1', N'JotForm')
GO

INSERT INTO [Lookups].[DataSource] ([id], [name]) VALUES (N'2', N'NczForm')
GO


-- ----------------------------
-- Table structure for EntityType
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[EntityType]') AND type IN ('U'))
	DROP TABLE [Lookups].[EntityType]
GO

CREATE TABLE [Lookups].[EntityType] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [Lookups].[EntityType] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of EntityType
-- ----------------------------
INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'1', N'CustomerProfile')
GO

INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'2', N'Event')
GO

INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'3', N'Meeting')
GO

INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'4', N'Customer')
GO

INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'5', N'Portal Customer')
GO


-- ----------------------------
-- Table structure for FormCategory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[FormCategory]') AND type IN ('U'))
	DROP TABLE [Lookups].[FormCategory]
GO

CREATE TABLE [Lookups].[FormCategory] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [Lookups].[FormCategory] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of FormCategory
-- ----------------------------
INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'1', N'Certification')
GO

INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'2', N'Event')
GO

INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'3', N'Meeting')
GO

INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'4', N'Blue Award Questionnaire')
GO

INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'5', N'Gold Award Questionnaire')
GO


-- ----------------------------
-- Table structure for PowerBIExportStatus
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[PowerBIExportStatus]') AND type IN ('U'))
	DROP TABLE [Lookups].[PowerBIExportStatus]
GO

CREATE TABLE [Lookups].[PowerBIExportStatus] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Lookups].[PowerBIExportStatus] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of PowerBIExportStatus
-- ----------------------------

-- ----------------------------
-- Table structure for QuestionInputType
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[QuestionInputType]') AND type IN ('U'))
	DROP TABLE [Lookups].[QuestionInputType]
GO

CREATE TABLE [Lookups].[QuestionInputType] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Lookups].[QuestionInputType] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of QuestionInputType
-- ----------------------------
INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'1', N'TextBox')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'2', N'TextArea')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'3', N'Date')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'4', N'Time')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'5', N'Select')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'6', N'Number')
GO


-- ----------------------------
-- Table structure for QuestionType
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[QuestionType]') AND type IN ('U'))
	DROP TABLE [Lookups].[QuestionType]
GO

CREATE TABLE [Lookups].[QuestionType] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Lookups].[QuestionType] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of QuestionType
-- ----------------------------
INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'1', N'EntityReference')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'2', N'ReportingFrequency')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'3', N'OptInPreference')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'4', N'UserInputByMonth')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'5', N'UserInputAnnualByMonth')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'6', N'UserInputAnnual')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'7', N'Month')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'8', N'ManagementBasedDecision')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'9', N'DataUnit')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'10', N'ConversionFactor')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'11', N'UserInputAnnualFromJanToJun')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'12', N'UnserInputAnnualFromJulToDec')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'13', N'UserInputTextBox')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'14', N'DeliveriesItemiseInput')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'15', N'EmailEntityReference')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'16', N'OtherItemiseInput')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'17', N'HotelStayItemiseInput')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'18', N'DomesticFlightItemiseInput')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'19', N'Short-HaulFlightItemiseInput')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'20', N'Long-HaulFlightItemiseInput')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'21', N'ChargingPercentAtWorkPlace')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'22', N'ElectricityTariffItemiseInput')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'23', N'ElectricityGreenTariffYesNo_Portal')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'24', N'ElectricityGreenTariffPercentage_Portal')
GO


-- ----------------------------
-- Table structure for ReportingFrequency
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[ReportingFrequency]') AND type IN ('U'))
	DROP TABLE [Lookups].[ReportingFrequency]
GO

CREATE TABLE [Lookups].[ReportingFrequency] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [Lookups].[ReportingFrequency] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ReportingFrequency
-- ----------------------------
INSERT INTO [Lookups].[ReportingFrequency] ([id], [name]) VALUES (N'1', N'weekly')
GO

INSERT INTO [Lookups].[ReportingFrequency] ([id], [name]) VALUES (N'2', N'monthly')
GO

INSERT INTO [Lookups].[ReportingFrequency] ([id], [name]) VALUES (N'3', N'annualised_monthly')
GO

INSERT INTO [Lookups].[ReportingFrequency] ([id], [name]) VALUES (N'4', N'annualised')
GO


-- ----------------------------
-- Auto increment value for Countries
-- ----------------------------
DBCC CHECKIDENT ('[Lookups].[Countries]', RESEED, 277)
GO


-- ----------------------------
-- Primary Key structure for table DataSource
-- ----------------------------
ALTER TABLE [Lookups].[DataSource] ADD CONSTRAINT [PK__DataSour__3213E83F71CB05E6] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table EntityType
-- ----------------------------
ALTER TABLE [Lookups].[EntityType] ADD CONSTRAINT [PK__DataSour__3213E83FEF413F5F] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table FormCategory
-- ----------------------------
ALTER TABLE [Lookups].[FormCategory] ADD CONSTRAINT [PK__EntityTy__3213E83F6ED58800] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table PowerBIExportStatus
-- ----------------------------
ALTER TABLE [Lookups].[PowerBIExportStatus] ADD CONSTRAINT [PK__PowerBIE__3213E83F5F0817CC] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table QuestionInputType
-- ----------------------------
ALTER TABLE [Lookups].[QuestionInputType] ADD CONSTRAINT [PK__Question__3213E83F2F517493] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table QuestionType
-- ----------------------------
ALTER TABLE [Lookups].[QuestionType] ADD CONSTRAINT [PK__DataSour__3213E83F3A6C84F0] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table ReportingFrequency
-- ----------------------------
ALTER TABLE [Lookups].[ReportingFrequency] ADD CONSTRAINT [PK__Reportin__3213E83F94E0C394] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

