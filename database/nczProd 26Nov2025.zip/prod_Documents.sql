/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [PROD]
 Source Server Type    : SQL Server
 Source Server Version : 12001017 (12.00.1017)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczprod
 Source Schema         : Documents

 Target Server Type    : SQL Server
 Target Server Version : 12001017 (12.00.1017)
 File Encoding         : 65001

 Date: 26/11/2025 10:38:22
*/


-- ----------------------------
-- Table structure for Document
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[Document]') AND type IN ('U'))
	DROP TABLE [Documents].[Document]
GO

CREATE TABLE [Documents].[Document] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [parentEntityId] int  NOT NULL,
  [parentEntityType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [customerId] int  NULL,
  [container] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [blobName] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [title] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [singleInstance] bit DEFAULT 0 NULL,
  [canEmbed] bit DEFAULT 0 NULL,
  [modifiedDate] bigint  NULL,
  [mimeType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [activeTo] bigint  NULL,
  [size] int DEFAULT 0 NOT NULL,
  [userAccountId] int  NULL
)
GO

ALTER TABLE [Documents].[Document] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Document
-- ----------------------------
SET IDENTITY_INSERT [Documents].[Document] ON
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'39', N'17', N'certification', N'13', N'certifications', N'certification-17-e670191f-73a3-4ee4-bc18-98165e4b6842', N'1. MUSTANG WASHROOMS GOLD Carbon Footprint Report 2023-24 (1).pdf', N'0', N'0', N'1758630314', N'application/pdf', N'1759218516', N'2782291', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'40', N'17', N'certification', N'13', N'certifications', N'certification-17-4d9c41ee-7a89-4d46-a3f7-0d8db1067923', N'2. Mustang Washrooms 2023-24 Gold Certificate.pdf', N'0', N'0', N'1758630328', N'application/pdf', NULL, N'124895', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'41', N'13', N'certification', N'9', N'certifications', N'certification-13-0527d577-5ff0-4b1d-82ce-02f781eb7743', N'Kingdom Group Gold Carbon Footprint Report.pdf', N'0', N'0', N'1758784215', N'application/pdf', N'1759218033', N'650127', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'42', N'13', N'certification', N'9', N'certifications', N'certification-13-a90681ac-42a4-4111-b8ec-3e3c966f4049', N'Kingdom Gold Certificate 2023.pdf', N'0', N'0', N'1758784230', N'application/pdf', NULL, N'121156', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'43', N'1', N'certification', N'1', N'certifications', N'certification-1-60a7494c-8962-4535-9f7e-a2f436f4b398', N'Nicholls Solicitors SILVER Carbon Footprint Report.pdf', N'0', N'0', N'1758791828', N'application/pdf', N'1758796822', N'1881409', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'44', N'1', N'certification', N'1', N'certifications', N'certification-1-183ae8a7-ca46-48df-ac25-f29e973b0af4', N'Nicholls Solicitors SILVER Certificate.pdf', N'0', N'0', N'1758791843', N'application/pdf', N'1758796816', N'126212', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'45', N'20', N'certification', N'15', N'certifications', N'certification-20-32e526c1-d207-404e-9729-c578c2a391b2', N'AIM Cleaning GOLD Carbon Footprint Report 2023-24.pdf', N'0', N'0', N'1758794950', N'application/pdf', NULL, N'2743342', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'46', N'20', N'certification', N'15', N'certifications', N'certification-20-36003254-c5b5-433f-acb5-35089c54443d', N'AIM Cleaning Gold Certificate year 3.pdf', N'0', N'0', N'1758794961', N'application/pdf', N'1759218748', N'122503', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'47', N'21', N'certification', N'15', N'certifications', N'certification-21-e7ecc744-65bc-4620-a10f-ec3dd54f61af', N'AIM Cleaning Carbon Footprint Report 2022-23.pdf', N'0', N'0', N'1758795328', N'application/pdf', NULL, N'594419', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'48', N'21', N'certification', N'15', N'certifications', N'certification-21-4c47234a-39b5-49b1-928e-f89b27af078b', N'AIM Cleaning Gold Certification 2022-23.pdf', N'0', N'0', N'1758795343', N'application/pdf', NULL, N'121786', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'49', N'22', N'certification', N'16', N'certifications', N'certification-22-f2c5deb8-b4d7-453d-9475-1bee0c68b65a', N'1. Apollo Cleaning GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1758796750', N'application/pdf', N'1759224610', N'2569586', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'50', N'22', N'certification', N'16', N'certifications', N'certification-22-c5b83105-d4e8-4c02-86b1-0ae743854fae', N'2. Apollo Cleaning GOLD Certificate.pdf', N'0', N'0', N'1758796762', N'application/pdf', N'1759224616', N'124638', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'51', N'1', N'certification', N'1', N'certifications', N'certification-1-ca3fc608-11be-42a6-8088-207735ccc7f7', N'Journey Silver Award - social template.png', N'0', N'0', N'1759207411', N'image/png', N'1759211876', N'2440046', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'52', N'1', N'certification', N'1', N'certifications', N'certification-1-79cc72fa-cdb6-4293-96c6-7639add8197b', N'Journey Silver Award Announcement Guide.pdf', N'0', N'0', N'1759207422', N'application/pdf', N'1759211881', N'1358505', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'53', N'1', N'certification', N'1', N'certifications', N'certification-1-521423d2-5e2f-4d47-8c07-4a5c54e7f759', N'Completed Silver Award - Copy.pdf', N'0', N'0', N'1759207559', N'application/pdf', N'1760527699', N'3453606', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'54', N'1', N'certification', N'1', N'certifications', N'certification-1-2f864735-f155-4a23-bd46-ec070fa13102', N'Completed Silver Award - digital badge.png', N'0', N'0', N'1759207568', N'image/png', NULL, N'1587094', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'55', N'1', N'certification', N'1', N'certifications', N'certification-1-d3a84fb3-918c-4a3f-8c86-b6a7ef879c72', N'Completed Silver Award Marketing Guide.pdf', N'0', N'0', N'1759207583', N'application/pdf', NULL, N'3453606', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'56', N'1', N'certification', N'1', N'certifications', N'certification-1-99049280-af27-450f-84e4-e91adc82b549', N'Completed-Brandguideline.pdf', N'0', N'0', N'1759207609', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'57', N'1', N'certification', N'1', N'certifications', N'certification-1-fb5b02c2-1309-4a23-b295-d1cd599b445a', N'Completed-silver-award-ALL-white.png', N'0', N'0', N'1759207619', N'image/png', NULL, N'25973', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'58', N'1', N'certification', N'1', N'certifications', N'certification-1-f854c7fa-c993-460e-9c01-5d3b0884412a', N'Completed-silver-award-black.png', N'0', N'0', N'1759207629', N'image/png', NULL, N'27916', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'59', N'1', N'certification', N'1', N'certifications', N'certification-1-29e52ea6-5411-4855-99aa-41ad6eb20af5', N'Completed-silver-award-white.png', N'0', N'0', N'1759207641', N'image/png', NULL, N'26311', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'60', N'1', N'certification', N'1', N'certifications', N'certification-1-27f063bd-5df6-4d23-879c-d0bac06be22f', N'Nicholls Solicitors 2023-24 SILVER Carbon Footprint Report.pdf', N'0', N'0', N'1759208063', N'application/pdf', NULL, N'1881409', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'61', N'1', N'certification', N'1', N'certifications', N'certification-1-37b9ee41-bef1-4bff-b7a6-2b5cd973f141', N'Nicholls Solicitors 2023-24 SILVER Certificate.pdf', N'0', N'0', N'1759208072', N'application/pdf', NULL, N'126212', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'62', N'4', N'certification', N'4', N'certifications', N'certification-4-2f683905-5d6d-4700-85dc-be5880ca0808', N'Completed Silver Award - Copy.pdf', N'0', N'0', N'1759213944', N'application/pdf', NULL, N'3453606', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'63', N'4', N'certification', N'4', N'certifications', N'certification-4-8bfc3580-b181-46a6-aa4e-7bb96e280643', N'Completed Silver Award - digital badge.png', N'0', N'0', N'1759213961', N'image/png', NULL, N'1587094', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'64', N'4', N'certification', N'4', N'certifications', N'certification-4-72515d1d-c9e8-4089-9f60-efc4d9280846', N'Completed Silver Award Marketing Guide.pdf', N'0', N'0', N'1759213983', N'application/pdf', NULL, N'3453606', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'65', N'4', N'certification', N'4', N'certifications', N'certification-4-b5c930c1-edf5-4f54-b73e-431eb7358597', N'Completed-Brandguideline.pdf', N'0', N'0', N'1759214019', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'66', N'4', N'certification', N'4', N'certifications', N'certification-4-72e213fa-dba6-4ecc-bf6a-ce5d47a8a423', N'Completed-silver-award-ALL-white.png', N'0', N'0', N'1759214032', N'image/png', NULL, N'25973', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'67', N'4', N'certification', N'4', N'certifications', N'certification-4-2b3a1d26-795b-4103-826e-cdf28efbf2c3', N'Completed-silver-award-white.png', N'0', N'0', N'1759216733', N'image/png', NULL, N'26311', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'68', N'4', N'certification', N'4', N'certifications', N'certification-4-14ba6224-acb9-49f6-9b99-809ff87fc9ac', N'Completed-silver-award-black.png', N'0', N'0', N'1759216769', N'image/png', NULL, N'27916', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'69', N'4', N'certification', N'4', N'certifications', N'certification-4-6f886606-a620-4797-b372-d7e52eb34e9a', N'Z J Building Services 2024-25 SILVER Carbon Footprint Report.pdf', N'0', N'0', N'1759216790', N'application/pdf', NULL, N'1826542', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'70', N'4', N'certification', N'4', N'certifications', N'certification-4-73037931-58db-42eb-a916-bfb59f3a3c8a', N'Z J Building Services 2024-25 SILVER Certificate.pdf', N'0', N'0', N'1759216799', N'application/pdf', NULL, N'126742', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'71', N'6', N'certification', N'6', N'certifications', N'certification-6-ed9c738e-0831-497f-acd8-236714ddc1f1', N'Completed Silver Award - Copy.pdf', N'0', N'0', N'1759217722', N'application/pdf', NULL, N'3453606', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'72', N'6', N'certification', N'6', N'certifications', N'certification-6-57a569bd-47f6-4067-a0c0-d82d114b3608', N'Completed Silver Award - digital badge.png', N'0', N'0', N'1759217745', N'image/png', NULL, N'1587094', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'73', N'6', N'certification', N'6', N'certifications', N'certification-6-a9606471-ed66-45e8-aacf-b635e76d8f54', N'Completed Silver Award Marketing Guide.pdf', N'0', N'0', N'1759217754', N'application/pdf', NULL, N'3453606', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'74', N'6', N'certification', N'6', N'certifications', N'certification-6-d06d1da9-e0d1-4eab-bb4e-bcacda6757ed', N'Completed-Brandguideline.pdf', N'0', N'0', N'1759217775', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'75', N'6', N'certification', N'6', N'certifications', N'certification-6-580c82fe-3300-4448-a8f8-351d3dcbff95', N'Completed-silver-award-ALL-white.png', N'0', N'0', N'1759217786', N'image/png', NULL, N'25973', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'76', N'6', N'certification', N'6', N'certifications', N'certification-6-2bea8203-2c84-4904-bf56-dfbc578a30ec', N'Completed-silver-award-black.png', N'0', N'0', N'1759217794', N'image/png', NULL, N'27916', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'77', N'6', N'certification', N'6', N'certifications', N'certification-6-491abb5b-073d-438f-8f2f-6fa5bf59a88b', N'Completed-silver-award-white.png', N'0', N'0', N'1759217803', N'image/png', NULL, N'26311', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'78', N'6', N'certification', N'6', N'certifications', N'certification-6-7e60ac5a-9771-492b-b177-dff0dbb5bc48', N'F H Harvey UK Limited 2024 SILVER Carbon Footprint Report.pdf', N'0', N'0', N'1759217814', N'application/pdf', NULL, N'1893434', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'79', N'6', N'certification', N'6', N'certifications', N'certification-6-ecf707f8-39a0-41db-bce4-c26cde97afe9', N'F H Harvey 2024 SILVER Certificate.pdf', N'0', N'0', N'1759217822', N'application/pdf', NULL, N'126555', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'80', N'13', N'certification', N'9', N'certifications', N'certification-13-a69283fe-51fe-4082-bc13-6745649ea3e5', N'Kingdom Group 2023 Carbon Footprint Report.pdf', N'0', N'0', N'1759218042', N'application/pdf', NULL, N'650127', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'81', N'13', N'certification', N'9', N'certifications', N'certification-13-75d95fb8-37c6-4ae8-aa08-a56a96bf1b7c', N'Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1759218128', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'82', N'13', N'certification', N'9', N'certifications', N'certification-13-292e17fd-72d4-40b7-9422-bc3c2c6e876a', N'Completed Gold Certification - digital badge.png', N'0', N'0', N'1759218142', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'83', N'13', N'certification', N'9', N'certifications', N'certification-13-2fb2cc49-be14-4016-b0d6-01468b5e5af0', N'Completed Gold Certification - social template.png', N'0', N'0', N'1759218156', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'84', N'13', N'certification', N'9', N'certifications', N'certification-13-2fb55eaa-b9b9-44da-8349-f4eb314f6cec', N'Completed-Certified-Gold-ALL-white-NCZ.png', N'0', N'0', N'1759218167', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'85', N'13', N'certification', N'9', N'certifications', N'certification-13-89ccde09-495f-4406-bad9-3428e3245662', N'Completed-Brandguideline.pdf', N'0', N'0', N'1759218217', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'86', N'13', N'certification', N'9', N'certifications', N'certification-13-d84976f5-aa70-4618-a73f-ee67e53f04c4', N'Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1759218232', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'87', N'13', N'certification', N'9', N'certifications', N'certification-13-bc60050c-0735-4963-b2e3-51b51f49ecd3', N'Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1759218239', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'88', N'17', N'certification', N'13', N'certifications', N'certification-17-eb419506-c7c8-4a6e-8cd2-f2d7310aba91', N'1. MUSTANG WASHROOMS 2023-24 GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1759218551', N'application/pdf', NULL, N'2782291', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'89', N'17', N'certification', N'13', N'certifications', N'certification-17-c05b8f6b-7328-4dd7-8a67-a0bf676090f6', N'Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1759218594', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'90', N'17', N'certification', N'13', N'certifications', N'certification-17-d4215ba8-5358-4fac-b757-21194b99e08e', N'Completed Gold Certification - digital badge.png', N'0', N'0', N'1759218605', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'91', N'17', N'certification', N'13', N'certifications', N'certification-17-2d300ff3-5641-450a-9075-d8287ee1c345', N'Completed Gold Certification - social template.png', N'0', N'0', N'1759218618', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'92', N'17', N'certification', N'13', N'certifications', N'certification-17-325c1f1a-28df-4e61-a76f-ff079f40239d', N'Completed-Certified-Gold-ALL-white-NCZ.png', N'0', N'0', N'1759218628', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'93', N'17', N'certification', N'13', N'certifications', N'certification-17-8e51b7c3-b9b8-4f14-b430-06518cc4a6e2', N'Completed-Brandguideline.pdf', N'0', N'0', N'1759218643', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'94', N'17', N'certification', N'13', N'certifications', N'certification-17-c0168b0a-c66c-4a3b-addc-e67979856b67', N'Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1759218653', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'95', N'17', N'certification', N'13', N'certifications', N'certification-17-dd6299f8-d2c6-4635-9c38-54e39de871e5', N'Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1759218663', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'96', N'20', N'certification', N'15', N'certifications', N'certification-20-0d401037-42b7-44fe-9bcc-952d6cf8a56d', N'AIM Cleaning 2023-24 Gold Certificate.pdf', N'0', N'0', N'1759218734', N'application/pdf', NULL, N'122503', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'97', N'20', N'certification', N'15', N'certifications', N'certification-20-f3c5b03d-a138-435f-98c1-dabe738b7a7c', N'Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1759220729', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'98', N'20', N'certification', N'15', N'certifications', N'certification-20-4f72b006-36d0-4db6-9c2a-3edf4bc30c35', N'Completed Gold Certification - digital badge.png', N'0', N'0', N'1759220745', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'99', N'20', N'certification', N'15', N'certifications', N'certification-20-ebb6babd-444b-44be-b412-9835184d0c2e', N'Completed Gold Certification - social template.png', N'0', N'0', N'1759220764', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'100', N'20', N'certification', N'15', N'certifications', N'certification-20-74911a95-e08e-4993-8149-6eb942c5d233', N'Completed-Certified-Gold-ALL-white-NCZ.png', N'0', N'0', N'1759220782', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'101', N'20', N'certification', N'15', N'certifications', N'certification-20-2d22efef-c7b5-41f1-8073-0523e095d4d6', N'Completed-Brandguideline.pdf', N'0', N'0', N'1759220817', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'102', N'20', N'certification', N'15', N'certifications', N'certification-20-4123463f-504f-470f-bba2-391271c54135', N'Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1759220829', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'103', N'20', N'certification', N'15', N'certifications', N'certification-20-31a34fed-4085-4094-be01-a517c7c8a702', N'Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1759220842', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'104', N'22', N'certification', N'16', N'certifications', N'certification-22-dfaa9b75-12af-41ab-808b-f7fbdab823a2', N'1. Apollo Cleaning 2023 GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1759224638', N'application/pdf', NULL, N'2569586', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'105', N'22', N'certification', N'16', N'certifications', N'certification-22-743f659b-6680-42aa-910b-e99634e6fff5', N'2. Apollo Cleaning 2023 GOLD Certificate.pdf', N'0', N'0', N'1759224647', N'application/pdf', NULL, N'124638', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'106', N'22', N'certification', N'16', N'certifications', N'certification-22-427764d7-3e74-4219-b4ea-98c656f69bfb', N'Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1759224980', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'107', N'22', N'certification', N'16', N'certifications', N'certification-22-419f3c66-6275-4347-880a-ad1d53325532', N'Completed Gold Certification - digital badge.png', N'0', N'0', N'1759224989', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'108', N'22', N'certification', N'16', N'certifications', N'certification-22-368f7d46-0407-45bd-b318-e7c77390ca84', N'Completed Gold Certification - social template.png', N'0', N'0', N'1759225001', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'109', N'22', N'certification', N'16', N'certifications', N'certification-22-d272d0d4-1769-46f3-97f4-45096edc6a33', N'Completed-Certified-Gold-ALL-white-NCZ.png', N'0', N'0', N'1759225011', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'110', N'22', N'certification', N'16', N'certifications', N'certification-22-a69f1dc1-84b4-4546-9003-fc572025d7cc', N'Completed-Brandguideline.pdf', N'0', N'0', N'1759225032', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'111', N'22', N'certification', N'16', N'certifications', N'certification-22-be7329ea-e479-43ed-a5b5-41a2e9ed64a8', N'Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1759225047', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'112', N'22', N'certification', N'16', N'certifications', N'certification-22-fba6bb71-4b52-4dcf-911f-8b32b6b17aa3', N'Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1759225058', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'113', N'25', N'certification', N'17', N'certifications', N'certification-25-3aa32288-c1e3-4b89-b634-dd71f53e2bfa', N'Thames Cleaning 2024 PLATINUM Carbon Footprint Report.pdf', N'0', N'0', N'1759226094', N'application/pdf', NULL, N'2616773', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'114', N'25', N'certification', N'17', N'certifications', N'certification-25-5b343b3e-b9e2-47f1-8387-c3d4913672cc', N'Thames Cleaning 2024 CN Platinum Certificate.pdf', N'0', N'0', N'1759226106', N'application/pdf', NULL, N'127638', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'115', N'25', N'certification', N'17', N'certifications', N'certification-25-edf3f4ca-c428-4238-87a7-50418fcbd086', N'CN Platinum Certification - digital badge.png', N'0', N'0', N'1759227758', N'image/png', NULL, N'1604993', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'116', N'25', N'certification', N'17', N'certifications', N'certification-25-41360487-9264-4ca0-bd37-7777f1dac912', N'CN Platinum Certification - social template.png', N'0', N'0', N'1759227789', N'image/png', NULL, N'2536830', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'117', N'25', N'certification', N'17', N'certifications', N'certification-25-b955c2c2-cea7-49dc-ae47-e7dfc6e30ba4', N'CN Platinum Certification Marketing Guide.pdf', N'0', N'0', N'1759227812', N'application/pdf', NULL, N'1333466', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'118', N'25', N'certification', N'17', N'certifications', N'certification-25-982104ab-74e9-49e4-bdd6-825e6489fa08', N'CN-platinum-black.png', N'0', N'0', N'1759227825', N'image/png', NULL, N'33816', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'119', N'25', N'certification', N'17', N'certifications', N'certification-25-7dfeb0c3-a816-445c-a81d-0b07631f1b1e', N'CN-platinum-white.png', N'0', N'0', N'1759227835', N'image/png', NULL, N'33859', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'124', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-33b81b15-789d-4bd2-9ca6-a993bbc8e00e', N'S1. Journey Silver Award - social template.png', N'0', N'0', N'1759907209', N'image/png', NULL, N'2440046', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'125', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-97c92cd2-e710-4a28-91bc-d876d496b0fb', N'S1. Journey Silver Award Announcement Guide.pdf', N'0', N'0', N'1759907214', N'application/pdf', NULL, N'1358505', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'126', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-d0c72472-8b4c-4c5d-ad3b-d45a91b5b805', N'S2. Completed Silver Award - digital badge.png', N'0', N'0', N'1759907216', N'image/png', NULL, N'1587094', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'127', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-93cf6adf-daa8-4ade-a32b-077afcd424dc', N'S2. Completed Silver Award Marketing Guide.pdf', N'0', N'0', N'1759907217', N'application/pdf', NULL, N'3453606', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'128', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-acdaf768-38b0-4584-8884-5ce42674b52e', N'S2. Completed Silver-award-ALL-white.png', N'0', N'0', N'1759907218', N'image/png', NULL, N'25973', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'129', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-e63b7e3a-e857-4627-b0c7-549865c0aa33', N'S2. Completed Silver-award-black.png', N'0', N'0', N'1759907219', N'image/png', NULL, N'27916', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'130', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-253cf210-fd93-494a-bf85-da377bd9eea2', N'S2. Completed Silver-award-white.png', N'0', N'0', N'1759907220', N'image/png', NULL, N'26311', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'131', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-1ece40d0-1121-4809-b70b-6a48e8f768d7', N'S3. CN-silver-black.png', N'0', N'0', N'1759907221', N'image/png', NULL, N'31030', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'132', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-76e7081e-6390-49ce-82c1-999017d17007', N'S3. CN-silver-digital-badge.png', N'0', N'0', N'1759907222', N'image/png', NULL, N'867744', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'133', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-aff5d55c-d934-4cab-8ec8-57fd7d92b897', N'S3. CN-silver-white.png', N'0', N'0', N'1759907223', N'image/png', NULL, N'29427', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'134', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-cd6d615b-2884-4ade-9350-31259b71eb2e', N'G1. Journey Gold Certification Announcement Guide.pdf', N'0', N'0', N'1759907224', N'application/pdf', NULL, N'1572124', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'135', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-ea94647a-df09-4a6f-94a4-c426abeb7545', N'G1. Journey Gold Certification- social template.png', N'0', N'0', N'1759907225', N'image/png', NULL, N'2424024', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'136', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-a1eb289b-a683-424b-8f71-364df1083875', N'G2. Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1759907226', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'137', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-25b55c8a-25a3-4c4d-bf9b-e149d58fa16a', N'G2. Completed Gold Certification - digital badge.png', N'0', N'0', N'1759907227', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'138', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-78c47535-41c9-478a-bbe1-3317597413e4', N'G2. Completed Gold Certification - social template.png', N'0', N'0', N'1759907228', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'139', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-436d6442-0c57-46e6-93d6-a16ba5d44d5c', N'G2. Completed-Certified Gold-ALL-white-NCZ.png', N'0', N'0', N'1759907229', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'140', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-8b47c9ba-e796-4968-a15a-775c413b56cd', N'G2. Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1759907230', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'141', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-b34ba6da-88d8-4258-bb08-28028ce6461b', N'G2. Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1759907231', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'142', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-ec8277bc-a302-4a35-bebb-58ac8c9409ca', N'G3. CN Gold Certification - digital badge.png', N'0', N'0', N'1759907232', N'image/png', NULL, N'1586178', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'143', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-61adf9ca-b199-4aea-b309-044ca0c4910a', N'G3. CN Gold Certification - social template.png', N'0', N'0', N'1759907233', N'image/png', NULL, N'2463501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'144', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-4917fd40-0649-4431-a91a-7aca624b4e28', N'G3. CN Gold Certification Marketing Guide.pdf', N'0', N'0', N'1759907234', N'application/pdf', NULL, N'1352693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'145', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-d19f9de7-7f55-42b8-8e6b-40ab0f4b8737', N'G3. CN-gold-black.png', N'0', N'0', N'1759907236', N'image/png', NULL, N'33501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'146', N'3', N'certification-prog', N'0', N'certification-docs', N'certification-prog-3-6f094aed-4e1a-43a2-917c-b80a6ba403b5', N'G3. CN-gold-white.png', N'0', N'0', N'1759907236', N'image/png', NULL, N'33693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'147', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-abaced44-fef3-4cd5-8aa6-d0a0da86a90b', N'P1. Journey Platinum Certification Announcement Guide.pdf', N'0', N'0', N'1759907237', N'application/pdf', NULL, N'1344672', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'148', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-e1692eb9-5e30-4d52-8a4f-5b76274765b5', N'P1. Journey Platinum Certification- social template.png', N'0', N'0', N'1759907238', N'image/png', NULL, N'2398458', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'149', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-fb9fb45c-ead0-4952-9f24-b21ee23aa4aa', N'P2. Completed - Platinum Certification Marketing Guide.pdf', N'0', N'0', N'1759907239', N'application/pdf', NULL, N'1360770', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'150', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-0ed582cd-8a92-4ae0-aad0-72d8751e7269', N'P2. Completed Platinum Certification - digital badge.png', N'0', N'0', N'1759907240', N'image/png', NULL, N'1595163', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'151', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-dc15b107-eb2f-42a3-8250-b6288e2ad92c', N'P2. Completed Platinum Certification - social template.png', N'0', N'0', N'1759907241', N'image/png', NULL, N'2533886', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'152', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-2f421d1b-6a04-4ec0-a379-dd2998d998d4', N'P2. Completed Platinum-dark-font-transparent1.png', N'0', N'0', N'1759907243', N'image/png', NULL, N'64640', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'153', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-05d0fa04-2380-4402-b522-d92097dcc908', N'P2. Completed Platinum-with-white-font-transparent.png', N'0', N'0', N'1759907244', N'image/png', NULL, N'64342', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'154', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-cfaf0ead-b198-481c-ab9c-2f99e4f50719', N'P3. CN Platinum Certification - digital badge.png', N'0', N'0', N'1759907244', N'image/png', NULL, N'1604993', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'155', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-cfb4ea4b-5964-4db9-96ad-92093f1ce9fc', N'P3. CN Platinum Certification - social template.png', N'0', N'0', N'1759907246', N'image/png', NULL, N'2536830', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'156', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-aa59e693-d5cb-4306-b23c-f792477c08b0', N'P3. CN Platinum Certification Marketing Guide.pdf', N'0', N'0', N'1759907247', N'application/pdf', NULL, N'1333466', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'157', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-9096e2db-dcbe-4f10-9294-4974f16b1d66', N'P3. CN-platinum-black.png', N'0', N'0', N'1759907248', N'image/png', NULL, N'33816', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'158', N'4', N'certification-prog', N'0', N'certification-docs', N'certification-prog-4-a0fcc54a-5ea4-49e0-98a7-04381c5ef022', N'P3. CN-platinum-white.png', N'0', N'0', N'1759907249', N'image/png', NULL, N'33859', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'159', N'2', N'certification-prog', N'0', N'certification-docs', N'certification-prog-2-32197cd2-4816-46f1-ae4a-18ba3a010fc1', N'NCZ Brand Guideline.pdf', N'0', N'0', N'1759907250', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'160', N'8', N'supply-chain', N'8', N'supply-chain-docs', N'supply-chain-8-8f8b1d51-3d36-422b-a072-c17744a92fa2', N'final-sample.xlsx', N'0', N'0', N'1760347785', N'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', N'1760347875', N'4880', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'161', N'8', N'supply-chain', N'8', N'supply-chain-docs', N'supply-chain-8-f41198b1-3305-4d55-a0d5-62a41f62eeb2', N'final-sample.xlsx', N'0', N'0', N'1760347883', N'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', NULL, N'4880', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'162', N'31', N'certification', N'23', N'certifications', N'certification-31-24271bb8-0a16-43f5-a560-f195dc304f1d', N'1. Floorbrite 2023-24 GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1760347891', N'application/pdf', NULL, N'2602678', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'163', N'31', N'certification', N'23', N'certifications', N'certification-31-a6f655a0-5c0e-4f61-81f5-96d5e7f3b83b', N'Floorbrite 2023-24 Gold Certificate.pdf', N'0', N'0', N'1760347913', N'application/pdf', NULL, N'123706', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'164', N'8', N'supply-chain', N'8', N'supply-chain-docs', N'supply-chain-8-7c752db2-d41e-42f0-941a-f7e88aa2b7b8', N'Suppliers data.xlsx', N'0', N'0', N'1760416574', N'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', N'1760416581', N'8015', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'165', N'1', N'supply-chain', N'1', N'supply-chain-docs', N'supply-chain-1-7e427a93-1ba7-4ef2-b974-3fcac9606209', N'update-sample.xlsx', N'0', N'0', N'1760699412', N'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', N'1760700218', N'4946', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'166', N'41', N'certification', N'28', N'certifications', N'certification-41-42fcc1d0-b552-4534-92d4-424d5b79e3e0', N'JSM Building Solutions Carbon Footprint Report.pdf', N'0', N'0', N'1760954033', N'application/pdf', NULL, N'562421', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'167', N'41', N'certification', N'28', N'certifications', N'certification-41-5a2ea6dc-7a83-4258-8a40-797f5bf4318e', N'Gold Certificate 2023-24.pdf', N'0', N'0', N'1760954048', N'application/pdf', NULL, N'121224', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'168', N'41', N'certification', N'28', N'certifications', N'certification-41-9f1b2d89-d5a3-4042-8c28-ec28ead7d9bb', N'Gold CN Certificate 2023-24.pdf', N'0', N'0', N'1760954056', N'application/pdf', NULL, N'127545', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'169', N'43', N'certification', N'30', N'certifications', N'certification-43-fe856bcc-7a7a-487a-bf0a-cf8bcb8f78b9', N'1. Tenon FM 2022 GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1760963515', N'application/pdf', NULL, N'2575036', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'170', N'43', N'certification', N'30', N'certifications', N'certification-43-6b840d9d-b7af-431d-b6b7-324d731aaaeb', N'2. Tenon FM 2022 GOLD Certificate.pdf', N'0', N'0', N'1760963523', N'application/pdf', NULL, N'122609', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'171', N'44', N'certification', N'30', N'certifications', N'certification-44-f068a593-1b3c-418e-ae83-4399ec4a398d', N'1. Tenon FM 2023 GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1760963589', N'application/pdf', NULL, N'2683131', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'172', N'44', N'certification', N'30', N'certifications', N'certification-44-2990befe-2a48-4a26-8493-16eb957bd5f9', N'2. Tenon FM 2023 GOLD Certificate.pdf', N'0', N'0', N'1760963596', N'application/pdf', NULL, N'122836', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'173', N'46', N'certification', N'31', N'certifications', N'certification-46-66c2cbe3-5e45-46aa-b4f4-c1976d57a022', N'Investec GOLD Certificate.pdf', N'0', N'0', N'1761034345', N'application/pdf', NULL, N'123722', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'174', N'46', N'certification', N'31', N'certifications', N'certification-46-16da3fd6-75b8-4143-a182-5387cac25681', N'Investec GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1761034356', N'application/pdf', NULL, N'3040570', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'175', N'50', N'certification', N'35', N'certifications', N'certification-50-35ed02b8-38b4-47ed-a69c-1d19f9dde45b', N'2. PLATINUM Carbon Footprint Report City and Essex.pdf', N'0', N'0', N'1761134370', N'application/pdf', NULL, N'2681069', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'176', N'50', N'certification', N'35', N'certifications', N'certification-50-b208c60d-da94-4e88-acad-094ecbb8b6f0', N'4. Platinum-City and Essex (SCCP).pdf', N'0', N'0', N'1761134380', N'application/pdf', NULL, N'1365898', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'177', N'50', N'certification', N'35', N'certifications', N'certification-50-d5a14adc-9b38-4b5e-8f32-204c303e9253', N'Certificate PLATINUM Advance.pdf', N'0', N'0', N'1761134389', N'application/pdf', NULL, N'123621', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'178', N'50', N'certification', N'35', N'certifications', N'certification-50-139fecac-98e5-4dc4-af62-2af7c5048c94', N'Certificate PLATINUM City and Essex.pdf', N'0', N'0', N'1761134398', N'application/pdf', NULL, N'119843', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'179', N'53', N'certification', N'37', N'certifications', N'certification-53-1792f857-b775-47c0-b213-5f8626301a8e', N'2. PLATINUM Carbon Footprint Report Greenzest.pdf', N'0', N'0', N'1761138679', N'application/pdf', NULL, N'2649408', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'180', N'53', N'certification', N'37', N'certifications', N'certification-53-19dd10e6-7380-491f-8e50-577f8084f470', N'3. Greenzest PLATINUM Certificate.pdf', N'0', N'0', N'1761138688', N'application/pdf', NULL, N'123251', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'181', N'53', N'certification', N'37', N'certifications', N'certification-53-79556de7-1816-4116-845f-18ccd21f7fd2', N'4. Greenzest Platinum (SCCP).pdf', N'0', N'0', N'1761138701', N'application/pdf', NULL, N'1352899', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'182', N'53', N'certification', N'37', N'certifications', N'certification-53-0b3c42bb-f751-45a5-8345-241228b71b01', N'LCA Report - Greenzest.pdf', N'0', N'0', N'1761138714', N'application/pdf', NULL, N'1489977', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'183', N'55', N'certification', N'38', N'certifications', N'certification-55-d8d56e59-0cb8-401b-9c76-35a663823223', N'1. MSC GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1761139233', N'application/pdf', NULL, N'2613251', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'184', N'55', N'certification', N'38', N'certifications', N'certification-55-d8b772a2-bc0c-4dd6-a487-957263c490c4', N'2. MSC Gold NCZ Certificate.pdf', N'0', N'0', N'1761139241', N'application/pdf', NULL, N'124319', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'185', N'55', N'certification', N'38', N'certifications', N'certification-55-3322a8ea-bc89-4cf2-8526-296c1202184f', N'LCA Report - MSC.pdf', N'0', N'0', N'1761139254', N'application/pdf', NULL, N'1442088', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'186', N'55', N'certification', N'38', N'certifications', N'certification-55-2f6d8208-ed68-4a7e-8a68-eaa4513c6413', N'3. Carbon-Reduction-Plan-MSC.pdf', N'0', N'0', N'1761139265', N'application/pdf', NULL, N'520535', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'187', N'53', N'certification', N'37', N'certifications', N'certification-53-f10f3ad2-4c44-4701-9623-ab176f3eb537', N'3. Carbon-Reduction-Plan-Greenzest.pdf', N'0', N'0', N'1761139361', N'application/pdf', NULL, N'538025', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'188', N'62', N'certification', N'39', N'certifications', N'certification-62-b78b6773-c985-40db-af6d-cd4734a9af9d', N'2024 BELFOR UK GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1761201116', N'application/pdf', NULL, N'2685759', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'189', N'62', N'certification', N'39', N'certifications', N'certification-62-7992f6ef-c9cc-49bd-8617-3d6e0324ff76', N'2024 BELFOR UK Gold CN Certificate.pdf', N'0', N'0', N'1761201175', N'application/pdf', NULL, N'127415', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'190', N'62', N'certification', N'39', N'certifications', N'certification-62-7a8d4c4b-2e43-4212-88f6-4be0b6ffeb42', N'G3. CN Gold Certification - digital badge.png', N'0', N'0', N'1761201194', N'image/png', NULL, N'1586178', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'191', N'62', N'certification', N'39', N'certifications', N'certification-62-e61d738f-0bf8-4f82-b757-23f5cf77bc4f', N'G3. CN Gold Certification - social template.png', N'0', N'0', N'1761201204', N'image/png', NULL, N'2463501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'192', N'62', N'certification', N'39', N'certifications', N'certification-62-80759475-445a-4a91-bbcd-32657f453e96', N'G3. CN Gold Certification Marketing Guide.pdf', N'0', N'0', N'1761201214', N'application/pdf', NULL, N'1352693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'193', N'62', N'certification', N'39', N'certifications', N'certification-62-41ed5306-5578-4e13-af42-9c5e5886bc66', N'G3. CN-gold-black.png', N'0', N'0', N'1761201223', N'image/png', NULL, N'33501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'194', N'62', N'certification', N'39', N'certifications', N'certification-62-711c1a0e-b93d-4d29-9e0c-e3cb27fb150c', N'G3. CN-gold-white.png', N'0', N'0', N'1761201231', N'image/png', NULL, N'33693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'195', N'62', N'certification', N'39', N'certifications', N'certification-62-07d33365-37ab-4184-b65d-24e17562cc91', N'BELFOR LCA 2024 Report.pdf', N'0', N'0', N'1761201394', N'application/pdf', NULL, N'1546390', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'196', N'62', N'certification', N'39', N'certifications', N'certification-62-1d1829d3-7b24-4287-9d4d-3dc1c54576cc', N'3. Carbon-Reduction-Plan-BELFOR.pdf', N'0', N'0', N'1761201418', N'application/pdf', NULL, N'525557', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'197', N'63', N'certification', N'40', N'certifications', N'certification-63-fe8a6889-8d5e-4f57-9ab7-5b7fddba30b5', N'Kindred 2023 Carbon Footprint Report.pdf', N'0', N'0', N'1761202595', N'application/pdf', NULL, N'628564', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'198', N'63', N'certification', N'40', N'certifications', N'certification-63-f7509d2c-dc00-4d7a-a306-5fc253591bf4', N'Kindred 2023 Gold Certificate.pdf', N'0', N'0', N'1761202605', N'application/pdf', NULL, N'121113', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'199', N'63', N'certification', N'40', N'certifications', N'certification-63-c24e451a-fb9a-4cab-b9b9-92c38f040768', N'Carbon-Reduction-Plan-Kindred.pdf', N'0', N'0', N'1761202701', N'application/pdf', NULL, N'529518', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'200', N'63', N'certification', N'40', N'certifications', N'certification-63-f634eda0-382c-43b9-b46a-2c363adc47da', N'LCA Report - Kindred 2023.pdf', N'0', N'0', N'1761202714', N'application/pdf', NULL, N'1487609', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'201', N'63', N'certification', N'40', N'certifications', N'certification-63-97818c54-2a86-4ba9-a1b3-875d859751f1', N'G3. CN Gold Certification - digital badge.png', N'0', N'0', N'1761202754', N'image/png', N'1761202768', N'1586178', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'202', N'63', N'certification', N'40', N'certifications', N'certification-63-6eb9c4bb-a37f-49a4-8a7e-0296d3a1e060', N'Completed-Brandguideline.pdf', N'0', N'0', N'1761202932', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'203', N'63', N'certification', N'40', N'certifications', N'certification-63-3115addb-97e1-4f1d-84b6-a941e8cd8ec3', N'G2. Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1761202945', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'204', N'63', N'certification', N'40', N'certifications', N'certification-63-15a05fc7-b6e8-4fb1-a748-b7f073c1c2c9', N'G2. Completed Gold Certification - digital badge.png', N'0', N'0', N'1761202958', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'205', N'63', N'certification', N'40', N'certifications', N'certification-63-e97b7e22-5f12-4a49-bcd9-bb30d9ada571', N'G2. Completed Gold Certification - social template.png', N'0', N'0', N'1761202970', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'206', N'63', N'certification', N'40', N'certifications', N'certification-63-c530e0f4-ff22-43d3-89d0-76b8c5735f93', N'G2. Completed-Certified Gold-ALL-white-NCZ.png', N'0', N'0', N'1761202985', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'207', N'63', N'certification', N'40', N'certifications', N'certification-63-259d80cc-9707-4f69-8833-279259b5d279', N'G2. Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1761202995', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'208', N'63', N'certification', N'40', N'certifications', N'certification-63-3f4066f2-eddf-4a0a-b387-7597631be9a6', N'G2. Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1761203006', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'209', N'64', N'certification', N'41', N'certifications', N'certification-64-eeb64350-e983-4894-b60a-b34ce4af8a0a', N'2024 Chamberlaine Cleaning Services Carbon Footprint Report.pdf', N'0', N'0', N'1761205240', N'application/pdf', NULL, N'588961', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'210', N'64', N'certification', N'41', N'certifications', N'certification-64-bbee81d1-1bd9-4aaa-a48e-146ae45ea71a', N'2024 Chamberlaine Cleaning Services Ltd GOLD Certificate.pdf', N'0', N'0', N'1761205252', N'application/pdf', NULL, N'122496', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'211', N'64', N'certification', N'41', N'certifications', N'certification-64-ed6be4a0-1971-4708-a9cb-ae8354cfdc9b', N'Carbon-Reduction-Plan-Chamberlaine.pdf', N'0', N'0', N'1761205264', N'application/pdf', NULL, N'514338', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'212', N'64', N'certification', N'41', N'certifications', N'certification-64-a95ef581-6c8c-4c0c-806e-398d22a75a80', N'LCA Report - Chamberlaine.pdf', N'0', N'0', N'1761205633', N'application/pdf', NULL, N'1432415', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'213', N'64', N'certification', N'41', N'certifications', N'certification-64-4e1111b7-22fb-4899-b59d-28a3a69642c4', N'Completed-Brandguideline.pdf', N'0', N'0', N'1761205651', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'214', N'64', N'certification', N'41', N'certifications', N'certification-64-8f25b048-e7ed-441b-b37b-389618a997d8', N'G2. Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1761205673', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'215', N'64', N'certification', N'41', N'certifications', N'certification-64-4ab667a9-f882-4136-a6a2-e3bf9336a6ac', N'G2. Completed Gold Certification - digital badge.png', N'0', N'0', N'1761205852', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'216', N'64', N'certification', N'41', N'certifications', N'certification-64-028e8ade-b8e1-4655-a36a-777e6a4b8122', N'G2. Completed Gold Certification - social template.png', N'0', N'0', N'1761205867', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'217', N'64', N'certification', N'41', N'certifications', N'certification-64-d20648a6-b99d-4ce1-ace1-a9d2deaabfeb', N'G2. Completed-Certified Gold-ALL-white-NCZ.png', N'0', N'0', N'1761205880', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'218', N'64', N'certification', N'41', N'certifications', N'certification-64-649ed870-f5ef-4f59-8156-b39599a034f2', N'G2. Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1761205891', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'219', N'64', N'certification', N'41', N'certifications', N'certification-64-065f4434-fbc8-4598-8cde-49a9328aea13', N'G2. Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1761205906', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'220', N'65', N'certification', N'41', N'certifications', N'certification-65-cf08f4b4-967e-424d-8864-5d313327c6a3', N'2024 PLATINUM Carbon Footprint Report Chamberlaine Cleaning.pdf', N'0', N'0', N'1761207310', N'application/pdf', NULL, N'2763814', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'221', N'65', N'certification', N'41', N'certifications', N'certification-65-f79c3dbf-ec76-40fe-be7b-7d707f5e2416', N'2024 Chamberlaine Cleaning CN Platinum Certificate.pdf', N'0', N'0', N'1761207343', N'application/pdf', NULL, N'127295', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'222', N'65', N'certification', N'41', N'certifications', N'certification-65-215d4a17-50e5-44de-aec3-0452c06c440a', N'P3. CN Platinum Certification - digital badge.png', N'0', N'0', N'1761207495', N'image/png', NULL, N'1604993', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'223', N'65', N'certification', N'41', N'certifications', N'certification-65-dc29a7a2-bd23-4963-a9c5-7192fe2b9d7a', N'P3. CN Platinum Certification - social template.png', N'0', N'0', N'1761207507', N'image/png', NULL, N'2536830', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'224', N'65', N'certification', N'41', N'certifications', N'certification-65-5bb19161-f3c2-4cb0-bf7e-f4c56edfc60f', N'P3. CN Platinum Certification Marketing Guide.pdf', N'0', N'0', N'1761207518', N'application/pdf', NULL, N'1333466', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'225', N'65', N'certification', N'41', N'certifications', N'certification-65-dae11901-b026-40e4-8433-acfbe34ff4aa', N'P3. CN-platinum-black.png', N'0', N'0', N'1761207527', N'image/png', NULL, N'33816', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'226', N'65', N'certification', N'41', N'certifications', N'certification-65-e0fd7516-4ad3-43c1-9257-987e470cc57a', N'P3. CN-platinum-white.png', N'0', N'0', N'1761207536', N'image/png', NULL, N'33859', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'227', N'65', N'certification', N'41', N'certifications', N'certification-65-9e794d7c-2d6c-4621-a17f-3c8e9c5c71cc', N'Carbon-Reduction-Plan-Chamberlaine (2024).pdf', N'0', N'0', N'1761208027', N'application/pdf', NULL, N'515202', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'228', N'66', N'certification', N'42', N'certifications', N'certification-66-58b51394-65a7-4fc2-b17c-eefaa3cb6ed2', N'2023 LINAKER GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1761215593', N'application/pdf', NULL, N'570702', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'229', N'66', N'certification', N'42', N'certifications', N'certification-66-8e07f7ed-c4a6-47d9-a681-8ef16dcee563', N'2023 NCZ Certificate GOLD Linaker.pdf', N'0', N'0', N'1761215607', N'application/pdf', NULL, N'122983', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'230', N'66', N'certification', N'42', N'certifications', N'certification-66-73180ccc-0451-43b9-83cd-f6a5214ef1ed', N'G2. Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1761215683', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'231', N'66', N'certification', N'42', N'certifications', N'certification-66-4a0ed64f-6df1-47f5-b4d6-ec7d859ab48d', N'Completed-Brandguideline.pdf', N'0', N'0', N'1761215756', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'232', N'66', N'certification', N'42', N'certifications', N'certification-66-cf8db50e-8e84-4b79-996d-7885aea3cf0f', N'G2. Completed Gold Certification - digital badge.png', N'0', N'0', N'1761215794', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'233', N'66', N'certification', N'42', N'certifications', N'certification-66-555570ce-6c31-4625-9b18-39c2c64184ff', N'G2. Completed Gold Certification - social template.png', N'0', N'0', N'1761215823', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'234', N'66', N'certification', N'42', N'certifications', N'certification-66-14b6a9fa-df3a-4d02-bc63-968be03b2d86', N'G2. Completed-Certified Gold-ALL-white-NCZ.png', N'0', N'0', N'1761215837', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'235', N'66', N'certification', N'42', N'certifications', N'certification-66-5f8cf295-2705-4b9f-a966-cd13975f46ae', N'G2. Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1761215868', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'236', N'66', N'certification', N'42', N'certifications', N'certification-66-ae437e4d-f26a-44fc-9627-8086fbbbe386', N'G2. Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1761215880', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'237', N'67', N'certification', N'42', N'certifications', N'certification-67-631f90d2-21ab-48bc-b669-f1ecc4fcfc45', N'2024 Linaker PLATINUM Carbon Footprint Report.pdf', N'0', N'0', N'1761216477', N'application/pdf', NULL, N'2772767', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'238', N'67', N'certification', N'42', N'certifications', N'certification-67-0bb6514d-3414-434e-b2b0-f9d3c1ebb89d', N'2024 Linaker PLATINUM Certificate.pdf', N'0', N'0', N'1761216495', N'application/pdf', NULL, N'123587', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'239', N'67', N'certification', N'42', N'certifications', N'certification-67-966c5caa-da6b-44a0-aa91-041506d94022', N'3. Carbon-Reduction-Plan-Linaker.pdf', N'0', N'0', N'1761216509', N'application/pdf', NULL, N'532094', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'240', N'67', N'certification', N'42', N'certifications', N'certification-67-2a93b2bd-26f3-4ade-b8d7-89a54632718a', N'Completed-Brandguideline (1).pdf', N'0', N'0', N'1761216614', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'241', N'67', N'certification', N'42', N'certifications', N'certification-67-8c8bc577-5852-4d21-adc8-e4d7a2ee62a7', N'P2. Completed - Platinum Certification Marketing Guide.pdf', N'0', N'0', N'1761216639', N'application/pdf', NULL, N'1360770', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'242', N'67', N'certification', N'42', N'certifications', N'certification-67-5f325a2b-54d4-483e-af9d-7271f4467311', N'P2. Completed Platinum Certification - digital badge.png', N'0', N'0', N'1761216655', N'image/png', NULL, N'1595163', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'243', N'67', N'certification', N'42', N'certifications', N'certification-67-f4093e0e-3fd1-4dfe-a2b3-94673e060355', N'P2. Completed Platinum-dark-font-transparent1.png', N'0', N'0', N'1761216677', N'image/png', NULL, N'64640', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'244', N'67', N'certification', N'42', N'certifications', N'certification-67-e536e427-d08a-45cd-bf7b-2a73d9750c17', N'P2. Completed Platinum Certification - social template.png', N'0', N'0', N'1761216694', N'image/png', NULL, N'2533886', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'245', N'67', N'certification', N'42', N'certifications', N'certification-67-866dacb9-e0d9-4020-86cb-ee2a3736bf0f', N'P2. Completed Platinum-with-white-font-transparent.png', N'0', N'0', N'1761216711', N'image/png', NULL, N'64342', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'246', N'68', N'certification', N'43', N'certifications', N'certification-68-1c481d72-8dea-466d-bf26-7c370afa7548', N'2022 Silver Certificate Agilite.pdf', N'0', N'0', N'1761217449', N'application/pdf', NULL, N'118108', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'247', N'68', N'certification', N'43', N'certifications', N'certification-68-7c5c379f-36ab-40ee-8698-ba5965721ec9', N'2022 Agilite Carbon Footprint Report.pdf', N'0', N'0', N'1761217466', N'application/pdf', NULL, N'553674', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'248', N'69', N'certification', N'43', N'certifications', N'certification-69-d78acc0f-4655-4a7b-89ad-5c0ecd0cf447', N'2023 AGILITE Carbon Footprint Report.pdf', N'0', N'0', N'1761217668', N'application/pdf', NULL, N'593507', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'249', N'69', N'certification', N'43', N'certifications', N'certification-69-1b73d4d7-c25c-46e9-ae28-7180f7ea46c2', N'2023 Agilite Gold Certificate.pdf', N'0', N'0', N'1761217686', N'application/pdf', NULL, N'123256', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'250', N'69', N'certification', N'43', N'certifications', N'certification-69-6042709b-aa5d-42ff-b6cc-54140aca2cb9', N'Carbon-Reduction-Plan-Agilité.pdf', N'0', N'0', N'1761217701', N'application/pdf', NULL, N'505570', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'251', N'69', N'certification', N'43', N'certifications', N'certification-69-5283771e-1844-4063-9299-ecadf978487b', N'Completed-Brandguideline.pdf', N'0', N'0', N'1761217786', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'252', N'69', N'certification', N'43', N'certifications', N'certification-69-2dcc328d-9c13-419a-a0df-e9de5d835493', N'G2. Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1761217806', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'253', N'69', N'certification', N'43', N'certifications', N'certification-69-28617078-fcf3-4e9e-bea1-fe6c51ffc333', N'G2. Completed Gold Certification - digital badge.png', N'0', N'0', N'1761217824', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'254', N'69', N'certification', N'43', N'certifications', N'certification-69-62aeba8d-325d-4984-9df2-0c628e20e8c1', N'G2. Completed Gold Certification - social template.png', N'0', N'0', N'1761217844', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'255', N'69', N'certification', N'43', N'certifications', N'certification-69-ea146de5-1298-4ca8-9c97-0d015a3fe22b', N'G2. Completed-Certified Gold-ALL-white-NCZ.png', N'0', N'0', N'1761217855', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'256', N'69', N'certification', N'43', N'certifications', N'certification-69-daed448c-4097-4706-8454-48da4076e5a2', N'G2. Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1761217866', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'257', N'69', N'certification', N'43', N'certifications', N'certification-69-fc672a3f-48ca-43a2-ac92-e3c03feea273', N'G2. Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1761217881', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'258', N'70', N'certification', N'43', N'certifications', N'certification-70-21786f4b-6338-4928-8811-c9904ea79757', N'2024 PLATINUM Carbon Footprint Agilite.pdf', N'0', N'0', N'1761218126', N'application/pdf', NULL, N'2763479', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'259', N'70', N'certification', N'43', N'certifications', N'certification-70-521091fb-0998-477d-aa35-abf61b89c8d7', N'2024 Agilite PLATINUM Certificate.pdf', N'0', N'0', N'1761218139', N'application/pdf', NULL, N'125551', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'260', N'70', N'certification', N'43', N'certifications', N'certification-70-93c0b01a-1c44-45f4-a3b2-997cc813ba1a', N'Carbon-Reduction-Plan-Agilité (2).pdf', N'0', N'0', N'1761218149', N'application/pdf', NULL, N'762665', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'261', N'70', N'certification', N'43', N'certifications', N'certification-70-5a134122-f2ce-492e-800a-ff63c6a82d26', N'Completed-Brandguideline (1).pdf', N'0', N'0', N'1761218201', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'262', N'70', N'certification', N'43', N'certifications', N'certification-70-798860d4-299e-4358-9b4b-67678683e081', N'P2. Completed - Platinum Certification Marketing Guide.pdf', N'0', N'0', N'1761218246', N'application/pdf', NULL, N'1360770', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'263', N'70', N'certification', N'43', N'certifications', N'certification-70-c49673df-1cb8-4481-a3db-73cde452bc6b', N'P2. Completed Platinum Certification - digital badge.png', N'0', N'0', N'1761218264', N'image/png', NULL, N'1595163', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'264', N'70', N'certification', N'43', N'certifications', N'certification-70-26e48e71-27ff-4211-9641-7a318901bdd9', N'P2. Completed Platinum-dark-font-transparent1.png', N'0', N'0', N'1761218290', N'image/png', NULL, N'64640', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'265', N'70', N'certification', N'43', N'certifications', N'certification-70-975df1e5-b8e6-4b57-b41e-0973ca5e2c30', N'P2. Completed Platinum Certification - social template.png', N'0', N'0', N'1761218314', N'image/png', NULL, N'2533886', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'266', N'70', N'certification', N'43', N'certifications', N'certification-70-2dc4d736-e24f-47dc-b4c6-9061a48eab9f', N'P2. Completed Platinum-with-white-font-transparent.png', N'0', N'0', N'1761218329', N'image/png', NULL, N'64342', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'267', N'70', N'certification', N'43', N'certifications', N'certification-70-a87d185a-80ae-43ee-bf6f-9433a21a9ea4', N'LCA Report - Agilite.pdf', N'0', N'0', N'1761218459', N'application/pdf', NULL, N'1437028', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'268', N'71', N'certification', N'39', N'certifications', N'certification-71-d6cab1b4-1756-4643-a770-a40a28a82cb3', N'2023 Belfor Carbon Footprint Report (1).pdf', N'0', N'0', N'1761218714', N'application/pdf', NULL, N'569262', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'269', N'71', N'certification', N'39', N'certifications', N'certification-71-c9aae821-8dea-4d36-a5fa-8e615c304f78', N'2023 Belfor Gold Certificate.pdf', N'0', N'0', N'1761218721', N'application/pdf', NULL, N'121538', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'270', N'72', N'certification', N'40', N'certifications', N'certification-72-7900b9b2-03b3-4910-b1f2-82bb0813acd3', N'2024 Kindred PLATINUM Carbon Footprint Report.pdf', N'0', N'0', N'1761220336', N'application/pdf', NULL, N'2789394', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'271', N'72', N'certification', N'40', N'certifications', N'certification-72-9c3bab5d-19dc-4847-a8d8-3e05c367e4dd', N'2024 Carbon-Reduction-Plan-Kindred v2 Oct 25.pdf', N'0', N'0', N'1761220348', N'application/pdf', NULL, N'534321', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'272', N'72', N'certification', N'40', N'certifications', N'certification-72-42659b28-737a-4d8f-98aa-60d5b675fe1b', N'2024 Kindred PLATINUM Certificate.pdf', N'0', N'0', N'1761220357', N'application/pdf', NULL, N'123411', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'273', N'72', N'certification', N'40', N'certifications', N'certification-72-fbf3002d-8572-4100-9806-c6704e348db4', N'Completed-Brandguideline (1).pdf', N'0', N'0', N'1761220397', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'274', N'72', N'certification', N'40', N'certifications', N'certification-72-7b49dddc-b385-4f54-839c-b801849287e0', N'P2. Completed - Platinum Certification Marketing Guide.pdf', N'0', N'0', N'1761220430', N'application/pdf', NULL, N'1360770', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'275', N'72', N'certification', N'40', N'certifications', N'certification-72-6bad2d01-2389-406e-b981-c766fe28756e', N'P2. Completed Platinum Certification - digital badge.png', N'0', N'0', N'1761220446', N'image/png', NULL, N'1595163', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'276', N'72', N'certification', N'40', N'certifications', N'certification-72-1faae104-8c0a-41f5-99de-751e602088c9', N'P2. Completed Platinum-dark-font-transparent1.png', N'0', N'0', N'1761220457', N'image/png', NULL, N'64640', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'277', N'72', N'certification', N'40', N'certifications', N'certification-72-55d5c295-baa7-47d1-9edd-f78bddc19022', N'P2. Completed Platinum Certification - social template.png', N'0', N'0', N'1761220479', N'image/png', NULL, N'2533886', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'278', N'72', N'certification', N'40', N'certifications', N'certification-72-6296d96d-f03e-4812-92e3-cbf2722dcb54', N'P2. Completed Platinum-with-white-font-transparent.png', N'0', N'0', N'1761220489', N'image/png', NULL, N'64342', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'279', N'73', N'certification', N'41', N'certifications', N'certification-73-bc855de9-e615-41e6-956c-d7a593ac88ff', N'2022 Chamberlaine Cleaning Services Silver Certificate.pdf', N'0', N'0', N'1761220870', N'application/pdf', NULL, N'121579', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'280', N'73', N'certification', N'41', N'certifications', N'certification-73-e0122442-8510-4d90-8940-d871da0dee2b', N'2022 Chamberlaine Carbon Footprint Report.pdf', N'0', N'0', N'1761220880', N'application/pdf', NULL, N'403569', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'281', N'74', N'certification', N'42', N'certifications', N'certification-74-35a71ef7-ed79-484e-b4d4-8c7f93bd594d', N'2022 Linaker Gold Certificate.pdf', N'0', N'0', N'1761221280', N'application/pdf', NULL, N'121348', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'282', N'74', N'certification', N'42', N'certifications', N'certification-74-a1bbf33c-7b43-4c74-bf08-875a5a296049', N'2022 LINAKER Carbon Footprint Report GOLD.pdf', N'0', N'0', N'1761221290', N'application/pdf', NULL, N'585149', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'283', N'80', N'certification', N'15', N'certifications', N'certification-80-43d1bef1-a0e3-4500-af8d-3a73b8700cc7', N'2021-22 AIM Commercial Cleaning Carbon Footprint Report.pdf', N'0', N'0', N'1761799390', N'application/pdf', NULL, N'516249', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'284', N'81', N'certification', N'22', N'certifications', N'certification-81-f3e21431-338e-4b9f-98f3-6b7033ba6c66', N'2023-24 RAPID ENERGY GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1761800112', N'application/pdf', NULL, N'2810252', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'285', N'81', N'certification', N'22', N'certifications', N'certification-81-a740764c-39aa-4955-9824-b3b1b900035e', N'2023-24 Rapid Energy CN Gold Certificate.pdf', N'0', N'0', N'1761800141', N'application/pdf', NULL, N'125867', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'286', N'81', N'certification', N'22', N'certifications', N'certification-81-0c5c64a3-4b4f-4976-bb99-d6d3e19ff194', N'G3. CN Gold Certification - digital badge.png', N'0', N'0', N'1761800156', N'image/png', NULL, N'1586178', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'287', N'81', N'certification', N'22', N'certifications', N'certification-81-2dca0832-733d-427b-88af-0951009f1ee6', N'G3. CN Gold Certification - social template.png', N'0', N'0', N'1761800173', N'image/png', NULL, N'2463501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'288', N'81', N'certification', N'22', N'certifications', N'certification-81-02c17b91-f065-43cc-8613-84057229f41a', N'G3. CN Gold Certification Marketing Guide.pdf', N'0', N'0', N'1761800189', N'application/pdf', NULL, N'1352693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'289', N'81', N'certification', N'22', N'certifications', N'certification-81-32e55c76-23f9-45d6-aff8-70b156003a84', N'G3. CN-gold-black.png', N'0', N'0', N'1761800201', N'image/png', NULL, N'33501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'290', N'81', N'certification', N'22', N'certifications', N'certification-81-002ac4a9-8d44-477d-ace8-bcb06d94567e', N'G3. CN-gold-white.png', N'0', N'0', N'1761800208', N'image/png', NULL, N'33693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'291', N'82', N'certification', N'23', N'certifications', N'certification-82-c994d7cc-6396-41e8-bd3f-0aaf0f92fd08', N'Floorbrite Carbon Footprint Report 2022.pdf', N'0', N'0', N'1761804309', N'application/pdf', NULL, N'447303', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'292', N'83', N'certification', N'25', N'certifications', N'certification-83-1d3aca22-2071-4eb4-9023-334a543f3712', N'2023-24 DesertSnow GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1761807800', N'application/pdf', NULL, N'2581212', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'293', N'83', N'certification', N'25', N'certifications', N'certification-83-f6329ee7-0f61-480a-96ff-5db73c227678', N'2023-24 DesertSnow Gold Certificate.pdf', N'0', N'0', N'1761807811', N'application/pdf', NULL, N'121014', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'294', N'83', N'certification', N'25', N'certifications', N'certification-83-17052f95-58b6-412f-8421-5cfbd9628258', N'Completed-Brandguideline.pdf', N'0', N'0', N'1761807875', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'295', N'83', N'certification', N'25', N'certifications', N'certification-83-ae222636-98a9-4205-800f-f8773f8fb3ad', N'G2. Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1761807894', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'296', N'83', N'certification', N'25', N'certifications', N'certification-83-715b729c-e709-4749-a090-6907de7da1ef', N'G2. Completed Gold Certification - digital badge.png', N'0', N'0', N'1761807919', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'297', N'83', N'certification', N'25', N'certifications', N'certification-83-bfa91367-4c4c-48f0-a1b9-bc11f493e108', N'G2. Completed Gold Certification - social template.png', N'0', N'0', N'1761807935', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'298', N'83', N'certification', N'25', N'certifications', N'certification-83-cda8ea84-40c7-440e-8947-9a3c412f1724', N'G2. Completed-Certified Gold-ALL-white-NCZ.png', N'0', N'0', N'1761807948', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'299', N'83', N'certification', N'25', N'certifications', N'certification-83-44a5a866-84ff-4896-9c14-c35c17e8440d', N'G2. Completed-Certified-Gold-NCZ.png', N'0', N'0', N'1761807957', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'300', N'83', N'certification', N'25', N'certifications', N'certification-83-7b88f2dd-fb38-4332-ba11-dbb7c014b25f', N'G2. Completed-Certified-Gold-white-NCZ.png', N'0', N'0', N'1761807967', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'301', N'84', N'certification', N'28', N'certifications', N'certification-84-20d751de-37d9-44d4-b07c-ee3a37f02d93', N'2022 JSM_NCZ Carbon Footprint Report.pdf', N'0', N'0', N'1761808640', N'application/pdf', NULL, N'503934', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'302', N'85', N'certification', N'34', N'certifications', N'certification-85-069e0edf-809b-4d3c-bc71-04273d867f58', N'2023-24 Fairclean GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1761809351', N'application/pdf', NULL, N'496005', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'303', N'85', N'certification', N'34', N'certifications', N'certification-85-8816749a-f2a4-478f-81df-ab2305ed8770', N'2023-24 Fairclean GOLD Certificate CN Cert.pdf', N'0', N'0', N'1761809359', N'application/pdf', NULL, N'125383', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'304', N'85', N'certification', N'34', N'certifications', N'certification-85-239fe026-d514-4fbf-857b-62d72939c27f', N'G3. CN Gold Certification - digital badge.png', N'0', N'0', N'1761809488', N'image/png', NULL, N'1586178', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'305', N'85', N'certification', N'34', N'certifications', N'certification-85-a21c9fae-f68d-4ec3-be0b-e6ea9238bf19', N'G3. CN Gold Certification - social template.png', N'0', N'0', N'1761809503', N'image/png', NULL, N'2463501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'306', N'85', N'certification', N'34', N'certifications', N'certification-85-02878c4c-96a3-4c05-9350-7546d46cf88e', N'G3. CN Gold Certification Marketing Guide.pdf', N'0', N'0', N'1761809513', N'application/pdf', NULL, N'1352693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'307', N'85', N'certification', N'34', N'certifications', N'certification-85-f1837233-caec-4fc8-9ba0-e3d5ebc130cd', N'G3. CN-gold-black.png', N'0', N'0', N'1761809523', N'image/png', NULL, N'33501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'308', N'85', N'certification', N'34', N'certifications', N'certification-85-15415d90-90c2-46dc-98cd-4976ef822c64', N'G3. CN-gold-white.png', N'0', N'0', N'1761809532', N'image/png', NULL, N'33693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'309', N'86', N'certification', N'36', N'certifications', N'certification-86-3c6035b9-94ac-4d5f-9687-8c0151bdcfa0', N'2022 NCZ YESSS Carbon Footprint Report.pdf', N'0', N'0', N'1761809785', N'application/pdf', NULL, N'377381', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'310', N'87', N'certification', N'40', N'certifications', N'certification-87-3f41ac3f-dd6a-47e9-8902-04e5f71e590c', N'2021 NCZ_Carbon Footprint Report_Kindred.pdf', N'0', N'0', N'1761810714', N'application/pdf', NULL, N'424612', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'311', N'88', N'certification', N'40', N'certifications', N'certification-88-5493e640-28a3-4d76-80c6-664d58b38dfe', N'2022 Kindred NCZ Carbon Footprint Report.pdf', N'0', N'0', N'1761810755', N'application/pdf', NULL, N'363415', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'312', N'89', N'certification', N'45', N'certifications', N'certification-89-729452ec-5cc6-4e90-9890-80640115a091', N'2022-23 Cosourced Carbon Footprint Report.pdf', N'0', N'0', N'1761812022', N'application/pdf', NULL, N'569371', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'313', N'89', N'certification', N'45', N'certifications', N'certification-89-02ce12b2-b038-4c9f-bc57-60969a6a82ae', N'2022-23 CoSourced Silver Cert.pdf', N'0', N'0', N'1761812031', N'application/pdf', NULL, N'121493', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'314', N'90', N'certification', N'46', N'certifications', N'certification-90-3b23d7e2-22c5-4d7c-98c9-ccd6014bb090', N'2022-23 JD Services Carbon Footprint Report GOLD.pdf', N'0', N'0', N'1761813387', N'application/pdf', NULL, N'539592', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'315', N'90', N'certification', N'46', N'certifications', N'certification-90-da20e46f-1611-4ea5-958e-0fd96d0aafad', N'2022-23 JD SERVICES Gold Cert.pdf', N'0', N'0', N'1761813399', N'application/pdf', NULL, N'121717', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'316', N'92', N'certification', N'48', N'certifications', N'certification-92-4800c47a-6f1a-4d78-8c45-eb5a69403f7c', N'2. GOLD Carbon Footprint Report GENCO 2.0.pdf', N'0', N'0', N'1761827127', N'application/pdf', N'1761827146', N'2553413', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'317', N'92', N'certification', N'48', N'certifications', N'certification-92-a6ec77af-ab7b-44e1-8e7d-5391b01c0eab', N'2. GOLD Carbon Footprint Report GENCO 2.0.pdf', N'0', N'0', N'1761827141', N'application/pdf', NULL, N'2553413', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'318', N'92', N'certification', N'48', N'certifications', N'certification-92-044c6103-4eb1-4268-982f-c209a743a417', N'GENCO Gold Certificate.pdf', N'0', N'0', N'1761827156', N'application/pdf', NULL, N'122442', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'319', N'94', N'certification', N'8', N'certifications', N'certification-94-1885b006-a639-4d95-9712-81c0925b57ed', N'ATS SILVER Carbon Footprint Report 2023.pdf', N'0', N'0', N'1762237349', N'application/pdf', NULL, N'543307', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'320', N'94', N'certification', N'8', N'certifications', N'certification-94-4bfef858-51f4-4034-83ea-2677c9fe7b5f', N'ATS 2023 Silver Certificate.pdf', N'0', N'0', N'1762237361', N'application/pdf', NULL, N'121768', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'321', N'95', N'certification', N'8', N'certifications', N'certification-95-8a9bf9b4-dab1-4a73-840e-ba7761424484', N'APL 2023 Silver Certificate.pdf', N'0', N'0', N'1762237382', N'application/pdf', NULL, N'122604', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'322', N'95', N'certification', N'8', N'certifications', N'certification-95-be3f02fd-8778-46b9-b7fb-3f1249156a18', N'APL Carbon Footprint Report 2023.pdf', N'0', N'0', N'1762237390', N'application/pdf', NULL, N'543186', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'323', N'96', N'certification', N'8', N'certifications', N'certification-96-941881f9-5f10-4785-8654-08ee5078d909', N'ADS SILVER Carbon Footprint Report.pdf', N'0', N'0', N'1762237411', N'application/pdf', NULL, N'533137', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'324', N'96', N'certification', N'8', N'certifications', N'certification-96-f7a8334f-5c6c-4ae1-8d7e-86bbbfb3d4c9', N'ADS 2023 SILVER Certificate.pdf', N'0', N'0', N'1762237428', N'application/pdf', NULL, N'122081', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'325', N'97', N'certification', N'12', N'certifications', N'certification-97-70cc0bea-0753-4245-a8b2-978dcf4e2162', N'Cynergi 2023 Gold Certificate.pdf', N'0', N'0', N'1762237990', N'application/pdf', NULL, N'123498', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'326', N'97', N'certification', N'12', N'certifications', N'certification-97-afc564cb-add2-4e38-beed-422559f9b8a7', N'Cynergi 2023 GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1762238002', N'application/pdf', NULL, N'2931593', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'327', N'97', N'certification', N'12', N'certifications', N'certification-97-678ac4c9-4f7b-46bd-ad2e-dedde2ec4c92', N'Completed-Brandguideline.pdf', N'0', N'0', N'1762239225', N'application/pdf', NULL, N'15845716', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'328', N'97', N'certification', N'12', N'certifications', N'certification-97-0bf9dcce-9231-43ed-9b97-93effe28947a', N'G2. Completed - Gold Certification Marketing Guide.pdf', N'0', N'0', N'1762239236', N'application/pdf', NULL, N'1351513', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'329', N'97', N'certification', N'12', N'certifications', N'certification-97-19f8d877-defb-4fb8-bac9-5a469eb3cda7', N'G2. Completed Gold Certification - digital badge (1).png', N'0', N'0', N'1762239251', N'image/png', NULL, N'1583664', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'330', N'97', N'certification', N'12', N'certifications', N'certification-97-7808f1e9-10bf-4215-8a0c-5e0c1b683646', N'G2. Completed Gold Certification - social template (1).png', N'0', N'0', N'1762239272', N'image/png', NULL, N'2524940', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'331', N'97', N'certification', N'12', N'certifications', N'certification-97-ee1bc77e-9df5-4a6f-a8a8-590d5ba5cc1e', N'G2. Completed-Certified Gold-ALL-white-NCZ (1).png', N'0', N'0', N'1762239282', N'image/png', NULL, N'31980', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'332', N'97', N'certification', N'12', N'certifications', N'certification-97-0fe7864e-4d7a-49ba-8fd0-83610bbf7ef5', N'G2. Completed-Certified-Gold-NCZ (1).png', N'0', N'0', N'1762239299', N'image/png', NULL, N'35410', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'333', N'97', N'certification', N'12', N'certifications', N'certification-97-7e6e2912-749c-4f4b-a163-84764fa407d3', N'G2. Completed-Certified-Gold-white-NCZ (1).png', N'0', N'0', N'1762239306', N'image/png', NULL, N'32440', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'334', N'99', N'certification', N'49', N'certifications', N'certification-99-03208c63-f43c-4009-8a63-c4a3d245af73', N'Grade One 2023-24 GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1762753835', N'application/pdf', NULL, N'2940374', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'335', N'99', N'certification', N'49', N'certifications', N'certification-99-81b706ca-a260-4f1b-b098-fa32a5551788', N'Grade One Commercial Cleaning Services 2023-24 Gold CN Certificate.pdf', N'0', N'0', N'1762753848', N'application/pdf', NULL, N'124983', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'336', N'99', N'certification', N'49', N'certifications', N'certification-99-dc4a1162-7130-42ac-983e-26584c5a59d7', N'G3. CN-gold-white.png', N'0', N'0', N'1762753862', N'image/png', NULL, N'33693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'337', N'99', N'certification', N'49', N'certifications', N'certification-99-2acde140-f9ea-4693-912c-6470a3d8d842', N'G3. CN-gold-black.png', N'0', N'0', N'1762753904', N'image/png', NULL, N'33501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'338', N'99', N'certification', N'49', N'certifications', N'certification-99-805ece96-f46d-4af4-9575-d4e5df7f636e', N'G3. CN Gold Certification Marketing Guide.pdf', N'0', N'0', N'1762753917', N'application/pdf', NULL, N'1352693', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'339', N'99', N'certification', N'49', N'certifications', N'certification-99-905f6ae1-2172-4184-a04a-ec82398e5390', N'G3. CN Gold Certification - social template.png', N'0', N'0', N'1762753943', N'image/png', NULL, N'2463501', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'340', N'99', N'certification', N'49', N'certifications', N'certification-99-3322153b-4793-4040-b6ed-f3d184dd1a17', N'G3. CN Gold Certification - digital badge.png', N'0', N'0', N'1762753964', N'image/png', NULL, N'1586178', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'341', N'100', N'certification', N'49', N'certifications', N'certification-100-22c67024-ef64-44f9-a3b9-d552bd02d385', N'Grade One Carbon Footprint Report 2022-23.pdf', N'0', N'0', N'1762754205', N'application/pdf', NULL, N'440436', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'342', N'99', N'certification', N'49', N'certifications', N'certification-99-85b677b1-acbc-47f8-92f4-87ec8e384858', N'Carbon-Reduction-Plan-Grade One.pdf', N'0', N'0', N'1762754454', N'application/pdf', NULL, N'515254', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'343', N'40', N'certification', N'28', N'certifications', N'certification-40-423ba236-5253-45b1-b156-5c341915b48f', N'2. JSM Building Solutions 2024-25 GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1762954576', N'application/pdf', NULL, N'2836637', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'344', N'40', N'certification', N'28', N'certifications', N'certification-40-2744c687-46b5-4c4c-a939-962bc260c9b9', N'2a. JSM Building Solutions One Page Summary.pdf', N'0', N'0', N'1762954586', N'application/pdf', NULL, N'348266', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'345', N'40', N'certification', N'28', N'certifications', N'certification-40-9bc2f254-0783-451e-abed-43e46ea2d7fb', N'JSM Building 2024-25 GOLD Certificate.pdf', N'0', N'0', N'1762954595', N'application/pdf', NULL, N'124488', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'346', N'102', N'certification', N'50', N'certifications', N'certification-102-7902bf91-7722-402d-92f5-4f62d067ea3e', N'Lancer Scott 2023-24 Carbon Footprint Report.pdf', N'0', N'0', N'1763442274', N'application/pdf', NULL, N'3079803', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'347', N'102', N'certification', N'50', N'certifications', N'certification-102-dc2d68d5-4448-48ae-aa4f-38a647085bac', N'Lancer Scott 2023-24 Gold Certificate.pdf', N'0', N'0', N'1763442283', N'application/pdf', NULL, N'121532', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'348', N'102', N'certification', N'50', N'certifications', N'certification-102-546ffe01-6ad4-4bf5-85db-54a89eb1091a', N'Lancer Scott  Carbon Reduction Plan 2023-24.pdf', N'0', N'0', N'1763442296', N'application/pdf', NULL, N'514852', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'349', N'103', N'certification', N'50', N'certifications', N'certification-103-618aa908-a082-4682-9856-6f9ec3fc37ed', N'2022-23 LANCER SCOTT Carbon Footprint Report.pdf', N'0', N'0', N'1763445086', N'application/pdf', NULL, N'548349', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'350', N'103', N'certification', N'50', N'certifications', N'certification-103-be04b1d8-f118-4e8a-bc7f-82a54fffc42e', N'2022-23 Certificate Lancer Scott 104686.pdf', N'0', N'0', N'1763445093', N'application/pdf', NULL, N'121323', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'351', N'104', N'certification', N'50', N'certifications', N'certification-104-7ec1cee0-3dbb-48e0-abcf-fcf7dc67e0a4', N'LancerScott_Carbon Footprint Report 2022 .pdf', N'0', N'0', N'1763445362', N'application/pdf', NULL, N'384580', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'352', N'10', N'certification', N'8', N'certifications', N'certification-10-9953a9a3-67b7-406e-bc54-46f5da19c326', N'NCZ Platinum Certification - social template.png', N'0', N'0', N'1763471195', N'image/png', NULL, N'2533886', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'353', N'10', N'certification', N'8', N'certifications', N'certification-10-5e4b661e-f27b-4003-8441-bc28e9e85a69', N'NCZ - Platinum Certification Announcement Guide March25.pdf', N'0', N'0', N'1763471206', N'application/pdf', NULL, N'1143740', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'354', N'15', N'certification', N'13', N'certifications', N'certification-15-bb04bb62-7977-4456-b784-1503794b2286', N'Mustang Washrooms 2024-25 GOLD Carbon Footprint Report.pdf', N'0', N'0', N'1763721423', N'application/pdf', NULL, N'2770784', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'355', N'15', N'certification', N'13', N'certifications', N'certification-15-037f241d-f72b-44a0-96a1-9faa3c798249', N'Mustang CN GOLD Certificate 2024-25.pdf', N'0', N'0', N'1763721432', N'application/pdf', NULL, N'126672', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'356', N'15', N'certification', N'13', N'certifications', N'certification-15-e2c91447-246d-4120-9a0c-0dc8dd016804', N'2024-25 One Page Summary.pdf', N'0', N'0', N'1763721442', N'application/pdf', NULL, N'333776', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'357', N'109', N'certification', N'54', N'certifications', N'certification-109-23caea49-5ba8-4273-a87d-67e836b0cf78', N'Johnsons 2023-24 PLATINUM Carbon Footprint Report 2.0.pdf', N'0', N'0', N'1764067670', N'application/pdf', NULL, N'2696662', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'358', N'109', N'certification', N'54', N'certifications', N'certification-109-aca0b929-db45-47ac-b9e6-92f99f0365d1', N'Johnsons 2023-24 PLATINUM Certificate.pdf', N'0', N'0', N'1764067680', N'application/pdf', NULL, N'124070', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'359', N'109', N'certification', N'54', N'certifications', N'certification-109-b4312b7e-fb18-4f77-b39d-0018716817b2', N'Johnsons 1871 Platinum (SCCP).pdf', N'0', N'0', N'1764067696', N'application/pdf', NULL, N'1370492', NULL)
GO

SET IDENTITY_INSERT [Documents].[Document] OFF
GO


-- ----------------------------
-- procedure structure for spDocument_Delete
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_Delete]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [Documents].[spDocument_Delete]
GO

CREATE PROCEDURE [Documents].[spDocument_Delete]
    @id INT
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @now bigint = [utilities].DateToEpoch(null);
	UPDATE [documents].[Document] SET [activeTo] = @now WHERE [id] = @id;

END
GO


-- ----------------------------
-- procedure structure for spDocument_CreateVersion
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_CreateVersion]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [Documents].[spDocument_CreateVersion]
GO

CREATE PROCEDURE [Documents].[spDocument_CreateVersion]
   @documentId int
	,@parentDocId int
	,@uid nvarchar(50) = NULL
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @now BIGINT = utilities.DatetoEpoch(GetDate());
	DECLARE @version int = (SELECT ISNULL([version], 0) FROM [documents].[DocumentVersion] WHERE [documentId] = @parentDocId)
	
	DECLARE @userACcountId INT = NULL
	IF @uid IS NOT NULL 
		SET @userAccountId = (SELECT [id] FROM [registrations].[UserAccount] WHERE [uid] = @uid)

	INSERT INTO [documents].[DocumentVersion] (
			[documentId]
			,[parentDocId]
			,[version]
			,[createdDate]
			,[createdBy]
		) VALUES (
			@documentId
			,@parentDocId
			,ISNULL(@version, 0) + 1
			,@now
			,@userACcountId
		)

	RETURN 1;

END
GO


-- ----------------------------
-- procedure structure for spDocument_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [Documents].[spDocument_Save]
GO

CREATE PROCEDURE [Documents].[spDocument_Save]
        @parentEntityId INT
        ,@parentEntityType NVARCHAR(100)
        ,@customerId INT = null
        ,@container NVARCHAR(100)
        ,@blobName NVARCHAR(500) = null
        ,@title NVARCHAR(100)
        ,@mimeType [nvarchar](100)
        ,@singleInstance BIT = NULL
        ,@canEmbed BIT -- we can embed image types for instance
        ,@size INT = NULL
        ,@uid nvarchar(50) = NULL
        ,@ownerName nvarchar(100) = NULL
        ,@reviewDate bigint = NULL
		,@reference nvarchar(50) = NULL
AS
BEGIN

	SET NOCOUNT ON;
  
	DECLARE @id int = NULL
	IF @singleInstance = 1 
	BEGIN
		SELECT TOP 1 @id = [id] FROM [documents].[document] WHERE [parentEntityId] = @parentEntityId AND [parentEntityType] = @parentEntityType
	END
	
	DECLARE @userACcountId INT = NULL
	IF @uid IS NOT NULL 
		SET @userAccountId = (SELECT [id] FROM [registrations].[UserAccount] WHERE [uid] = @uid)

	DECLARE @now BIGINT = utilities.DatetoEpoch(GetDate());
	IF @id IS NULL
	BEGIN
		INSERT INTO [documents].[Document] (
			 [parentEntityId]
			,[parentEntityType]
			,[customerId] 
			,[container]
			,[blobName]
			,[title]
			,[mimeType]
			,[singleInstance]
			,[canEmbed]
			,[modifiedDate]
			,[size]
			,[userAccountId]
		) VALUES (
			 @parentEntityId
			,@parentEntityType
			,@customerId
			,@container
			,@blobName
			,@title
			,@mimeType
			,@singleInstance
			,@canEmbed
			,@now
			,ISNULL(@size, 0)
			,@userAccountId
		)
		SET @id = (SCOPE_IDENTITY())
		IF @ownerName IS NOT NULL OR @reviewDate IS NOT NULL OR @reference IS NOT NULL
		BEGIN
			INSERT INTO [documents].[DocumentInfo] ([documentId], [owner], [reviewDate], [reference]) VALUES (@id, @ownerName, @reviewDate, @reference)
		END
	END
	ELSE
		UPDATE [documents].[Document]
		   SET [modifiedDate] = @now
				,[title] = @title
				,[container] = @container
				,[blobName] = @blobName
				,[size] = ISNULL(@size, 0)
				,[userAccountId] = @userAccountId
		 WHERE [id] = @id
	
	SELECT *
	  FROM [documents].[Document]
	 WHERE [id] = @id
END
GO


-- ----------------------------
-- procedure structure for spDocument_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [Documents].[spDocument_Get]
GO

CREATE PROCEDURE [Documents].[spDocument_Get]
   @documentId int
AS
BEGIN
	SET NOCOUNT ON;
  
	SELECT d.* FROM [documents].[document] d
  WHERE d.[id] = @documentId AND d.[activeTo] IS NULL;

END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectByBlobName
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectByBlobName]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [Documents].[spDocument_SelectByBlobName]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectByBlobName]
    @blobName nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT TOP 1 d.*
			,ISNULL(f.sectionId, d.parentEntityId) as sectionId --When there is no folder, we use sectionId as parentEntityId
	  FROM [documents].[document] d
 LEFT JOIN [documents].[Folder] f on f.id = d.parentEntityId AND d.parentEntityType = 'folder'
	 WHERE [blobName] = @blobName;

END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectByIds
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectByIds]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [Documents].[spDocument_SelectByIds]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectByIds]
   @ids NVARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT d.*
		,u.displayName as [userDisplayName]
		,u.picture as [userPicture]
		,u.email as [userEmail]
		,di.owner as [ownerName]
		,di.reviewDate
	  FROM [documents].[document] d
	LEFT JOIN [registrations].[UserAccount] u on u.[id] = d.[userAccountId]
	LEFT JOIN [documents].[DocumentInfo] di on di.[documentId] = d.[id]
	 WHERE d.[id] in (SELECT [value] FROM STRING_SPLIT(@ids, ','))
		 AND d.[activeTo] IS NULL
		ORDER BY d.[modifiedDate] DESC
END
GO


-- ----------------------------
-- procedure structure for spDocumentsByContainer
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocumentsByContainer]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [Documents].[spDocumentsByContainer]
GO

CREATE PROCEDURE [Documents].[spDocumentsByContainer]
  @container NVARCHAR(100) 
AS
BEGIN
	SELECT d.[id]
        ,d.[blobName]
        ,d.[title]
        ,d.[modifiedDate]
        ,d.[mimeType]
        ,df.[name] as [folderName]
        ,dpf.[name] as [parentFolderName]
     FROM [documents].[Document] d 
     LEFT JOIN [documents].[Folder] df ON d.[parentEntityId] = df.[id] AND d.[parentEntityType] = 'folder'
     LEFT JOIN [documents].[Folder] dpf ON df.[parentFolderId] = dpf.[id]
     WHERE d.[container] = @container
     AND d.[activeTo] IS NULL
     AND d.[mimeType] NOT LIKE 'image%'
END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectVersions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectVersions]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [Documents].[spDocument_SelectVersions]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectVersions]	
	@documentId INT
AS
BEGIN
  	
	SET NOCOUNT ON;
	
	;With docs as
		(
			SELECT [documentId], [parentDocId] FROM [documents].[DocumentVersion]
			 WHERE [documentId] = @documentId
			 UNION ALL
			SELECT dv.[documentId], dv.[parentDocId] FROM [documents].[DocumentVersion] dv
			 -- Will allow matching to all documents in the upstream hieracrhy
			 INNER JOIN docs d ON dv.[documentId] = d.[parentDocId]
		)

		SELECT d.*
				,u.displayName as [userDisplayName]
				,u.picture as [userPicture]
				,u.email as [userEmail]
	  FROM [documents].[document] d
	LEFT JOIN [registrations].[UserAccount] u on u.[id] = d.[userAccountId]
	 WHERE d.[id] in (select [parentDocId] FROM docs)
		ORDER BY d.[modifiedDate] DESC

END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectForEntity
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectForEntity]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [Documents].[spDocument_SelectForEntity]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectForEntity]
    @parentEntityId INT
   ,@parentEntityType NVARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT d.*
                ,u.displayName as [userDisplayName]
                ,u.picture as [userPicture]
                ,u.email as [userEmail]
                ,di.owner as [ownerName]
                ,di.reviewDate
	  FROM [documents].[document] d
	LEFT JOIN [registrations].[UserAccount] u on u.[id] = d.[userAccountId]
	LEFT JOIN [documents].[DocumentInfo] di on di.[documentId] = d.[id]
	 WHERE d.[parentEntityId] = @parentEntityId 
	   AND d.[parentEntityType] = @parentEntityType
		 AND d.[activeTo] IS NULL
		ORDER BY d.[modifiedDate] DESC
END
GO


-- ----------------------------
-- Auto increment value for Document
-- ----------------------------
DBCC CHECKIDENT ('[Documents].[Document]', RESEED, 359)
GO


-- ----------------------------
-- Indexes structure for table Document
-- ----------------------------
CREATE NONCLUSTERED INDEX [IDX_Document_parent]
ON [Documents].[Document] (
  [parentEntityId] ASC,
  [parentEntityType] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table Document
-- ----------------------------
ALTER TABLE [Documents].[Document] ADD CONSTRAINT [PK__Document__3213E83F31DADF25] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

