/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [PROD]
 Source Server Type    : SQL Server
 Source Server Version : 12001017 (12.00.1017)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczprod
 Source Schema         : currency

 Target Server Type    : SQL Server
 Target Server Version : 12001017 (12.00.1017)
 File Encoding         : 65001

 Date: 26/11/2025 10:33:01
*/


-- ----------------------------
-- Table structure for CurrencyRate
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[currency].[CurrencyRate]') AND type IN ('U'))
	DROP TABLE [currency].[CurrencyRate]
GO

CREATE TABLE [currency].[CurrencyRate] (
  [currency] nvarchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [rate] decimal(10,2)  NOT NULL,
  [updatedDate] datetime  NULL
)
GO

ALTER TABLE [currency].[CurrencyRate] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of CurrencyRate
-- ----------------------------
INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'AED', N'3.67', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'AFN', N'66.36', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ALL', N'83.97', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'AMD', N'381.91', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ANG', N'1.79', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'AOA', N'915.36', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ARS', N'1422.74', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'AUD', N'1.55', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'AWG', N'1.80', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'AZN', N'1.70', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BAM', N'1.70', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BBD', N'2.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BDT', N'122.55', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BGN', N'1.70', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BHD', N'0.38', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BIF', N'2947.95', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BMD', N'1.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BND', N'1.31', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BOB', N'6.91', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BRL', N'5.40', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BSD', N'1.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BTC', N'0.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BTN', N'89.46', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BWP', N'13.48', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BYN', N'3.41', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'BZD', N'2.01', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CAD', N'1.41', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CDF', N'2276.61', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CHF', N'0.81', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CLF', N'0.02', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CLP', N'938.99', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CNH', N'7.11', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CNY', N'7.11', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'COP', N'3759.05', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CRC', N'500.33', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CUC', N'1.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CUP', N'25.75', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CVE', N'95.80', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'CZK', N'21.04', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'DJF', N'178.01', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'DKK', N'6.48', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'DOP', N'63.10', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'DZD', N'130.77', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'EGP', N'47.52', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ERN', N'15.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ETB', N'154.73', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'EUR', N'0.87', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'FJD', N'2.29', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'FKP', N'0.76', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'GBP', N'0.76', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'GEL', N'2.70', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'GGP', N'0.76', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'GHS', N'11.12', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'GIP', N'0.76', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'GMD', N'73.50', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'GNF', N'8682.47', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'GTQ', N'7.66', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'GYD', N'209.14', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'HKD', N'7.78', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'HNL', N'26.31', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'HRK', N'6.54', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'HTG', N'130.89', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'HUF', N'333.09', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'IDR', N'16705.32', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ILS', N'3.27', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'IMP', N'0.76', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'INR', N'89.20', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'IQD', N'1309.51', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'IRR', N'42100.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ISK', N'127.60', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'JEP', N'0.76', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'JMD', N'160.75', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'JOD', N'0.71', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'JPY', N'156.55', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'KES', N'129.40', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'KGS', N'87.45', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'KHR', N'3998.12', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'KMF', N'428.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'KPW', N'900.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'KRW', N'1476.31', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'KWD', N'0.31', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'KYD', N'0.83', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'KZT', N'520.45', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'LAK', N'21704.09', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'LBP', N'89568.38', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'LKR', N'307.69', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'LRD', N'178.93', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'LSL', N'17.37', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'LYD', N'5.47', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MAD', N'9.29', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MDL', N'17.15', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MGA', N'4513.27', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MKD', N'53.45', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MMK', N'2099.70', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MNT', N'3582.15', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MOP', N'8.02', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MRU', N'39.57', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MUR', N'46.26', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MVR', N'15.40', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MWK', N'1733.38', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MXN', N'18.48', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MYR', N'4.14', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'MZN', N'63.91', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'NAD', N'17.37', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'NGN', N'1452.68', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'NIO', N'36.78', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'NOK', N'10.24', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'NPR', N'143.13', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'NZD', N'1.78', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'OMR', N'0.38', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'PAB', N'1.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'PEN', N'3.38', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'PGK', N'4.23', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'PHP', N'58.94', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'PKR', N'282.47', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'PLN', N'3.68', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'PYG', N'7012.74', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'QAR', N'3.64', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'RON', N'4.42', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'RSD', N'101.92', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'RUB', N'78.96', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'RWF', N'1453.46', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SAR', N'3.75', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SBD', N'8.23', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SCR', N'13.95', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SDG', N'601.50', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SEK', N'9.55', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SGD', N'1.31', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SHP', N'0.76', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SLE', N'23.38', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SLL', N'20969.50', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SOS', N'570.26', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SRD', N'38.55', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SSP', N'130.26', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'STD', N'22281.80', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'STN', N'21.29', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SVC', N'8.75', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SYP', N'13002.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'SZL', N'17.37', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'THB', N'32.49', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'TJS', N'9.22', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'TMT', N'3.51', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'TND', N'2.96', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'TOP', N'2.41', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'TRY', N'42.44', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'TTD', N'6.79', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'TWD', N'31.46', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'TZS', N'2459.07', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'UAH', N'42.28', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'UGX', N'3633.22', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'USD', N'1.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'UYU', N'39.76', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'UZS', N'11966.66', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'VES', N'241.18', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'VND', N'26374.79', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'VUV', N'122.16', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'WST', N'2.82', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XAF', N'569.36', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XAG', N'0.02', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XAU', N'0.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XCD', N'2.70', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XCG', N'1.80', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XDR', N'0.71', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XOF', N'569.36', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XPD', N'0.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XPF', N'103.58', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'XPT', N'0.00', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'YER', N'238.50', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ZAR', N'17.38', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ZMW', N'23.07', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ZWG', N'26.41', N'2025-11-24 06:00:01.217')
GO

INSERT INTO [currency].[CurrencyRate] ([currency], [rate], [updatedDate]) VALUES (N'ZWL', N'322.00', N'2025-11-24 06:00:01.217')
GO


-- ----------------------------
-- function structure for fnAmountToUSD
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[currency].[fnAmountToUSD]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION [currency].[fnAmountToUSD]
GO

CREATE FUNCTION [currency].[fnAmountToUSD] (
  @currency NVARCHAR(10),
  @amount DECIMAL(10, 2)
)
RETURNS DECIMAL(10, 2)
AS
BEGIN

  return (Select @amount/rate from currency.CurrencyRate where currency = @currency);

END
GO


-- ----------------------------
-- procedure structure for spCurrency_AddRate
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[currency].[spCurrency_AddRate]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE [currency].[spCurrency_AddRate]
GO

CREATE PROCEDURE [currency].[spCurrency_AddRate]
	@currency_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @currency TABLE(
		[currency] nvarchar(100),
		[rate] decimal(10,2)
	)
	INSERT INTO @currency ([currency], [rate])
	SELECT ln.[currency], ln.[rate]
	  FROM OPENJSON(@currency_JSON) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[currency] nvarchar(100),
		[rate] decimal(10,2)
	) ln;

	MERGE [currency].[CurrencyRate] cr
		USING @currency c
	ON (c.[currency] = cr.[currency])
	WHEN MATCHED
		THEN UPDATE
			SET cr.[currency] = c.[currency],
					cr.[rate] = c.[rate],
					cr.[updatedDate] = GETDATE()
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([currency], [rate], [updatedDate])
			 VALUES (c.[currency], c.[rate], GETDATE())
	--WHEN NOT MATCHED BY SOURCE
		-- THEN do nothing
	;

	Return 1;
END
GO


-- ----------------------------
-- Primary Key structure for table CurrencyRate
-- ----------------------------
ALTER TABLE [currency].[CurrencyRate] ADD CONSTRAINT [PK__Currency__AFC4E28581341A87] PRIMARY KEY CLUSTERED ([currency])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

