/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : portal

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:34:13
*/


-- ----------------------------
-- Table structure for Application
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Application]') AND type IN ('U'))
	DROP TABLE [portal].[Application]
GO

CREATE TABLE [portal].[Application] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [path] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[Application] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Application
-- ----------------------------
SET IDENTITY_INSERT [portal].[Application] ON
GO

INSERT INTO [portal].[Application] ([id], [name], [description], [path], [displayName]) VALUES (N'1', N'nczportal', NULL, NULL, NULL)
GO

SET IDENTITY_INSERT [portal].[Application] OFF
GO


-- ----------------------------
-- Table structure for ApplicationFeature
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationFeature]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationFeature]
GO

CREATE TABLE [portal].[ApplicationFeature] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationId] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[ApplicationFeature] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ApplicationFeature
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationFeature] ON
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'1', N'1', N'adm-dashboard', N'Admin only', N'Dashboard (Admin)')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'2', N'1', N'adm-companies', N'Admin only', N'Companies  (Admin)')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'3', N'1', N'adm-certifications', N'Admin only', N'Certifications  (Admin)')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'4', N'1', N'submissions', NULL, N'Submissions')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'5', N'1', N'adm-users', N'Admin only', N'Users  (Admin)')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'7', N'1', N'dashboard', NULL, N'Dashboard')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'8', N'1', N'certifications', NULL, N'Certifications')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'9', N'1', N'users', NULL, N'Users')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'10', N'1', N'locations', NULL, N'Locations')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'11', N'1', N'ncz-directory', NULL, N'NCZ Directory')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'6', N'1', N'adm-settings', N'Admin only', N'Settings (Admin)')
GO

SET IDENTITY_INSERT [portal].[ApplicationFeature] OFF
GO


-- ----------------------------
-- Table structure for ApplicationFeatureOption
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationFeatureOption]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationFeatureOption]
GO

CREATE TABLE [portal].[ApplicationFeatureOption] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationFeatureId] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[ApplicationFeatureOption] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ApplicationFeatureOption
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationFeatureOption] ON
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'1', N'1', N'availableFromMainMenu', N'Show Dashboard link in menu', N'Show Dashboard on menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'2', N'2', N'availableFromMainMenu', N'Show Companies', N'Show Companies on menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'5', N'2', N'add', N'Add Comapany', N'Add Company')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'6', N'2', N'edit', N'Edit Company', N'Edit Company')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'7', N'2', N'delete', N'Delete Company', N'Delete Company')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'9', N'3', N'add', N'Add Certification', N'Add Certification')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'10', N'3', N'edit', N'Edit Certification', N'Edit Certification')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'11', N'3', N'delete', N'Delete Certification', N'Delete Certification')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'12', N'3', N'availableFromMainMenu', N'Show Certifications', N'Show Certifications on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'13', N'4', N'add', N'Add Submission', N'Add Submission')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'14', N'5', N'add', N'Add User', N'Add User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'15', N'5', N'edit', N'Edit User', N'Edit User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'16', N'5', N'delete', N'Delete User', N'Delete User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'18', N'5', N'availableFromMainMenu', N'Show Users', N'Show Users on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'21', N'7', N'availableFromMainMenu', N'Show Dashboard link in menu', N'Show Dashboard on menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'22', N'8', N'availableFromMainMenu', N'Show Certifications', N'Show Certifications on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'23', N'9', N'availableFromMainMenu', N'Show Users', N'Show Users on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'24', N'9', N'add', N'Add User', N'Add User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'25', N'9', N'edit', N'Edit User', N'Edit User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'26', N'9', N'delete', N'Delete User', N'Delete User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'27', N'10', N'add', N'Add Location', N'Add Location')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'28', N'10', N'edit', N'Edit Location', N'Edit Location')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'29', N'10', N'delete', N'Delete Location', N'Delete Location')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'30', N'10', N'availableFromMainMenu', N'Show Locations on menu', N'Show Locations on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'31', N'4', N'delete', N'Delete Submission', N'Delete Submission')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'32', N'11', N'availableFromMainMenu', N'Show Customer directory on menu', N'Show Customer directory on menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'33', N'11', N'settings', N'Change settings of NCZ directory item', N'Change settings of NCZ directory item')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'34', N'3', N'uploadDocument', N'Upload Document for Certification', N'Upload Document for Certification')
GO

SET IDENTITY_INSERT [portal].[ApplicationFeatureOption] OFF
GO


-- ----------------------------
-- Table structure for ApplicationRole
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationRole]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationRole]
GO

CREATE TABLE [portal].[ApplicationRole] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationId] int  NOT NULL,
  [applicationAccessId] int  NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [roleScope] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [companyId] int DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[ApplicationRole] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'admin, client, both',
'SCHEMA', N'portal',
'TABLE', N'ApplicationRole',
'COLUMN', N'roleScope'
GO

EXEC sp_addextendedproperty
'MS_Description', N'0 = available to all companies',
'SCHEMA', N'portal',
'TABLE', N'ApplicationRole',
'COLUMN', N'companyId'
GO


-- ----------------------------
-- Records of ApplicationRole
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationRole] ON
GO

INSERT INTO [portal].[ApplicationRole] ([id], [applicationId], [applicationAccessId], [name], [description], [roleScope], [companyId]) VALUES (N'1', N'1', NULL, N'Super Admin', N'NCZ Admin ', N'admin', N'0')
GO

INSERT INTO [portal].[ApplicationRole] ([id], [applicationId], [applicationAccessId], [name], [description], [roleScope], [companyId]) VALUES (N'2', N'1', NULL, N'Admin', N'Client''s Admin user', N'client', N'0')
GO

INSERT INTO [portal].[ApplicationRole] ([id], [applicationId], [applicationAccessId], [name], [description], [roleScope], [companyId]) VALUES (N'3', N'1', NULL, N'Operator', NULL, N'client', N'0')
GO

INSERT INTO [portal].[ApplicationRole] ([id], [applicationId], [applicationAccessId], [name], [description], [roleScope], [companyId]) VALUES (N'4', N'1', NULL, N'Standard', NULL, N'admin', N'0')
GO

SET IDENTITY_INSERT [portal].[ApplicationRole] OFF
GO


-- ----------------------------
-- Table structure for ApplicationRoleOption
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationRoleOption]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationRoleOption]
GO

CREATE TABLE [portal].[ApplicationRoleOption] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationRoleId] int  NOT NULL,
  [applicationFeatureOptionId] int  NOT NULL,
  [available] bit  NOT NULL,
  [assignable] bit  NOT NULL
)
GO

ALTER TABLE [portal].[ApplicationRoleOption] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ApplicationRoleOption
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationRoleOption] ON
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'1', N'1', N'1', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'3', N'1', N'2', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'4', N'1', N'5', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'5', N'2', N'22', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'6', N'2', N'23', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'10', N'1', N'6', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'11', N'1', N'7', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'12', N'1', N'9', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'13', N'1', N'10', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'14', N'1', N'11', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'15', N'1', N'12', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'16', N'1', N'13', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'17', N'1', N'14', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'18', N'1', N'15', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'19', N'1', N'16', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'20', N'1', N'18', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'21', N'2', N'24', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'22', N'2', N'25', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'23', N'2', N'26', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'25', N'2', N'13', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'26', N'1', N'27', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'27', N'1', N'28', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'28', N'1', N'29', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'29', N'2', N'27', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'30', N'2', N'28', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'31', N'2', N'29', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'32', N'2', N'30', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'34', N'1', N'31', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'35', N'1', N'32', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'36', N'2', N'32', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'37', N'1', N'33', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'38', N'1', N'34', N'1', N'0')
GO

SET IDENTITY_INSERT [portal].[ApplicationRoleOption] OFF
GO


-- ----------------------------
-- Table structure for ApplicationUserGrant
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationUserGrant]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationUserGrant]
GO

CREATE TABLE [portal].[ApplicationUserGrant] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [userAccountId] int  NOT NULL,
  [applicationFeatureOptionId] int  NOT NULL,
  [assignedByUserAccountId] int  NULL,
  [assignedDate] datetime DEFAULT getdate() NULL,
  [available] bit  NOT NULL,
  [assignable] bit  NOT NULL
)
GO

ALTER TABLE [portal].[ApplicationUserGrant] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ApplicationUserGrant
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationUserGrant] ON
GO

SET IDENTITY_INSERT [portal].[ApplicationUserGrant] OFF
GO


-- ----------------------------
-- Table structure for ApplicationUserRoleGrant
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationUserRoleGrant]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationUserRoleGrant]
GO

CREATE TABLE [portal].[ApplicationUserRoleGrant] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationRoleId] int  NOT NULL,
  [userAccountId] int  NOT NULL,
  [assignedByUserAccountId] int  NULL
)
GO

ALTER TABLE [portal].[ApplicationUserRoleGrant] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ApplicationUserRoleGrant
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationUserRoleGrant] ON
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'3', N'1', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'4', N'1', N'2', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'5', N'1', N'4', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'6', N'2', N'5', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'7', N'2', N'7', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'8', N'2', N'8', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'9', N'2', N'10', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'10', N'2', N'13', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'11', N'4', N'16', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'12', N'4', N'17', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'13', N'4', N'18', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'14', N'3', N'19', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'15', N'3', N'20', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'16', N'2', N'21', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'17', N'3', N'23', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'40', N'2', N'47', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'41', N'1', N'48', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'42', N'4', N'49', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'44', N'2', N'51', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'47', N'2', N'54', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'49', N'2', N'56', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'50', N'2', N'57', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'52', N'2', N'59', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'53', N'2', N'60', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'55', N'2', N'62', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'57', N'2', N'64', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'58', N'2', N'65', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'59', N'2', N'66', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'43', N'2', N'50', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'45', N'2', N'52', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'46', N'2', N'53', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'48', N'2', N'55', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'51', N'2', N'58', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'54', N'2', N'61', N'0')
GO

INSERT INTO [portal].[ApplicationUserRoleGrant] ([id], [applicationRoleId], [userAccountId], [assignedByUserAccountId]) VALUES (N'56', N'2', N'63', N'0')
GO

SET IDENTITY_INSERT [portal].[ApplicationUserRoleGrant] OFF
GO


-- ----------------------------
-- Table structure for BlueAwardSubmissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[BlueAwardSubmissions]') AND type IN ('U'))
	DROP TABLE [portal].[BlueAwardSubmissions]
GO

CREATE TABLE [portal].[BlueAwardSubmissions] (
  [bluesubmissionId] int  IDENTITY(1,1) NOT NULL,
  [jotformId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [status] int  NULL,
  [notes] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dateSubmitted] datetime2(7)  NULL,
  [isProcessed] bit DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[BlueAwardSubmissions] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'status list from dropdownitems',
'SCHEMA', N'portal',
'TABLE', N'BlueAwardSubmissions',
'COLUMN', N'status'
GO


-- ----------------------------
-- Records of BlueAwardSubmissions
-- ----------------------------
SET IDENTITY_INSERT [portal].[BlueAwardSubmissions] ON
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'1', N'241290444812856', N'6236322365118962345', NULL, NULL, N'2025-05-21 10:23:58.1966667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'2', N'241290444812856', N'6236495726014477567', NULL, NULL, N'2025-05-21 15:12:53.4200000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'3', N'241290444812856', N'6236518286317384163', NULL, NULL, N'2025-05-21 15:50:31.1600000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'4', N'241290444812856', N'6237288775968528255', NULL, NULL, N'2025-05-22 13:14:39.1866667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'5', N'241290444812856', N'6238061920511511277', NULL, NULL, N'2025-05-23 10:43:15.0966667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'6', N'241290444812856', N'6238192886613077520', NULL, NULL, N'2025-05-23 14:21:30.1966667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'7', N'241290444812856', N'6238222680617851255', NULL, NULL, N'2025-05-23 15:11:10.1766667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'8', N'241290444812856', N'6243203173315658824', NULL, NULL, N'2025-05-29 09:31:59.3500000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'9', N'241290444812856', N'6243214686811646816', NULL, NULL, N'2025-05-29 09:51:09.3400000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'10', N'241290444812856', N'6243369576811984272', NULL, NULL, N'2025-05-29 14:09:18.0466667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'11', N'241290444812856', N'6246727163513640994', NULL, NULL, N'2025-06-02 11:25:19.3266667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'12', N'241290444812856', N'6249557036144155257', NULL, NULL, N'2025-06-05 18:01:45.1700000', N'0')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'13', N'241290444812856', N'6251829638249313445', NULL, NULL, N'2025-06-08 09:09:27.5633333', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'14', N'241290444812856', N'6254360356312890112', NULL, N'LMPC Ltd', N'2025-06-11 07:27:17.1900000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'15', N'241290444812856', N'6255283822315766796', NULL, N'ZJ Mechanical Ltd t/a ZJ Building Services', N'2025-06-12 09:06:24.5033333', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'16', N'241290444812856', N'6255375572121715048', NULL, N'Stonebridge FM Consulting Ltd.', N'2025-06-12 11:39:19.3633333', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'17', N'241290444812856', N'6255477496427994389', NULL, N'Proactive Cleaners Ltd', N'2025-06-12 14:29:11.1433333', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'18', N'241290444812856', N'6256226525126533161', NULL, N'B.K.R Cleaning', N'2025-06-13 11:17:34.2000000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'19', N'241290444812856', N'6257041746316091121', NULL, N'AQUA CLEAN', N'2025-06-14 09:56:16.6733333', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'20', N'241290444812856', N'6259669170015118711', NULL, N'A & R Chemicals LTD', N'2025-06-17 10:55:19.2066667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'21', N'241290444812856', N'6260595005714454902', NULL, N'Just Save Ltd', N'2025-06-18 13:01:32.7900000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'22', N'241290444812856', N'6243214686811646816', NULL, N'Jacobs Jackets', N'2025-06-19 09:27:18.6266667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'23', N'241290444812856', N'6259669170015118711', NULL, N'A & R Chemicals LTD', N'2025-06-19 09:27:59.2166667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'24', N'241290444812856', N'6264900542522165909', NULL, N'UK Merchandising Ltd.', N'2025-06-23 12:14:16.0666667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'25', N'241290444812856', N'6264994938328645568', NULL, N'Surrey Ceramics', N'2025-06-23 14:51:34.2300000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'26', N'241290444812856', N'6265001578129838432', NULL, N'Grunwerg', N'2025-06-23 15:02:38.0933333', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'27', N'241290444812856', N'6265834248314077382', NULL, N'JDS Products Ltd', N'2025-06-24 14:10:27.1033333', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'28', N'241290444812856', N'6265838208318326502', NULL, N'JDS Products Ltd', N'2025-06-24 14:17:02.6200000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'29', N'241290444812856', N'6266303336427363207', NULL, N'Oriental Raise Stone', N'2025-06-25 03:12:18.4666667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'30', N'241290444812856', N'6268318365115290258', NULL, N'Yorkshire Cleaning Fabrics Limited', N'2025-06-27 11:10:38.4066667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'31', N'241290444812856', N'6271022482013702931', NULL, N'Nicholls Solicitors', N'2025-06-30 14:17:29.4200000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'32', N'241290444812856', N'6272634872022180565', NULL, N'Multy UK', N'2025-07-02 11:04:49.1166667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'33', N'241290444812856', N'6273804123517168863', NULL, N'South eastern Gas Service Ltd', N'2025-07-03 19:33:35.1266667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'34', N'241290444812856', N'6275314597983371042', NULL, N'Noble creations limited', N'2025-07-05 13:31:01.7700000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'35', N'241290444812856', N'6276910596832192626', NULL, N'Geldbach UK Ltd', N'2025-07-07 09:51:00.0600000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'36', N'241290444812856', N'6276942367846198673', NULL, N'AURA UK', N'2025-07-07 10:43:58.0066667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'37', N'241290444812856', N'6277054487843807779', NULL, N'BDMA', N'2025-07-07 13:50:49.0900000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'38', N'241290444812856', N'6277066738323383880', NULL, N'Bad Betty Press', N'2025-07-07 14:11:13.7000000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'39', N'241290444812856', N'6277183666603360806', NULL, N'ABC Construction', N'2025-07-07 17:26:08.0000000', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'40', N'241290444812856', N'6277196999706081541', NULL, N'Forma. Srl', N'2025-07-07 17:48:21.0566667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'41', N'241290444812856', N'6278586819919708096', NULL, N'Barre Bouillet', N'2025-07-09 08:24:42.0833333', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'42', N'241290444812856', N'6278690670528642864', NULL, N'TWC (services) Ltd', N'2025-07-09 11:17:49.0666667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'43', N'241290444812856', N'6278726196426632178', NULL, N'C & P INSTALL LIMITED', N'2025-07-09 12:17:01.7366667', N'1')
GO

INSERT INTO [portal].[BlueAwardSubmissions] ([bluesubmissionId], [jotformId], [submissionId], [status], [notes], [dateSubmitted], [isProcessed]) VALUES (N'44', N'241290444812856', N'6278763937248661509', NULL, N'BIO PRODUCTIONS LTD', N'2025-07-09 13:19:55.0333333', N'1')
GO

SET IDENTITY_INSERT [portal].[BlueAwardSubmissions] OFF
GO


-- ----------------------------
-- Table structure for CertFormSubmissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[CertFormSubmissions]') AND type IN ('U'))
	DROP TABLE [portal].[CertFormSubmissions]
GO

CREATE TABLE [portal].[CertFormSubmissions] (
  [certsubmissionId] int  IDENTITY(1,1) NOT NULL,
  [certId] int  NULL,
  [jotformId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
  [dateSubmitted] datetime2(7)  NULL,
  [userId] int DEFAULT 0 NULL,
  [locationId] int DEFAULT 0 NULL,
  [notes] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
  [isProcessed] bit DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[CertFormSubmissions] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'jotform submission Id',
'SCHEMA', N'portal',
'TABLE', N'CertFormSubmissions',
'COLUMN', N'submissionId'
GO


-- ----------------------------
-- Records of CertFormSubmissions
-- ----------------------------
SET IDENTITY_INSERT [portal].[CertFormSubmissions] ON
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'3', N'2', N'231921316591454', N'6193173424015696087', N'2025-04-01 18:08:45.1033333', N'1', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'6', N'1', N'231921316591454', N'6193976154017903617', N'2025-04-02 10:06:57.1766667', N'1', N'1', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'7', N'1', N'231835207128453', N'6193981554012635180', N'2025-04-02 10:15:57.5900000', N'1', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'8', N'1', N'231761029921959', N'6193995164012556487', N'2025-04-02 10:38:36.6333333', N'1', N'1', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'9', N'1', N'231702222306037', N'6194006984012454718', N'2025-04-02 10:58:19.0733333', N'1', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'10', N'1', N'232102389529457', N'6194017342313531702', N'2025-04-02 11:15:35.3233333', N'0', N'1', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'11', N'1', N'232102389529457', N'6194019172311018628', N'2025-04-02 11:18:38.0733333', N'0', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'12', N'1', N'232102389529457', N'6194024082316593814', N'2025-04-02 11:26:49.0233333', N'0', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'13', N'1', N'232102389529457', N'6194029322318719993', N'2025-04-02 11:35:33.2133333', N'0', N'1', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'14', N'1', N'232102389529457', N'6194032112315223579', N'2025-04-02 11:40:12.0100000', N'0', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'37', N'11', N'231835207128453', N'6195667867313524477', N'2025-04-04 09:06:27.0066667', N'1', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'38', N'11', N'232102389529457', N'6195669097313324753', N'2025-04-04 09:08:30.0300000', N'0', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'39', N'4', N'231835207128453', N'6195710422934785523', N'2025-04-04 10:17:23.0400000', N'1', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'40', N'4', N'232102389529457', N'6195711632931883276', N'2025-04-04 10:19:24.2900000', N'0', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'41', N'2', N'231835207128453', N'6210586964749222845', N'2025-04-21 15:31:37.7166667', N'1', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'42', N'1', N'231951471518458', N'6217108352294372461', N'2025-04-29 04:40:36.6733333', N'50', N'1', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'43', N'1', N'232571467469467', N'6217128022299967832', N'2025-04-29 05:13:23.1466667', N'48', N'1', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'47', N'2', N'250151633085854', NULL, N'2025-05-14 06:26:04.4233333', N'47', N'9', N'Submit once', N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'49', N'1', N'231953063487462', N'6230256798515053525', N'2025-05-14 09:53:33.5566667', N'1', N'1', N'May 2025', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'55', N'1', N'232408584059461', N'6230912668518914542', N'2025-05-15 04:05:47.8700000', N'1', N'1', N'May 2025', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'59', N'2', N'231761029921959', N'6234675030719390109', N'2025-05-15 04:44:32.5500000', N'47', N'9', N'May 2025', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'60', N'2', N'231702222306037', N'6234612610714678859', N'2025-05-19 10:51:23.1933333', N'47', N'9', N'May 2025', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'61', N'2', N'231761029921959', N'6235275890712757177', N'2025-05-20 04:05:29.2666667', N'1', N'14', N'Test submit', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'62', N'2', N'231835207128453', N'6235290420718688617', N'2025-05-20 05:42:54.2233333', N'47', N'14', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'63', N'5', N'241290444812856', N'6249942972018278064', N'2025-06-06 04:41:09.8900000', N'1', N'15', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'65', N'14', N'241290444812856', N'6249973352011514018', N'2025-06-06 05:33:49.6700000', N'1', N'16', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'66', N'14', N'231921316591454', N'6249975342015274746', N'2025-06-06 05:38:08.9066667', N'1', N'16', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'67', N'2', N'231921316591454', NULL, N'2025-06-09 16:12:01.6133333', N'5', N'9', NULL, N'0')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'69', N'9', N'250151633085854', N'6253464270129242734', N'2025-06-10 06:32:03.4400000', N'1', N'18', N'company profile', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'70', N'19', N'241290444812856', N'6253556530124906427', N'2025-06-10 09:04:56.5133333', N'1', N'19', N'Company profile ', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'71', N'19', N'231835207128453', N'6253558700122492945', N'2025-06-10 09:10:23.1733333', N'1', N'19', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'72', N'19', N'231921316591454', N'6253682860128473115', N'2025-06-10 12:37:00.5233333', N'1', N'19', N'Water', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'73', N'19', N'231761029921959', N'6253683470124399000', N'2025-06-10 12:38:19.7433333', N'1', N'19', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'74', N'19', N'231702222306037', N'6253684340121642187', N'2025-06-10 12:39:26.3433333', N'1', N'19', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'75', N'19', N'232571467469467', N'6254307567613906627', N'2025-06-11 05:57:51.4400000', N'1', N'19', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'76', N'9', N'231702222306037', N'6255390279309256926', N'2025-06-12 10:30:59.3200000', N'1', N'18', N'Amount Spend test', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'77', N'9', N'231702222306037', N'6256227804425962028', N'2025-06-13 11:16:53.9366667', N'1', N'18', N'Amount spend test 2', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'78', N'9', N'232013593953456', N'6258869637535939907', N'2025-06-16 12:40:02.8300000', N'1', N'18', N'Amount spend test', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'79', N'9', N'232408584059461', N'6259627322363709177', N'2025-06-17 09:44:42.4000000', N'1', N'18', N'Amount spend test', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'80', N'9', N'232408584059461', N'6259630762368417260', N'2025-06-17 09:46:58.0400000', N'1', N'18', N'Amount spend test for itemised', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'81', N'9', N'232561815184457', N'6259631672364246235', N'2025-06-17 09:51:59.3400000', N'1', N'18', N'Amount spend Test', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'82', N'9', N'232561815184457', N'6259632772363730664', N'2025-06-17 09:53:31.2566667', N'1', N'18', N'Amount spend test for itemised', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'83', N'9', N'231702222306037', N'6260505202216845269', N'2025-06-18 10:03:10.6900000', N'1', N'18', N'Airport distance test', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'84', N'9', N'231702222306037', N'6260573832219223226', N'2025-06-18 11:45:46.2166667', N'1', N'18', N'Airport distance test monthly', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'85', N'9', N'232571467469467', N'6260602862219136613', N'2025-06-18 12:43:44.8500000', N'1', N'18', N'Amount Spend test', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'86', N'9', N'232571467469467', N'6261366827415905463', N'2025-06-19 10:01:07.5833333', N'1', N'18', N'Charging percent test', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'87', N'9', N'232102389529457', N'6261513717413528626', N'2025-06-19 14:09:32.1033333', N'0', N'0', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'88', N'9', N'232102389529457', N'6262037193603587303', N'2025-06-20 04:42:00.1300000', N'0', N'0', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'89', N'9', N'231835207128453', N'6262060353609154181', N'2025-06-20 05:16:22.0466667', N'1', N'18', N'Tariff calculation', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'90', N'9', N'231835207128453', N'6262121393604004409', N'2025-06-20 06:47:58.6066667', N'1', N'18', N'Tariff Calculation Monthly', N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'91', N'9', N'232102389529457', N'6262219863608598377', N'2025-06-20 09:46:27.6766667', N'0', N'0', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'92', N'20', N'241290444812856', N'6264808340817048146', N'2025-06-23 09:37:22.8500000', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'93', N'20', N'231835207128453', N'6264809180814289831', N'2025-06-23 09:40:55.4233333', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'94', N'20', N'231921316591454', N'6264809760816479212', N'2025-06-23 09:42:11.9766667', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'95', N'20', N'231761029921959', N'6264810400815472383', N'2025-06-23 09:43:16.2733333', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'96', N'20', N'231951471518458', N'6264811730819079312', N'2025-06-23 09:44:13.2100000', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'97', N'20', N'232571467469467', N'6264813670812174796', N'2025-06-23 09:46:25.2100000', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'98', N'20', N'231702222306037', N'6264817060812033994', N'2025-06-23 09:49:41.4600000', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'99', N'20', N'231953063487462', N'6264817610812381099', N'2025-06-23 09:55:23.0400000', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'100', N'20', N'232013593953456', N'6264818190813506621', N'2025-06-23 09:56:16.5600000', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'101', N'20', N'231998306100453', N'6264818880819554238', N'2025-06-23 09:57:23.6766667', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'102', N'20', N'232408584059461', N'6264819470818155106', N'2025-06-23 09:58:22.1933333', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'103', N'20', N'232561815184457', N'6264820830811754274', N'2025-06-23 09:59:23.3400000', N'1', N'20', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'104', N'20', N'232102389529457', N'6264823840812989433', N'2025-06-23 10:06:25.1033333', N'0', N'0', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'105', N'20', N'232102389529457', N'6264835830811236722', N'2025-06-23 10:26:25.0333333', N'0', N'0', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'106', N'20', N'232102389529457', N'6264848670814445032', N'2025-06-23 10:47:48.4100000', N'0', N'0', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'107', N'20', N'232102389529457', N'6264849710813741588', N'2025-06-23 10:49:31.9500000', N'0', N'0', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'108', N'20', N'232102389529457', N'6264853310812303949', N'2025-06-23 10:55:32.0800000', N'0', N'0', NULL, N'1')
GO

INSERT INTO [portal].[CertFormSubmissions] ([certsubmissionId], [certId], [jotformId], [submissionId], [dateSubmitted], [userId], [locationId], [notes], [isProcessed]) VALUES (N'109', N'4', N'232102389529457', N'6276887910226455851', N'2025-07-07 09:13:12.9866667', N'0', N'0', N'First Last (work@email.com)', N'1')
GO

SET IDENTITY_INSERT [portal].[CertFormSubmissions] OFF
GO


-- ----------------------------
-- Table structure for Certification
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Certification]') AND type IN ('U'))
	DROP TABLE [portal].[Certification]
GO

CREATE TABLE [portal].[Certification] (
  [certId] int  IDENTITY(1,1) NOT NULL,
  [companyId] int  NULL,
  [progId] int  NULL,
  [startDate] datetime2(7)  NULL,
  [endDate] datetime2(7)  NULL,
  [status] int  NULL,
  [description] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [clickupTaskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [certYear] int  NULL,
  [isDeleted] bit DEFAULT 0 NULL,
  [dateUpdated] datetime2(7) DEFAULT getdate() NULL,
  [refNumber] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[Certification] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Certification
-- ----------------------------
SET IDENTITY_INSERT [portal].[Certification] ON
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'1', N'1', N'2', N'2025-03-10 15:11:35.0000000', N'2026-03-09 15:11:35.0000000', N'1', N'descr', N'8698xdpcx', N'2025', N'0', NULL, N'ALP-2025-001')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'2', N'2', N'3', N'2025-03-19 16:20:15.0000000', N'2026-03-18 16:20:15.0000000', N'1', NULL, NULL, N'2025', N'0', NULL, NULL)
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'3', N'1', N'2', N'2025-03-25 18:30:00.0000000', NULL, N'1', N'assafsdf', NULL, NULL, N'1', N'2025-04-17 13:45:32.1800000', NULL)
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'4', N'3', N'3', N'2025-03-25 18:30:00.0000000', N'2026-03-24 18:30:00.0000000', N'1', N'gdfgdfg', NULL, N'2025', N'0', N'2025-03-26 15:28:34.2700000', NULL)
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'5', N'4', N'2', N'2025-03-26 18:30:00.0000000', N'2026-03-25 18:30:00.0000000', N'1', N'rerterte', N'8699b0zny', N'2025', N'0', N'2025-03-27 16:13:25.4366667', NULL)
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'6', N'48', N'3', N'2025-03-25 18:30:00.0000000', N'2026-03-24 18:30:00.0000000', N'1', NULL, NULL, N'2025', N'1', N'2025-04-17 04:56:52.1966667', NULL)
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'7', N'9', N'4', N'2025-03-13 18:30:00.0000000', N'2026-03-12 18:30:00.0000000', N'1', NULL, NULL, N'2025', N'1', N'2025-04-03 12:32:26.4266667', NULL)
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'8', N'9', N'3', N'2025-03-13 18:30:00.0000000', N'2026-03-12 18:30:00.0000000', N'1', N'descr', NULL, N'2025', N'1', N'2025-04-03 12:32:24.2100000', NULL)
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'9', N'21', N'3', N'2025-03-25 18:30:00.0000000', N'2026-03-24 18:30:00.0000000', N'1', N'descr', N'123456', N'2025', N'0', N'2025-04-03 12:30:35.4833333', N'PHT-2025-001')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'10', N'17', N'4', N'2025-03-13 18:30:00.0000000', N'2026-03-12 18:30:00.0000000', N'1', N'descr', NULL, N'2025', N'0', N'2025-04-03 12:32:57.8166667', N'RHS-2025-001')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'11', N'50', N'3', N'2025-04-03 18:30:00.0000000', N'2026-04-02 18:30:00.0000000', N'1', NULL, NULL, N'2025', N'1', N'2025-05-01 09:48:03.8700000', N'TST-2025-001')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'12', N'50', N'2', N'2025-04-29 18:30:00.0000000', N'2026-04-28 18:30:00.0000000', N'1', NULL, NULL, N'2025', N'1', N'2025-04-30 07:11:29.2900000', N'TST-2025-01')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'13', N'24', N'2', N'2025-04-29 18:30:00.0000000', N'2026-04-28 18:30:00.0000000', N'1', NULL, NULL, N'2025', N'1', N'2025-04-30 07:15:41.3333333', N'OMG-2025-01')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'14', N'24', N'2', N'2025-04-24 18:30:00.0000000', N'2026-04-23 18:30:00.0000000', N'1', NULL, N'8699b3rq9', N'2025', N'0', N'2025-04-30 09:06:12.0933333', N'OMG-2025-01')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'15', N'20', N'2', N'2025-04-29 18:30:00.0000000', N'2026-04-28 18:30:00.0000000', N'1', NULL, N'8698x2v3u', N'2025', N'0', N'2025-04-30 11:13:31.7800000', N'UPS-2025-01')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'16', N'14', N'3', N'2025-05-04 18:30:00.0000000', N'2026-05-03 18:30:00.0000000', N'1', NULL, N'8698xczfe', N'2025', N'1', N'2025-05-01 09:47:45.1633333', N'XiS-2025-01')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'17', N'50', N'3', N'2025-04-30 18:30:00.0000000', N'2026-04-29 18:30:00.0000000', N'1', NULL, N'8698xd9t7', N'2025', N'1', N'2025-05-01 09:58:36.9700000', N'TST-2025-01')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'18', N'50', N'3', N'2025-04-30 18:30:00.0000000', N'2026-04-29 18:30:00.0000000', N'1', NULL, NULL, N'2025', N'0', N'2025-05-01 10:33:18.6966667', N'TST-2025-01')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'19', N'6', N'2', N'2025-06-09 18:30:00.0000000', N'2026-06-08 18:30:00.0000000', N'1', N'TEST by RAM', N'8699c9pe3', N'2025', N'0', N'2025-06-10 08:51:37.1933333', N'RAM-2025-003')
GO

INSERT INTO [portal].[Certification] ([certId], [companyId], [progId], [startDate], [endDate], [status], [description], [clickupTaskId], [certYear], [isDeleted], [dateUpdated], [refNumber]) VALUES (N'20', N'51', N'2', N'2025-06-22 18:30:00.0000000', N'2026-06-21 18:30:00.0000000', N'1', N'Test of portal silver report', N'8699gxgp0', N'2025', N'0', N'2025-06-23 09:36:40.8266667', N'SLR-2025-001')
GO

SET IDENTITY_INSERT [portal].[Certification] OFF
GO


-- ----------------------------
-- Table structure for Company
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Company]') AND type IN ('U'))
	DROP TABLE [portal].[Company]
GO

CREATE TABLE [portal].[Company] (
  [companyId] int  IDENTITY(1,1) NOT NULL,
  [companyName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [email] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [registrationNumber] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [phone] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [address] nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [industryType] int  NULL,
  [website] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [status] int  NOT NULL,
  [logo] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [clickupTaskId] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dateCreated] datetime2(7)  NULL,
  [dateUpdated] datetime2(7)  NULL,
  [isDeleted] bit DEFAULT 0 NULL,
  [industryTypeOther] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
  [contactName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [jobTitle] nvarchar(75) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [countryId] int  NULL,
  [nczCustomerDirectory] bit DEFAULT 1 NULL,
  [linkedInPage] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(300) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[Company] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'dropdownItems groupId=3',
'SCHEMA', N'portal',
'TABLE', N'Company',
'COLUMN', N'countryId'
GO

EXEC sp_addextendedproperty
'MS_Description', N'Show in NCZ Customer Directory',
'SCHEMA', N'portal',
'TABLE', N'Company',
'COLUMN', N'nczCustomerDirectory'
GO


-- ----------------------------
-- Records of Company
-- ----------------------------
SET IDENTITY_INSERT [portal].[Company] ON
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'1', N'Alpha Tech', N'contact@alphatech.com', N'REG1001', N'+91-9998887771', N'123 Street, New Delhi', N'6', N'https://alphatech.com', N'1', NULL, NULL, NULL, N'2025-05-27 06:04:38.7266667', N'0', NULL, N'Jen Straus', N'Senior executive', N'32', N'1', NULL, N'This is description text')
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'2', N'Beta Solutions', N'info@betasolutions.com', N'REG1002', N'+91-9998887772', N'456 Road, Mumbai', N'7', N'https://betasolutions.com', N'1', NULL, NULL, NULL, N'2025-04-03 13:15:29.0266667', N'0', NULL, N'Sam peterson', N'Production Manager', N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'3', N'Gamma Corp', N'support@gammacorp.com', N'REG1003', N'+91-9998887773', N'789 Avenue, Bangalore', N'27', N'https://gammacorp.com', N'0', NULL, NULL, NULL, N'2025-03-27 18:31:56.6166667', N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'4', N'Delta Systems', N'sales@deltasystems.com', N'REG1004', N'+91-9998887774', N'101 Circle, Hyderabad', N'9', N'https://deltasystems.com', N'1', NULL, NULL, NULL, N'2025-05-26 06:26:32.8366667', N'0', NULL, N'Martin Crow', N'Director', N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'5', N'Epsilon Industries', N'hello@epsilon.com', N'REG1005', N'+91-9998887775', N'202 Block, Pune', N'10', N'https://epsilon.com', N'2', NULL, NULL, NULL, N'2025-06-16 06:21:56.7400000', N'0', NULL, N'Rob Johnson', N'Production Manager', N'33', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'6', N'Zeta Enterprises', N'contact@zeta.com', N'REG1006', N'+91-9998887776', N'123 Road, Ahmedabad', N'11', N'https://zeta.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6253556530124906427/Zeta.png', NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'7', N'Eta Solutions', N'info@eta.com', N'REG1007', N'+91-9998887777', N'456 Lane, Surat', N'12', N'https://eta.com', N'0', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'8', N'Theta Corp', N'support@theta.com', N'REG1008', N'+91-9998887778', N'789 Avenue, Jaipur', N'13', N'https://theta.com', N'2', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'9', N'Iota Systems', N'sales@iota.com', N'REG1009', N'+91-9998887779', N'101 Block, Chennai', N'14', N'https://iota.com', N'1', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'10', N'Kappa Enterprises', N'hello@kappa.com', N'REG1010', N'+91-9998887780', N'202 Street, Kolkata', N'15', N'https://kappa.com', N'0', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'11', N'Lambda Technologies', N'contact@lambda.com', N'REG1011', N'+91-9998887781', N'123 Main Road, Chandigarh', N'16', N'https://lambda.com', N'1', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'12', N'Mu Solutions', N'info@mu.com', N'REG1012', N'+91-9998887782', N'456 Circle, Bhopal', N'17', N'https://mu.com', N'2', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'13', N'Nu Corp', N'support@nu.com', N'REG1013', N'+91-9998887783', N'789 Avenue, Lucknow', N'18', N'https://nu.com', N'0', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'14', N'Xi Systems', N'sales@xi.com', N'REG1014', N'+91-9998887784', N'101 Road, Patna', N'19', N'https://xi.com', N'1', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'15', N'Omicron Enterprises', N'hello@omicron.com', N'REG1015', N'+91-9998887785', N'202 Lane, Raipur', N'20', N'https://omicron.com', N'0', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'16', N'Pi Tech', N'contact@pi.com', N'REG1016', N'+91-9998887786', N'123 Avenue, Bhubaneswar', N'21', N'https://pi.com', N'1', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'17', N'Rho Solutions', N'info@rho.com', N'REG1017', N'+91-9998887787', N'456 Block, Guwahati', N'22', N'https://rho.com', N'1', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'18', N'Sigma Corp', N'support@sigma.com', N'REG1018', N'+91-9998887788', N'789 Road, Dehradun', N'23', N'https://sigma.com', N'2', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'19', N'Tau Systems', N'sales@tau.com', N'REG1019', N'+91-9998887789', N'101 Street, Shimla', N'24', N'https://tau.com', N'0', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'20', N'Upsilon Enterprises', N'hello@upsilon.com', N'REG1020', N'+91-9998887790', N'202 Circle, Ranchi', N'25', N'https://upsilon.com', N'1', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'21', N'Phi Tech', N'contact@phi.com', N'REG1021', N'+91-9998887791', N'123 Lane, Trivandrum', N'26', N'https://phi.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6253464270129242734/Phitech.png', NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'22', N'Chi Solutions', N'info@chi.com', N'REG1022', N'+91-9998887792', N'456 Avenue, Panaji', N'27', N'https://chi.com', N'0', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'23', N'Psi Corp', N'support@psi.com', N'REG1023', N'+91-9998887793', N'789 Block, Itanagar', N'28', N'https://psi.com', N'2', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'24', N'Omega Systems', N'sales@omega.com', N'REG1024', N'+91-9998887794', N'101 Road, Kohima', N'29', N'https://omega.com', N'1', NULL, NULL, NULL, NULL, N'0', NULL, NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'25', N'Prime Enterprises', N'hello@prime.com', N'REG1025', N'+91-9998887795', N'202 Circle, Aizawl', N'30', N'https://prime.com', N'0', NULL, NULL, NULL, NULL, N'0', N'custom type', NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'48', N'dsfdsf', N'dsfsdf', N'dsfsd', N'df', N'dsfdsf', N'30', NULL, N'1', NULL, NULL, N'2025-03-28 14:55:35.3566667', NULL, N'0', N'Other industry', NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'49', N'teat', N'ertr', N'ewtert', N'ert', N'ert', N'30', N'ret', N'1', NULL, NULL, N'2025-03-28 15:45:47.5800000', NULL, N'0', N'test', NULL, NULL, N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'50', N'Test company', N'test@test.com', N'12345', N'123-456-7890', N'hjgsfjhds
dsfdsf', N'26', NULL, N'1', NULL, NULL, N'2025-04-04 09:03:40.3866667', NULL, N'0', N'', N'Sam peterson', N'CEO', N'32', N'1', NULL, NULL)
GO

INSERT INTO [portal].[Company] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description]) VALUES (N'51', N'Silver report Test', N'ram@test2025.com', N'SLVR TEST JUN 2025', N'675765787687', N'Test address', N'6', NULL, N'1', NULL, NULL, N'2025-06-23 09:35:19.6966667', NULL, N'0', N'', N'Ram Barot', N'Test', N'32', NULL, NULL, NULL)
GO

SET IDENTITY_INSERT [portal].[Company] OFF
GO


-- ----------------------------
-- Table structure for DropdownItems
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[DropdownItems]') AND type IN ('U'))
	DROP TABLE [portal].[DropdownItems]
GO

CREATE TABLE [portal].[DropdownItems] (
  [itemId] int  IDENTITY(1,1) NOT NULL,
  [itemName] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [groupId] int  NULL,
  [isDeleted] bit  NULL
)
GO

ALTER TABLE [portal].[DropdownItems] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of DropdownItems
-- ----------------------------
SET IDENTITY_INSERT [portal].[DropdownItems] ON
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'1', N'Data collection pending', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'2', N'Data collection complete', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'3', N'Report under process', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'4', N'Report generated', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'5', N'Certificate issued', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'6', N'Financial', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'7', N'Security', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'8', N'Recruitment', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'9', N'Engineering', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'10', N'Retail', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'11', N'Hospitality', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'12', N'Cleaning', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'13', N'Construction', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'14', N'Trades', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'15', N'Facilities Management', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'16', N'Sustainability', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'17', N'Graphics/Branding/Design', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'18', N'Technical/Digital/Telecoms', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'19', N'Education/Healthcare', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'20', N'Plant/Equipment/Haulage', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'21', N'Portals/Procurement Platforms', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'22', N'Retailer', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'23', N'logistics', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'24', N'Insurance', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'25', N'Charity', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'26', N'Legal', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'27', N'Pest Control', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'28', N'Window Cleaning', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'29', N'Consultancy', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'30', N'Other', N'2', N'0')
GO

SET IDENTITY_INSERT [portal].[DropdownItems] OFF
GO


-- ----------------------------
-- Table structure for Location
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Location]') AND type IN ('U'))
	DROP TABLE [portal].[Location]
GO

CREATE TABLE [portal].[Location] (
  [locationId] int  IDENTITY(1,1) NOT NULL,
  [companyId] int  NULL,
  [locationName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isDeleted] bit DEFAULT 0 NULL,
  [dateUpdated] datetime2(7)  NULL
)
GO

ALTER TABLE [portal].[Location] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Location
-- ----------------------------
SET IDENTITY_INSERT [portal].[Location] ON
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'1', N'1', N'Main site', N'0', N'2025-05-13 04:57:05.8233333')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'2', N'1', N'UK Office', N'0', N'2025-05-13 03:36:57.3200000')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'3', N'1', N'Test site 1', N'1', N'2025-05-13 05:08:14.0266667')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'4', N'1', N'Test site 2', N'1', N'2025-05-13 05:08:15.7300000')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'5', N'1', N'Test 3', N'1', N'2025-05-13 05:08:17.3533333')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'6', N'1', N'test 4', N'1', N'2025-05-13 05:08:22.1833333')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'7', N'1', N'test 6', N'1', N'2025-05-13 05:09:01.2133333')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'8', N'1', N'Test site', N'1', N'2025-05-15 10:18:23.1466667')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'9', N'2', N'Main site', N'0', N'2025-05-14 04:15:13.3866667')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'10', N'2', N'UAE Office', N'1', N'2025-05-13 05:23:47.2966667')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'11', N'2', N'test 2', N'1', N'2025-05-14 04:15:38.0366667')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'12', N'2', N'Test site', N'1', N'2025-05-15 05:13:07.0266667')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'13', N'2', N'Test site', N'1', N'2025-05-15 05:32:05.3866667')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'14', N'2', N'Test site', N'0', N'2025-05-15 05:32:20.6833333')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'15', N'4', N'Main site', N'0', N'2025-06-06 04:40:50.4566667')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'16', N'24', N'Main site', N'0', N'2025-06-06 05:25:09.4533333')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'17', N'16', N'Main site', N'0', N'2025-06-10 05:46:50.5600000')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'18', N'21', N'Main site', N'0', N'2025-06-10 05:47:47.2266667')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'19', N'6', N'Main office', N'0', N'2025-06-10 08:50:46.0000000')
GO

INSERT INTO [portal].[Location] ([locationId], [companyId], [locationName], [isDeleted], [dateUpdated]) VALUES (N'20', N'51', N'Main site', N'0', N'2025-06-23 09:35:19.7233333')
GO

SET IDENTITY_INSERT [portal].[Location] OFF
GO


-- ----------------------------
-- Table structure for NCZDirectory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[NCZDirectory]') AND type IN ('U'))
	DROP TABLE [portal].[NCZDirectory]
GO

CREATE TABLE [portal].[NCZDirectory] (
  [dirItemId] int  IDENTITY(1,1) NOT NULL,
  [companyId] int  NULL,
  [salesName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [salesEmail] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [salesPhone] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [esgName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [esgEmail] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [esgPhone] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [website] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [linkedinPage] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [facebookPage] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [instagramPage] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [logo] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [emissionOffset] nvarchar(5) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [industryType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [companyDescription] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [offersDiscounts] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [customerReference] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [companyName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [certTaskId] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isVisible] bit DEFAULT 0 NULL,
  [submissionId] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dateUpdated] datetime2(7) DEFAULT getdate() NULL
)
GO

ALTER TABLE [portal].[NCZDirectory] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of NCZDirectory
-- ----------------------------
SET IDENTITY_INSERT [portal].[NCZDirectory] ON
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'1', NULL, N'Alex Beardmore', N'abeardmore@johnsons1871.co.uk', N'(07738) 635712', N'Alex Beardmore', N'abeardmore@johnsons1871.co.uk', N'(07738) 635712', N'https://asset-360.co.uk/', N'https://www.linkedin.com/company/johnsons-asset-360', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6242361034512315575/Asset%20360%20logo%2024.5.23.jpg', N'No', N'Transportation and Logistics', N'Business Moves
Project Management
Asset Management
Social Enterprise dedicated to reuse / donate good quality office furniture', N'N/A', N'JOH-2024-001', N'Johnsons 1871', N'8695t1nc3', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'2', NULL, N'Dave Clark', N'sales@vanitorials.co.uk', N'(01268 ) 752224', N'Vicky Braxton', N'vicky.braxton@vanitorials.co.uk', N'(01268 ) 752224', N'www.vanitorials.co.uk', N'https://www.linkedin.com/company/vanitorials', N'https://www.facebook.com/vanitorialsltd', NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6241534381955922917/Vanitorials%20logo%20redesign_AW-colour%20small%20.jpg', N'No', N'Other', N'Vanitorials (www.vanitorials.co.uk) delivers janitorial supplies to a wide range of clients from sole traders to blue chip companies.

Uncompromising commitment to providing sustainable innovations, quality products, excellent service and valuable solutions makes Vanitorials the leading supplier for Essex, London and the South East. 

Additionally we provide a maintenance and repair service to floor care machinery.', N'N/A', N'VAN-2022-004', N'Vanitorials Ltd', N'86989b6rx', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'3', NULL, N'Sadie Prince', N'sprince@johnsons1871.co.uk', N'(44) 7471037066', N'Alex Beardmore', N'abeardmore@johnsons1871.co.uk', N'(44) 7738635712', N'www.johnsonslablogistics.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6226093180617386382/Lab%20Logistics%20logo%2024.5.23.png', N'Yes', N'Transportation and Logistics', N'Johnsons Lab Logistics are global experts in freight forwarding and specialist logistics for the life sciences sector. They provide tailored solutions for temperature-controlled transportation, time-critical deliveries, and complex supply chain management, ensuring reliability and precision.', N'N/A', N'JLL-2024-001', N'Johnsons Lab logistics', N'8695t1nc3', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'4', NULL, N'Martin Shepherd', N'martinshepherd@threesixtyds.com', N'(07827) 073312', NULL, NULL, NULL, N'https://threesixtyds.com/', N'https://uk.linkedin.com/company/three-sixty-design-solutions', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6226081603255677905/Coloured%20Version%20with%20Transparent%20Background.png', N'Yes', N'Construction', N'Three Sixty is a multi-disciplinary consultancy, offering Architectural, Mechanical & Electrical Engineering, Sustainability, Building Surveying and Project Management services to the construction industry in support of RIBA 0-1 Condition & Feasibility Studies, RIBA 2-4 Design, and client consultant support during RIBA 5-7 construction stage.', N'N/A', N'JOD-2024-001', N'360 Design Solutions', N'8695t1nc3', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'5', NULL, N'Sadie Prince', N'sprince@johnsons1871.co.uk', N'(44) 7471037066', N'Alex Beardmore', N'abeardmore@johnsons1871.co.uk', N'(44) 7738635712', N'www.johnsons1871.com', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6225992020611666043/JFM%20Logo%20grey.png', N'Yes', N'Facilities Management', N'* Facilities management
* Mechanical and electrical
* Facilities service
* Cleaning Services
* Waste Management
* Hygiene Services
* Pest Control
* Janitorial Services
* Grounds Maintenance
* Landscaping
* Window Cleaning
* Security Services
* Front of House
* Housekeeping
* Helpdesk Support 
* Portering Services', N'N/A', N'JFM-2024-001', N'Johnsons FM', N'8695t1nc3', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'6', NULL, N'Scott Tortosa', N'scott.tortosa@agilitesolutions.com', N'(352) 621829751', N'Scott Tortosa', N'scott.tortosa@agilitesolutions.com', N'(352) 621829751', N'https://www.agilitesolutions.com/', N'https://www.linkedin.com/company/agilite-solutions', NULL, N'https://www.instagram.com/agilitesolutions/', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6224170962372795246/RGB%20-%20Agilite%20Logo%20Strapline.png', N'No', N'Construction', N'Agilité is an international commercial interiors specialist helping organisations enter, relocate, or expand throughout Europe. With offices in France, Italy, Germany, the UK, and Luxembourg, Agilité is specialised in office, retail, and hospitality fit outs across the continent.', N'N/A', N'AGI-2023-003', N'Agilite Solutions', N'86967e8ce', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'7', NULL, N'Tony Carter', N'tony.carter@abec.co.uk', N'(+44) 07860392749', N'Ewa Skorek-Pawlowska', N'ewa.skorekpawlowska@abec.co.uk', N'(+44) 07775945633', N'www.abec.co.uk', N'https://www.linkedin.com/company/automated-building-controls-group/?trk=company_name', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6216549423781325664/ABEC_STRAP_CMYK_REV.png
https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6216549423781325664/aBEC%20STRAPLINE%20FULL%20COLOUR.png', N'No', N'Energy', N'Tony Carter already discussed this with Krys', N'as discussed with Krys', N'ABE-2024-001', N'Automated Building & Energy Controls (Ltd)', N'8697rjy23', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'8', NULL, N'james Thornton', N'james@acseu.co.uk', N'(01257) 441443', NULL, NULL, NULL, N'www.acseu.co.uk', N'acseu.ltd', N'acseu.ltd', N'acseu.ltd', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6212153701427231708/ACSeu-Limited-logo%20V2.png', N'No', N'Hospitality', N'Here at ACSEU we carry out specialised cleaning and reactive work to the hospitality industry and more. 
Kitchen extraction and ventilation deep cleaning 
Industrial deep cleaning 
Reactive repairs to vent and extraction systems 
Fire damper servicing and fitting 
All industrial and commercial cleaning', N'All New customers we will carry out free surveys to any sites.
All new customers will receive a 20% discount and our initial visits', N'AEU-2024-001', N'ACSEU Ltd', N'8696rw0hm', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'9', NULL, N'Jolanta Cerkauskiene', N'JolantaCerkauskiene@birkingroup.co.uk', N'(01707) 322228', N'Jolanta Cerkauskiene', N'JolantaCerkauskiene@birkingroup.co.uk', N'(01707) 322228', N'https://www.birkingroup.co.uk/', N'https://www.linkedin.com/company/birkin-cleaning-services/', N'https://www.facebook.com/BirkinClean?mibextid=wwXIfr&rdid=QyPAyWh8de4ZeWRh&share_url=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AArDiAscc%2F%3Fmibextid%3DwwXIfr#', N'https://www.instagram.com/birkingroup/?igsh=MXN4ZWxoejU3bW8xYQ%3D%3D#', NULL, N'Yes', N'Facilities Management', N'Birkin Cleaning Services offers a comprehensive range of cleaning solutions across various sectors, including commercial, education, public, and construction. Our services are designed to maintain clean and safe environments, enhancing relationships, happiness, and business results.', N'N/A', N'BIR-2023-002', N'Birkin', N'8698fuxtj', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'10', NULL, N'Chloe Sholl', N'Chloe.Sholl@msupply.co.uk', N'(01277) 200520', NULL, NULL, NULL, N'https://shop.msupply.co.uk', N'https://uk.linkedin.com/company/the-maintenance-supply-co-ltd', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6200951002606941412/Logo.png', N'No', N'Other', N'Distribution of Cleaning Chemicals/Janitorial Supplies/Clothing/Cleaning Machinery Nationwide.', N'N/A', N'MSC-2025-001', N'Maintenance Supply Co Ltd', N'8698gf4rr', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'11', NULL, N'Klavs Henriksen', N'klavs.henriksen@ie-uk.com', N'(0044) 07866821481', N'Klavs Henriksen', N'klavs.henriksen@ie-uk.com', NULL, N'www.ie-uk.com', N'https://www.linkedin.com/company/insightful-environments', NULL, N'https://www.instagram.com/insightfulenv', NULL, N'No', N'Other', N'IE creates, and supplies integrated furniture, technology, and service solutions. We focus on enhancing workplace performance and design, working with various clients to transform their spaces using innovative products and insights.', N'n/a', N'INE-2023-003', N'Insightful Environments', N'8698ku25x', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'12', NULL, N'Lianne Gray', N'l.gray@wagstaffgroup.co.uk', N'(07974) 024429', N'Lianne Gray', N'l.gray@wagstaffgroup.co.uk', N'(07974) 024429', N'www.wagstaffgroup.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6195632530024803161/W_Wagstaff_logo_black_text-01.png', N'No', N'Other', N'Furniture and interior fit-out', N'n/a', N'WAI-2024-001', N'Wagstaff Interiors', N'8696xwurv', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'13', NULL, N'Adam Atkins', N'aatkins@coatfacilitiesgroup.com', N'(+441675) 463900', N'Sarah Fearby', N'sfearby@coatfacilitiesgroup.com', N'(+44) 7774 331757', N'https://www.diamond-fs.com/', N'https://www.linkedin.com/company/diamondfacilitiessupport', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6192370050313138325/DFS%20Logo.png', N'No', N'Facilities Management', N'Facilities Maintenance Service. Reactive, pre planned maintenance (compliance) and Quoted Works.', N'N/A', N'DFS-2024-001', N'Diamond Facilities Support Ltd', N'8697x1k1j', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'14', NULL, N'Allison Tomlin', N'Allison.tomlin@lancerscott.co.uk', N'(0117) 9439800', NULL, NULL, NULL, N'https://www.lancerscott.co.uk/', N'https://www.linkedin.com/company/lancer-scott/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6190624871127348404/Final%20logo-01.jpg', N'No', N'Other', N'Lancer Scott was established in 1996 with the objective of working in maintenance, repair, project and construction sector working across both the housing and commercial markets for both public and private sector bodies.  The business is owned and operated by the original owners supported by a board of Directors drawn from across a diverse range of skills and market sectors allowing us to provide bespoke services to our clients.', N'N/A', N'LSC-2023-003', N'Lancer Scott', N'869878uty', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'15', NULL, N'Dan Stratton', N'dstratton@pfsltd.co.uk', N'(+44) 07514930030', N'Dan Stratton', N'dstratton@pfsltd.co.uk', N'(+44) 07514930030', N'www.pfsltd.co.uk', N'https://www.linkedin.com/company/pfsgroupltd', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6189648296912159269/PFS_Group_LimitedFS_outlines_CMYK.pdf', N'No', N'Construction', N'Supply, Installation, Commissioning and Maintenance of fire alarm and life safety systems across the England and Wales. PFS hold many accreditations and partnerships with world leading fire alarm manufacturers such as GENT24, Siemens, Kentec, Baldwin Boxall and more, making us able to provide state of the art fire and life safety systems in all types of buildings.', N'N/A', N'PFS-2024-001', N'PFS Group', N'8698f45b6', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'16', NULL, N'Sadie pRINCE', N'sprince@johnsons1871.co.uk', N'(+44) 7471037066', NULL, NULL, NULL, N'www.johnsonsinstallationservices.co.uk', N'@johnsonsinstallationservices', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6187123363329339161/Installations%20logo%2024.5.23.png', N'Yes', N'Facilities Management', N'Johnsons Installation Services specialises in delivering professional furniture installation, relocation, and refurbishment solutions across the UK. With expertise in office, education, and healthcare sectors, they offer end-to-end services, from planning to execution. Backed by skilled teams and sustainable practices, they ensure seamless transitions and high-quality results tailored to meet the unique needs of every project.', N'N/A', N'JIS-2024-001', N'Johnsons Installation Services', N'8695t1nc3', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'17', NULL, N'Vicky Chivell', N'vchivell@biologicalpreparations.com', N'(07543) 503500', N'Vicky Chivell', N'vchivell@biologicalpreparations.com', N'(07543) 503500', N'www.biologicalpreparations.com', N'https://www.linkedin.com/company/biological-preparations-limited', N'https://www.facebook.com/BioHygieneUK', NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6186445213317680118/LinkedIn-cover-image%20%28002%29.jpg', N'Yes', N'Manufacturing', N'UK leaders in environmental biotechnology offering solutions in cleaning, disinfection, odour control, grease management and water treatment.', N'n/a', N'BPL-2024-001', N'Biological Preparations', N'8694cjk4h', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'18', NULL, N'Steve Emery', N'steven.emery@uk.belfor.com', N'(+44) 7825177942', N'Steve Emery', N'steven.emery@uk.belfor.com', N'(+44) 7825177942', N'www.belfor.com', N'https://uk.linkedin.com/company/belforukltd', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6186437660314458546/BELFOR%20Logo.jpg', N'Yes', N'Construction', N'Damage management, restoration and construction services for commercial, industrial and domestic properties', N'N/A', N'BEL-2023-002', N'BELFOR UK', N'8697nj16n', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'19', NULL, N'George O''Brien', N'Georgeo@sw-gr.com', N'(+44) 7912564796', N'George O''Brien', N'Georgeo@sw-gr.com', N'(44) 7912564796', N'https://www.sw-gr.com/', N'https://www.linkedin.com/company/swgr100211-001614', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6177911812202389312/Screenshot%202025-03-14%20at%2019.50.36.png', N'No', N'Other', N'What Does SWGR Do?
SWGR (SW Global Resourcing Ltd) is a company that provides specialist workforce solutions, primarily for rail, construction, and infrastructure sectors. Their services include:

Rail Infrastructure Support

Workforce supply for railway maintenance, track renewal, and infrastructure projects.
Providing skilled professionals such as engineers, safety-critical staff, and project managers.
Construction & Engineering

Supporting major infrastructure projects with skilled personnel.
Ensuring compliance with health, safety, and environmental regulations.
Sustainability & Carbon Reduction Initiatives

Implementing carbon reduction strategies to achieve Net Zero by 2050.
Reducing fleet emissions, promoting sustainable transport, and increasing recycling efforts.
Workforce Solutions & Training

Recruiting and training personnel for various industries.
Investing in upskilling workers to meet industry standards.', N'N/A', N'SWG-2025-001', N'SW Global Resourcing Ltd', N'86981tjuy', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'20', NULL, N'Stephen Corrigan', N'Stephen@grade-one.co.uk', N'(44) 7802617521', N'Stephen Corrigan', N'stephen@grade-one.co.uk', N'(44) 7802617521', N'www.grade-one.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6176729206117321826/website%20logo.png', N'Yes', N'Other', N'Cleaning and Support Services including but not limited to:
Daily Commercial Cleaning
Window Cleaning (inc Rope Access)
Power Washing
Graffiti Removal
High Level Cleaning 
Education Cleaning  
Carpet and Upholstery Cleaning', N'N/A', N'gra-2023-002', N'Grade One Commercial Cleaning Services', N'86946g14c', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'21', NULL, N'Marcus Doliveira', N'sales@geldbach.co.uk', N'(+44) 1215411717', NULL, NULL, NULL, N'https://www.geldbach.co.uk/', N'https://www.linkedin.com/company/geldbach-uk', NULL, NULL, NULL, N'No', N'Construction', N'Carbon Steel Fittings, Flanges and Pipe.
Stainless Steel Flanges.', N'N/A', N'guk-2024-001', N'Geldbach UK Ltd', N'8696hy242', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'22', NULL, N'Daisy Hunter', N'd.hunter@jangrohq.net', N'(01204) 795955', N'Daisy Hunter', N'd.hunter@jangrohq.net', N'(01204) 795955', N'https://www.jangro.net/', N'https://www.linkedin.com/company/jangro-ltd/', NULL, NULL, NULL, N'No', N'Other', N'Jangro is a dynamic force in the cleaning supply industry and is the largest network of independent janitorial distributors in the UK and Ireland.

The Jangro mark has evolved over the years to be recognised as the premier independent brand for the professional janitorial service contractor. You will note that our branding, packaging and colour coded safety system has been improved to enhance usability and all of the cleaning products have been tested and have passed rigorous selection processes prior to being given the official Jangro stamp of approval.', N'NA', N'JAN-2024-001', N'Jangro Ltd', N'8697vj424', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'23', NULL, N'Peter Brooks', N'peter.brooks@edmundservices.com', N'(+44) 7841380999', N'Peter Brooks', N'peter.brooks@edmundservices.com', N'(+44) 7841380999', N'www.edmundserivces.com', N'https://www.linkedin.com/company/edmund-services/?viewAsMember=true', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6171540033849962792/GetAttachmentThumbnail.jpg', N'No', N'Facilities Management', N'Mechanical & Electrical Maintenance contractor within the Facilities Management sector.', N'N/A', N'EDS-2024-001', N'Edmund Services', N'86985ueh0', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'24', NULL, N'Anthony Samuel', N'tsamuel@flashart.com', N'(052) 1275849', N'Anthony Samuel', N'tsamuel@flashart.com', N'(971) 521275849', N'www.flashart.com', N'none', N'none', N'none', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6168900749617555573/A9Rw7bckt_1173rbj_aao.jpg', N'Yes', N'Other', N'Flash Art is the world’s first carbon-neutral fireworks company, delivering high-profile displays like Jumeirah and Dubai Frame NYE, Expo 2020, and UAE National Day. Using advanced firing tech, we ensure precision and sustainability, creating unforgettable experiences that connect and inspire.', N'N/A', N'fla-2024-002', N'Flash Art', N'86984mqbe', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'25', NULL, N'Ash Hurrell', N'ashley.hurrell@eiffage.com', N'(0044) 07385661541', NULL, NULL, NULL, N'https://herbosch-kiere.be/en/', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6165680568229294783/HK%20logo.png', N'No', N'Construction', N'Herbosch Kiere Marine Contractors Ltd is the wholly owned subsidiary of an internationally respected Marine Construction Company, with over 100 years experience in marine and fluvial construction. We have over the years, achieved an outstanding track record and professional reputation, having worked all over the world on various rivers, ports and harbours. Our core works include marine piling, marine demolition, marine salvage, rock dumping and offshore construction.

We own and operate a complete range of equipment and plant including piling barges, rock barges, stone placement vessels, floating cranes and workboats and our staff and crews are trained to optimise performance from the equipment and vessels they are assigned to.', N'Please contact our business development manager to discuss future working opportunities.', N'eif-2024-001', N'HERBOSCH KIERE', N'8693wmvyx', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'26', NULL, N'Paul Mitchell', N'paulmitchell@cynergi-services.co.uk', N'(07506) 37935495', N'Lydia Bennie', N'lydiabennie@cynergi-services.co.uk', N'(020) 37935495', N'https://cynergi-services.co.uk/', N'Cynergi Cleaning & Support Services', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6159502481324512344/Cynergi%20Logo.jpg', N'No', N'Other', N'Cynergi Cleaning & Support Services is one of the leading providers of soft services management, with an exhaustive list of services including daily office cleaning, feminine hygiene, grounds maintenance, window cleaning, floor maintenance and waste management. Cynergi has been in operation since 2006, growing at a constant rate over consecutive years. This has been achieved by organic growth; recommendations and new business.  
 
At Cynergi, we pride ourselves on our adaptability, allowing us to supply services to blue chip companies, the public sector and SMEs in a variety of sectors including large commercial establishments, corporate institutions, corporate offices and complexes, educational facilities, media, entertainment and manufacturing establishments. Our success is attributed to our ability to provide the best-in-class multi-services to our clients.', N'N/A', N'CYN-2023-001', N'Cynergi Services', N'8677jkqv0', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'27', NULL, N'Chris Frankland', N'chris@tectonix.co.uk', N'(07939) 872308', N'Christopher Frankland', N'Chris@tectonix.co.uk', N'(07939) 872308', N'www.tectonix.co.uk', N'https://www.linkedin.com/company/tectonixuk/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6156863075388093365/Tectonix_MASTER_logo%20PNG%20High.png', N'No', N'Construction', N'Tectonix is an innovative external surfaces company based in Leeds, UK, specializing in providing natural stone paving and masonry solutions for the landscaping industry. With over 35 years of combined experience, Tectonix offers products like porcelain, granite, sandstone, and Yorkstone for both residential and commercial projects.', N'N/A', N'TEX-2023-001', N'Tectonix Natural Stone Ltd', N'86933hdfu', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'28', NULL, N'Hayley Smith', N'hayley.smith@wastetowonder.com', N'(+44) 7897554359', N'Michael Amos', N'michael.amos@wastetowonder.com', N'(+44) 7403041766', N'https://www.wastetowonder.com/', N'https://www.linkedin.com/company/18314645/admin/dashboard/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6152588923318269042/Waste%20to%20Wonder%20Worldwide%20Logo_Full%20Colour.png', N'Yes', N'Facilities Management', N'At Waste to Wonder Worldwide, we turn office clearances into opportunities for change. By repurposing surplus furniture and equipment, we can reduce carbon emissions, eliminate waste, and support schools and charities in underserved communities worldwide.', N'N/A', N'WTW-2023-002', N'Waste to Wonder', N'86946g1bd', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'29', NULL, N'REBECCA HALLIDAY', N'accounts@seldram.co.uk', N'(01276) 685985', NULL, NULL, NULL, N'www.seldram.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6148382459155792061/krystal_hygiene_limited_logo.jpg', N'No', N'Retail', N'Krystal Hygiene is one of the leading independent distributors of paper and catering disposables, chemicals and associated cleaning and hygiene materials in the UK. We offer the single source solution for all of your cleaning and hygiene materials and aim to offer nothing less than excellence.', N'N/A', N'SKH-2024-001', N'Krystal Hygiene', N'8697gr8j1', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'30', NULL, N'Will McLaughlin', N'will.mclaughlin@kpsltd.co.uk', N'(0044) 2082534588', NULL, NULL, NULL, N'www.kpsltd.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6147440068912284250/KPS%20Box%20Logo.png', N'No', N'Construction', N'Construction services to refurbish existing buildings for commercial clients across the south of England.', N'.', N'KPS-2023-002', N'Knightsbridge Property Services', N'8677fpqwx', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'31', NULL, N'Paul Todd', N'paul@etechsouthern.co.uk', N'(44) 07972877848', NULL, NULL, NULL, N'https://etechsouthern.co.uk/', NULL, NULL, N'etech southern limited', NULL, N'No', N'Construction', N'We are a professional Design and Build Electrical Contractor with offices in Essex and London, UK. Our expertise spans a wide range of electrical services, and our strategically located offices enable us to efficiently serve clients across the region and beyond. We specialise in office fit outs across London and the south east.', N'N/A', N'ESL-2024-001', N'Etech Southern Ltd', N'8697qz4ax', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'32', NULL, N'Joe Weller', N'kwiltshire@sherwoods.uk', N'(0330) 3902058', NULL, NULL, NULL, N'www.sherwoods.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6145774311826900274/Sherwoods-logo.jpg', N'No', N'Construction', N'Sherwoods is a Southwest based Family run business established since 1970, and has earned the reputation of delivering our promises and commitments over and above the standards required.

Our systems are designed to ensure a compliant service delivery to current standards and requirements, allowing for legislative changes and flexibility to meet our clients operational needs.

Our Management and engineering team has many experienced years of delivering Building Service''s, PPM, reactive and project works to Schools, Colleges, Commercial & Industrial premises, Sports Facilities and understands the need to ensure the plant and equipment within buildings are maintained to a high standard to ensure safety and reliability.

Our mobile field team consist of commercial Gas, Oil, LPG heating engineers, Electricians, Fire Alarm engineers, Plumbers, Air conditioning engineers & building fabric operatives. All staff are enhanced DBS checked.', N'N/A', N'SHW-2024-001', N'Sherwoods', N'8696uxu8n', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'33', NULL, N'Alex Weller', N'alex.weller@thamescleaning.co.uk', N'(0208 ) 302 6633', N'Danielle Middleton', N'danielle.middleton@thamescleaning.co.uk', NULL, N'https://www.thamescleaning.co.uk/', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6144847368877454435/Co%20Logo.jpg', N'Yes', N'Other', N'We provide professional cleaning solutions primarily to commercial businesses based in London and the South East of England.   As well as daily interior cleaning services, Thames offer specialist deep cleaning services, bespoke clean and green audits and the cleaning of building exteriors including high level windows and facades.', N'na', N'TCS-2024-001', N'Thames Cleaning & Support Services Ltd', N'86975t1f2', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'34', NULL, N'Victoria Cox', N'victoria.cox@rapidenergy.co.uk', N'(447) 07484548633', NULL, NULL, NULL, N'https://rapidenergy.co.uk/', N'Rapid Energy Ltd', N'Rapid Energy Ltd', N'Rapid Energy Ltd', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6139746544224846617/RE_full-colour_tagline-SM.png', N'No', N'Other', N'Rapid Energy is a nationwide temporary heating and hot water solutions provider. We design, specify and build our own packaged boilers in-house for temporary hire and long term rental. We provide a full turnkey solution for businesses, across our entire fleet of equipment.', N'10% discount on hire.', N'REL-2024-001', N'Rapid Energy Limited', N'8696u6xey', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'35', NULL, N'Stefan Solaybar', N'accounts@mission-global.com', N'(+971) 567245399', NULL, NULL, NULL, N'www.mission-global.com', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6139631911254699284/2%20Mission%20Global%20Logo%20Original.png', N'Yes', N'Transportation and Logistics', N'We do event and specialized logistics and transportation', N'N/A', N'MGL-2023-002', N'Mission Global LLC', N'8692vnhet', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'36', NULL, N'DONNA KANE', N'donna.kane@pinkhygiene.co.uk', N'(+44) 01702671530', N'Donna Kane', N'donna.kane@pinkhygiene.co.uk', N'(+44) 01702671530', N'www.pinkhygiene.co.uk', N'https://www.linkedin.com/company/pink-hygiene/?viewAsMember=true', N'https://www.facebook.com/pinkhygiene', N'https://www.instagram.com/pinkhygiene/', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6138434952118995296/PINK%20HYGIENE%20LOGO.png', N'Yes', N'Facilities Management', N'The Provision of Washroom & Hygiene Services​

​The service and maintenance of washroom products, predominately feminine hygiene services, air care products, nappy & sharps units including the provision of hand hygiene products, sanitary vending, along with laundry and floorcare services.', N'N/A', N'PHL-2024-001', N'Pink Hygiene Ltd', N'86956cn06', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'37', NULL, N'Tristan Adams', N'tristan@pestcheck.co.uk', N'(44) 7766761271', NULL, N'tristan@pestcheck.co.uk', N'(44) 7766761271', N'www.pestcheck.co.uk', N'n/a', N'n/a', N'n/a', NULL, N'Yes', N'Other', N'We cover commercial and domestic pest control dealing with all forms of protection, prevention and treatment.', N'n/a', N'pes-2023-002', N'Pest Check', N'8697d8by6', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'38', NULL, N'REBECCA HALLIDAY', N'accounts@seldram.co.uk', N'(01276) 685985', NULL, NULL, NULL, N'www.seldram.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6137803839153662236/Seldram-Logo-Blue.png', N'No', N'Retail', N'Seldram Supplies, your go-to partner for high-quality cleaning and hygiene solutions. As a proud independent business, we are dedicated to supporting local enterprises and enhancing our community. We take pride in our exceptional customer service and are determined to deliver superior support.', N'N/A', N'SSC-2024-001', N'Seldram Supplies Camberley', N'8697gr8j1', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'39', NULL, N'REBECCA HALLIDAY', N'accounts@seldram.co.uk', N'(01276) 685985', NULL, NULL, NULL, N'www.seldram.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6133544559156252435/Seldram-Logo-Blue.png', N'No', N'Retail', N'Seldram Supplies, your go-to partner for high-quality cleaning and hygiene solutions. As a proud independent business, we are dedicated to supporting local enterprises and enhancing our community. We take pride in our exceptional customer service and are determined to deliver superior support.', N'N/A', N'SSO-2024-001', N'Seldram Supplies Oxford', N'8697gr8j1', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'40', NULL, N'Tim Marshall', N'sales@floorbrite.co.uk', N'(44) 0161 972 3000', N'Ella Warburton', N'ella.warburton@floorbrite.co.uk', N'(44) 01619723049', N'www.Floorbrite.co.uk', N'https://www.linkedin.com/company/the-floorbrite-group-ltd', N'https://www.facebook.com/FloorbriteUK', N'https://www.instagram.com/thefloorbritegroup/', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6098123466418359837/Floorbrite%20Logo.png', N'No', N'Facilities Management', N'Floorbrite''s comprehensive range of services covers daily, industrial, and window cleaning across all sectors. In addition to cleaning, we provide support for washroom and hygiene supplies, waste management, pest control, plants and grounds maintenance, and security.', N'N/A', N'FLB-2023-002', N'Floorbrite Group', N'8695vqk51', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'41', NULL, N'Michael Savage', N'mike@apollocleaning.co', N'(0208) 0044431', N'Michael Savage', N'mike@apollocleaning.co', N'(0) 7447550058', N'www.apollocleaning.co', N'https://www.linkedin.com/company/apollo-cleaning-uk/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6093004790913893351/Apollo%20logo.jpg', N'No', N'Facilities Management', N'NA', N'NA', N'ACS-2024-001', N'Apollo Cleaning Services Ltd', N'86955xku2', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'42', NULL, N'Craig Blake', N'craig.blake@kingdom.co.uk', N'(+44) 7392460127', N'Jennifer Hanson', N'jrubyrus@gmail.com', N'(+44) 3301758363', N'https://kingdom-healthcare.com/', N'https://www.linkedin.com/company/kingdom-healthcare/', N'https://www.facebook.com/kingdomhealthcareofficial', N'N / A', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6092395209412902062/Kingdom%20Healthcare%20Ltd%20Logo.jpg', N'No', N'Healthcare', N'Kingdom Healthcare Limited provides domiciliary carers and nurses to care agencies across the UK.', N'N / A', N'KHE-2024-001', N'Kingdom Healthcare Limited', N'8696n9p1x', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'43', NULL, N'Neil Duggins', N'neil.duggins@kingdom.co.uk', N'(+44) 7979859058', N'Jennifer Hanson', N'jennifer.hanson@kingdom.co.uk', N'(+44) 3301758363', N'https://www.kingdom.co.uk/recruitment', N'https://www.linkedin.com/company/kingdom-people/', N'https://www.facebook.com/kingdompeople12/', N'N / A', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6092192584617986390/Kingdom%20People%20Ltd%20Logo.jpg', N'No', N'Facilities Management', N'Kingdom People Limited provide agency staff, and as part of this delivers best in class training services, supporting clients through various training courses by using the apprenticeship levy fund, to sectors across the UK.', N'N / A', N'KPE-2024-001', N'Kingdom People Limited', N'8696n9p1x', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'44', NULL, N'Lucy Lloyd', N'lucy.lloyd@kingdom.co.uk', N'(+44) 7979459814', N'Jennifer Hanson', N'jennifer.hanson@kingdom.co.uk', N'(+44) 3301758363', N'https://www.kingdom.co.uk/cleaning', N'https://www.linkedin.com/company/kingdomcleaning/', N'https://www.facebook.com/profile.php?id=100064189145937', N'N / A', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6092168204614493140/Kingdom%20Cleaning%20Ltd%20Logo.jpg', N'No', N'Facilities Management', N'Kingdom Cleaning Limited provides commercial cleaning services, including cleaning supplies, across the UK.', N'N / A', N'KCL-2024-001', N'Kingdom Cleaning Limited', N'8696n9p1x', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'45', NULL, N'Andy Ellis', N'andy.ellis@kingdom.co.uk', N'(+44) 7917287431', N'Jennifer Hanson', N'jennifer.hanson@kingdom.co.uk', N'(+44) 3301758363', N'https://www.kingdom.co.uk/security', N'https://www.linkedin.com/company/kingdom-security-services/', N'https://www.facebook.com/kingdomservicesgroup', N'N / A', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6091580739416472868/Kingdom%20Security%20Ltd%20Logo.jpg', N'No', N'Facilities Management', N'Kingdom Security Limited provides security officers to various organisations across the UK, and as part of this provides technology solutions to support security and facilities management, and also supports local authorities with trained enforcement officers to minimise environmental offences.', N'N / A', N'KSE-2024-001', N'Kingdom Security Limited', N'8696n9p1x', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'46', NULL, N'Tony Fish', N'tony.fish@mustangwashrooms.com', N'(01322) 445700', NULL, NULL, NULL, N'www.mustangwashrooms.com', N'Mustang Washrooms Limited', N'Mustang Washrooms', N'Mustang Washrooms Ltd', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6090484938976307480/Mustang%20wash%20Logo%20HIGH%20RES.jpg', N'Yes', N'Other', N'Washroom and hygiene services', N'N/A', N'MUW-2024-001', N'Mustang Washrooms Limited', N'8695r2q2u', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'47', NULL, N'Nicole Daley', N'sales@peartreecleaning.co.uk', N'(01277) 201420', N'Georgianna Hull', N'ghull@peartreecleaning.co.uk', N'(01277) 201420', N'www.peartreecleaning.co.uk', N'https://www.linkedin.com/company/peartree-cleaning-services-limited/mycompany/?viewAsMember=true', N'https://www.facebook.com/profile.php?id=100073768213474', NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6086869211713213453/Peartree%20Logo.jpg', N'Yes', N'Other', N'We offer a contract cleaning service working in a variety of different industries, we also offer subcontracting services including windows cleaning, pest control, horticultural services.', N'N/A', N'pea-2023-103', N'Peartree Cleaning', N'8696u6z38', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'48', NULL, N'Filipe Vitorino', N'Filipe.Vitorino@tenonfm-uk.com', N'(0) 07791 611 806', N'Filipe Vitorino', N'Filipe.Vitorino@tenonfm-uk.com', N'(0) 7535 697 176', N'https://www.tenonfm-uk.com/', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6067074779799502301/T%20logo.png', N'Yes', N'Facilities Management', N'General cleaning services', N'N/A', N'TFM-2024-002', N'Tenon FM', N'8696hnjyg', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'49', NULL, N'Juseph Londono', N'juseph.londono@tenonfm-uk.com', N'(0) 07535 697 176', N'Filipe Vitorino', N'filipe.vitorino@tenonfm-uk.com', N'(0) 07535 697 176', N'https://www.tenonfm-uk.com/', N'https://uk.linkedin.com/company/tenon-fm-uk', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6065263413915283891/T%20logo.png', N'Yes', N'Facilities Management', N'General Cleaning services', N'N/A', N'TFM-2024-001', N'Tenon fm', N'8695tf8dy', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'50', NULL, N'Meg smith', N'megan.smith@jsmbuildingsolutions.co.uk', N'(0) 1253890690', NULL, NULL, NULL, N'www.jsmbuildingsolutions.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6059408789215238840/JSMLogo-Black.png', N'No', N'Other', N'M&E Contractors, Fabric Contractors, Technical Maintenance, Refurbishment & Fit Out', N'n/a', N'jsm-2023-002', N'JSM Building Solutions', N'8694a986w', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'51', NULL, N'Helen Harrison', N'helen.harrison@pceltd.co.uk', N'(01827) 301020', N'N/A N/A', NULL, NULL, N'https://pceltd.co.uk/', N'https://www.linkedin.com/company/pce-limited/?viewAsMember=true', N'https://www.facebook.com/PCEHybrid', N'N/A', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6055706994519549785/PCE%20Logo%20%28no%20background%29.png', N'Yes', N'Construction', N'PCE are specialists in offsite construction utilising system based construction methods. PCE deal with the design, manufacture and delivery of complete structures in multiple sectors such as residential, healthcare, prisons, education etc. 
We manage a diverse supply chain for the manufacture of the building products which get delivered directly to site in time/following a build sequence for installation, reducing the number of deliveries to site and the need for products to be stored somewhere.', N'N/A', N'PCE-2023-002', N'PCE LTD', N'86938zbhm', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'52', NULL, N'Ben Dunn', N'ben@onestopconsult.co.uk', N'(+44) 7478773308', NULL, NULL, NULL, N'www.onestopconsult.co.uk', N'https://www.linkedin.com/company/onestopconsult', N'https://www.facebook.com/onestopconsultltd/', N'https://www.instagram.com/onestopconsult', NULL, N'No', N'Construction', N'One Stop Consult Ltd provides a wide range of services for the construction and property development industry. Here is a broad overview of their services:

Building Control Services: They offer management and support for building regulations compliance, working with approved building control inspectors.

Structural Engineering: Full structural design services including calculations for steel beams, foundations, roofs, and floors.

Planning and Design: Assistance with planning applications, architectural designs, and various assessments like flood risk and ecological surveys.

Sustainability and Energy: Services like SAP calculations, energy performance certificates (EPCs), and carbon assessments to support energy efficiency and sustainability goals.

Testing and Surveys: They provide air tightness, sound insulation, residential noise, and fire risk assessments, along with other specialized surveys.

Structural Warranties: Offering 10-year structural warranties for new builds and conversions.

Building Products Supply: They supply essential building materials like precast concrete flooring, roof trusses, block and beam floors, and fire suppression systems.

These services are aimed at helping developers, architects, and builders streamline their projects, ensuring compliance and quality throughout.', N'One Stop Consult Ltd offers package discounts for clients who require multiple services. When several services or products are booked together, the company provides a streamlined solution that can lead to cost savings. By consolidating these services through their extensive network of partners, they are able to offer preferential rates and tailored pricing options to suit project needs, reducing overall costs for clients.

This allows for more efficient project management and budget-friendly solutions for builders, architects, and developers looking for comprehensive project support.', N'OSC-2023-001', N'One Stop Consult Ltd', N'8692vpr6n', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'53', NULL, N'Nick Winstone', N'nick@biovatehygienics.com', N'(44) 325899', N'Nick Winstone', N'nick@biovatehygienics.com', N'(07583) 325899', N'www.biovatehygienics.com', N'https://www.linkedin.com/company/biovate-hygienics/', N'https://www.facebook.com/Biovate-Hygenics-102451052428450', N'https://www.instagram.com/biovatehygienics/#', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6041267402417870431/BVH%20logo%20PDF.pdf
https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6041267402417870431/BioVate%20Logo%20PNG.png', N'Yes', N'Manufacturing', N'BioVate Hygienics is a leading manufacturer of certified, naturally derived biological cleaning products. Our mission is to drive sustainable change in the commercial cleaning industry by offering eco-friendly alternatives. We are leading the way for sustainable and  serviced cleaning products, ensuring our customers of high-performance cleaning solutions that align with their sustainability goals.', N'10% off first order when NCZ10 is entered.', N'BIO-2023-002', N'Biovate', N'8695m0hjv', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'54', NULL, N'Aine Solomon', N'aine@advance.fm', N'(01622) 720888', N'Glenn Thompson', N'glenn@advance.fm', N'(01622) 720888', N'https://advancedrains.com/', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6036926468953526429/cropped-Advance-drain-services-01-l.png', N'No', N'Other', N'DRAIN MAINTENANCE AND REPAIRS.', N'N/A', N'ADS-2023-001', N'ADVANCE DRAIN SERVICES LTD', N'8692uxw49', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'55', NULL, N'Rohan Lee', N'rohan@bandotowels.com', N'(44) 07538533714', NULL, NULL, NULL, N'https://bandotowels.com/', N'https://www.linkedin.com/company/bandotowels', N'https://www.facebook.com/bandotowels', N'https://www.instagram.com/bandotowels/', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6035914404358924627/Bando.%20logo%20black%20transparent.png', N'No', N'Retail', N'Bando Sports Merchandise supplies fully custom sustainable products for event gifting, retail and charities. We work with some of the most recognisable companies in the country, whilst supporting a number of purpose driven initiatives.', N'N/A', N'BAN-2024-001', N'Bando Towels', N'8693rrhxy', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'56', NULL, N'Rich Watts', N'rich.watts@morethansafety.co.uk', N'(44) 7795066973', N'Emma Campbell', N'emma.campbell@morethansafety.co.uk', N'(44) 1489780255', N'https://www.morethansafety.co.uk/', N'https://www.linkedin.com/company/more-than-safety-ltd/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6035834582418539718/MTS%202022.dark.1024.png
https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6035834582418539718/MTS%202022.dark.xl.jpg
https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6035834582418539718/MTS%202022.light.1024.png
https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6035834582418539718/MTS%202022.light.xl.jpg', N'No', N'Other', N'More Than Safety (MTS) have been experts in FM supply for over 35 years. Specialists in Uniform & Workwear, Tools, PPE, Test Equipment, LOTO and more. With their bespoke online portal, More Than Safety guide compliance, ensuring that all products purchased, are ones that have been approved by QHSE & Technical.
Champions of innovation, they bring the latest technologies and technical expertise to their clients, seeking product approval from onsite trials and testing. Being members of BSIF makes More Than Safety a supplier that can be relied upon for compliant products.
More Than Safety are most highly regarded for their mobilisation support with new contracts, often working with extremely tight schedules to deliver a faultless go-live experience, ensuring all new employees have the items they need on day one, a service backed up by dedicated account management.
More Than Safety are proud to be a true ESG friendly business. Members of Sedex, Eco Vadis Silver Award accredited, a Neutral Carbon Zone Gold Partner and a Living Wage Employer. Their new investment in Green Energy means that they are net exporters of electricity, producing more from their recent solar installation than they consume over the course of the year. They continue to improve upon their ISO 14001 Environmental Management plan and are ahead of schedule in their NetZero commitment. 
From the supply of new, innovative products to “end of lifecycle” recycling, More Than Safety are considered strategic partners by their clients in the FM industry.

Product Offering
•	Uniform
•	Corporate Clothing
•	PPE
•	Tools
•	Test equipment
•	Bespoke signage & boards
•	HV & LV inc Arc Flash PPE
•	LOTO
•	Access
•	Environmental spill response
•	Lone working devices

Service Delivery
•	In house Design & Production
•	Led by Procurement  Technical & QHSE
•	All items go through a strict approval process
•	Bespoke online system fully integrated into myBuy 
•	Dedicated customer service team & account management
•	Trusted & transparent supply chain

Value Add Services
•	A wide range of surveys available to ensure that sites are compliant:
•	Face Fit Testing
•	Tool Inspections
•	Spill Surveys
•	Signage Surveys
•	Site Footwear Days
•	Uniform & Workwear 
•	Sizing Days
•	Toolkit Specification Days 
(with manufacturers)', N'Special volume based discounts and rebates available to all NCZ customers', N'MTS-2024-001', N'MORE THAN SAFETY LTD', N'8695t1udh', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'57', NULL, N'Mark Parish', N'sales@aimcleaning.co.uk', N'(+44) 1322625650', NULL, NULL, NULL, N'https://www.aimcleaning.co.uk/', N'https://www.linkedin.com/company/aim-hygiene-services-ltd', NULL, NULL, NULL, N'Yes', N'Facilities Management', N'Commercial cleaning of buildings
Window cleaning
Carpet cleaning
Other one-off cleaning', N'N/A', N'AIM-2023-003', N'AIM Commercial Cleaning', N'8695mjxg2', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'58', NULL, N'Kelly Dolphin', N'kdolphin@sb-fm.co.uk', N'(07494) 450126', N'paul marsh', N'pmarsh@sb-fm.co.uk', N'(07957) 125526', N'sb-fm.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6029205424619907949/SBFM%20-%20Logo_White.png
https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6029205424619907949/SBFM%20x%20New%20Branding%20-%20Word.%20Letterhead%20Template%20Master.docx', N'Yes', N'Facilities Management', N'Services include (but not restricted to) 
Cleaning
Catering
Security
Waste management
Pest control
Grounds maintenance

Sectors include
Retail
Leisure and hospitality
Logistics and distribution
Corporate and professional services
Industrial and manufacturing
Public sector and education', N'NA at this time, for the purposes of completing this program, but can be discussed further with relevant parties', N'sbf-2024-001', N'SBFM', N'8677fpxbf', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'59', NULL, N'Phil Smith', N'philsmith@indigoifm.com', N'(07830) 340136', N'Jasmin Panzid-Foster', N'jasmin@panzima.com', N'(07855) 340136', N'www.indigoifm.com', N'https://www.linkedin.com/company/91674307', N'n/a', N'n/a', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6028204200275888250/INDIGO%20LOGO%202023%28Transparent%292.png', N'No', N'Facilities Management', N'Our approach is simple yet powerful - we bring together a team of best-of-breed performance specialists to ensure outstanding customer satisfaction.

In today''s competitive business landscape, managing facilities and ensuring smooth operations can be a daunting task for SMEs. That''s where we come in. Indigo offers a comprehensive suite of soft services tailored to meet the diverse needs of businesses across various sectors.

What sets us apart is our commitment to integration. We believe that by consolidating a range of services—including daily & specialist cleaning, pest control, reactive maintenance, landscaping, waste management, and more—we can streamline operations, enhance efficiency and minimise disruptions for our clients.

At Indigo, excellence is our guiding principle. We have handpicked a team of performance specialists who are leaders in their respective fields. Their expertise, combined with the latest technologies and innovative strategies, ensures that every aspect of our service delivery is of the highest standard.', N'25% discount on our Preferred Supply Partner annual subscription for all NCZ accredited organisations', N'IFM-2024-001', N'Indigo Integrated FM limited', N'8693retzm', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'60', NULL, N'Ollie Rastall', N'ollie@sourcesupplies.co.uk', N'(00144) 7889331687', NULL, NULL, NULL, N'https://www.sourcesupplies.co.uk/', NULL, NULL, NULL, NULL, N'Yes', N'Other', N'Source is a trusted partner for organisations at national and local level from a variety of sectors involved in cleaning and hygiene.', N'N/A', N'SOU-2023-001', N'Source Supplies', N'8677fpt2q', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'61', NULL, N'Francesca Moody', N'francesca.moody@goshorty.co.uk', N'(01625) 800147', N'Francesca Moody', N'francesca.moody@goshorty.co.uk', N'(0333) 4330001', N'https://goshorty.co.uk/', N'https://uk.linkedin.com/company/goshorty', N'https://www.facebook.com/goshortyinsurance/', N'https://www.instagram.com/goshortyuk/?hl=en-gb', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/6001464647716494886/goshorty-logo-master-rgb-1852px%4072ppi.jpeg', N'No', N'Other', N'GoShorty is a provider of Short-Term Insurance, sometimes called Temporary Vehicle Insurance. We offer Short Term Car, Van, and Learner Driver Insurance as well as Impound Release Insurance. This is our specialism and we are experts in the field. It is a flexible and affordable way to insure a car or van from 1 hour up to 28 days. Learners can get cover from 1-6 hours, or from 1 day up to 24 weeks. Quotes are quick and easy and insurance documents are delivered to your inbox immediately meaning customers are insured to drive straight away.
GoShorty also have a partnership scheme for anyone who wants to introduce customers to us in return for a healthy commission for those that go ahead and purchase a policy. We work with a large range of partners from the insurance industry such as brokers and networks as well as key affiliate partners and those positioned in the automotive industry.', N'N/A', N'GOS-2024-001', N'GoShorty', N'86958cw51', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'62', NULL, N'Syiane Knowles', N'syiane.knowles@airit.co.uk', N'(0115) 880004', N'Syiane Knowles', N'syiane.knowles@airit.co.uk', N'(+44) 7757335087', N'https://www.airit.co.uk/', N'https://www.linkedin.com/company/air-it/', N'https://www.facebook.com/AirITLtd', NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5987656822315143381/AirIT-Logo-Pos-Colour-CMYK.pdf', N'No', N'Information Technology', N'Managed IT Services - everything to do with companies IT from hardware, software and any other computer related difficulties and Cyber Security.', N'This is not a decision I can make but I can put you in touch with the decision maker on this topic following the completed report and NetZero Strategy. We are waiting for this information before we are able to look at offsetting etc.', N'AIT-2024-001', N'Air IT Limited', N'86940bb1d', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'63', NULL, N'Phil Smith', N'philsmith@indigoifm.com', N'(07830) 094421', N'Jasmin Panzid-Foster', N'jasmin@panzima.com', N'(07855) 340136', N'www.indigoifm.com', N'https://www.linkedin.com/company/91674307', N'n/a', N'n/a', NULL, N'No', N'Facilities Management', N'Daily commercial cleaning - offices, leisure facilities, manufacturing, warehousing & distribution
Washroom & janitorial services
Pest management
Grounds maintenance & landscaping
Waste management
Reactive cleaning & disaster recovery
Window cleaning & high-level maintenance
Signage - wayfaring, hoarding, building wrapping, vehicle wrapping
Vehicle leasing & fleet management', N'For any 3-year cleaning-led integrated facilities contract secured with another NCZ customer we will guarantee a minimum 8% cost reduction - on a like-for-like service - for the 1st year.', N'IFM-2024-001', N'Indigo Integrated FM limited', N'8693retzm', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'64', NULL, N'Elin Smith', N'elin@libertyexpressltd.com', N'(01932) 454852', NULL, NULL, NULL, N'www.libertyexpressltd.com', N'https://www.linkedin.com/company/93781196/', N'https://www.facebook.com/profile.php?id=61552074280590', N'https://www.instagram.com/liberty_express_ltd/', NULL, N'Yes', N'Transportation and Logistics', N'Freight forwarders', N'Please call or email for further details.', N'LEX-2023-003', N'LIBERTY EXPRESS LTD', N'8694vrnpr', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'65', NULL, N'brenda AXTEN', N'accounts@libertyexpressltd.com', N'(01932) 454852', NULL, NULL, NULL, N'www.libertyexpressltd.com', NULL, NULL, NULL, NULL, N'Yes', N'Transportation and Logistics', N'Freight forwarder', N'n/a', N'LEX-2023-003', N'LIBERTY EXPRESS LTD', N'8694vrnpr', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'66', NULL, N'Jason Roberts', N'jason@kaleida.co', N'(44) 7507681122', N'Jason Roberts', N'jason@kaleida.co', N'(44) 7507681122', N'https://kaleida.co', N'https://www.linkedin.com/company/kaleidaint/', NULL, N'www.instagram/kaleidaint', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5975360373414555370/Kaleida%20-%20Logo_Transparent_sml.gif', N'No', N'Information Technology', N'Founded in 2019, Kaleida International is a B2B marketplace for Tenders
connecting Buyers to Suppliers, and Diverse Suppliers. With a focus on helping
the Chief Procurement Office achieve its ESG goals, and alerting companies to
new revenue opportunities, Kaleida''s fully-inclusive platform helps Buyers find,
identify and assess Diverse Suppliers they can invite to Tender.

Kaleida''s fully-inclusive platform, a one-stop shop, and golden source of data is a market disruptor. We believe that for equality to be achieved, and equity distributed without prejudice or discrimination, Exclusive truly cannot be
Inclusive.', N'N/a - come back to me for the future', N'KAL-2023-001', N'Kaleida International Limited', N'8677fpqza', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'68', NULL, N'Joe Benitez', N'j.benitez@integrated-em.com', N'(+44) 7850853251', N'Christy Smith', N'c.smith@integrated-em.com', N'(7944) 624543', N'https://integrated-em.com/', N'https://www.linkedin.com/company/integrated-estate-management-ltd/mycompany/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5970351164415561225/100x100_logo.png
https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5970351164415561225/100x100_logo_JPEG.jpg', N'No', N'Facilities Management', N'We solve all your building maintenance challenges Quickly, Affordably and Efficiently', N'N/A', N'NCZ-2024-010', N'Integrated Estate Management Ltd', N'8678e1dd0', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'69', NULL, N'Eddie Hing', N'eddie.hing@universalnetworks.com', N'(01488) 685800', N'Ellie Thomas', N'Ellie.Thomas@universalnetworks.com', N'(01488) 685800', N'https://www.universalnetworks.co.uk/', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5970142771321715381/Universal-Networks-Logo-RGB-Dark.png', N'No', N'Information Technology', N'As fibre optic and copper cabling specialists, we’re focused on delivering reliable deployable fibre solutions suitable for the harshest of environments. With 30 years of experience and technical know-how, our journey is marked by a genuine passion to go the extra mile for our customers. Our Joscar, Cyber Essentials, ISO9001 and ISO14001 accreditations underpin our commitment to providing honest and open support for communications projects all over the world. 

Our termination capabilities include our ArmourLux range, HMA compatible Expanded Beam, Neutrik opticalCON, Hubbell/Hawke FibreEX, SC/ST/LC/FC alongside OCC MARS, IP connectivity boxes and media conversion. From initial enquiry through to after-sales servicing and repairs, we pride ourselves on being a responsive, reliable partner for those operating across multiple sectors, from Broadcast and Events to Defence and Aerospace.', N'N/A', N'UNL-2024-001', N'Universal Networks', N'8694cjgg8', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'70', NULL, N'Sarah Lumb', N'sarah@mission-global.com', N'(+971) 509116845', NULL, NULL, NULL, N'www.mission-global.com', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5957086486225893387/2%20Mission%20Global%20Logo%20Original.png', N'Yes', N'Transportation and Logistics', N'Mission Global, the future of event logistics; specialises in moving impossible commodities with those unrealistic deadlines
and necessary demands, such as Fireworks, Drones, UAV kits, Broadcasting and Communication, Music and Stage, all of
which require special local approvals. All complemented by our qualified air and ocean charter division and our onsite
logistics management teams, this is the “Mission Way” to secure successful Missions for all our clients.', N'N/A', N'MGL-2023-001', N'Mission Global LLC', N'86967kwwy', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'71', NULL, N'Malcolm Hills', N'Malcolm.hills@thinkfmsolutions.com', N'(0844) 8264842', NULL, NULL, NULL, N'www.thinkfmsolutions.com', N'https://www.linkedin.com/company/thinkfmsolutions/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5947756791317544132/Think%20FM%20Logo%20%28002%29.png', N'Yes', N'Facilities Management', N'Sure, Tommy! Here is a revised version of the text:

Think FM is a leading commercial cleaning company based in London, UK, offering a comprehensive range of cleaning services.

Our services include:

Fogging & Misting.
Daily Office Cleaning.
Window Cleaning.
Specialist Floor Cleaning.
Retail & Boutique Cleaning.
Communal Areas Cleaning.

By employing Think FM, you can concentrate on your core business and employees, while we take care of all your cleaning requirements.

Our dedicated area managers are central to our operations. They visit most sites weekly to ensure that our cleaners are well-trained, the sites are immaculate, and our clients are satisfied.

We also conduct a detailed monthly cleaning audit of your site, with the results easily accessible via our customer portal', N'N/A', N'TFM-2023-002', N'Think FM Solutions', N'8694cduzh', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'72', NULL, N'Sandy Muirhead', N'sandy@nomorebottles.ae', N'(971) 504169160', N'Sandy Muirhead', N'sandy@nomorebottles.ae', N'(971) 504169160', N'https://nomorebottles.ae', N'https://www.linkedin.com/company/no-more-bottles/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5941736095592193403/No%20More%20Bottles%20Logo%20-%20REGISTERED-01.png', N'Yes', N'Other', N'Water filtration solutions for homes, offices, hotels, restaurants', N'We will create landing page with special offers for NCZ clients', N'NMB-2024-001', N'N M B Water Treatment LLC', N'8694myuvm', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'73', NULL, N'Amanda Lovell', N'amanda.lovell@excellerateservices.com', N'(01277) 268899', N'Amanda Lovell', N'amanda.lovell@excellerateservices.com', N'(01277) 268899', N'https://www.excellerateservices.com/', N'https://www.linkedin.com/company/excellerateservicesukltd', N'https://www.facebook.com/ExcellerateUK', N'We do not have one', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5939263396415126635/ES_Logo-01.png', N'No', N'Facilities Management', N'We are a technology-led facilities management and support services company providing cleaning solutions to clients across the UK and Ireland. Our service delivery shapes our clients experiences through effective cleaning operations that focus on our stakeholders journeys, value for money, minimising risks, and delivering environments that befits our clients reputations.', N'N/A', N'EXS-2024-001', N'Excellerate Services UK Limited', N'86948jne1', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'74', NULL, N'Amanda Lovell', N'sales@excellerateservices.com', N'(01277) 268899', N'Amanda Lovell', N'amanda.lovell@excellerateservices.com', N'(01277) 268899', N'https://www.excellerateservices.com/', N'https://www.linkedin.com/company/excellerateservicesukltd', N'https://www.facebook.com/ExcellerateUK', N'We do not have one', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5929600165316920144/ExcellerateServicesLogo%20-%20High%20Res-05.png', N'No', N'Facilities Management', N'We are a technology-led facilities management and support services company providing cleaning solutions to clients across the UK and Ireland. Our service delivery shapes our clients experiences through effective cleaning operations that focus on our stakeholders journeys, value for money, minimising risks, and delivering environments that befits our clients reputations.', N'N/A', N'EXS-2024-001', N'Excellerate Services UK Limited', N'86948jne1', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'75', NULL, N'PAULINE FOSS', N'pauline.foss@hispec.co.uk', N'(1257) 262197', N'PAULINE FOSS', N'pauline.foss@hispec.co.uk', N'(1257) 262197', N'Hispec Electrical Products Limited', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5927873599914872015/Hispec%20logo%20White_Clear_Text_2023.png', N'Yes', N'Manufacturing', N'Importers and Distributors of Electrical Appliances encompassing lighting, domestic and commercial fire detection systems including CO Detection to Electrical Wholesalers throughout the UK.', N'N/A', N'HIS-2023-001', N'Hispec Electrical Products Limited', N'85zrqfekf', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'76', NULL, N'Trudy Cross', N'tcross@weareworkforce.co.uk', N'(044) 7854011817', N'Trudy Cross', N'tcross@weareworkforce.co.uk', N'(07854) 011817', N'www.weareworkforce.co.uk', N'https://www.linkedin.com/company/weareworkforce/', N'Workforce staffing', N'Workforce staffing', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5926998776886422212/WF_23_logo.jpg', N'No', N'Other', N'Employment agency providing temporary, contract and permanent job opportunities to clients and candidates', N'NA', N'WOR-2023-001', N'Workforce ', N'8677yq8rt', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'77', NULL, N'Vicky Chivell', N'vchivell@biologicalpreparations.com', N'(07543 ) 503500', N'Vicky Chivell', N'vchivell@biologicalpreparations.com', N'(07543) 503500', N'www.biologicalpreparations.com', N'https://www.linkedin.com/company/biological-preparations-limited/?lipi=urn%3Ali%3Apage%3Ad_flagship3_search_srp_all%3BXb1%2F3M6iS%2Bu7xz3m9hWtKw%3D%3D', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5921942933319298448/Bioloigcal%20Preparations%20Logo%202023%201.png', N'Yes', N'Other', N'Replacing harmful, non-renewable chemicals with Environmental Biotechnology', N'N/A', N'BPL-2024-001', N'Biological Preparations', N'8694cjk4h', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'78', NULL, N'Dominic Hobson', N'dominic.hobson@advantos.com', N'(07403) 166652', N'Dominic Hobson', N'dominic.hobson@advantos.com', N'(07403) 166652', N'https://ijcbuildingservices.co.uk/', N'https://www.linkedin.com/company/ijc-building-services-limited/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5910598467233390322/ijc-master-logo_group-with-logo.png', N'No', N'Construction', N'Founded in 2009, IJC Building Services is an experienced and reputable mechanical & electrical based company that services the commercial M&E market, the new build & private residential market as well as the wider facilities management market. The company differentiates itself by focusing primarily on service & response, having a dedicated service team, and ensuring dedicated supervision on each of its working sites for major projects, The majority of services are carried out by their own dedicated and qualified in house team of mechanical, electrical and fabric engineers but they are also able to service clients through the collaboration with the 100+ field team colleagues across the wider group.', N'Founded in 2009, IJC Building Services is an experienced and reputable mechanical & electrical based company that services the commercial M&E market, the new build & private residential market as well as the wider facilities management market. The company differentiates itself by focusing primarily on service & response, having a dedicated service team, and ensuring dedicated supervision on each of its working sites for major projects, The majority of services are carried out by their own dedicated and qualified in house team of mechanical, electrical and fabric engineers but they are also able to service clients through the collaboration with the 100+ field team colleagues across the wider group.', N'IJC-2024-001', N'IJC BUILDING SERVICES LIMITED', N'8694b66u2', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'79', NULL, N'Aine Solomon', N'aine@advance.fm', N'(01622) 720888', N'Glenn Thompson', N'glenn@advance.fm', N'(01622) 720888', N'https://advance.fm/', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5902772918959115602/Advance.png', N'No', N'Construction', N'Advance is a facilities maintenance provider offering a range of services to Commercial clients within the retail, industrial, health and social industries. Our services include fabric maintenance, plumbing, electrical, external repairs and internal repairs.', N'NA', N'ATS-2023-001', N'Advance Technical Solutions', N'8677fpr6h', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'80', NULL, N'Catriona Pow', N'catriona.pow@gs-associates.co.uk', N'(44) 7720998346', N'Bella Murray', N'Bella.murray@gs-associates.co.uk', N'(44) 7544156121', N'www.gs-associates.co.uk', N'linkedin.com/company/91151', N'facebook.com/gsassociatesltd', N'N/A', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5889921506229510849/Full_colour_LOGO_noBG.png', N'No', N'Facilities Management', N'GSA is a leading provider of cleaning services throughout the UK and Ireland, with expertise in multi-site retail premises, distribution centres and corporate office buildings.
Established in 1997, we are proud to deliver a high-quality, cost-effective and consistent service to a prestigious client list which includes Marks & Spencer, Currys, TKMaxx and Selfridges. Our exceptional client retention is testament to the commitment and dedication of our team.  
Guided by our company values of Reputation, Reliability, Responsibility and Reward, we approach every existing and new client relationship with honesty, flexibility and transparency.  We are committed to understanding every client’s particular needs and tailoring the delivery of our services to match their exact requirements.  We see every new client contract as a new partnership.  
Our company has enjoyed exponential growth in recent years; throughout which we have never lost sight of the importance of delivering an exceptional, value-for-money service for every client. 
We invest in our teams, in our equipment, and in our monitoring and reporting systems – and continuously review and improve our range of services.  This provides our clients with the peace of mind and certainty that their brand and their working environments, are in the best possible hands. 
To discuss how GSA could work in partnership with you across your retail sites, office buildings or distribution centres, why not send us an email to helpdesk@gs-associates.co.uk.', N'N/A', N'GSA-2024-001', N'GSA', N'869483v46', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'81', NULL, N'David O''Gorman', N'dogorman@citronhygiene.com', N'(+44) 7850 770519', N'Philip Fantham', N'philip.fantham@citronhygiene.com', N'(+44) 7825 283034', N'www.citronhygiene.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5874473334313522568/Citron%20Hygiene%20logo%20without%20TM.png', N'No', N'Other', N'With over 45 years of industry experience, we are one of the world’s leading providers of washroom hygiene services and products.

We have a wide range of washroom hygiene services such as air care, sanitary hygiene waste disposal, hand hygiene, and more.', N'N/A', N'CHL-2023-002', N'Citron Hygiene', N'8692tkcra', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'82', NULL, N'Jeremy mitchell', N'jeremy.mitchell@eiffage.com', N'(7795) 843422', N'Jeremy mitchell', N'jeremy.mitchell@eiffage.com', N'(7795) 843422', N'https://herbosch-kiere.be/en/', N'https://herbosch-kiere.be/en/', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5862944622511335459/Herbosch-Kiere_01_colour_RGB.jpg', N'No', N'Construction', N'The scope for the business conducted by Herbosch-Kiere is:
The planning, management, delivery and commissioning of hydraulic works, marine works, heavy lifting, general contracting, marine contracting, salvage works, demolition, foundation works and steel construction of engineering projects and soils remediation projects within Europe and worldwide.
This includes the following types of work; 
•	Marine engineering works including demolition, construction or refurbishment of structures along waterways such as quay walls, bridge abutments within national and international waters.
•	Civil engineering works including building work, concreting work, masonry, earthmoving etc.
•	Salvage and demolition work including ships, barges and vessels etc.
•	Construction of sewers and drains.
•	Environmental works including soils remediation and decontamination
•	Construction of steel structures such as bridges etc.
•	Foundation works including sheet-pile walls, slurry walls, various types of pile foundations and the placement of anchors etc.

Herbosch-Kiere is recognised for category 8 works within the EU.

Herbosch-Kiere''s design study service is limited to drawing up technical implementation plans of the above-mentioned buildings and the technical design of foundation works.
Herbosch-Kiere operate a fleet of marine vessels and marine plant which must also comply with national and international maritime law where applicable.', N'N/A', N'eif-2024-001', N'HERBOSCH KIERE', N'8693wmvyx', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'83', NULL, N'Sharon Griffin', N'sharon.griffin@apl-refurbishments.co.uk', N'(01622) 720888', N'Andy Weightman', N'andy@apl-refurbishments.co.uk', N'(01622) 720888', N'www.apl-refurbishments.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5854502438953483529/APL%20round.jpg', N'No', N'Construction', N'Refurbishment', N'N/A', N'APL-2023-001', N'Advance Group APL Refurbishments', N'8692uwjmu', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'84', NULL, N'Simon Harold', N'simon.harold@pceltd.co.uk', N'(01827) 301020', N'Mark Grubb', N'mark.grubb@pceltd.co.uk', N'(01827) 301020', N'www.pceltd.co.uk', N'https://www.linkedin.com/company/pce-limited/mycompany/?viewAsMember=true', N'https://www.facebook.com/PCEHybrid', NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5853517554513425533/PCE%2050th%20Anniversary%20Logos%20FINAL.png', N'Yes', N'Construction', N'PCE is a specialist in the design, manufacture, and construction of offsite hybrid solutions. Predominantly utilising pre-cast concrete and other materials that are manufactured offsite and delivered to the site in sequence in a just-in-time method which reduces the number of deliveries required and waste/product. We have delivered prisons such HMP Millsike, HMP Five Wells, Dakita Hotel Manchester, multi award winining Kingston University Townhouse to name a few.', N'N/A', N'PCE-2023-002', N'PCE LTD', N'86938zbhm', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'85', NULL, N'Andy Etherington', N'andy@59club.com', N'(077) 85614531', N'Andrew Etherington', N'andy@59club.com', NULL, N'www.59clubuk.com', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5847643117819416945/59club%20Main%20Logo.png', N'Yes', N'Other', N'59club, the Industry leading Customer Service Analysts and Training Provider, operates within, UK, Ireland, Europe, USA, Canada, Middle East, Africa, Asia, Australia & New Zealand.

With a wealth of ground-breaking Customer Satisfaction Surveys, Mystery Shopper Audits, Financial Comparison Tools and Employee Training Programs; 59club UK provides performance management solutions and global data to the Golf, Leisure, Spa, F&B and Hotel Industries, to elevate Sales Performance and the Customer Experience across their respective client properties.', N'N/A', N'CLU-2023-002', N'59club', N'8693wjvfx', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'86', NULL, N'Sharon Griffin', N'sharon.griffin@apl-refurbishments.co.uk', N'(01622) 720888', N'Andy Weightman', N'andy@apl-refurbishments.co.uk', NULL, N'www.apl-refurbishments.co.uk', N'APL Refurbishments', NULL, NULL, NULL, N'No', N'Construction', N'APL is a refurbishment and refit specialist operating throughout London and the South East of England. We are multi-sector contractors with a full service team that can undertake complete commercial fit-out and refurbishments up to £2m, and smaller-scale refit and refurbishment projects. APL can operate as principal contractors, sub-contractors or project managers for both end-users and consultants.', N'N/A', N'apl-2023-001', N'APL-refurbishments', N'8692uwjmu', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'87', NULL, N'Scott Rogers', N'scott.rogers@jsmbuildingsolutions.co.uk', N'(01253) 890690', N'Scott Rogers', N'scott.rogers@jsmbuildingsolutions.co.uk', N'(01253) 890690', N'www.jsmbuildingsolutions.co.uk', N'https://www.linkedin.com/company/jsm-building-solutions-ltd-', N'https://www.facebook.com/JSMBuildingSolutions', N'N/a', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5843161889217751053/FINAL%20LOGO.jpg', N'No', N'Facilities Management', N'Turn-Key Delivery within the built environment - Mechanical - Electrical - Building Fabric - Maintenance all deliverer and managed in house.', N'Free consultations', N'JSM-2023-001', N'JSM Building Solutions', N'8677fprb6', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'88', NULL, N'Alina Cozma', N'alina.cozma@sayvol.co.uk', N'(01536) 280040', N'Alina Cozma', NULL, NULL, N'www.sayvol.co.uk', N'(26) Sayvol Environmental and Building Services Limited: My Company | LinkedIn', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5842479511328849971/Sayvol%20Logo.png', N'Yes', N'Other', N'Sayvol, established in 1989, are a traditional water treatment company who have expanded over the years into environmental and building services to meet the demands of both existing and new clients.
In 2002 Sayvol Environmental & Building Services Limited was created to dedicate an experienced team to these ever growing needs.
Sayvol recognise that their success is based on a working partnership, and this is reflected in our commitment to all our customers.
Sayvol currently collaborates with over 120 customers, with over £9M annual turnover and with more than 65 employees, we expertly deliver essential water compliance and sustainable services in any sector across the UK and Ireland.

We have a Head Office in Kettering, near Northampton and Regional Offices in Canary Wharf/London, Nutley/East Sussex and Stoke-on-Trent, which ensures that we can provide UK wide cover.



Accreditations and Membership 

Sayvol Environmental & Building Services Ltd are suppliers of water treatment/hygiene services to various M&E companies, Facilities Management Service companies and Direct End Users. 

Sayvol Environmental & Building Services Ltd have achieved the following accreditations:

ISO 9001:2015
ISO 14001:2015

ISO 45001:2018
PAS99
CHAS

SafeContractor
ConstructionLine
Common Assessment Scheme (CAS)
Achilles
Carbon Neutral

Sayvol Enviromental and Building Services Ltd are comprehensively registered with the Legionella Control Association.


              






Services and Supplies 

Sayvol specialise in the following service offerings:

Water Treatment

Cooling Tower, Closed System & Steam Boiler treatment programmes.
Domestic water biocidal treatment such as chlorine dioxide, chlorine, hydrogen peroxide and others best suited to the application.
Chemical cleaning/flushing/descaling of water systems.
Supply of a wide range of associated chemicals, best suited to the application.

Water Hygiene
 
L8/HSG 274 monitoring & management.
Cleaning & Disinfection of tanks/water systems.
Water sampling – waterborne pathogens.

Consultancy

Legionella & Water Risk Assessments.
Bespoke Written Schemes.
BS8552 Closed System investigative reporting/sampling.
Training Courses – Water.

Engineering

Tank Replacements/Refurbishment.
Turnkey solutions for water/energy/chemical cost saving.
Cooling water reclamation systems.
Bespoke solutions for specific water quality.
Borehole water treatment.

Equipment

Installation, commissioning and servicing of:
Water Softeners, Reverse Osmosis (RO), Ultra-Violet (UV) water treatment units.
Ion-exchange systems.
Cooling Tower dosing & control equipment.
S-Sensing Closed System water quality monitoring stations.
Filtration/Dosing units. We are proud to be a DosaFil® approved supplier and installer.
Reduced Pressure Zone (RPZ) valves.

Air Hygiene

Ventilation & Indoor Air Quality surveys.
Indoor Air Quality monitoring regime.
LEV Testing.
Ventilation and associated ductwork cleaning.', N'N/A', N'SAY-2023-001', N'Sayvol Environmental & Building Services Ltd', N'8692vn67a', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'89', NULL, N'Euan Johnson', N'e.johnson@camsupport.co.uk', N'(44) 7375323829', N'Rumaysa Pujara', N'r.pujara@camsupport.co.uk', N'(44) 7850986767', N'www.camsupport.co.uk', N'https://uk.linkedin.com/company/cam-specialist-support', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5838161924514293737/CAM-col.jpg', N'No', N'Facilities Management', N'High level cleaning, and maintenance services.', N'For new sites, projects and tasks; we offer 3% discount on quoted works.', N'CAM-2023-001', N'CAM Specialist Support Ltd', N'86937q5j8', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'90', NULL, N'Gillian Drummond', N'gillian.drummond@mgm.ltd.uk', N'(0191) 4822100', NULL, NULL, NULL, N'www.mgm.ltd.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5838161763846996571/Logo-2022%20%28002%29.jpg', N'No', N'Construction', N'Building Contractor', N'n/a', N'MGM-2023-001', N'MGM Ltd', N'8677fpr9c', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'91', NULL, N'Euan Johnson', N'e.johnson@camsupport.co.uk', N'(+44) 7375323829', N'Rumaysa Pujara', N'r.pujara@camsupport.co.uk', N'(+44) 7850986767', N'WWW.CAMSupport.CO.UK', N'https://uk.linkedin.com/company/cam-specialist-support', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5838067904518471844/CAM-col.jpg', N'No', N'Facilities Management', N'High Level cleaning, Maintenance services', N'For new projects, sites or orders; we would offer a 3% discount on quoted works.', N'CAM-2023-001', N'CAM Specialist Support Ltd', N'86937q5j8', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'92', NULL, N'Taylor Grice', N'taylor.grice@hexenergy.co.uk', N'(+44) 76999382', NULL, NULL, NULL, N'www.hexenergy.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5832085641568717486/hex%20logo%20canva-%20grey%20.png', N'No', N'Energy', N'Hex Energy specializes in designing, installing, and maintaining a wide range of heat pumps, catering to various energy needs. In addition to heat pump solutions, the company also offers services for solar photovoltaic (PV) systems, mechanical ventilation with heat recovery (MVHR), and underfloor heating systems. Our comprehensive approach ensures sustainable and efficient energy solutions for both residential and commercial properties.', N'n/a', N'hex-2023-001', N'Hex Energy ltd ', N'86785yqg4', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'93', NULL, N'Alina Cozma', N'alina.cozma@sayvol.co.uk', N'(7518) 398796', NULL, NULL, NULL, N'www.sayvol.co.uk', NULL, NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5831162694211053980/Sayvol%20Logo.png', N'Yes', N'Other', N'Sayvol Environmental and Building Services Ltd

Sayvol, established in 1989, are a traditional water treatment company who have expanded over the years into environmental and building services to meet the demands of both existing and new clients.
In 2002 Sayvol Environmental & Building Services Limited was created to dedicate an experienced team to these ever growing needs.
Sayvol recognise that their success is based on a working partnership, and this is reflected in our commitment to all our customers.

Sayvol currently collaborates with over 120 customers, with over £10M annual turnover and with more than 65 employees, we expertly deliver essential water compliance and sustainable services in any sector across the UK and Ireland.
We have a Head Office in Kettering, near Northampton and Regional Offices in Canary Wharf/London, Nutley/East Sussex and Stoke-on-Trent, which ensures that we can provide UK wide cover.



Accreditations and Membership 

Sayvol Environmental & Building Services Ltd are suppliers of water treatment/hygiene services to various M&E companies, Facilities Management Service companies and Direct End Users. 

Sayvol Environmental & Building Services Ltd have achieved the following accreditations:

ISO 9001:2015
ISO 14001:2015

ISO 45001:2018
PAS99
CHAS

SafeContractor
ConstructionLine
Common Assessment Scheme (CAS)
Achilles
Carbon Neutral

Sayvol Enviromental and Building Services Ltd are comprehensively registered with the Legionella Control Association.', N'Services and Supplies 

Sayvol specialise in the following service offerings:

Water Treatment

Cooling Tower, Closed System & Steam Boiler treatment programmes.
Domestic water biocidal treatment such as chlorine dioxide, chlorine, hydrogen peroxide and others best suited to the application.
Chemical cleaning/flushing/descaling of water systems.
Supply of a wide range of associated chemicals, best suited to the application.

Water Hygiene
 
L8/HSG 274 monitoring & management.
Cleaning & Disinfection of tanks/water systems.
Water sampling – waterborne pathogens.

Consultancy

Legionella & Water Risk Assessments.
Bespoke Written Schemes.
BS8552 Closed System investigative reporting/sampling.
Training Courses – Water.

Engineering

Tank Replacements/Refurbishment.
Turnkey solutions for water/energy/chemical cost saving.
Cooling water reclamation systems.
Bespoke solutions for specific water quality.
Borehole water treatment.

Equipment

Installation, commissioning and servicing of:
Water Softeners, Reverse Osmosis (RO), Ultra-Violet (UV) water treatment units.
Ion-exchange systems.
Cooling Tower dosing & control equipment.
S-Sensing Closed System water quality monitoring stations.
Filtration/Dosing units. We are proud to be a DosaFil® approved supplier and installer.
Reduced Pressure Zone (RPZ) valves.

Air Hygiene

Ventilation & Indoor Air Quality surveys.
Indoor Air Quality monitoring regime.
LEV Testing.
Ventilation and associated ductwork cleaning.', N'SAY-2023-001', N'Sayvol Environmental & Building Services Ltd', N'8692vn67a', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'94', NULL, N'Richard Theobold', N'richard.theobold@precisionfm.co.uk', N'(0116) 3666508', N'Richard Theobold', N'richard.theobold@precisionfm.co.uk', N'(0116) 3666508', N'https://www.precisionfm.co.uk/', N'https://uk.linkedin.com/company/precision-facilities-management', N'https://www.facebook.com/precfm/', N'https://www.instagram.com/precisionfm/', N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5831140616414417551/new%20logo%20June%2021.png', N'Yes', N'Facilities Management', N'Hard FM -From reactive maintenance to planned and preventative maintenance including damage and repairs
-Cleaning Services including High Level, Deep cleans, Contract Cleaning and Environmental
-Ground Maintenance and Landscaping
-Call handling and Call Centre support services
-Workplace design and interior fit-outs ( including project management)
-Security Services - Guarding, Key-holding, CCTV Remote handling, Mobile Patrols and Consultancy', N'N/A', N'PFM-2023-001', N'Precision Facilities Management', N'869357awe', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'95', NULL, N'Sharon McLaren', N'smclaren@corpssecurity.co.uk', N'(07980) 769178', N'Sharon McLaren', N'smclaren@corpssecurity.co.uk', N'(07980) 769178', N'Corps Security UK Ltd', N'Corps Security UK Ltd', NULL, NULL, N'https://app.neutralcarbonzone.com/uploads/!team_231353647716055/240292243754859/5830227649217820318/CS%20Logo_2022_colour.png', N'No', N'Other', N'Security Services', N'N/A', N'COR-2023-001', N'Corps Security UK Ltd', N'8677fpr7u', N'1', NULL, NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'96', NULL, N'ram barot', N'ram@test.com', N'765-765757', N'nilesh bhakhar', N'nil@test.com', N'876-876876', N'company.com', N'li.in/company', N'fb.com/company', N'insta.com/company', NULL, N'Yes', N'Hospitality', N'company description', N'discounts/offers', N'NIL-1234-567', N'Test company', NULL, N'0', N'6246773319428273179', NULL)
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'97', NULL, N'tara borner', N'tara.borner@otiumservices.co.uk', N'01474-822144', N'tara borner', N'tara.borner@otiumservices.co.uk', N'01474-822144', N'Otium Services and Facilities Limited', N'', N'', N'', NULL, N'Yes', N'Facilities Management', N'Otium Services is a leading UK provider of superior cleaning and soft services for educational 
institutions, businesses, and more. Committed to creating clean, safe, and sustainable 
environments, Otium combines expertise, advanced technology and a custom approach to 
clients needs. 
Established with a vision to provide exceptional cleaning and soft services, Otium Services 
has been the preferred choice for many educational institutions, businesses, and industries 
across the UK. Their comprehensive services range from regular maintenance and cleaning 
to creating environmentally friendly spaces. 
Leveraging their dedicated team of professionals, advanced technology, and a strong 
commitment to sustainability, they deliver high-quality solutions to surpass expectations. 
Otium Services believe in fostering clean, safe, and sustainable environments that 
contribute to a healthier future. ', N'n/a', N'osf-2024-001', NULL, NULL, N'0', N'6249376310129884443', N'2025-06-05 13:00:33.4100000')
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'98', NULL, N'Stephanie Henderson', N'info@securigroup.co.uk', N'0844-8080999', N'Kieran  Foy', N'Kieran.Foy@securigroup.co.uk', N'0141-2255218', N'www.securigroup.co.uk', N'', N'', N'', NULL, N'Yes', N'Other', N'SecuriGroup Limited is one of the UK''s leading security service providers, offering a comprehensive range of products and services tailored to various sectors. 

Our offerings include:
Core Security Services
Manned Guarding: On-site security personnel for commercial, retail, and public sector clients.
Retail Security: Specialist services for retail environments, including loss prevention and customer service.
Key Holding & Alarm Response: Secure key management and rapid response to alarm activations.
Event Security: Crowd management and safety services for events of all sizes.
Door Supervision: Licensed personnel for nightlife and hospitality venues.
Close Protection: Personal security services for high-profile individuals.
Public Space CCTV Monitoring: Surveillance and monitoring services for public areas.

Technology & Systems
Security Systems: Installation and maintenance of CCTV, access control, and intruder alarms.
Remote Monitoring: 24/7 monitoring of security systems from a central control room.

Specialist Services
Consultancy & Risk Assessment: Tailored security audits and risk management strategies.
Training Services: Accredited training programs for security professionals.', N'N/A', N'SEG-2025-001', NULL, NULL, N'0', N'6249383867462087766', N'2025-06-05 13:13:07.8700000')
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'99', NULL, N'Suna Ahioglu', N'suna@chamberlaine.co.uk', N'020-76246330', N'Suna Ahioglu', N'suna@chamberlaine.co.uk', N'020-76246330', N'www.chamberlaine.co.uk', N'', N'', N'', NULL, N'No', N'Other', N'Chamberlaine provide a full suite of facilities services to complement their daily office cleaning contracts including washroom services, window cleaning, specialist periodic services and hard floor care to 200 plus clients throughout Central London and have one of the highest retention rates of staff and clients within the industry. ', N'N/A', N'CCS-2023-002', NULL, NULL, N'0', N'6254637166818663631', N'2025-06-11 15:08:38.3566667')
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'100', NULL, N'Max Reames', N'sales@peartreecleaning.co.uk', N'01277-201420', N'Georgianna Hull', N'ghull@peartreecleaning.co.uk', N'01277-240754', N'www.peartreecleaning.co.uk', N'https://www.linkedin.com/company/peartree-cleaning-services-limited/mycompany/?viewAsMember=true ', N'https://www.facebook.com/profile.php?id=100073768213474 ', N'', NULL, N'Yes', N'Other', N'We offer a contract cleaning service working in a variety of different industries, we also offer subcontracting services including windows cleaning, pest control, horticultural services.', N'N/A', N'PEA-2023-004', NULL, NULL, N'0', N'6271698091715342043', N'2025-07-01 09:03:32.1900000')
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'101', NULL, N'John Braimoh', N'john.braimoh@dubaiharbour.com', N'00971-506634724', N'John  Braimoh', N'john.braimoh@dubaiharbour.com', N'00971-506634724', N'https://www.dubaiharbour.com/', N'https://www.linkedin.com/company/dubaiharbour/', N'https://www.facebook.com/VisitDubaiHarbour', N'https://www.instagram.com/dubaiharbour/', NULL, N'No', N'Other', N'Dubai Harbour Marina

Offers commercial and private vessel berthing within its Marinas.

Services to vessels while staying within the Marinas. ', N'N/A', N'DHM-2025-001', NULL, NULL, N'0', N'6274132814818288450', N'2025-07-04 04:41:25.1033333')
GO

INSERT INTO [portal].[NCZDirectory] ([dirItemId], [companyId], [salesName], [salesEmail], [salesPhone], [esgName], [esgEmail], [esgPhone], [website], [linkedinPage], [facebookPage], [instagramPage], [logo], [emissionOffset], [industryType], [companyDescription], [offersDiscounts], [customerReference], [companyName], [certTaskId], [isVisible], [submissionId], [dateUpdated]) VALUES (N'102', NULL, N'Dubai Harbour Marinas', N'john.braimoh@dubaiharbour.com', N'00971-0506634724', N'John  Braimoh', N'john.braimoh@dubaiharbour.com', N'-', N'https://www.dubaiharbour.com/', N'https://www.linkedin.com/company/dubaiharbour/', N'https://www.facebook.com/VisitDubaiHarbour', N'https://www.instagram.com/dubaiharbour/', NULL, N'No', N'Other', N'Dubai Harbour Marinas is a premier maritime destination in the Middle East, offering over 700 berths for yachts up to 160 meters in length. Strategically located with direct access to the Arabian Gulf, it provides year-round berthing supported by advanced technical facilities, high-end security, and luxury services1. Designed as a vibrant seafront district, the marina integrates retail, hospitality, and entertainment, making it not just a docking space but a lifestyle hub for yacht owners, crew, and visitors.', N'N/A', N'DHM-2025-001', NULL, NULL, N'0', N'6276948028229924660', N'2025-07-07 10:53:24.4466667')
GO

SET IDENTITY_INSERT [portal].[NCZDirectory] OFF
GO


-- ----------------------------
-- Table structure for Programme
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Programme]') AND type IN ('U'))
	DROP TABLE [portal].[Programme]
GO

CREATE TABLE [portal].[Programme] (
  [progId] int  NOT NULL,
  [progName] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isActive] bit  NULL,
  [description] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[Programme] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Programme
-- ----------------------------
INSERT INTO [portal].[Programme] ([progId], [progName], [isActive], [description]) VALUES (N'1', N'Blue Award', N'1', NULL)
GO

INSERT INTO [portal].[Programme] ([progId], [progName], [isActive], [description]) VALUES (N'2', N'Silver Award', N'1', NULL)
GO

INSERT INTO [portal].[Programme] ([progId], [progName], [isActive], [description]) VALUES (N'3', N'Gold Award', N'1', NULL)
GO

INSERT INTO [portal].[Programme] ([progId], [progName], [isActive], [description]) VALUES (N'4', N'Platinum Award', N'1', NULL)
GO


-- ----------------------------
-- Table structure for ProgrammeDocuments
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ProgrammeDocuments]') AND type IN ('U'))
	DROP TABLE [portal].[ProgrammeDocuments]
GO

CREATE TABLE [portal].[ProgrammeDocuments] (
  [progId] int  NOT NULL,
  [documentId] int  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayOrder] smallint DEFAULT 0 NULL,
  [isDeleted] bit DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[ProgrammeDocuments] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'documents.document.id',
'SCHEMA', N'portal',
'TABLE', N'ProgrammeDocuments',
'COLUMN', N'documentId'
GO


-- ----------------------------
-- Records of ProgrammeDocuments
-- ----------------------------
INSERT INTO [portal].[ProgrammeDocuments] ([progId], [documentId], [displayName], [displayOrder], [isDeleted]) VALUES (N'2', N'12', N'Silver_Award_Document_1.pdf', N'1', N'0')
GO

INSERT INTO [portal].[ProgrammeDocuments] ([progId], [documentId], [displayName], [displayOrder], [isDeleted]) VALUES (N'2', N'13', N'Silver_Award_Document_2.pdf', N'2', N'0')
GO

INSERT INTO [portal].[ProgrammeDocuments] ([progId], [documentId], [displayName], [displayOrder], [isDeleted]) VALUES (N'2', N'14', N'Silver_Award_Document_3.pdf', N'3', N'0')
GO

INSERT INTO [portal].[ProgrammeDocuments] ([progId], [documentId], [displayName], [displayOrder], [isDeleted]) VALUES (N'3', N'15', N'Gold_Award_Document_1.pdf', N'1', N'0')
GO

INSERT INTO [portal].[ProgrammeDocuments] ([progId], [documentId], [displayName], [displayOrder], [isDeleted]) VALUES (N'3', N'16', N'Gold_Award_Document_2.pdf', N'2', N'0')
GO

INSERT INTO [portal].[ProgrammeDocuments] ([progId], [documentId], [displayName], [displayOrder], [isDeleted]) VALUES (N'3', N'17', N'Gold_Award_Document_3.pdf', N'3', N'0')
GO

INSERT INTO [portal].[ProgrammeDocuments] ([progId], [documentId], [displayName], [displayOrder], [isDeleted]) VALUES (N'4', N'18', N'Platinum_Award_Document_1.pdf', N'1', N'0')
GO

INSERT INTO [portal].[ProgrammeDocuments] ([progId], [documentId], [displayName], [displayOrder], [isDeleted]) VALUES (N'4', N'19', N'Platinum_Award_Document_2.pdf', N'2', N'0')
GO

INSERT INTO [portal].[ProgrammeDocuments] ([progId], [documentId], [displayName], [displayOrder], [isDeleted]) VALUES (N'4', N'20', N'Platinum_Award_Document_3.pdf', N'3', N'0')
GO


-- ----------------------------
-- Table structure for ProgrammeForms
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ProgrammeForms]') AND type IN ('U'))
	DROP TABLE [portal].[ProgrammeForms]
GO

CREATE TABLE [portal].[ProgrammeForms] (
  [progId] int  NOT NULL,
  [jotformId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayOrder] smallint DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[ProgrammeForms] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ProgrammeForms
-- ----------------------------
INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'1', N'241290444812856', N'NCZ Blue Award Questionnaire', N'1')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231702222306037', N'Business Travel', N'7')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231761029921959', N'Natural Gas', N'4')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231835207128453', N'Electricity', N'2')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231921316591454', N'Water', N'3')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231951471518458', N'Other Fuels', N'5')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231953063487462', N'Refrigerents', N'8')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231998306100453', N'Waste and Recycling', N'10')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232013593953456', N'Purchased Goods & Services', N'9')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232102389529457', N'Commuting & Home Working', N'13')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232408584059461', N'Upstream deliveries', N'11')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232561815184457', N'Downstream deliveries', N'12')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232571467469467', N'Company Vehicles', N'6')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'241290444812856', N'Company Profile', N'1')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231702222306037', N'Business Travel', N'10')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231761029921959', N'Natural Gas', N'4')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231835207128453', N'Electricity', N'2')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231921316591454', N'Water', N'3')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231951471518458', N'Other Fuels', N'5')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231953063487462', N'Refrigerents', N'7')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231998306100453', N'Waste and Recycling', N'8')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232013593953456', N'Purchased Goods and Services', N'11')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232102389529457', N'Commuting & Home Working', N'9')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232408584059461', N'Upstream deliveries', N'13')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232561815184457', N'Downstream deliveries', N'12')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232571467469467', N'Company Vehicles', N'6')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'250151633085854', N'Company Profile', N'1')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231702222306037', N'Business Travel', N'10')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231761029921959', N'Natural Gas', N'4')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231835207128453', N'Electricity', N'2')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231921316591454', N'Water', N'3')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231951471518458', N'Other Fuels', N'5')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231953063487462', N'Refrigerents', N'7')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231998306100453', N'Waste and Recycling', N'8')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232013593953456', N'Purchased Goods and Services', N'11')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232102389529457', N'Commuting & Home Working', N'9')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232408584059461', N'Upstream deliveries', N'13')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232561815184457', N'Downstream deliveries', N'12')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232571467469467', N'Company Vehicles', N'6')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'250151633085854', N'Company Profile', N'1')
GO


-- ----------------------------
-- Table structure for Users
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Users]') AND type IN ('U'))
	DROP TABLE [portal].[Users]
GO

CREATE TABLE [portal].[Users] (
  [userId] int  IDENTITY(1,1) NOT NULL,
  [companyId] int DEFAULT 0 NULL,
  [fullName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [email] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [status] int  NULL,
  [uId] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isDeleted] bit DEFAULT 0 NULL,
  [dateUpdated] datetime2(7)  NULL,
  [phone] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isEmailVerified] bit DEFAULT 0 NULL,
  [guId] uniqueidentifier DEFAULT newid() NULL
)
GO

ALTER TABLE [portal].[Users] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Users
-- ----------------------------
SET IDENTITY_INSERT [portal].[Users] ON
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'1', N'0', N'NCZ Support', N'support@neutralcarbonzone.com', N'1', N'dedljIi0nmNlAhI4Q6lEMEVT2Yj2', N'0', N'2025-04-29 05:30:05.4100000', NULL, N'1', N'7BAEB5DC-53B9-4708-BE86-5C2F36243940')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'2', N'0', N'Nilesh Bhakhar', N'nilesh@neutralcarbonzone.com', N'1', N'vthQXFyrjJPEBzKwBWyS0hLAlCI2', N'0', N'2025-03-31 17:59:25.1400000', NULL, N'1', N'EB68E04B-AFA1-4EA7-9BE0-D4E6BD2E3867')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'4', N'0', N'NCZ Admin', N'admin@neutralcarbonzone.com', N'1', N'qIHmLMp8nGZpRMqlC70y4bChtur1', N'0', N'2025-04-17 13:16:53.1866667', NULL, N'1', N'28218B85-2DAB-4421-B857-F53689A229E8')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'5', N'2', N'NCZ Client', N'client@neutralcarbonzone.com', N'1', N'CU2ylHl9nnRkSWPIQpWBKQmDLTw1', N'0', N'2025-03-31 11:43:14.4433333', NULL, N'1', N'D43C73CD-4181-47E2-B366-52BE84CDA938')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'7', N'7', N'Ryan White', N'ryan.white@example.com', N'1', N'firebase_107', N'0', N'2025-03-31 11:43:14.4433333', NULL, N'0', N'6D3A316F-55E2-4DB4-9E4E-F22112D0F79A')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'8', N'8', N'Olivia Hall', N'olivia.hall@example.com', N'1', N'firebase_108', N'0', N'2025-03-31 11:43:14.4433333', NULL, N'0', N'4138199F-D8DB-44F5-A6F9-CBD7BC7D64A9')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'10', N'10', N'Mia Walker', N'mia.walker@example.com', N'1', N'firebase_110', N'0', N'2025-03-31 11:43:14.4433333', NULL, N'0', N'7F030998-0C9A-44FD-854A-E9B100D50C62')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'13', N'1', N'sdfsdf', N'john.doe@example2.com', N'0', NULL, N'0', N'2025-04-17 13:02:23.1800000', NULL, N'0', N'2272E277-96DA-48B3-A2A5-282613CA4C8D')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'16', N'0', N'Alpha Tech 1', N'john.doe2@example.com', N'1', NULL, N'0', N'2025-04-17 12:22:13.7000000', NULL, N'0', N'F6EECA8D-450A-4F27-99C8-D859579D733F')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'17', N'0', N'Ram Barot', N'rbarot@example.com', N'1', NULL, N'0', N'2025-04-04 06:57:04.3700000', N'123-456-7890', N'0', N'67D03CB0-5625-4A20-BA3C-699E5D4F1C02')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'18', N'0', N'Ram test', N'ramtest@example.com', N'1', NULL, N'0', N'2025-04-04 10:22:20.5233333', NULL, N'0', N'466F8005-7C50-423E-A5A1-AEEF6A5AE94D')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'19', N'2', N'Role Test', N'role@test.com', N'1', NULL, N'0', N'2025-04-17 11:58:46.7400000', N'fgdfg', N'0', N'B6417E80-3D3D-489B-844F-CEE89EF67CBF')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'20', N'2', N'dasdasd', N'sadas@sddg.hgfh', N'1', NULL, N'1', N'2025-04-19 06:07:36.5933333', NULL, N'0', N'44A41F8D-C995-4ADD-B615-F926E5EEC88C')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'21', N'2', N'gfdgdfg', N'fdgf@fgdfg.hjhj', N'1', NULL, N'1', N'2025-04-19 06:07:27.5533333', NULL, N'0', N'DEF3C2CD-4090-4B4C-96F7-FBD0C22C2AF9')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'23', N'1', N'Test 180425', N'Test@180425.com', N'2', NULL, N'0', N'2025-04-18 10:18:11.2200000', N'123-456-7890', N'0', N'E1003F99-1542-48B6-8A60-B9D6014BF92E')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'47', N'2', N'Ramkrishna Barot', N'ramkrishna.barot@gmail.com', N'1', N'cTQEh1Sh3UMZffwVTjq9AkDSxdC2', N'0', N'2025-04-28 06:18:57.4866667', NULL, N'1', N'8ABC26CA-B6EC-42AF-A140-8E990EFE1ADC')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'48', N'0', N'Nilesh Bhakhar', N'nileshbhakhar22@gmail.com', N'1', N'RiyVJSueqHYCb7oKNFXPcSKSeWw1', N'0', N'2025-04-28 08:53:40.7266667', NULL, N'1', N'CFF6ED5C-A015-41A8-A69F-C0948949F8DB')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'49', N'0', N'Nitin Bhakhar', N'nitinbhakhar22@gmail.com', N'2', N'qwWpYc2X2UQZ8gwJyLsqGAST2jL2', N'0', N'2025-04-28 08:54:27.8700000', NULL, N'0', N'B47E6973-6A1C-46E2-B873-E1CA24D0DEAB')
GO

INSERT INTO [portal].[Users] ([userId], [companyId], [fullName], [email], [status], [uId], [isDeleted], [dateUpdated], [phone], [isEmailVerified], [guId]) VALUES (N'50', N'1', N'Ramkrishna Yahoo', N'ramkrishna_barot@yahoo.co.in', N'1', N'Syi3KUJdKXPTl3C06NsOqEsmb4G2', N'0', N'2025-04-29 10:05:04.3500000', NULL, N'1', N'B6424E45-1AB1-43AC-B827-EE5D881EFC09')
GO

SET IDENTITY_INSERT [portal].[Users] OFF
GO


-- ----------------------------
-- Table structure for XCertificationDocuments
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XCertificationDocuments]') AND type IN ('U'))
	DROP TABLE [portal].[XCertificationDocuments]
GO

CREATE TABLE [portal].[XCertificationDocuments] (
  [certDocId] int  IDENTITY(1,1) NOT NULL,
  [certId] int  NOT NULL,
  [documentId] int  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayOrder] smallint DEFAULT 0 NULL,
  [isDeleted] bit DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[XCertificationDocuments] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of XCertificationDocuments
-- ----------------------------
SET IDENTITY_INSERT [portal].[XCertificationDocuments] ON
GO

SET IDENTITY_INSERT [portal].[XCertificationDocuments] OFF
GO


-- ----------------------------
-- Table structure for XCustomerDirectory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XCustomerDirectory]') AND type IN ('U'))
	DROP TABLE [portal].[XCustomerDirectory]
GO

CREATE TABLE [portal].[XCustomerDirectory] (
  [companyId] int  IDENTITY(1,1) NOT NULL,
  [companyName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [email] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [registrationNumber] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [phone] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [address] nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [industryType] int  NULL,
  [website] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [status] int  NOT NULL,
  [logo] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [clickupTaskId] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dateCreated] datetime2(7)  NULL,
  [dateUpdated] datetime2(7)  NULL,
  [isDeleted] bit DEFAULT 0 NULL,
  [industryTypeOther] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
  [contactName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [jobTitle] nvarchar(75) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [countryId] int  NULL,
  [nczCustomerDirectory] bit DEFAULT 1 NULL,
  [linkedInPage] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(300) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[XCustomerDirectory] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'dropdownItems groupId=3',
'SCHEMA', N'portal',
'TABLE', N'XCustomerDirectory',
'COLUMN', N'countryId'
GO

EXEC sp_addextendedproperty
'MS_Description', N'Show in NCZ Customer Directory',
'SCHEMA', N'portal',
'TABLE', N'XCustomerDirectory',
'COLUMN', N'nczCustomerDirectory'
GO


-- ----------------------------
-- Records of XCustomerDirectory
-- ----------------------------
SET IDENTITY_INSERT [portal].[XCustomerDirectory] ON
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'1', N'SFS PROTECT LTD', N'ruth.harrison@sfsprotect.co.uk', N'10993362', NULL, NULL, N'12', N'www.sfsprotect.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/5974487257744643086/SFS%20Landscape%20web.jpeg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', NULL, N'Ruth  Harrison', N'Managing Director', N'32', N'1', N'www.linkedin.com/in/ruth-harrison-6aa067182/', NULL, N'5974487257744643086')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'2', N'Think FM Solutions Limited', N'Tommy@thinkfm.co.uk', N'08694984', NULL, NULL, N'12', N'Think FM Solutions Limited', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6086041549217058837/Think_FM_Logo%20jpeg.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Tommy Taylor', N'Compliance and Quality Manager', N'32', N'1', N'Think FM Solutions Limited', N'Think FM, a London-based cleaning company with 20+ years'' experience, offers tailored services like office, retail, and specialist cleaning. Accredited for quality, sustainability, and fair wages, Think FM prides itself on delivering reliable, profes', N'6086041549217058837')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'3', N'Kingdom Cleaning Limited', N'jennifer.hanson@kingdom.co.uk', N'02102149', NULL, NULL, N'12', N'https://www.kingdom.co.uk/cleaning', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6092162924614201514/Kingdom%20Cleaning%20Ltd%20Logo.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Jennifer Hanson', N'Compliance Officer', N'32', N'1', N'https://www.linkedin.com/company/kingdomcleaning/', N'Kingdom Cleaning Limited provides commercial cleaning services, including cleaning supplies, across the UK.', N'6092162924614201514')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'4', N'PCMS Cleaning Services Ltd', N'vikki@pcms-ltd.co.uk', N'12123696', NULL, NULL, N'12', N'www.pcms-ltd.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6132755757227751237/NEW%20lOGO%20photoshop%20Support%20Services%20Thicker%20SAGE.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Vikki Vincent', N'Commercial Manager', N'32', N'1', N'PCMS Cleaning Services Ltd', N'Commercial Cleaning Services ', N'6132755757227751237')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'5', N'Capitol Cleaning & Support Services ', N'mason@capitolhygiene.co.uk', N'07875732 & 08823060', NULL, NULL, N'12', N'www.capitolhygiene.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6154199851415300467/capitol%20logo%20AMX.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Mason Edwards', N'Director', N'32', N'1', N'Capitol Cleaning & Support Services ', N'At Capitol Cleaning & Support Services, we provide high quality, professional cleaning services throughout the UK. Our focus is on daily contract cleaning for offices, shops, schools and other business premises, as well as ad hoc services such as builders cleans, carpet cleaning etc.', N'6154199851415300467')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'6', N'Carb''n-Off Limited', N'luka@carbn-off.co.uk', N'7330066', NULL, NULL, N'12', N'www.carbn-off.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6158704224327131481/carbn_off_logo_a_2023_rgb.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Luka Arlauske', N'Director of Operations', N'32', N'1', N'', N'We specialise in professional kitchen environment deep cleaning services, with a strong focus on commercial kitchen extraction and ductwork cleaning. ', N'6158704224327131481')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'7', N'Tectonix Natural Stone Ltd', N'chris@tectonix.co.uk', N'14171285', NULL, NULL, N'13', N'www.tectonix.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6156998205385853094/Tectonix_MASTER_logo%20PNG%20High.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Chris Frankland', N'Director', N'32', N'1', N'https://www.linkedin.com/company/tectonixuk/', N'Tectonix is an innovative external surfaces company based in Leeds, UK, specialising in providing natural stone paving and masonry solutions for the landscaping industry. ', N'6156998205385853094')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'9', N'PCE Limited', N'helen.harrison@pceltd.co.uk', N'1146346', NULL, NULL, N'13', N'https://pceltd.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6055675224515637674/PCE%20Logo%20%28no%20background%29.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Helen Harrison', N'Sales & Estimating Administrator', N'32', N'1', N'https://www.linkedin.com/company/pce-limited/?viewAsMember=true', N'Design, Manufacture and Construction of offsite Hybrid Structures. ', N'6055675224515637674')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'10', N'RSS Infrastructure Ltd', N'tenderenquiries@rssinfrastructure.com', N'6278727', NULL, NULL, N'13', N'rssinfrastructure.com', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Matthew Cardiff', N'Bid Writer', N'32', N'1', N'https://www.linkedin.com/company/rss-infra', NULL, N'5982353188313331529')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'12', N'Reade Signs Ltd', N'naomif@readesigns.com', N'4103520', NULL, NULL, N'13', N'www.readesigns.com', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'naomi fowler', N'Finance Director', N'32', N'1', N'https://www.linkedin.com/company/3493714/admin/dashboard/', NULL, N'6044676622615393365')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'13', N'One Stop Consult Ltd', N'ben@onestopconsult.co.uk', N'10891161', NULL, NULL, N'13', N'www.onestopconsult.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6049684102417849002/onestopimg.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Ben Dunn', N'Managing Director ', N'32', N'0', N'https://www.linkedin.com/company/onestopconsult', N'Welcome to One Stop Consult – Your Construction Supply Chain Experts!

We provide cost-effective, high-quality solutions for developers, builders, & pros. Choose from building control, structural engineering, testing, and more. Trusted partners, fa', N'6049684102417849002')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'14', N'Wright Choice VA Ltd', N'lianne@wrightchoiceva.co.uk', N'13641872', NULL, NULL, N'29', N'www.wrightchoiceva.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6006016802424392811/Wright_Choice_Logo_Long_white.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Lianne Wright', N'Director', N'32', N'1', N'https://www.linkedin.com/company/wright-choice-virtual-assistants/?viewAsMember=true', NULL, N'6006016802424392811')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'15', N'Green Fields Environmental Consultancy', N'bilal.khalid@gfecsa.com', N'2051226246', NULL, NULL, N'29', N'www.gfecsa.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6007342196286762395/gfec%20logo.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Bilal Khalid Shaikh', N'Senior Environmental Specialist', N'227', N'1', N'https://www.linkedin.com/company/gfecsa/', NULL, N'6007342196286762395')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'16', N'WB Shiels Ltd', N'rob@wbshiels.com', N'09498732', NULL, NULL, N'29', N'www.wbshiels.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6017933470721156645/Logo.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Rob Beales', N'Director', N'32', N'1', N'https://www.linkedin.com/company/wb-shiels  ', NULL, N'6017933470721156645')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'17', N'Empro Business Group Ltd', N'emma@emprogroup.co.uk', N'11666540', NULL, NULL, N'29', N'www.emprogroup.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/5939071600718095449/EmPro%20Logo%20Circle.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Emma Armstrong ', N'Managing Director ', N'32', N'1', N'https://www.linkedin.com/company/12668876/admin/feed/posts/', NULL, N'5939071600718095449')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'19', N'Kingdom Healthcare Limited', N'jennifer.hanson@kingdom.co.uk', N'NI058523', NULL, NULL, N'19', N'https://kingdom-healthcare.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6092439519416151593/Kingdom%20Healthcare%20Ltd%20Logo.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Jennifer Hanson', N'Compliance Officer', N'32', N'1', N'https://www.linkedin.com/company/kingdom-healthcare/', N'Kingdom Healthcare Limited provides domiciliary carers and nurses to care agencies across the UK. ', N'6092439519416151593')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'21', N'Light Projects Evolve Ltd', N'ba@lightprojects.co.uk', N'15471551', NULL, NULL, N'9', N'www.lpevolve.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6236322365118962345/02581b11-d208-4130-a05b-84c238c92354.jpeg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Brendon airey', N'Director', N'32', N'1', N'', N'Provides high quality led lighting and mesh based lighting controls to buildings that have a need for lighting. ', N'6236322365118962345')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'22', N'NCS South Ltd', N'novac.controls@btinternet.com', N'1273206001', NULL, NULL, N'9', N'https://app.neutralcarbonzone.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6093031403521593007/nvc.PNG', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Mr Neil Clarke', N'director', N'32', N'1', N'NCS South Ltd', N'design supply install and maintenance of Building management systems and general control systems', N'6093031403521593007')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'29', N'BioAir Solutions L.L.C', N'hezaldeen@bioairsolutions.com', N'', NULL, NULL, N'9', N'www.bioairsolutions.com', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Haidar Ezal-Deen', N'Regional Sales Manager', N'34', N'1', N'https://www.linkedin.com/company/bioair-solutions-llc/mycompany/', NULL, N'5989207328719563090')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'30', N'I-Flow Technologies ', N'tomlangdell@electroair.org.uk', N'12419249', NULL, NULL, N'9', N'https://i-flowtechnologies.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6013497008767416935/i-flow-logo-gradient-bg_rev1.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Tom  Langdell', N'Owner ', N'32', N'1', N'https://i-flowtechnologies.com/', NULL, N'6013497008767416935')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'32', N'Competent Management', N'ask@cmsyst.com', N'207342', NULL, NULL, N'15', N'www.cmsyst.com', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Faraz Ali', N'MD', N'34', N'1', N'cmsyst.com', NULL, N'6014510740528806685')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'33', N'SLM Waste Management Ltd', N'lucy@slm-waste.com', N'12606981', NULL, NULL, N'15', N'slm-waste.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6017739063328915803/Company%20Logo.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Lucy Annett', N'Managing Director ', N'32', N'1', N'SLM Waste Management Ltd', NULL, N'6017739063328915803')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'35', N'ABC Ltd', N'jberk@abc.com', N'2345678', NULL, NULL, N'15', N'abc.com', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'johnny berk', N'MD', N'32', N'1', N'linkedin.com/abc', NULL, N'5938976933214238769')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'36', N'H2O Hygiene Ltd', N'liam.pirrie@h2ohygiene.co.uk', N'10878528', NULL, NULL, N'15', N'www.h2ohygiene.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6065249560318004547/H2O.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Liam Pirrie', N'Compliance Manger', N'32', N'1', N'H2O Hygiene Ltd', N'H2O Hygiene Ltd is a water hygiene company providing services for clients including legionella risk assessments, monitoring contracts, water treatment, water hygiene, sampling and legionella control, plumbing and mechanical solutions for water system', N'6065249560318004547')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'37', N'Tenon fm', N'juseph.londono@tenonfm-uk.com', N'', NULL, NULL, N'15', N'https://www.tenonfm-uk.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6067046229793666262/T%20logo.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Juseph Londono', N'ESG & Quality Assurance Coordinator', N'32', N'1', N'https://uk.linkedin.com/company/tenon-fm-uk', N'Facilities Management which currently mainly focus on cleaning services', N'6067046229793666262')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'39', N'Fairclean LTd', N'harry@neutralcarbonzone.com', N'05843880', NULL, NULL, N'15', N'N/a', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Harry Bentham', N'Director', N'32', N'1', N'N/A', N'', N'6074827998745522161')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'40', N'Integrated Estate Management Ltd', N'j.benitez@integrated-em.com', N'11657337', NULL, NULL, N'15', N'https://integrated-em.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6120782616514995351/100x100_logo_JPEG.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Joe Benitez', N'Managing Director', N'32', N'1', N'https://www.linkedin.com/company/integrated-estate-management-ltd/?viewAsMember=true', N'IEM are a full-service FM company dedicated to providing tailored solutions for various sector clients. We specialise in delivering reactive and planned maintenance, compliance management and projects. ', N'6120782616514995351')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'41', N'Apollo Cleaning Services Ltd', N'mike@apollocleaning.co', N'01197218', NULL, NULL, N'15', N'https://apollocleaning.co/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6092999150919818570/Apollo%20logo.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Michael Savage', N'Director', N'32', N'1', N'https://www.linkedin.com/company/apollo-cleaning-uk/about/', N'Since 1970, Apollo Cleaning Services has specialized in in providing daily cleaning and related services for non-residential spaces.  Apollo Cleaning prices itself on independent, personal approach led by our deeply experienced team.  ', N'6092999150919818570')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'42', N'Pendergate Limited t/a Kindred', N'lwaller@kindredfm.com', N'2289025', NULL, NULL, N'15', N'www.kindredfm.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6095566907821701842/Kindred%20Logo%20COLOUR%20CMYK.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Lucy Waller', N'Marketing & Change Director', N'32', N'1', N'https://www.linkedin.com/company/kindredfm', N'We are Kindred, and our purpose is to create, deliver and maintain cleaning services for commercial and learning environments.  We have over 30 years’ of experience in running specialist cleaning contracts across the UK. ', N'6095566907821701842')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'43', N'Hawkesworth Appliance Testing', N'm.maguire@hawktest.co.uk', N'721 6363 52', NULL, NULL, N'15', N'www.hawkesworth.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6102632212027259653/Hawkesworth%20white%20logo%20600dpi.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Maggie Maguire', N'Head of People', N'32', N'1', N'https://www.linkedin.com/company/hawkesworth-appliance-testing-limited/', N'Hawkesworth provide electrical and fire safety services across the UK and Ireland.', N'6102632212027259653')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'46', N'Southcote Financial Limited ', N'wkiely@southcotefinancial.co.uk', NULL, NULL, NULL, N'6', N'www.southcotefinancial.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6045540959407617444/Southcote-logo%20%281%29.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', NULL, N'Will Kiely ', N'Financial Advisor ', N'32', N'1', N'Southcote Financial Limited ', N'We are a wealth management firm specialising in advice for business owners, high net worth individuals and those who are approaching retirement. We offer advice across a range of products, services and taxation strategies. ', N'6045540959407617444')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'47', N'Zest Marketing Services Ltd', N'sophie@zestmarketingagency.co.uk', N'15217156', NULL, NULL, N'17', N'zestmarketingagency.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6055168655763580111/zest-logo-full-deep-blue%403x.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Sophie Donald', N'Director', N'32', N'1', N'https://www.linkedin.com/company/zestmarketingagency', N'We specialise in the FM and built environment industry and understand the challenges you face. Your expertise is in helping people; ours is in helping you.

We’re a full-service agency, expertly driven to support you with the full marketing mix.', N'6055168655763580111')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'48', N'RAGC Limited', N'manager@ragolf.co.uk', N'04279097', NULL, NULL, N'11', N'www.ragolf.co.uk', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Stephen Nicholson', N'General Manager', N'32', N'1', N'www.linkedin.com/company/royal-ascot-golf-club', N'Royal Ascot Golf Club is a private members golf club that offers golf to a variety of golfers, from beginner to seasoned golfer.

We offer a rare mix of tradition, exciting social dining and corporate facilities and a modern golf course built in an', N'6048856858447013090')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'53', N'Digitalalina', N'abdul@digitalina.io', N'11223344', NULL, NULL, N'30', N'www.digitalina.io', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'Marketing', N'Test Abdul', N'VA', N'32', N'1', N'www.digitalina.io', NULL, N'5989309609536268673')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'54', N'Candour Fitness and Movement', N'trevor@candourfm.com', N'', NULL, NULL, N'30', N'www.candourfm.com', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'Fitness and Wellbeing', N'Trevor Chaplin', N'Director', N'32', N'1', N'https://www.linkedin.com/in/trevorchaplin/', NULL, N'6005554777209974694')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'55', N'Sun-X (UK) Ltd', N'james@sun-x.co.uk', N'1382406', NULL, NULL, N'30', N'www.sun-x.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6029945049447739879/Sun-X%20logo%20%26%20royal%20warrant%282%29.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'window film, blinds', N'james willson', N'Director', N'32', N'1', N'www.linkedin.com/in/jameswillsonatsunx', NULL, N'6029945049447739879')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'57', N'Candour Fitness and Movement', N'trevor@candourfm.com', N'', NULL, NULL, N'30', N'https://www.candourfm.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6043609114229216222/trevor1.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'Fitness and Wellbeing', N'Trevor Chaplin', N'Personal Trainer', N'32', N'0', N'https://www.linkedin.com/in/trevorchaplin/', NULL, N'6043609114229216222')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'59', N'TWinFM Test', N'dave@twinfm.com', N'', NULL, NULL, N'30', N'www.twinfm.com', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'Media', N'Dave Mapps', N'Director', N'32', N'1', N'ThisWeekinFM', N'Reviewing this system.  This is not accurate data.', N'6095430280911830153')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'60', N'Mustang Washrooms Limited', N'doreen.springate@mustangwashrooms.com', N'5832029', NULL, NULL, N'30', N'www.mustangwashrooms.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6072273318977002893/Mustang%20wash%20Logo%20HIGH%20RES.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'Washroom Services', N'Doreen Springate', N'Accounts', N'32', N'1', N'Mustangwashroomslimited', N'Mustang Washrooms is a market leader in the washroom and hygiene industry thanks to our wide range of high quality products and excellent customer service.
We recognise the importance of keeping our staff and clients happy, as well as reducing the i', N'6072273318977002893')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'61', N'Pest Check Ltd', N'tristan@pestcheck.co.uk', N'11509939', NULL, NULL, N'27', N'www.pestcheck.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6137806733511283090/Pest-Check-Logo.bmp', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Tristan  Adams ', N'Director ', N'32', N'1', N'n/a', N'We cover commercial and domestic pest control dealing with all forms of protection, prevention and treatment.', N'6137806733511283090')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'63', N'ALKOBLAN', N'rdtech@alkoblan.com.sa', N'', NULL, NULL, N'20', N'www.alkoblan.com.sa', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'AHMED SATTI', N'MR', N'227', N'1', N'N/A', NULL, N'6000439372113554852')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'66', N'Finlay Jude Associates Ltd ', N'rose@fjal.co.uk', N'08166365', NULL, NULL, N'8', N'www.finlayjudeassociates.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6104286448973983555/Finlay%20Jude%20Logo.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Rose Langley', N'Business Administrator ', N'32', N'1', N'Finlay Jude Associates Ltd ', N'Finlay Jude Associates Ltd specialise in placing candidates in various sectors, such as, utilities, water/wastewater, civil engineering, manufacturing, industrial, office, and finance roles, both temporary and permanent. ', N'6104286448973983555')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'68', N'Tecrec', N'Harrison@wearetecrec.com', N'11752587', NULL, NULL, N'8', N'https://www.wearetecrec.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6066327264512967191/Hi%20res%20TR%20Logo%20%28002%29.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', NULL, N'Harrison Andrews', N'Director ', N'32', N'1', N'https://www.linkedin.com/company/86204859', N'Tecrec is one of the industry’s fastest growing staffing agencies. With over 30 years + combined recruitment experience, we have the capacity to build longevity within your workforce.

', N'6066327264512967191')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'69', N'Kingdom People Limited ', N'jennifer.hanson@kingdom.co.uk', N'10006972', NULL, NULL, N'8', N'https://www.kingdom.co.uk/recruitment', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6092225624618518181/Kingdom%20People%20Ltd%20Logo.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Jennifer Hanson', N'Compliance Officer', N'32', N'1', N'https://www.linkedin.com/company/kingdom-people/', N'Kingdom People Limited provides agency staff, and as part of this delivers best in class training services, supporting clients through various training courses by using the apprenticeship levy fund, to various sectors across the UK. ', N'6092225624618518181')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'70', N'Bandobras Ltd (TA Bando Towels)', N'rohan@bandotowels.com', N'12713189', NULL, NULL, N'22', N'bandotowels.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6081024424352635635/Bando%20sustainable%20sports%20merchandise%20-%20Logo%20black.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Rohan Lee', N'Co-Founder', N'32', N'1', N'https://www.linkedin.com/company/bandotowels', N'Bando Towels is the sustainable choice for premium custom sports towels and event gifts. Made from post-consumer recycled plastic materials, our towels are fully customisable for any branding or event. Design yours today at bandotowels.com.', N'6081024424352635635')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'71', N'Kingdom Security Limited', N'jennifer.hanson@kingdom.co.uk', N'09983854', NULL, NULL, N'7', N'https://www.kingdom.co.uk/security', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6092031604614175884/Kingdom%20Security%20Ltd%20Logo.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Jennifer Hanson', N'Compliance Officer', N'32', N'1', N'https://www.linkedin.com/company/kingdom-security-services/', N'Kingdom Security Limited provides security officers to various organisations across the UK, and as part of this provides technology solutions to support security and facilities management, and also supports local authorities with trained enforcement ', N'6092031604614175884')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'73', N'Corps Security (UK) Ltd', N'jcollier@corpssecurity.co.uk', N'03473589', NULL, NULL, N'7', N'www.corpssecurity.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6135425099219532903/GetAttachmentThumbnail.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'James Collier', N'Compliance & Sustainability Co-ordinator', N'32', N'1', N'https://www.linkedin.com/company/corps-of-commissionaires-management-ltd/', N'At Corps, we provide specialist security services tailored to ensure the safety of property and people. We’re also a Social Enterprise, with the goal of making a difference, improving lives and protecting the things that matter to us all.', N'6135425099219532903')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'75', N'SmartSec Solutions Limited', N'dele.ogunlaru@smartsecsolutions.com', N'7036995', NULL, NULL, N'7', N'https://www.smartsecsolutions.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6127865778324912083/SmartSec%20Solutions.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Dele Ogunlaru', N'Operations Director', N'32', N'1', N'https://www.linkedin.com/company/smartsec-solutions/', N'SmartSec Solutions is a specialist security and reception provider that supports organisations across the UK.
Offering a full suite of protection and management services in bespoke packages, we are the preferred security provider for prestige properties in Central London and throughout the Capital.', N'6127865778324912083')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'76', N'City Guardians Ltd', N'rob@cityguardians.co.uk', N'15339532', NULL, NULL, N'7', N'https://www.cityguardians.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/5941855578613837536/Main%20-%20Blue%20on%20White%202400x1800.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Rob Du Toit', N'Director', N'32', N'1', N'https://www.linkedin.com/company/city-guardians/', NULL, N'5941855578613837536')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'77', N'Circle UK Group ltd. ', N'thomas@circleukgroup.co.uk', N'09133602', NULL, NULL, N'7', N'https://circleukgroup.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6174317430103473352/Circle%20UK%20group%20black.jpg', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Thomas Babu', N'HSE and Compliance Officer', N'32', N'1', N'https://www.linkedin.com/company/circleukgroup', N'Circle UK Group Ltd, based in Enfield, specializes in security services. Approved under the ACS for 8 years, its directors hold SIA licenses and each own 50%. Operating near Southbury Station, it complies with BS 7499 & BS 7858. With £7.6M revenue, it holds ISO9001:2015 and key industry memberships.', N'6174317430103473352')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'78', N'Bermia IT', N'ricky.majer@bermiait.co.uk', N'123456', NULL, NULL, N'18', N'www.bermiait.co.uk', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', NULL, N'Ricky Majer', N'CTO', N'32', N'1', N'www.linkedin.com', NULL, N'5911248312932453196')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'80', N'Betterup', N'ophelia.bellio@betterup.co', N'464390865', NULL, NULL, N'18', N'https://www.betterup.com/', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'ophelia Bellio', N'Head of Workplace Services ', N'32', N'1', N'https://www.linkedin.com/company/betterup/', NULL, N'5998823217217629080')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'81', N'Betterup', N'ophelia.bellio@betterup.co', N'5455102', NULL, NULL, N'18', N'https://www.betterup.com', N'1', NULL, NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'ophelia Bellio', N'Global Work place Manager ', N'33', N'0', N'https://www.linkedin.com/company/betterup/', NULL, N'5988449127217973861')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'82', N'JSM Building Solutions Ltd', N'megan.smith@jsmbuildingsolutions.co.uk', N'8803091', NULL, NULL, N'14', N'www.jsmbuildingsolutions.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/241290444812856/6061136869219633413/JSMLogo-Black.png', NULL, N'2025-05-28 09:42:01.5933333', NULL, N'0', N'', N'Meg smith', N'Buyer', N'32', N'1', N'n/a', N'M&E Contractors, fabric contractors, technical maintenance, refurbishment & fit out.', N'6061136869219633413')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'110', N'Herbosch-Kiere', N'oliver.mallinson@eiffage.com', N'291 8680', NULL, NULL, N'13', N'https://herbosch-kiere.be/en/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6159463468225997065/HK%20logo.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Oliver Mallinson', N'SHEQ Manager', N'32', N'1', N'https://www.linkedin.com/company/herbosch-kiere-marine-contractors-ltd/posts/?feedView=all', N'Marine construction management ', N'6159463468225997065')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'111', N'Cynergi Cleaning & Support Services', N'lydiabennie@cynergi-services.co.uk', N'05725284', NULL, NULL, N'12', N'https://cynergi-services.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6159500181324538286/Cynergi%20Logo%20dual.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Lydia Bennie', N'HSEQ Administrator', N'32', N'1', N'Cynergi Cleaning & Support Services', N'Cynergi Cleaning & Support Services is one of the leading providers of soft services management. Cynergi works across a variety of sectors including large commercial establishments, corporate offices and manufacturing establishments. ', N'6159500181324538286')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'112', N'Etech Southern Limited', N'paul@etechsouthern.co.uk', N'06754667', NULL, NULL, N'13', N'www.etechsouthern.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6161979932674882171/eTech2500.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Paul Todd', N'Managing Director', N'32', N'1', N'Etech Southern Limited', N'We are a professional Design and Build Electrical Contractor with offices in Essex and London, UK. Our expertise spans a wide range of electrical services, and our strategically located offices enable us to efficiently serve clients across the region and beyond.', N'6161979932674882171')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'113', N'Redditch United Football Club Ltd', N'iain.wain@redditchunited.co.uk', N'01082116', NULL, NULL, N'30', N'https://redditchunited.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6162125253878408778/badge.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Sport - Football', N'Iain Wain', N'Managing Director', N'32', N'1', N'https://www.linkedin.com/company/redditch-united/', N'Home to 45 junior teams, 500+ players, mens and Womens first teams, Redditch United is the community hub of the town of Redditch. 

The club delivers education provision for mainstream and SEND students, with two full-time football & education programmes, collectively housing 75 students.', N'6162125253878408778')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'114', N'Geldbach (UK) Ltd', N'mirek.nowak@geldbach.co.uk', N'5853863', NULL, NULL, N'9', N'https://www.geldbach.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6163866269439145122/gelbach-logo-web.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Mirek Nowak', N'Purchasing Manager', N'32', N'1', N'https://www.linkedin.com/company/geldbach-uk/', N'Importer and Stockist of Steel Fittings and Flanges', N'6163866269439145122')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'115', N'Grade One', N'stephen@grade-one.co.uk', N'3024184', NULL, NULL, N'12', N'www.grade-one.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6165452556111325383/website%20logo.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Stephen Corrigan', N'Managing Director ', N'32', N'1', N'N/A', N'Cleaning and Support Services ', N'6165452556111325383')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'118', N'Pioneer Products T/A Janitorial Express', N'david@janitorialexpress.co.uk', N'02587625', NULL, NULL, N'12', N'www.janitorialexpress.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6168074604764880538/JE-MASTER-LOGO-COLOUR.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'David Gourlay', N'Managing Director', N'32', N'1', N'www.janitorialexpress.co.uk', N'Distribution of cleaning supplies and cleaning machinery to cleaning / FM companies.
We have 2 London sites and the vast majority of our customers are London based and serviced by our own drivers. Outside of London & surrounding areas we use TNT to deliver to our customers.', N'6168074604764880538')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'119', N'The Show & Effects LLC - Flash Art', N'tsamuel@flashart.com', N'558535', NULL, NULL, N'30', N'www.flashart.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6168896599613058908/A9Rw7bckt_1173rbj_aao.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Fireworks / Pyrotechnics', N'Anthony Samuel', N'Technical Director', N'34', N'1', N'None', N'Flash Art is the world’s first carbon-neutral fireworks company, delivering high-profile displays like Jumeirah and Dubai Frame NYE, Expo 2020, and UAE National Day. Using advanced firing tech, we ensure precision and sustainability, creating unforgettable experiences that connect and inspire.', N'6168896599613058908')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'120', N'Peartree Cleaning Services', N'ghull@peartreecleaning.co.uk', N'02045868', NULL, NULL, N'12', N'https://www.peartreecleaning.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6168927081714408212/Peartree%20Logo.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Georgianna Hull', N'ESG Manager', N'32', N'1', N'https://www.linkedin.com/company/peartree-cleaning-services-limited/posts/?feedView=all', N'Commercial cleaning and soft services', N'6168927081714408212')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'121', N'Geldbach UK Ltd', N'adam@neutralcarbonzone.com', N'', NULL, NULL, N'22', N'www.nzcworld.com', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Adam Hoult', N'', N'34', N'0', N'Geldbach UK Ltd', N'Standard Office Cleaning (UK) Ltd', N'6168931420616604755')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'123', N'BELFOR UK Ltd', N'steven.emery@uk.belfor.com', N'01369726', NULL, NULL, N'13', N'www.belfor.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6169045969214648301/BELFOR%20Logo.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Steve Emery', N'SHEQ Director', N'32', N'1', N'https://uk.linkedin.com/company/belforukltd', N'The provision of damage management, restoration and construction services for
commercial, industrial and domestic properties', N'6169045969214648301')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'124', N'One Stop Consult', N'ben@onestopconsult.co.uk', N'10891161', NULL, NULL, N'13', N'www.onestopconsult.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6169153942415559836/COMPANY%20LOGO.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Ben Dunn', N'Managing Director ', N'32', N'1', N'https://www.linkedin.com/company/onestopconsult', N'One Stop Consult is a team of construction professionals offering building compliance and project management. Using our bespoke portal system, we provide sustainable supply chain procurement, ensuring cost-effective solutions.', N'6169153942415559836')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'125', N'Knightsbridge Property Services', N'will.mclaughlin@kpsltd.co.uk', N'2659811', NULL, NULL, N'13', N'www.kpsltd.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6170560368913062861/KPS%20Box%20Logo%20%28JPEG%29.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Will McLaughlin', N'Managing Director', N'32', N'1', N'https://www.linkedin.com/company/knightsbridge-property-services-ltd/?viewAsMember=true', N'Knightsbridge Property Services Ltd (KPS) are a trustworthy, customer focused construction and refurbishment contractor delivering a wide range of services in a variety of sectors across the South of England. ', N'6170560368913062861')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'126', N'Edmund Services Limited', N'peter.brooks@edmundservices.com', N'01854921', NULL, NULL, N'15', N'www.edmundservices.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6171506563847835908/GetAttachmentThumbnail.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Peter Brooks', N'Business Director', N'32', N'1', N'https://www.linkedin.com/company/edmund-services/?viewAsMember=true', N'', N'6171506563847835908')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'128', N'Tate Security technology ltd', N'eashcroft@tate-security.co.uk', N'4119865', NULL, NULL, N'7', N'https://tate-security.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6174245720982559912/logo.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Emily Ashcroft', N'Compliance & Sales assistant ', N'32', N'0', N'https://www.linkedin.com/company/tate-security-technology-ltd/', N'Security systems in High Security Prison establishments, supplying over 110 prisons in the UK. Provide security & safety solutions to the public & private sectors including HMP services, MOJ, National Offender Management services, secure hospitals. Tate also provide Fire & Safety Systems to Stadiums', N'6174245720982559912')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'129', N'Jangro Ltd', N'd.hunter@jangrohq.net', N'03125118', NULL, NULL, N'30', N'https://www.jangro.net/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6174276036711180797/Jangro_logo.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Cleaning, Hygiene and Catering Suppliers', N'Daisy Hunter', N'Sustainability & Innovation Manager', N'32', N'1', N'https://www.linkedin.com/company/jangro-ltd/posts/?feedView=all', N'Jangro is a dynamic force in the cleaning supply industry and is the largest network of independent janitorial distributors in the UK and Ireland.

The Jangro mark has evolved over the years to be recognised as the premier independent brand for the professional janitorial service contractor. ', N'6174276036711180797')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'130', N'SW Global Resourcing', N'rhishays@sw-gr.com', N'SWG-2025-001', NULL, NULL, N'9', N'https://www.sw-gr.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6176029110311011427/Screenshot%202025-03-12%20at%2015.31.29.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Rhishay Sinha', N'Administrative Assistant ', N'32', N'1', N'https://www.linkedin.com/company/swgr100211-001614/posts/?feedView=all', N'SWGR provides specialist rail infrastructure services, focusing on workforce supply, track maintenance, and safety-critical operations. They offer skilled manpower, welding, and plant services, ensuring efficient railway construction, upgrades, and maintenance across the UK rail network.', N'6176029110311011427')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'131', N'Tate Security technology ltd', N'eashcroft@tate-security.co.uk', N'4119865', NULL, NULL, N'7', N'https://tate-security.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6181101810987717523/logo.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Emily Ashcroft', N'Compliance & Sales assistant ', N'32', N'1', N'https://www.linkedin.com/company/tate-security-technology-ltd/', N'Design, install, maintain security systems in High Security Prisons, & supply over 110 prisons in the UK. Provide security/safety solutions in public & private sectors; HMP''s, MOJ, National Offender Management & secure hospitals. Design, install, maintain, commission Fire/Safety Systems in stadiums', N'6181101810987717523')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'132', N'ACSEU Ltd', N'james@acseu.co.uk', N'11864474', NULL, NULL, N'12', N'www.acseu.co.uk', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'james Thornton', N'Operations Director', N'32', N'1', N'ACSEU Ltd', N'ACSEU provides industrial and specialised cleaning throughout the Uk, we work as a small facilities company looking after HVAC systems maintaining through a full list of clients.
We carry out everything from
Deep cleaning
Extract cleaning
Fresh air system cleaning
FD servicing and installation', N'6182755586362570823')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'133', N'Sherwoods (SW) Ltd', N'jweller@sherwoods.uk', N'4750554', NULL, NULL, N'13', N'www.sherwoods.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6186129061827365577/Sherwoods-logo%20%281%29.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Joe Weller', N'Quality, Compliance and H&S Lead', N'32', N'1', N'https://www.linkedin.com/company/sherwoods-sw-ltd/posts/?feedView=all', N'Sherwoods, a Southwest-based family business since 1970, is known for exceeding industry standards. We ensure compliance with evolving regulations while meeting client needs. Our expert team delivers building services, PPM, heating, electrical, plumbing and fire safety maintenance works.', N'6186129061827365577')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'134', N'MGL Freight Broker', N'accounts@mission-global.com', N'', NULL, NULL, N'23', N'www.mission-global.com', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Stefan Solaybar', N'accounts & Admin', N'34', N'1', N'https://ae.linkedin.com/company/mission-global', N'', N'6186180607121281582')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'135', N'Biological Preparations Limited', N'vchivell@biologicalpreparations.com', N'06729209', NULL, NULL, N'16', N'www.biologicalpreparations.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6186431663315797038/LinkedIn-cover-image%20%28002%29.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Vicky Chivell', N'Head of Finance', N'32', N'1', N'https://www.linkedin.com/company/biological-preparations-limited', N'We are Biological Preparations, an industry leader in environmental biotechnology. We replace harmful, non-renewable chemical technology with environmentally, socially, and commercially beneficial solutions that meet the needs and demands of the modern world. ', N'6186431663315797038')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'136', N'Diamond Facilities Support', N'sfearby@coatfacilitiesgroup.com', N'07145959', NULL, NULL, N'15', N'https://www.diamond-fs.com/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6186473070311258038/DFS%20Logo%20RGB.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Sarah Fearby', N'Continuous Improvement Manager', N'32', N'1', N'https://www.linkedin.com/company/diamondfacilitiessupport/posts/?feedView=all', N'Diamond Facilities Support offers innovative planned, reactive, compliance, and project works services to diverse clients. From fixing leaks to disaster recovery, cleaning, and security, we provide comprehensive services to meet and exceed expectations', N'6186473070311258038')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'137', N'Johnsons 1871 Ltd T/a Johnsons Installation Services', N'sprince@johnsons1871.co.uk', N'02372641', NULL, NULL, N'30', N'www.johnsonsinstallationservices.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6187118323325526729/Installations%20logo%2024.5.23.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Furniture Installation', N'Sadie  Prince', N'Strategic Governance Manager', N'32', N'1', N'@johnsonsinstallationservices', N'We specialise in delivering professional furniture installation, relocation, and refurbishment solutions across the UK. Backed by skilled teams and sustainable practices, we ensure seamless transitions and high-quality results tailored to meet the unique needs of every project.', N'6187118323325526729')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'138', N'More Than Safety LTD.', N'rich.watts@morethansafety.co.uk', N'02306254', NULL, NULL, N'10', N'www.morethansafety.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6187334472417008522/MTS%202022.dark.xl.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Rich Watts', N'Managing Director', N'32', N'1', N'https://www.linkedin.com/company/more-than-safety-ltd', N'More Than Safety (MTS) have been experts in FM supply for over 35 years. Specialists in Uniform & Workwear, Tools, PPE, Test Equipment, LOTO and more. With their bespoke online portal, More Than Safety guide compliance, ensuring that all products purchased, are ones that have been approved.', N'6187334472417008522')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'139', N'Lancer Scott Holdings Ltd', N'Allison.tomlin@lancerscott.co.uk', N'13175288', NULL, NULL, N'30', N'www.lancerscott.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6187990460286211240/Final%20logo-01.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Construction & Facilities Management', N'Allison Tomlin', N'Operations Manager', N'32', N'1', N'https://www.linkedin.com/company/lancer-scott/', N'Lancer Scott, founded in 1996, specialises in maintenance, repairs, projects, and construction services,serving public and private clients. The business is owned by its original founders and guided by a diverse board of directors, offering tailored services to clients.', N'6187990460286211240')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'140', N'Pink Hygiene Ltd', N'donna.kane@pinkhygiene.co.uk', N'8744825', NULL, NULL, N'15', N'www.pinkhygiene.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6188660154523297033/Pink%20Strapline.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'DONNA KANE', N'Health, Safety & Compliance Manager', N'32', N'1', N'https://www.linkedin.com/company/pink-hygiene/', N'The provision, service and maintenance of washroom products, predominately feminine hygiene services, air care products, nappy & sharps units including the provision of hand hygiene products, sanitary vending, along with laundry and floorcare services. ', N'6188660154523297033')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'141', N'PFS Group Limited', N'dstratton@pfsltd.co.uk', N'3511171', NULL, NULL, N'13', N'www.pfsltd.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6189619678911888991/PFS_Group_LimitedFS_outlines_CMYK.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Dan Stratton', N'Operations Manager', N'32', N'1', N'https://www.linkedin.com/company/pfsgroupltd', N'Supply, Install, Commission and Maintain fire alarm and life safety systems across the UK. ', N'6189619678911888991')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'142', N'Thames Cleaning & Support Services Ltd', N'alex.weller@thamescleaning.co.uk', N'940586', NULL, NULL, N'15', N'https://www.thamescleaning.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6193150378874760008/Co%20Logo.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Alex Weller', N'Managing Director', N'32', N'1', N'www.linkedin.com/company/2182156', N'Thames Cleaning is a contract cleaning company that has operated successfully for over 50 years providing cleaning and support services to the commercial sector for both landlord and office demises.  From its Head Office in Sidcup, the business employs over 500 cleaning operatives.', N'6193150378874760008')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'143', N'Birkin Cleaning Services Ltd', N'JolantaCerkauskiene@birkingroup.co.uk', N'01057375', NULL, NULL, N'15', N'https://www.birkingroup.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6194858538177542456/Birkin%20Logo_black%20background.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Jolanta Cerkauskiene', N'Compliance Coordinator', N'32', N'1', N'https://www.linkedin.com/company/birkin-cleaning-services/', N'We provide expert cleaning solutions tailored to various sectors, ensuring clean and hygienic environments. Our dedicated team delivers high-quality, service-led cleaning for offices, schools, and construction sites, helping businesses maintain safe, professional, and welcoming spaces.', N'6194858538177542456')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'144', N'Wagstaff Bros Limited', N'l.gray@wagstaffgroup.co.uk', N'295393', NULL, NULL, N'30', N'www.wagstaffgroup.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6195630760025490375/W_Wagstaff_logo_black_text-01.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Furniture Wholesale', N'Lianne Gray', N'Bid Director', N'32', N'1', N'https://uk.linkedin.com/company/wagstaff-interiors-group', N'Wagstaff is the UK’s largest independent furniture dealer, offering workplace consultancy, interior design, fit-out services, relocation, sustainability services and furniture hire. ', N'6195630760025490375')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'145', N'Nviro Limited', N'shaines@nviro.co.uk', N'2688985', NULL, NULL, N'12', N'www.nviro.co.uk', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Sophie Haines', N'Strategy Director', N'32', N'0', N'https://www.linkedin.com/company/nviro-limited/', N'', N'6198293383222660397')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'146', N'Grey Man Engineering Ltd', N'nicola@greymanengineering.co.uk', N'09994306', NULL, NULL, N'13', N'www.greymanengineering.co.uk', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Nicola Millard', N'Finance Manager', N'32', N'1', N'https://uk.linkedin.com/company/grey-man-engineering', N'Grey Man Engineering provides commercial building services to gas systems, heating and hot water systems, air conditioning systems, ventilation systems, pipework systems. We specialise in working within occupied building environments, causing minimal disruption - hence “The Grey Man”.', N'6198336071013666515')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'147', N'Steelcase (South East) Ltd t/a Insightful Environments', N'klavs.henriksen@ie-uk.com', N'05024679', NULL, NULL, N'30', N'www.ie-uk.com', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Sale and installation of office furniture', N'Klavs Henriksen', N'Sustainability and Compliance Manager ', N'32', N'1', N'https://www.linkedin.com/company/insightful-environments/posts/?feedView=all', N'Insightful Environments is a leading UK furniture and workplace design company. We offer services in workplace strategy, office design, furniture procurement, project management, product disposal, and training. We collaborate with top designers and have a vast supplier network to deliver solutions.', N'6200041854377979522')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'149', N'The Maintenance Supply Co Ltd', N'Chloe.Sholl@msupply.co.uk', N'02527541', NULL, NULL, N'30', N'https://shop.msupply.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6201065712609239578/Logo.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Distribution', N'Chloe Sholl', N'Internal Account Manager & Mobilisation Co-Ordinator', N'32', N'1', N'https://uk.linkedin.com/company/the-maintenance-supply-co-ltd', N'MSC is a family run Janitorial company situated in two prime locations either side of the M25. Ideally situated for deliveries across London, the home counties and nationwide, we offer distribution of cleaning chemicals, janitorial supplies, clothing and cleaning machinery.', N'6201065712609239578')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'150', N'Genco Construction Services Ltd', N'ehussein@gencocs.co.uk', N'05803910', NULL, NULL, N'13', N'www.gencocs.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6206176996464763277/GENCO%20Logo.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', NULL, N'Errel Hussein', N'Compliance Manager', N'32', N'1', N'www.gencocs.co.uk', N'Genco was founded in 2006 to deliver fabric maintenance building services that were high quality, reliable and timely. Today, we are a leader in the retail and construction sectors, helping hundreds of customers every week to manage a range of sites, across the South-East, with ease.', N'6206176996464763277')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'151', N'Saudi Arabian Drilling Academy (SADA)', N'Ikrams@sada.edu.sa', N'', NULL, NULL, N'19', N'https://www.sada.edu.sa', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6212180737111226883/SADA%20Logo.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Saami Haamid Ikram', N'Director Curriculum Development & Quality Assurance', N'227', N'1', N'https://www.linkedin.com/company/saudi-arabian-drilling-academy-sada/about/', N'SADA is a vocational training academy serving the upstream energy section of the oil & gas industry in Saudi Arabia. ', N'6212180737111226883')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'152', N'Otium Services and Facilities Limited', N'tara.borner@otiumservices.co.uk', N'09260561', NULL, NULL, N'12', N'www.otiumservices.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6213138620125998925/OS%20Logo_4655.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'tara borner', N'Internal Compliance Manager', N'32', N'1', N'Otium Services and Facilities Limited', N'Otium Services and Facilities Limited is a dedicated specialist cleaning service currently within the UK health, fitness and hospitality sectors, with a view of expansion to other sectors. 
We offer a high quality, professional service that delivers excellent value for money. ', N'6213138620125998925')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'154', N'AUTOMATED BUILDING & ENERGY CONTROLS (GROUP) LTD', N'ewa.skorekpawlowska@abec.co.uk', N'07287820', NULL, NULL, N'18', N'https://abec.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6216460823787824380/aBEC%20STRAPLINE%20FULL%20COLOUR.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Ewa Skorek-Pawlowska', N'Group HR and Compliance Director', N'32', N'1', N'https://www.linkedin.com/company/automated-building-controls-group/posts/?feedView=all', N'Founded in 2004, ABEC is a leading UK BEMS specialist. We deliver installations, refurbishments, and maintenance, helping clients cut carbon, save energy, and build a sustainable future through smarter, more efficient buildings.', N'6216460823787824380')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'155', N'Chamberlaine Cleaning Services Ltd', N'suna@chamberlaine.co.uk', N'', NULL, NULL, N'12', N'www.chamberlaine.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6217325636812437845/Chamberlaine%20logo%20HD.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Suna Ahioglu', N'HSEQ Manager', N'32', N'0', N'https://www.linkedin.com/company/chamberlaine-cleaning-services/posts/?feedView=all', N'Chamberlaine was founded in 1978 and employ nearly 500 staff and provide a full suite of facilities services to complement their daily office cleaning contracts including washroom services, window cleaning, specialist services and hard floor care to 200 plus clients throughout Central London.
', N'6217325636812437845')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'156', N'Nviro Limited', N'cgunn@nviro.co.uk', N'03032719', NULL, NULL, N'12', N'www.nviro.co.uk', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Clair Gunn', N'Compliance Manager', N'32', N'1', N'https://www.linkedin.com/company/nviro-limited/', N'We are a specialist provider of clean, hygienic and safe environments for the education and local government sectors in London, the South & South East.  As well as routine tasks, we also provide a range of specialist cleaning services from carpet & upholstery to decontamination & crisis cleaning.', N'6217405076817378415')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'157', N'Chamberlaine Cleaning Services Ltd', N'suna@chamberlaine.co.uk', N'', NULL, NULL, N'12', N'www.chamberlaine.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6218276456818899886/Chamberlaine%20logo%20HD.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Suna Ahioglu', N'HSEQ Manager', N'32', N'1', N'https://www.linkedin.com/company/chamberlaine-cleaning-services/posts/?feedView=all', N'Chamberlaine Cleaning Services is a highly reputable professional commercial cleaning company based in Farringdon, Central London. We have been serving small, medium and large corporate clients for over 35 years to a standard of excellence. ', N'6218276456818899886')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'158', N'Greenzest', N'giulia@greenzest.co.uk', N'07783991', NULL, NULL, N'12', N'https://greenzest.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6219013950524740006/Greenzest%20Logo%20-%20on%20white.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Giulia Cinque', N'HR and Payroll Manager', N'32', N'1', N'https://www.linkedin.com/company/greenzest/', N'We are a commercial cleaning company that prioritize the welfare of the planet, our people and our partnerships. We set out not to appear different, but to make a difference. Our business is founded on a Corporate Sustainability model that is central to our policies, strategy and procedures.', N'6219013950524740006')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'159', N'Vanitorials Ltd', N'vicky.braxton@vanitorials.co.uk', N'03952938', NULL, NULL, N'12', N'www.vanitorials.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6219856289618558604/Vanitorials%20logo%20redesign_AW-colour.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Vicky Braxton', N'PA / Project Administrator', N'32', N'1', N'linkedin.com/vanitorials', N'Vanitorials is a leading distributor of janitorial supplies to London, Essex and the South East.', N'6219856289618558604')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'160', N'SecuriGroup Limited', N'stephanie.henderson@securigroup.co.uk', N'SC346167', NULL, NULL, N'7', N'www.securigroup.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6223326838668430202/Header%20Logo%20-%20Copy.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Stephanie Henderson', N'Compliance Officer', N'32', N'1', N'https://uk.linkedin.com/company/securigroup', N'SecuriGroup is one of the largest security companies in the United Kingdom and Republic of Ireland, dedicated to delivering exceptional services with a focus on continuous improvement, innovation and corporate social responsibility.', N'6223326838668430202')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'161', N'Wales Millennium Centre', N'Alex.mathias@wmc.org.uk', N'03221924', NULL, NULL, N'25', N'https://www.wmc.org.uk/', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Alex Mathias', N'Business Operations Support', N'32', N'1', N'https://www.linkedin.com/company/wales-millennium-centre', N'Wales Millennium Centre is a world leading performing arts centre based
in Cardiff Bay. We are a cultural campus. We house the 1900-seat Donald Gordon Theatre, a 250-seat studio theatre, recital hall, dance house, cafés, cabaret venue, community workspace and immersive experience facility.', N'6225099997719863315')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'162', N'Johnsons 1871 Ltd T/a Johnsons Facilities Management', N'sprince@johnsons1871.co.uk', N'02372641', NULL, NULL, N'15', N'www.johnsons1871.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6225942610617463811/JFM%20Logo%20grey.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Sadie Prince', N'Strategic Governance Manager', N'32', N'1', N'@johnsons1871', N'JFM delivers expert soft facilities management solutions to workplace environments.  They ensure efficient, safe, and welcoming spaces tailored to each client’s needs and help businesses optimise operations & create exceptional workplace experiences.', N'6225942610617463811')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'163', N'Johnsons 1871 Ltd T/a Johnsons Laboratory Logistics', N'sprince@johnsons1871.co.uk', N'02372641', NULL, NULL, N'30', N'www.johnsonslablogistics.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6226032900619396662/Lab%20Logistics%20logo%2024.5.23.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Specialist relocations', N'Sadie Prince', N'Strategic Governance Manager', N'32', N'1', N'@johnsonslablogistics', N' Johnsons Laboratory Logistics are global experts in freight forwarding and specialist logistics for the life sciences sector. They provide tailored solutions for temperature-controlled transportation, time-critical deliveries, and complex supply chain management, ensuring reliability and precision.', N'6226032900619396662')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'164', N'Professional Security', N'm.woollam@professionalsecurityuk.com', N'5350306', NULL, NULL, N'7', N'www.professionalsecurityuk.com', N'1', N'[', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Martin Woollam', N'Group Commercial Director', N'32', N'1', N'https://www.linkedin.com/company/professional-security', N'Professional Security is a provider of security services to the hospitality, sports and entertainment, logistics, and local government sector. Currently we are a £64m turnover business with over 5000 security officers working either full time, part time or on an ad hoc basis.  ', N'6232162107515271153')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'165', N'The Floorbrite Group Limited', N'ella.warburton@floorbrite.co.uk', N'01219526', NULL, NULL, N'15', N'www.floorbrite.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6234542296419823168/Floorbrite%20Logo.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Ella Warburton', N'Sustainability Coordinator', N'32', N'1', N'https://www.linkedin.com/company/the-floorbrite-group-ltd', N'The Floorbrite Group is a leading UK commercial cleaning and facilities management company. Family-run since 1972, we provide cleaning, hygiene, waste, pest control, and soft FM services nationwide, with a strong focus on sustainability and customer care.', N'6234542296419823168')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'166', N'One Facility Ltd', N'emily.slowe@onefacility.co.uk', N'05469591', NULL, NULL, N'15', N'www.onefacility.co.uk', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6236357511713082798/Primary%20logo%20spaced%20white%20background.jpg', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Emily Slowe', N'HR & Quality Manager', N'32', N'1', N'https://www.linkedin.com/company/one-facility-ltd', N'One Facility delivers integrated facilities management, maintenance, cleaning, building services, and GMP expertise. From small maintenance tasks to complex infrastructure projects, we provide a reliable, tailored, end-to-end service that keeps buildings safe, compliant, and operational.', N'6236357511713082798')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'167', N'Linaker Ltd', N'jennie.davies@linaker.com', N'2806306', NULL, NULL, N'15', N'www.linaker.com', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Jennie Davies', N'Performance Director', N'32', N'1', N'https://www.linkedin.com/company/linaker-limited/', N'Linaker is a hard services engineering provider covering clients nationally and in a wide range of industry sectors', N'6237368074323442736')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'168', N'Wren Environmental ', N'm.caldecourt@wren-environmental.co.uk', N'02669441', NULL, NULL, N'15', N'www.wren-environmental.co.uk', N'1', NULL, NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'', N'Matthew Caldecourt', N'Projects Business Development/Estimator Manager', N'32', N'1', N'Wren Environmental Ltd', N'', N'6237453226019378600')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'169', N'XCLUSIVE BOATS CHARTER', N'ahlyssa@xclusiveyachts.com', N'613346', NULL, NULL, N'30', N'https://xclusiveyachts.com', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6237870000327996527/XY%20-EST%20%281%29.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Leisure ', N'Ahlyssa Recio', N'Project Manager', N'34', N'1', N'XCLUSIVE BOATS CHARTER', N'Xclusive Yachts Yacht Rental Dubai was established in 2006 & is Dubai''s leading award winning yacht charter company. We are the only charter company in Dubai to own its own fleet of yachts, setting the industry benchmarks & standards makes us pioneers in Dubai yacht chartering. ', N'6237870000327996527')
GO

INSERT INTO [portal].[XCustomerDirectory] ([companyId], [companyName], [email], [registrationNumber], [phone], [address], [industryType], [website], [status], [logo], [clickupTaskId], [dateCreated], [dateUpdated], [isDeleted], [industryTypeOther], [contactName], [jobTitle], [countryId], [nczCustomerDirectory], [linkedInPage], [description], [submissionId]) VALUES (N'170', N'Johnsons Asset 360', N'abeardmore@johnsons1871.co.uk', N'', NULL, NULL, N'30', N'https://asset-360.co.uk/', N'1', N'https://app.neutralcarbonzone.com/uploads/!team_241281014350038/250151633085854/6237968122716568272/Screenshot%202024%20Asset%20360.png', NULL, N'2025-05-28 09:46:16.0100000', NULL, N'0', N'Removals & Storage', N'Alex Beardmore', N'ESG and Reuse lead', N'32', N'1', N'https://www.linkedin.com/company/johnsons-asset-360', N'A total solution, driving efficiencies and delivering results.
In the ever-evolving business and technology landscape, effective asset management has emerged as a critical component for organisations aiming to optimise resources and enhance operational efficiency.', N'6237968122716568272')
GO

SET IDENTITY_INSERT [portal].[XCustomerDirectory] OFF
GO


-- ----------------------------
-- Table structure for XPermissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XPermissions]') AND type IN ('U'))
	DROP TABLE [portal].[XPermissions]
GO

CREATE TABLE [portal].[XPermissions] (
  [permissionId] int  NOT NULL,
  [permissionName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [accessOptions] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[XPermissions] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of XPermissions
-- ----------------------------
INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'1', N'Admin - Dashboard', N'R')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'2', N'Admin - Companies', N'C,R,U,D')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'3', N'Admin - Certifications', N'C,R,U,D')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'4', N'Admin - Submissions', N'C,R')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'5', N'Admin - Users', N'C,R,U,D')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'6', N'Admin - Reports', N'C,R')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'7', N'Admin - Settings', N'R,U')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'8', N'Standard - Certifications', N'R')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'9', N'Standard - Submissions', N'C,R')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'10', N'Standard - User', N'C,R,U,D')
GO

INSERT INTO [portal].[XPermissions] ([permissionId], [permissionName], [accessOptions]) VALUES (N'11', N'Standard - Reports', N'R')
GO


-- ----------------------------
-- Table structure for XRoles
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XRoles]') AND type IN ('U'))
	DROP TABLE [portal].[XRoles]
GO

CREATE TABLE [portal].[XRoles] (
  [roleId] int  IDENTITY(1,1) NOT NULL,
  [roleName] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [companyId] int  NULL
)
GO

ALTER TABLE [portal].[XRoles] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of XRoles
-- ----------------------------
SET IDENTITY_INSERT [portal].[XRoles] ON
GO

SET IDENTITY_INSERT [portal].[XRoles] OFF
GO


-- ----------------------------
-- Table structure for XUserAccount
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XUserAccount]') AND type IN ('U'))
	DROP TABLE [portal].[XUserAccount]
GO

CREATE TABLE [portal].[XUserAccount] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [uid] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [email] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dashboardAccessId] int  NULL,
  [customerAreaAccessId] int  NULL,
  [restricted] bit  NULL,
  [lastSeen] bigint  NULL,
  [reportToUserAccountId] int  NULL,
  [teamId] int  NULL,
  [picture] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [mfaRequired] bit DEFAULT 0 NULL,
  [mfaSecret] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [mfaCompleteDate] bigint  NULL,
  [mfaSetupDone] bit  NULL,
  [emailVerificationCode] int  NULL,
  [emailVerificationCodeActiveTo] bigint  NULL,
  [opsAccessId] int  NULL,
  [dmsAccessId] int  NULL
)
GO

ALTER TABLE [portal].[XUserAccount] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of XUserAccount
-- ----------------------------
SET IDENTITY_INSERT [portal].[XUserAccount] ON
GO

SET IDENTITY_INSERT [portal].[XUserAccount] OFF
GO


-- ----------------------------
-- View structure for vFeaturesList
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[vFeaturesList]') AND type IN ('V'))
	DROP VIEW [portal].[vFeaturesList]
GO

CREATE VIEW [portal].[vFeaturesList] AS Select f.applicationId, f.id as fId, f.name as fName, f.description as fDescription, f.displayName as fDisplayName,
       fo.id as foId, fo.name as foName, fo.description as foDescription, fo.displayName as foDisplayName
from portal.ApplicationFeature as F
INNER JOIN portal.ApplicationFeatureOption as FO on (F.id = FO.applicationFeatureId)
GO


-- ----------------------------
-- View structure for vFormQuestionEmissionActivityEF
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[vFormQuestionEmissionActivityEF]') AND type IN ('V'))
	DROP VIEW [portal].[vFormQuestionEmissionActivityEF]
GO

CREATE VIEW [portal].[vFormQuestionEmissionActivityEF] AS Select F.name as formName, QEA.*, EF.ef, EF.wtt, EF.tnd, EF.tndWtt, EF.[year]
From Dimension.Form as F 
RIGHT JOIN 
  (
    Select distinct QE.formId, QE.id as qId, QE.reference, QE.displayText, 
          EA.id as emissionActivityId, EA.name as emissionActivityName, EA.unit --, QE.id as qId, QE.REFERENCE, QE.displayText 
    from Emissions.EmissionActivity as EA INNER JOIN
    (
        Select DISTINCT 
            q.formid,
            q.id,
            q.reference,
            q.displayText,
            emissionActivityId
        from Forms.Question as Q INNER JOIN Forms.QuestionEmissionActivity as QEA on (Q.id = QEA.questionid)
        Where q.active=1
        
        UNION
        -- Extract emissionActivityId from flightEmissions
        SELECT DISTINCT 
            q.formid,
            q.id,
            q.reference,
            q.displayText,
            TRY_CAST(JSON_VALUE(x.value, '$.emissionActivityId') AS INT) AS emissionActivityId
        FROM Forms.Question q
        CROSS APPLY OPENJSON(q.properties, '$.flightEmissions') AS x
        WHERE ISJSON(q.properties) = 1 and q.active=1
          AND JSON_VALUE(x.value, '$.emissionActivityId') IS NOT NULL

        UNION

        -- Extract emissionActivityId from hotelEmissions
        SELECT DISTINCT
            q.formid,
            q.id,
            q.reference,
            q.displayText,
            TRY_CAST(JSON_VALUE(x.value, '$.emissionActivityId') AS INT) AS emissionActivityId
        FROM Forms.Question q
        CROSS APPLY OPENJSON(q.properties, '$.hotelEmissions') AS x
        WHERE ISJSON(q.properties) = 1 and q.active=1
          AND JSON_VALUE(x.value, '$.emissionActivityId') IS NOT NULL

        UNION

        -- Extract emissionActivityId from fuelConfigurations
        SELECT DISTINCT
            q.formid,
            q.id,
            q.reference,
            q.displayText,
            TRY_CAST(JSON_VALUE(x.value, '$.emissionActivityId') AS INT) AS emissionActivityId
        FROM Forms.Question q
        CROSS APPLY OPENJSON(q.properties, '$.fuelConfigurations') AS x
        WHERE ISJSON(q.properties) = 1 and q.active=1
          AND JSON_VALUE(x.value, '$.emissionActivityId') IS NOT NULL

        UNION

        -- Extract emissionActivityId from vehicleEmissions
        SELECT DISTINCT
            q.formid,
            q.id,
            q.reference,
            q.displayText,
            TRY_CAST(JSON_VALUE(x.value, '$.emissionActivityId') AS INT) AS emissionActivityId
        FROM Forms.Question q
        CROSS APPLY OPENJSON(q.properties, '$.vehicleEmissions') AS x
        WHERE ISJSON(q.properties) = 1 and q.active=1
          AND JSON_VALUE(x.value, '$.emissionActivityId') IS NOT NULL

        UNION

        -- Extract spendAmountEmissionActivityId from vehicleEmissions
        SELECT DISTINCT
            q.formid,
            q.id,
            q.reference,
            q.displayText,
            TRY_CAST(JSON_VALUE(x.value, '$.spendAmountEmissionActivityId') AS INT) AS emissionActivityId
        FROM Forms.Question q
        CROSS APPLY OPENJSON(q.properties, '$.vehicleEmissions') AS x
        WHERE ISJSON(q.properties) = 1 and q.active=1
          AND JSON_VALUE(x.value, '$.spendAmountEmissionActivityId') IS NOT NULL
    ) as QE on (QE.emissionActivityId = EA.id)
    Where QE.formid !=6
  ) as QEA on (F.id = QEA.formId)
  INNER JOIN Emissions.EmissionFactor as EF on (EF.activityId = QEA.emissionActivityId and EF.active=1 and EF.emissionProfileId=9)
GO


-- ----------------------------
-- View structure for vFormReportCategoryEmissionActivity
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[vFormReportCategoryEmissionActivity]') AND type IN ('V'))
	DROP VIEW [portal].[vFormReportCategoryEmissionActivity]
GO

CREATE VIEW [portal].[vFormReportCategoryEmissionActivity] AS Select F.id as FormId, F.name as FormName, RC.categoryId, RC.categoryName, EA.id as EmissionActivityId, EA.name as EmissionActivityName
from DataModel.ReportCategory as RC 
INNER JOIN DataModel.ReportCategoryMapping as RCM on (RC.categoryId = RCM.categoryId)
INNER JOIN Emissions.EmissionActivity as EA on (RCM.emissionActivityId = EA.id)
INNER JOIN Dimension.Form as F on (RC.formId = F.id);
GO


-- ----------------------------
-- View structure for vForms
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[vForms]') AND type IN ('V'))
	DROP VIEW [portal].[vForms]
GO

CREATE VIEW [portal].[vForms] AS Select name as formName, formId as jotformId, active
from Forms.JotForm where category='certifications'
GO


-- ----------------------------
-- View structure for vRoleFeaturesList
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[vRoleFeaturesList]') AND type IN ('V'))
	DROP VIEW [portal].[vRoleFeaturesList]
GO

CREATE VIEW [portal].[vRoleFeaturesList] AS Select R.id, R.name as rName, f.applicationId, f.id as fId, f.name as fName, f.description as fDescription, f.displayName as fDisplayName,
       fo.id as foId, fo.name as foName, fo.description as foDescription, fo.displayName as foDisplayName, RO.available
from  portal.ApplicationRole as R 
INNER JOIN portal.ApplicationRoleOption as RO on (R.id = RO.applicationRoleId) 
INNER JOIN portal.ApplicationFeatureOption as FO on (RO.applicationFeatureOptionId = FO.id)
INNER JOIN portal.ApplicationFeature as F on (F.id = FO.applicationFeatureId)
GO


-- ----------------------------
-- procedure structure for spLocation_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spLocation_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spLocation_Get]
GO

CREATE PROCEDURE [portal].[spLocation_Get]
  @companyId int = null,
  @locationId int = null
AS
BEGIN
  SET NOCOUNT ON;
  
  if @companyId is null 
    BEGIN
      SELECT L.*, C.companyName
      From portal.Location as L 
      INNER JOIN portal.Company as C on (C.companyId = L.companyId)
      Where L.locationId = @locationId;
    END
  ELSE
    BEGIN
      SELECT L.*, C.companyName
      From portal.Location as L 
      INNER JOIN portal.Company as C on (C.companyId = L.companyId)
      Where L.isDeleted = 0 and L.companyId = @companyId;
    END

END
GO


-- ----------------------------
-- procedure structure for spLocation_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spLocation_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spLocation_Save]
GO

CREATE PROCEDURE [portal].[spLocation_Save]
    @locationId int,
    @locationName NVARCHAR(50),
    @companyId int
AS
BEGIN
  SET NOCOUNT ON;
  
  if @locationId is NULL
    BEGIN
      INSERT INTO portal.Location 
      (locationName, companyId, dateUpdated)
      VALUES 
      (@locationName, @companyId, CURRENT_TIMESTAMP);
      
      SET @locationId = (SELECT SCOPE_IDENTITY());
    END
  else
    BEGIN
      UPDATE portal.Location
      SET 
          locationName = @locationName,
          dateUpdated = CURRENT_TIMESTAMP
      WHERE locationId = @locationId;
    END
  
    if @locationId is Not NULL -- return added/updated location data to frontend to show in grid etc
    BEGIN
      exec portal.spLocation_Get null, @locationId;
    END

END;
GO


-- ----------------------------
-- procedure structure for spSubmission_Get_07Jul2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spSubmission_Get_07Jul2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spSubmission_Get_07Jul2025]
GO

CREATE PROCEDURE [portal].[spSubmission_Get_07Jul2025]
  @certId int
AS
BEGIN
  SET NOCOUNT ON;
  
  -- Get Submissions made for a certification
  select cfs.certsubmissionId, cert.certId, cert.companyId, cert.progId, prg.progName, cert.certYear, pf.displayName as formName, pf.jotformId, cfs.submissionId, 
         FORMAT(cfs.dateSubmitted, 'dd/MM/yyyy') as dateSubmitted, cfs.notes,
         case pf.jotformId when '232102389529457' then 1 else 0 end as isCHW,
         cfs.formStatus, u.fullName as userName, c.companyName, cert.refNumber, L.locationName
  From portal.Certification as cert 
      INNER JOIN 
      ( Select certsubmissionId, certId, locationId, jotformId, submissionId, userId, dateSubmitted, isProcessed, notes, 0 as isCHW,
               case when SubmissionId is null then 'Pending' else (case isProcessed when 1 then 'Processed' else 'Submitted' end) end as formStatus
        From portal.CertFormSubmissions where certId = @certId and jotformId != '232102389529457'
        Union all
        Select null as certsubmissionId, max(certId) as certId, null as locationId, max(jotformId) as jotformId, null as submissionId, null as userId, null as dateSubmitted,
               0 as isProcessed, null AS notes, 1 as isCHW,
               CAST(COUNT(*) AS NVARCHAR(10)) + ' Submitted, ' + CAST(SUM(CAST(isProcessed AS INT)) AS NVARCHAR(10)) +' Processed' as formStatus
        From portal.CertFormSubmissions where certId = @certId and jotformId = '232102389529457'
        GROUP BY certId
      ) as cfs on (cfs.certId = cert.certId)
      INNER JOIN portal.Company as c on (c.companyId = cert.companyId)
      INNER JOIN portal.Programme as prg on (prg.progId = cert.progId) 
      INNER JOIN portal.ProgrammeForms as pf on (prg.progId = pf.progId and pf.jotformId = cfs.jotformId) 
      LEFT JOIN portal.Location as L on (L.locationId = cfs.locationId)
      LEFT JOIN portal.Users as u on (u.userId = cfs.userId)
  Where cert.certId = @certId
  ORDER BY cfs.dateSubmitted desc; --, pf.displayOrder;

END
GO


-- ----------------------------
-- procedure structure for spSubmission_Completed_07Jul2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spSubmission_Completed_07Jul2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spSubmission_Completed_07Jul2025]
GO

CREATE PROCEDURE [portal].[spSubmission_Completed_07Jul2025]
  @jotformId nvarchar(25) = null,
  @submissionId nvarchar(25),
  @data nvarchar(max)
AS
BEGIN
    -- When jotform submission completes
    DECLARE @portalCertSubmissionId int, @portalCertId int, @companyName NVARCHAR(100), @companyLogo NVARCHAR(max), @companyLogoJson NVARCHAR(max);
    DECLARE @TempTable TABLE ([key] NVARCHAR(50), [value] NVARCHAR(Max));

    INSERT INTO @TempTable
    SELECT [Key], [Value] FROM OPENJSON(@data) 
    WHERE [Key] LIKE '%_portal%' OR [Key] LIKE '%BAQ_CompanyName' OR [Key] = 'BAQ_CompanyLogo';

    if(@jotformId = '232102389529457') -- C&HW form submission
      begin
        SELECT @portalCertId = trim([Value]) FROM @TempTable WHERE [Key] LIKE '%_portalCertId'; 
    
        if Not(@portalCertId is null OR @portalCertId = '' OR @portalCertId = 0)
          begin
            INSERT INTO [portal].[CertFormSubmissions] (certId, jotformId, submissionId, locationId, userId, dateSubmitted) 
                                                VALUES (@portalCertId, @jotformId, @submissionId, 0, 0, CURRENT_TIMESTAMP);
          end
      end
    else 
      begin
        SELECT @portalCertSubmissionId = [Value] FROM @TempTable WHERE [Key] LIKE '%_portalCSId'; 
        
        if Not(@portalCertSubmissionId is null OR @portalCertSubmissionId = '' OR @portalCertSubmissionId = 0)
          begin
            Update portal.CertFormSubmissions
               set submissionId = @submissionId
            Where certsubmissionId = @portalCertSubmissionId;
            
            if(@jotformId = '241290444812856' OR @jotformId = '250151633085854')-- To update Company Logo from Company profile (Blue Award/Gold) form submission
            begin
              SELECT TOP 1 @companyLogoJson = [value] FROM @TempTable WHERE [key] = 'BAQ_CompanyLogo';
              Select @companyLogoJson;
              -- Parse the array and get the first item
              SELECT TOP 1 @companyLogo = [value] FROM OPENJSON(@companyLogoJson);
              select @companyLogo;
              if(NullIf(@companyLogo,'') is not null)
              begin 
                UPDATE C
                       SET C.logo = @companyLogo
                FROM portal.Company AS C
                INNER JOIN portal.Certification AS Cert ON C.companyId = Cert.companyId
                INNER JOIN portal.CertFormSubmissions AS CS ON CS.certId = Cert.certId
                WHERE CS.certsubmissionId = @portalCertSubmissionId;
              end
            end
          end
        else if(@jotformId = '241290444812856')-- Blue Award form submission (Not from portal)
          begin
            SELECT @companyName = [Value] FROM @TempTable WHERE [Key] LIKE '%BAQ_CompanyName'; 
            
            INSERT INTO [portal].[BlueAwardSubmissions] (jotformId, submissionId, notes, dateSubmitted) 
                                                VALUES (@jotformId, @submissionId, @companyName, CURRENT_TIMESTAMP);
          end
      end

END
GO


-- ----------------------------
-- procedure structure for XspCertificationDocument_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XspCertificationDocument_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[XspCertificationDocument_Save]
GO

CREATE PROCEDURE [portal].[XspCertificationDocument_Save]
    @certDocId INT = NULL,
    @certId INT = NULL,
    @documentId INT = NULL,
    @displayName NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    if @certDocId is not null
      BEGIN
          -- UPDATE
          UPDATE [portal].[CertificationDocuments]
          SET displayName = @displayName
          WHERE certDocId = @certDocId;
      END
    ELSE
      BEGIN
          -- INSERT
          INSERT INTO [portal].[CertificationDocuments] (
              certId,
              documentId,
              displayName,
              displayOrder,
              isDeleted
          )
          VALUES (
              @certId,
              @documentId,
              @displayName,
              0,
              0
          );
      END
END;
GO


-- ----------------------------
-- procedure structure for spSubmission_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spSubmission_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spSubmission_Save]
GO

CREATE PROCEDURE [portal].[spSubmission_Save]
    @certId int,
    @locationId int = 0,
    @userId int,
    @jotformId nvarchar(25),
    @notes nvarchar(100) = null
AS
BEGIN
    SET NOCOUNT ON;
    Declare @certsubmissionId int;
    
    INSERT INTO [portal].[CertFormSubmissions] (certId, userId, jotformId, locationId, notes, dateSubmitted) 
                                        VALUES (@certId, @userId, @jotformId, @locationId, @notes, CURRENT_TIMESTAMP);
    
    SET @certsubmissionId = (SELECT SCOPE_IDENTITY());
    
    Select @certsubmissionId as certsubmissionId, @jotformId as jotformId, @certId as certId;
END
GO


-- ----------------------------
-- procedure structure for spUser_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spUser_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spUser_Save]
GO

CREATE PROCEDURE [portal].[spUser_Save]
    @userId INT,
    @companyId INT = 0,
    @fullName NVARCHAR(100),
    @email NVARCHAR(50),
    @phone NVARCHAR(20),
    @status INT,
    @roleId int,
    @uId NVARCHAR(100) = null
AS
BEGIN
  SET NOCOUNT ON;
  
  if @userId is NULL
    BEGIN
      if Not EXISTS (Select userId from portal.Users where Lower(email) = Lower(@email) and isDeleted=0)
        BEGIN
          INSERT INTO [portal].[Users] ( companyId, fullName, email, phone, status, uId, dateUpdated )
          VALUES ( @companyId, @fullName, @email, @phone, @status, @uId, CURRENT_TIMESTAMP );
         
          SET @userId = (SELECT SCOPE_IDENTITY());
          
          INSERT into portal.ApplicationUserRoleGrant (userAccountId, applicationRoleId, assignedByUserAccountId) 
          Values (@userId, @roleId, 0);
        END
      ELSE
        BEGIN
          select 'DUPLICATE:User email already exists' as errorMsg;
          set @userId = null;
        END
    END
  else
    BEGIN
      if Not EXISTS (Select userId from portal.Users where email = @email and isDeleted=0 and userId != @userId)
        BEGIN
          UPDATE portal.Users
          SET 
              companyId = @companyId,
              fullName = @fullName,
              email = @email,
              phone = @phone,
              status = @status,
              dateUpdated = CURRENT_TIMESTAMP
          WHERE userId = @userId;
          
          UPDATE portal.ApplicationUserRoleGrant
          Set 
            applicationRoleId = @roleId
          WHERE userAccountId = @userId;
        END
      ELSE
        BEGIN
          select 'DUPLICATE:User email already exists' as errorMsg;
          set @userId = null;
        END
    END
  
    if @userId is Not NULL -- return added/updated user data to frontend to show in grid etc
    BEGIN
      exec portal.spUser_Get @status = null, @userId = @userId;
    END
    
END;
GO


-- ----------------------------
-- procedure structure for XspCertification_SaveSubmission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XspCertification_SaveSubmission]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[XspCertification_SaveSubmission]
GO

CREATE PROCEDURE [portal].[XspCertification_SaveSubmission]
    @jotformId nvarchar(25)
    ,@submissionId nvarchar(25)
    ,@data nvarchar(max)
AS
BEGIN

  DECLARE @portalCertId int, @portalUserId int;
  DECLARE @TempTable TABLE ([key] NVARCHAR(50), [value] NVARCHAR(50));

  INSERT INTO @TempTable
  SELECT [Key], [Value] FROM OPENJSON(@data) WHERE [Key] LIKE '%_portal%';

  SELECT @portalCertId = [Value] FROM @TempTable WHERE [Key] LIKE '%_portalCertId'; 
  SELECT @portalUserId = [Value] FROM @TempTable WHERE [Key] LIKE '%_portalUserId';
  
  if (isnull(@portalCertId, 0) > 0)
  begin
    INSERT INTO [portal].[CertFormSubmissions] ([certId], [userId], [jotformId], [submissionId], [dateSubmitted]) 
                                        VALUES (@portalCertId, @portalUserId, @jotformId, @submissionId, CURRENT_TIMESTAMP);
  end

END
GO


-- ----------------------------
-- procedure structure for spSubmission_Completed
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spSubmission_Completed]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spSubmission_Completed]
GO

CREATE PROCEDURE [portal].[spSubmission_Completed]
  @jotformId nvarchar(25) = null,
  @submissionId nvarchar(25),
  @data nvarchar(max)
AS
BEGIN
    -- When jotform submission completes
    DECLARE @portalCertSubmissionId int, @portalCertId int, @companyName NVARCHAR(100), @companyLogo NVARCHAR(max), @companyLogoJson NVARCHAR(max);
    DECLARE @TempTable TABLE ([key] NVARCHAR(50), [value] NVARCHAR(Max));

    INSERT INTO @TempTable
    SELECT [Key], [Value] FROM OPENJSON(@data) 
    WHERE [Key] LIKE '%_portal%' OR [Key] LIKE '%BAQ_CompanyName' OR [Key] = 'BAQ_CompanyLogo' OR
          [Key] = 'q283_name' OR [Key] = 'q284_workEmail'; -- << 2 fields are C&HW data

    if(@jotformId = '232102389529457') -- C&HW form submission
      begin
        SELECT @portalCertId = trim([Value]) FROM @TempTable WHERE [Key] LIKE '%_portalCertId'; 
    
        if Not(@portalCertId is null OR @portalCertId = '' OR @portalCertId = 0)
          begin
            Declare @personName NVARCHAR(100), @personEmail NVARCHAR(50);
            -- Set Person Name and Email in Notes
            Select @personName = JSON_VALUE([Value], '$.first')+' '+ JSON_VALUE([Value], '$.last')
            FROM @TempTable WHERE [Key] = 'q283_name'; 
            
            Select @personEmail = [Value] FROM @TempTable WHERE [Key] = 'q284_workEmail'; 
          
            INSERT INTO [portal].[CertFormSubmissions] (certId, jotformId, submissionId, notes, locationId, userId, dateSubmitted) 
                   VALUES (@portalCertId, @jotformId, @submissionId, @personName + ' (' + @personEmail +')', 0, 0, CURRENT_TIMESTAMP);
          end
      end
    else 
      begin
        SELECT @portalCertSubmissionId = [Value] FROM @TempTable WHERE [Key] LIKE '%_portalCSId'; 
        
        if Not(@portalCertSubmissionId is null OR @portalCertSubmissionId = '' OR @portalCertSubmissionId = 0)
          begin
            Update portal.CertFormSubmissions
               set submissionId = @submissionId
            Where certsubmissionId = @portalCertSubmissionId;
            
            if(@jotformId = '241290444812856' OR @jotformId = '250151633085854')-- To update Company Logo from Company profile (Blue Award/Gold) form submission
            begin
              SELECT TOP 1 @companyLogoJson = [value] FROM @TempTable WHERE [key] = 'BAQ_CompanyLogo';
              Select @companyLogoJson;
              -- Parse the array and get the first item
              SELECT TOP 1 @companyLogo = [value] FROM OPENJSON(@companyLogoJson);
              select @companyLogo;
              if(NullIf(@companyLogo,'') is not null)
              begin 
                UPDATE C
                       SET C.logo = @companyLogo
                FROM portal.Company AS C
                INNER JOIN portal.Certification AS Cert ON C.companyId = Cert.companyId
                INNER JOIN portal.CertFormSubmissions AS CS ON CS.certId = Cert.certId
                WHERE CS.certsubmissionId = @portalCertSubmissionId;
              end
            end
          end
        else if(@jotformId = '241290444812856')-- Blue Award form submission (Not from portal)
          begin
            SELECT @companyName = [Value] FROM @TempTable WHERE [Key] LIKE '%BAQ_CompanyName'; 
            
            INSERT INTO [portal].[BlueAwardSubmissions] (jotformId, submissionId, notes, dateSubmitted) 
                                                VALUES (@jotformId, @submissionId, @companyName, CURRENT_TIMESTAMP);
          end
      end

END
GO


-- ----------------------------
-- procedure structure for spCompany_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCompany_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCompany_Save]
GO

CREATE PROCEDURE [portal].[spCompany_Save]
    @companyId int,
    @companyName NVARCHAR(100),
    @email NVARCHAR(50),
    @registrationNumber NVARCHAR(100),
    @phone NVARCHAR(20),
    @address NVARCHAR(200),
    @industryType INT,
    @industryTypeOther NVARCHAR(100),
    @website NVARCHAR(100),
    @contactName NVARCHAR(50),
    @jobTitle NVARCHAR(75),
    @status INT, 
    @logo NVARCHAR(MAX),
    @countryId INT,
    @nczCustomerDirectory bit,
    @description nvarchar(300) = null,
    @linkedInPage nvarchar(100) = null
AS
BEGIN
  SET NOCOUNT ON;
  
  if @companyId is NULL
    BEGIN
      INSERT INTO portal.Company 
      (companyName, email, registrationNumber, phone, address, industryType, industryTypeOther, website, 
       contactName, jobTitle, status, logo, countryId, nczCustomerDirectory, linkedInPage, description, dateCreated)
      VALUES 
      (@companyName, @email, @registrationNumber, @phone, @address, @industryType, @industryTypeOther, @website, 
       @contactName, @jobTitle, @status, @logo, @countryId, @nczCustomerDirectory, @linkedInPage, @description, CURRENT_TIMESTAMP);
      
      SET @companyId = (SELECT SCOPE_IDENTITY());
      
      Insert into portal.Location (companyId, locationName, isDeleted, dateUpdated)
      values (@companyId, 'Main site', 0, CURRENT_TIMESTAMP);
    END
  else
    BEGIN
      UPDATE portal.Company
      SET 
          companyName = @companyName,
          email = @email,
          registrationNumber = @registrationNumber,
          phone = @phone,
          address = @address,
          industryType = @industryType,
          industryTypeOther = @industryTypeOther,
          website = @website,
          contactName = @contactName, 
          jobTitle = @jobTitle,
          status = @status,
          logo = @logo,
          countryId = @countryId, 
          nczCustomerDirectory = @nczCustomerDirectory,
          linkedInPage = @linkedInPage, 
          description = @description,
          dateUpdated = CURRENT_TIMESTAMP
      WHERE companyId = @companyId;
    END
  
    if @companyId is Not NULL -- return added/updated company data to frontend to show in grid etc
    BEGIN
      exec portal.spCompany_Get @status = null, @companyId = @companyId;
    END
    --SELECT * FROM portal.Company WHERE companyId = @companyId;
END;
GO


-- ----------------------------
-- procedure structure for XspCertificationDocument_Delete
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XspCertificationDocument_Delete]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[XspCertificationDocument_Delete]
GO

CREATE PROCEDURE [portal].[XspCertificationDocument_Delete]
    @certDocId INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE [portal].[CertificationDocuments]
    SET isDeleted = 1
    WHERE certDocId = @certDocId;
END;
GO


-- ----------------------------
-- procedure structure for spCompany_Delete
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCompany_Delete]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCompany_Delete]
GO

CREATE PROCEDURE [portal].[spCompany_Delete]
    @companyId INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE portal.Company set isDeleted = 1, dateUpdated = CURRENT_TIMESTAMP
    WHERE companyId = @companyId;
    --DELETE FROM portal.Company WHERE companyId = @companyId;
END;
GO


-- ----------------------------
-- procedure structure for spCompany_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCompany_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCompany_Get]
GO

CREATE PROCEDURE [portal].[spCompany_Get]
  @companyId int = null,
  @status bit = null
AS
BEGIN
  SET NOCOUNT ON;
  
  if @companyId is null 
    BEGIN
      SELECT C.*, case C.status when 0 then 'Inactive' when 1 then 'Active' when 2 then 'Pending' end as statusStr,
        case C.industryType when 30 then C.industryTypeOther else DI.itemName end as industryTypeStr
      From portal.Company as C LEFT JOIN portal.DropdownItems as DI on (C.industryType = DI.itemId)
      Where C.isDeleted = 0 and
       case when @status is null then 1 else C.status end = case when @status is null then 1 else @status end;
    END
  ELSE
    BEGIN
      SELECT C.*, case C.status when 0 then 'Inactive' when 1 then 'Active' when 2 then 'Pending' end as statusStr,
        case C.industryType when 30 then C.industryTypeOther else DI.itemName end as industryTypeStr
      From portal.Company as C LEFT JOIN portal.DropdownItems as DI on (C.industryType = DI.itemId)
      Where C.isDeleted = 0 and C.companyId = @companyId;
    END

END
GO


-- ----------------------------
-- procedure structure for XspCertification_GetSubmissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XspCertification_GetSubmissions]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[XspCertification_GetSubmissions]
GO

CREATE PROCEDURE [portal].[XspCertification_GetSubmissions]
  @certId int
AS
BEGIN
  SET NOCOUNT ON;
  
  -- Get forms listing for a certification
  select cert.certId, cert.companyId, cert.progId, prg.progName, cert.certYear, pf.displayName, pf.jotformId, cfs.submissionId, 
         FORMAT(cfs.dateSubmitted, 'dd/MM/yyyy') as dateSubmitted, 
         case pf.jotformId when '232102389529457' then 1 else 0 end as isCHW, isnull(submitCnt,0) as submitCnt,
         case when cfs.jotformId is null then 'Pending' else (case cfs.isProcessed when 1 then 'Processed' else 'Submitted' end) end as formStatus,
         u.fullName, c.companyName, cert.refNumber
  From portal.Certification as cert 
      INNER JOIN portal.Company as c on (c.companyId = cert.companyId)
      INNER JOIN portal.Programme as prg on (cert.progId=prg.progId) 
      INNER JOIN portal.ProgrammeForms as pf on (pf.progId=prg.progId) 
      INNER JOIN portal.vForms as f on (pf.jotformId=f.jotformId and f.active=1)
      LEFT JOIN (Select cs.certId, cs.jotformId, max(cs.submissionId) as submissionId, count(cs.jotformId) as submitCnt, 
                        max(cs.dateSubmitted) as dateSubmitted, max(cs.userId) as userId, MAX(CAST(jr.processFlag AS INT)) as isProcessed
                 From portal.CertFormSubmissions as cs 
                 LEFT JOIN Forms.JotformRawResponse as jr on (jr.submissionId=cs.submissionId)
                 WHERE cs.certId = @certId
                 GROUP BY cs.certId, cs.jotformId) as cfs on (cert.certId=cfs.certId and pf.jotformId=cfs.jotformId)
      LEFT JOIN portal.Users as u on (cfs.userId=u.userId)
  where cert.certId = @certId
  ORDER BY pf.displayOrder;

END
GO


-- ----------------------------
-- procedure structure for spCertification_Delete
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCertification_Delete]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCertification_Delete]
GO

CREATE PROCEDURE [portal].[spCertification_Delete]
    @certId INT
AS
BEGIN
    SET NOCOUNT ON;
    declare @clickupTaskId nvarchar(15) = (Select clickupTaskId from portal.Certification WHERE certId = @certId);
    
    UPDATE portal.Certification set isDeleted = 1, dateUpdated = CURRENT_TIMESTAMP
    WHERE certId = @certId;

    if(@clickupTaskId is not null)
    BEGIN
      exec clickup.spTask_DeleteTask @clickupTaskId;
    end

END;
GO


-- ----------------------------
-- procedure structure for spSubmission_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spSubmission_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spSubmission_Get]
GO

CREATE PROCEDURE [portal].[spSubmission_Get]
  @certId int,
  @listCHW bit = 0
AS
BEGIN
  SET NOCOUNT ON;
  declare @chwFormId nvarchar(20);
  set @chwFormId = '232102389529457';
  
  if (@listCHW = 0)
    begin
        -- Get Submissions made for a certification
        select cfs.certsubmissionId, cert.certId, cert.companyId, cert.progId, prg.progName, cert.certYear, pf.displayName as formName, pf.jotformId, cfs.submissionId, 
               FORMAT(cfs.dateSubmitted, 'dd/MM/yyyy') as dateSubmitted, cfs.notes,
               case pf.jotformId when @chwFormId then 1 else 0 end as isCHW,
               cfs.formStatus, u.fullName as userName, c.companyName, cert.refNumber, L.locationName
        From portal.Certification as cert 
            INNER JOIN 
            ( Select certsubmissionId, certId, locationId, jotformId, submissionId, userId, dateSubmitted, isProcessed, notes, 0 as isCHW,
                     case when SubmissionId is null then 'Pending' else (case isProcessed when 1 then 'Processed' else 'Submitted' end) end as formStatus
              From portal.CertFormSubmissions where certId = @certId and jotformId != @chwFormId
              Union all
              Select null as certsubmissionId, max(certId) as certId, null as locationId, max(jotformId) as jotformId, max(submissionId) as submissionId, null as userId, 
                     null as dateSubmitted, 0 as isProcessed, null AS notes, 1 as isCHW,
                     CAST(COUNT(*) AS NVARCHAR(10)) + ' Submitted, ' + CAST(SUM(CAST(isProcessed AS INT)) AS NVARCHAR(10)) +' Processed' as formStatus
              From portal.CertFormSubmissions where certId = @certId and jotformId = @chwFormId
              GROUP BY certId
            ) as cfs on (cfs.certId = cert.certId)
            INNER JOIN portal.Company as c on (c.companyId = cert.companyId)
            INNER JOIN portal.Programme as prg on (prg.progId = cert.progId) 
            INNER JOIN portal.ProgrammeForms as pf on (prg.progId = pf.progId and pf.jotformId = cfs.jotformId) 
            LEFT JOIN portal.Location as L on (L.locationId = cfs.locationId)
            LEFT JOIN portal.Users as u on (u.userId = cfs.userId)
        Where cert.certId = @certId
        ORDER BY cfs.dateSubmitted desc; --, pf.displayOrder;
     end
   else
     begin
        Select certsubmissionId, FORMAT(dateSubmitted, 'dd/MM/yyyy') as dateSubmitted, notes as submittedBy,
               case when SubmissionId is null then 'Pending' else (case isProcessed when 1 then 'Processed' else 'Submitted' end) end as formStatus
        From portal.CertFormSubmissions 
        Where certId = @certId and jotformId = @chwFormId;
     end

END
GO


-- ----------------------------
-- procedure structure for spCertification_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCertification_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCertification_Get]
GO

CREATE PROCEDURE [portal].[spCertification_Get]
  @certId int = null,
  @status int = null,
  @certYear int = null,
  @progId int = null
AS
BEGIN
  SET NOCOUNT ON;
  
  if @certId is null 
    BEGIN
      SELECT Crt.*, C.companyName, ISNULL(P.progName, '-') as progName, ISNULL(DI.itemName, '-') as statusStr,
         FORMAT(Crt.startDate, 'dd/MM/yyyy') + '-' + FORMAT(Crt.endDate, 'dd/MM/yyyy') as period,
         isnull(CS.submissionCnt, 0) as submissionCnt
      From portal.Certification as Crt INNER JOIN portal.Company as C on (Crt.companyId=C.companyId)
      Left JOIN portal.DropdownItems as DI on (Crt.status=DI.itemId and DI.groupId=1)
      LEFT JOIN portal.Programme as P on (P.progId = Crt.progId)
      LEFT JOIN (SELECT certId, COUNT(*) AS submissionCnt 
                 FROM portal.CertFormSubmissions 
                 GROUP BY certId) AS CS on (CS.certId = Crt.certId)
      Where Crt.isDeleted = 0 and
       case when @status is null then 1 else Crt.status end = case when @status is null then 1 else @status end and
       case when @certYear is null then 1 else certYear end = case when @certYear is null then 1 else @certYear end and 
       case when @progId is null then 1 else Crt.progId end = case when @progId is null then 1 else @progId end;
    END
  ELSE
    BEGIN
      SELECT Crt.*, C.companyName, ISNULL(P.progName, '-') as progName, ISNULL(DI.itemName, '-') as statusStr,
         FORMAT(Crt.startDate, 'dd/MM/yyyy') + '-' + FORMAT(Crt.endDate, 'dd/MM/yyyy') as period,
         0 as submissionCnt
      From portal.Certification as Crt INNER JOIN portal.Company as C on (Crt.companyId=C.companyId)
      Left JOIN portal.DropdownItems as DI on (Crt.status=DI.itemId and DI.groupId=1)
      LEFT JOIN portal.Programme as P on (P.progId = Crt.progId)
      Where Crt.isDeleted = 0 and certId = @certId;
    END

END
GO


-- ----------------------------
-- procedure structure for spCertification_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCertification_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCertification_Save]
GO

CREATE PROCEDURE [portal].[spCertification_Save]
    @certId INT = NULL,
    @companyId INT,
    @progId INT,
    @startDate DATETIME2(7),
    @refNumber NVARCHAR(25),
    @status INT,
    @description NVARCHAR(255),
    @clickupTaskId NVARCHAR(25)

AS
BEGIN

  SET NOCOUNT ON;

  IF @certId IS NULL
    BEGIN
        INSERT INTO portal.certification (
            companyId, progId, startDate, endDate, status, refNumber,
            description, clickupTaskId, certYear, isDeleted
        )
        VALUES (
            @companyId, @progId, @startDate, DATEADD(DAY, -1, DATEADD(YEAR, 1, @startDate)), @status, @refNumber,
            @description, @clickupTaskId, YEAR(@startDate), 0
        );
        
        SET @certId = (SELECT SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE portal.certification
        SET 
            companyId = @companyId,
            progId = @progId,
            startDate = @startDate,
            endDate = DATEADD(DAY, -1, DATEADD(YEAR, 1, @startDate)),
            status = @status,
            refNumber = @refNumber,
            description = @description,
            clickupTaskId = @clickupTaskId,
            certYear = YEAR(@startDate)
        WHERE certId = @certId;
    END

    if @certId is Not NULL -- return added/updated certification data to frontend to show in grid etc
    BEGIN
      exec portal.spCertification_Get @certId;
    END

END;
GO


-- ----------------------------
-- procedure structure for spDropdownItems_GetDDL
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spDropdownItems_GetDDL]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spDropdownItems_GetDDL]
GO

CREATE PROCEDURE [portal].[spDropdownItems_GetDDL]
  @groupId int,
  @itemId int = null
AS
BEGIN

  SET NOCOUNT ON;
  
  if @itemId is null 
    BEGIN
      SELECT itemId, itemName
      From portal.DropdownItems 
      Where isDeleted = 0 and groupId = @groupId;
      -- ORDER BY itemName;
    END
  ELSE
    BEGIN
      SELECT itemId, itemName
      From portal.DropdownItems 
      Where (itemId = @itemId or isDeleted = 0) and groupId = @groupId;
      -- ORDER BY itemName;
    END
    
END
GO


-- ----------------------------
-- procedure structure for spCompany_GetDDL
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCompany_GetDDL]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCompany_GetDDL]
GO

CREATE PROCEDURE [portal].[spCompany_GetDDL]
  @companyId int = null
AS
BEGIN

  SET NOCOUNT ON;
  
  if @companyId is null 
    BEGIN
      SELECT companyId, companyName
      From portal.Company 
      Where isDeleted = 0 and status = 1
      ORDER BY companyName;
    END
  ELSE
    BEGIN
      SELECT companyId, companyName
      From portal.Company 
      Where isDeleted = 0 and (companyId = @companyId or status = 1)
      ORDER BY companyName;
    END
    
END
GO


-- ----------------------------
-- procedure structure for spSubmission_Completed_10Jun2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spSubmission_Completed_10Jun2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spSubmission_Completed_10Jun2025]
GO

CREATE PROCEDURE [portal].[spSubmission_Completed_10Jun2025]
  @jotformId nvarchar(25) = null,
  @submissionId nvarchar(25),
  @data nvarchar(max)
AS
BEGIN
    -- When jotform submission completes
    DECLARE @portalCertSubmissionId int, @portalCertId int, @companyName NVARCHAR(100);
    DECLARE @TempTable TABLE ([key] NVARCHAR(50), [value] NVARCHAR(50));

    INSERT INTO @TempTable
    SELECT [Key], [Value] FROM OPENJSON(@data) WHERE [Key] LIKE '%_portal%';

    if(@jotformId = '232102389529457') -- C&HW form submission
      begin
        SELECT @portalCertId = trim([Value]) FROM @TempTable WHERE [Key] LIKE '%_portalCertId'; 
    
        if Not(@portalCertId is null OR @portalCertId = '' OR @portalCertId = 0)
          begin
            INSERT INTO [portal].[CertFormSubmissions] (certId, jotformId, submissionId, locationId, userId, dateSubmitted) 
                                                VALUES (@portalCertId, @jotformId, @submissionId, 0, 0, CURRENT_TIMESTAMP);
          end
      end
    else 
      begin
        SELECT @portalCertSubmissionId = [Value] FROM @TempTable WHERE [Key] LIKE '%_portalCSId'; 
        
        if Not(@portalCertSubmissionId is null OR @portalCertSubmissionId = '' OR @portalCertSubmissionId = 0)
          begin
            Update portal.CertFormSubmissions
               set submissionId = @submissionId
            Where certsubmissionId = @portalCertSubmissionId;
          end
        else if(@jotformId = '241290444812856')-- Blue Award form submission (Not from portal)
          begin
            SELECT @companyName = [Value] FROM @TempTable WHERE [Key] LIKE '%BAQ_CompanyName'; 
            
            INSERT INTO [portal].[BlueAwardSubmissions] (jotformId, submissionId, notes, dateSubmitted) 
                                                VALUES (@jotformId, @submissionId, @companyName, CURRENT_TIMESTAMP);
          end
      end

END
GO


-- ----------------------------
-- procedure structure for spProgramme_GetDDL
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spProgramme_GetDDL]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spProgramme_GetDDL]
GO

CREATE PROCEDURE [portal].[spProgramme_GetDDL]
  @progId int = null
AS
BEGIN

  SET NOCOUNT ON;
  
  if @progId is null 
    BEGIN
      SELECT progId, progName
      From portal.Programme 
      Where isActive = 1
      ORDER BY progName;
    END
  ELSE
    BEGIN
      SELECT progId, progName
      From portal.Programme 
      Where isActive = 1 or progId = @progId
      ORDER BY progName;
    END
    
END
GO


-- ----------------------------
-- procedure structure for spUser_Delete
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spUser_Delete]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spUser_Delete]
GO

CREATE PROCEDURE [portal].[spUser_Delete]
    @userId INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE portal.Users set isDeleted = 1, dateUpdated = CURRENT_TIMESTAMP
    WHERE userId = @userId;
    --DELETE FROM portal.Users WHERE userId = @userId;
END;
GO


-- ----------------------------
-- procedure structure for spUser_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spUser_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spUser_Get]
GO

CREATE PROCEDURE [portal].[spUser_Get]
  @userId int = null,
  @companyId int = 0,
  @status bit = null
AS
BEGIN
  SET NOCOUNT ON;
  
  if @userId is null 
    BEGIN
      SELECT U.userId, UR.applicationRoleId as roleId, U.companyId, U.email, U.fullName, U.status, U.phone,
              case U.companyId when 0 then 'Neutral Carbon Zone' else C.companyName end as companyNameStr,
              case U.status when 0 then 'Inactive' when 1 then 'Active' when 2 then 'Pending' end as statusStr,
              IsNull(R.name, '-') as userRole, u.guId
      From portal.Users as U LEFT JOIN portal.Company as C on (C.companyId = U.companyId)
           INNER JOIN portal.ApplicationUserRoleGrant as UR on (U.userId = UR.userAccountId)
           INNER JOIN portal.ApplicationRole as R on (R.id = UR.applicationRoleId)
      Where U.isDeleted = 0 
        and case when @status is null then 1 else U.status end = case when @status is null then 1 else @status end
        and case when @companyId = 0 then 1 else U.companyId end = case when @companyId = 0 then 1 else @companyId end
       ORDER BY U.companyId, companyNameStr;
    END
  ELSE
    BEGIN
      SELECT U.userId, UR.applicationRoleId as roleId, U.companyId, U.email, U.fullName, U.status, U.phone,
              case U.companyId when 0 then 'Neutral Carbon Zone' else C.companyName end as companyNameStr,
              case U.status when 0 then 'Inactive' when 1 then 'Active' when 2 then 'Pending' end as statusStr,
              IsNull(R.name, '-') as userRole, u.guId
      From portal.Users as U LEFT JOIN portal.Company as C on (C.companyId = U.companyId)
           INNER JOIN portal.ApplicationUserRoleGrant as UR on (U.userId = UR.userAccountId)
           INNER JOIN portal.ApplicationRole as R on (R.id = UR.applicationRoleId)
      Where U.isDeleted = 0 and U.userId = @userId;
    END

END
GO


-- ----------------------------
-- procedure structure for spProgrammeForms_GetDDL
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spProgrammeForms_GetDDL]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spProgrammeForms_GetDDL]
GO

CREATE PROCEDURE [portal].[spProgrammeForms_GetDDL]
  @certId int
AS
BEGIN

  SET NOCOUNT ON;
  
  -- Forms of Programme by CertificationID
  Select pf.displayName, pf.jotformId
  From portal.ProgrammeForms as pf 
  INNER JOIN portal.vForms as f on (pf.jotformId=f.jotformId and f.active=1)
  INNER JOIN portal.Certification as c on (c.progId = pf.progId)
  Where c.certId = @certId and pf.jotformId != '232102389529457' -- exclude C&HW
  ORDER BY pf.displayOrder
    
END
GO


-- ----------------------------
-- procedure structure for spLocation_GetDDL
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spLocation_GetDDL]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spLocation_GetDDL]
GO

CREATE PROCEDURE [portal].[spLocation_GetDDL]
  @certId int
AS
BEGIN
    SET NOCOUNT ON;
    -- Locations of company by CertificationID
    SELECT L.locationId, L.locationName
    From portal.Location as L INNER JOIN portal.Certification as C on (C.companyId = L.companyId)
    Where L.isDeleted = 0 and C.certId = @certId
    ORDER BY L.locationName;

END
GO


-- ----------------------------
-- procedure structure for spSubmission_Delete
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spSubmission_Delete]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spSubmission_Delete]
GO

CREATE PROCEDURE [portal].[spSubmission_Delete]
    @certsubmissionId int
AS
BEGIN
    SET NOCOUNT ON;
    
    Update Forms.JotformRawResponse set processFlag = 1 
    Where submissionId in (select submissionId from portal.CertFormSubmissions where certsubmissionId = @certsubmissionId);
    
    Delete from portal.CertFormSubmissions where certsubmissionId = @certsubmissionId;
END
GO


-- ----------------------------
-- procedure structure for spCountry_GetDDL
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCountry_GetDDL]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCountry_GetDDL]
GO

CREATE PROCEDURE [portal].[spCountry_GetDDL]
 
AS
BEGIN

    SET NOCOUNT ON;
  
    SELECT countryId, countryName From Lookups.Countries;
    
END
GO


-- ----------------------------
-- procedure structure for XspUser_SelectByUid
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XspUser_SelectByUid]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[XspUser_SelectByUid]
GO

CREATE PROCEDURE [portal].[XspUser_SelectByUid]
	@uid nvarchar(250)
   ,@email nvarchar(250) = null
   ,@displayName nvarchar(100) = null
AS
BEGIN
	/*
	EXEC [registrations].[spUser_SelectByUid] @uid = 'jNGrUMb0nWP3ibbBOAGY4ruSzTs1'
	*/
	DECLARE @now BIGINT = (SELECT [utilities].[DateToEpoch](null))
	DECLARE @id INT = (SELECT top 1 [id] FROM [registrations].[UserAccount] WHERE [uid] = @uid)
	IF @id IS NOT NULL
		UPDATE [registrations].[UserAccount]
		   SET [lastSeen] = @now
		 WHERE [id] = @id

	-- If there is no user account available, see if we have a pre-registratation that we can spawn one from
	IF @id IS NULL AND @email IS NOT NULL
	BEGIN
		DECLARE @pr_id int, @pr_mfaRequired bit, @pr_displayName nvarchar(100), @pr_dashboardAccessId int, @pr_opsAccessId int, @pr_customerAreaAccessId int, @pr_regions nvarchar(500), @pr_customers nvarchar(500)
		DECLARE @pr_reportToUserAccountId int, @pr_teamId int
		SELECT @pr_id = [id]
		      ,@pr_displayName = [displayName]
			  ,@pr_dashboardAccessId = [dashboardAccessId]
			  ,@pr_customerAreaAccessId = [customerAreaAccessId]
			  ,@pr_regions = [regions]
			  ,@pr_customers = [customers]
			  ,@pr_reportToUserAccountId = [reportToUserAccountId]
			  ,@pr_teamId = [teamId]
			  ,@pr_mfaRequired = [mfaRequired]
			  ,@pr_opsAccessId = [opsAccessId]
		  FROM [registrations].[UserAccountPreregister] 
		 WHERE [email] = @email

		IF @pr_id IS NOT NULL
			EXEC [registrations].[spUser_Update]
				 @uid = @uid
				,@email = @email
				,@displayName = @pr_displayName
				,@dashboardAccessId = @pr_dashboardAccessId
				,@customerAreaAccessId = @pr_customerAreaAccessId
				,@regions_JSON = @pr_regions
				,@customers_JSON = @pr_customers
				,@lastSeen = @now
				,@reportToUserAccountId = @pr_reportToUserAccountId
				,@teamId = @pr_teamId
				,@mfaRequired = @pr_mfaRequired
				,@opsAccessId = @pr_opsAccessId

		ELSE
		BEGIN
			DECLARE @p int = (SELECT CHARINDEX('@', @email, 0))
			DECLARE @defaultCustomerId INT
			DECLARE @domain nvarchar(100) = SUBSTRING(@email, @p+1, Len(@email))
			SELECT TOP 1 @pr_id = [id] 
				  ,@pr_displayName = IsNull(@displayName, @email)
				  ,@pr_dashboardAccessId = [defaultDashboardAccessId]
				  ,@pr_customerAreaAccessId = [defaultCustomerAreaAccessId]
				  ,@defaultCustomerId = [defaultCustomerId]
				  ,@pr_mfaRequired = [mfaRequired]
				  ,@pr_opsAccessId = [defaultOpsAccessId]
			  FROM [registrations].[vRegistrationWhitelist] wl
			 WHERE wl.[pattern] = @email
				OR wl.[pattern] = @domain
		  ORDER BY wl.[searchOrder], wl.[isEmail] DESC

			IF @pr_id IS NOT NULL
			BEGIN
				IF @defaultCustomerId IS NOT NULL
					SET @pr_customers = '[{"id":' + Cast(@defaultCustomerId as varchar(10)) + '}]'
				EXEC [registrations].[spUser_Update]
					@uid = @uid
					,@email = @email
					,@displayName = @pr_displayName
					,@dashboardAccessId = @pr_dashboardAccessId
					,@customerAreaAccessId = @pr_customerAreaAccessId
					,@regions_JSON = null
					,@customers_JSON = @pr_customers
					,@lastSeen = @now
					,@mfaRequired = @pr_mfaRequired
					,@opsAccessId = @pr_opsAccessId
			END
		END
	END

	SELECT top 1 u.*
	      ,cids.assigned as [cids]
	      ,rids.assigned as [rids]
          ,featureOptions.assigned as [options]
		  ,customer.maxLoginTime as [maxLoginTime]
	  FROM [registrations].[UserAccount] u
     CROSS APPLY (
		 	SELECT fo.[id], ug.[available], app.[name] as [applicationName], ft.[name] as [featureName], fo.[name] as [featureOptionName]
			  FROM [core].[ApplicationUserGrant] ug
        INNER JOIN [core].[ApplicationFeatureOption] fo ON fo.[id] = ug.[applicationFeatureOptionId]
        INNER JOIN [core].[ApplicationFEature] ft ON ft.[id] = fo.[applicationFeatureId]
        INNER JOIN [core].[Application] app ON app.[id] = ft.[applicationId]
			 WHERE ug.[userAccountId] = u.[id]
		  FOR JSON PATH
	 	) as featureOptions (assigned)
     CROSS APPLY (
		 	SELECT c.[customerId] as [id]
			  FROM [registrations].[UserAccountCustomer] c
			 WHERE c.[userAccountId] = u.[id]
		  FOR JSON AUTO
	 	) as cids (assigned)
     CROSS APPLY (
		 	SELECT c.[regionId] as [id]
			  FROM [registrations].[UserAccountRegion] c
			 WHERE c.[userAccountId] = u.[id]
		  FOR JSON AUTO
	 	) as rids (assigned)
	 OUTER APPLY (
		 	SELECT TOP 1 c.[maxLoginTime]
			  FROM [contracts].[Customer] c
				INNER JOIN [registrations].[UserAccountCustomer] uc on uc.customerId = c.[id]
				WHERE uc.[userAccountId] = u.[id]
	 	) as customer (maxLoginTime)
	 WHERE u.[uid] = @uid
END
GO


-- ----------------------------
-- procedure structure for spUser_GetbyUId
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spUser_GetbyUId]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spUser_GetbyUId]
GO

CREATE PROCEDURE [portal].[spUser_GetbyUId]
  @uId nvarchar(100)
AS
BEGIN
  SET NOCOUNT ON;
  
  if not @uId is null 
    BEGIN
      SELECT U.userId, U.companyId, U.email, U.fullName as displayName, U.status, UR.applicationRoleId as roleId, R.name as userRole, u.uId,
            CASE WHEN U.isEmailVerified = 1 THEN 1 ELSE 0 END AS emailVerified,
            CASE WHEN U.status != 1 THEN 1 ELSE 0 END AS disabled,
            Case U.companyId when 0 then 'Neutral Carbon Zone' else C.companyName end as companyName,
            Case U.companyId when 0 then '/dashboard' else '/certifications' end as landingPage
      From portal.Users as U LEFT JOIN portal.Company as C on (C.companyId = U.companyId)
           INNER JOIN portal.ApplicationUserRoleGrant as UR on (U.userId = UR.userAccountId)
           INNER JOIN portal.ApplicationRole as R on (R.id = UR.applicationRoleId)
      Where U.isDeleted = 0 and U.uId = @uId;
      
      -- Permissions
      Select A.name as applicationName, F.name as featureName, FO.name as featureOptionName
      From  portal.Users as U
            INNER JOIN portal.ApplicationUserRoleGrant as UR on (U.userId = UR.userAccountId)
            INNER JOIN portal.ApplicationRole as R on (R.id = UR.applicationRoleId)
            INNER JOIN portal.ApplicationRoleOption as RO on (R.id = RO.applicationRoleId)
            INNER JOIN portal.ApplicationFeatureOption as FO on (FO.id = RO.applicationFeatureOptionId)
            INNER JOIN portal.ApplicationFeature as F on (F.id = FO.applicationFeatureId)
            INNER JOIN portal.Application as A on (A.id = R.applicationId)
      Where RO.available = 1 and U.uId = @uId;
    END

END
GO


-- ----------------------------
-- procedure structure for spSubmission_GetDetails
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spSubmission_GetDetails]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spSubmission_GetDetails]
GO

CREATE PROCEDURE [portal].[spSubmission_GetDetails]
  @certsubmissionId int
AS
BEGIN
  SET NOCOUNT ON;
  
  -- Get Submission details
  select -- cfs.certsubmissionId, cert.certId, cert.companyId, cert.progId, pf.displayName as formName, pf.jotformId, 
         -- FORMAT(cfs.dateSubmitted, 'dd/MM/yyyy') as dateSubmitted, cfs.notes, u.fullName as userName, L.locationName
         c.companyName, cert.refNumber, prg.progName, pf.displayName as formName, cfs.submissionId, cfs.jotformId, cert.certId
  From portal.Certification as cert 
      INNER JOIN portal.CertFormSubmissions as cfs on (cfs.certId = cert.certId)
      INNER JOIN portal.Company as c on (c.companyId = cert.companyId)
      INNER JOIN portal.Programme as prg on (prg.progId = cert.progId) 
      INNER JOIN portal.ProgrammeForms as pf on (prg.progId = pf.progId and pf.jotformId = cfs.jotformId) 
      -- LEFT JOIN portal.Location as L on (L.locationId = cfs.locationId)
      -- LEFT JOIN portal.Users as u on (u.userId = cfs.userId)
  Where cfs.certsubmissionId = @certsubmissionId;

END
GO


-- ----------------------------
-- procedure structure for spSubmission_Completed_20May2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spSubmission_Completed_20May2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spSubmission_Completed_20May2025]
GO

CREATE PROCEDURE [portal].[spSubmission_Completed_20May2025]
  @jotformId nvarchar(25) = null,
  @submissionId nvarchar(25),
  @data nvarchar(max)
AS
BEGIN
    -- When jotform submission completes
    DECLARE @portalCertSubmissionId int, @portalCertId int;
    DECLARE @TempTable TABLE ([key] NVARCHAR(50), [value] NVARCHAR(50));

    INSERT INTO @TempTable
    SELECT [Key], [Value] FROM OPENJSON(@data) WHERE [Key] LIKE '%_portal%';

    if(@jotformId = '232102389529457') -- C&HW form submission
      begin
        SELECT @portalCertId = trim([Value]) FROM @TempTable WHERE [Key] LIKE '%_portalCertId'; 
    
        if Not(@portalCertId is null OR @portalCertId = '' OR @portalCertId = 0)
          begin
            INSERT INTO [portal].[CertFormSubmissions] (certId, jotformId, submissionId, locationId, userId, dateSubmitted) 
                                                VALUES (@portalCertId, @jotformId, @submissionId, 0, 0, CURRENT_TIMESTAMP);
          end
      end
    else 
      begin
        SELECT @portalCertSubmissionId = [Value] FROM @TempTable WHERE [Key] LIKE '%_portalCSId'; 
        
        if (@portalCertSubmissionId is not null)
          begin
            Update portal.CertFormSubmissions
               set submissionId = @submissionId
            Where certsubmissionId = @portalCertSubmissionId;
          end
      end

END
GO


-- ----------------------------
-- procedure structure for XspProgramme_GetDocuments
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XspProgramme_GetDocuments]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[XspProgramme_GetDocuments]
GO

CREATE PROCEDURE [portal].[XspProgramme_GetDocuments]
  @progId int
AS
BEGIN

    SET NOCOUNT ON;
    
    Select * from portal.ProgrammeDocuments
    Where isDeleted = 0 and progId = @progId
    ORDER BY displayOrder;
      
END
GO


-- ----------------------------
-- procedure structure for spCertificationDocument_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCertificationDocument_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCertificationDocument_Get]
GO

CREATE PROCEDURE [portal].[spCertificationDocument_Get]
  @certId int
AS
BEGIN

    SET NOCOUNT ON;
    
    Select d.title as displayName, d.title, d.id as documentId
    From Documents.Document as d
    Where d.activeTo is null and d.parentEntityType = 'certification' and d.parentEntityId = @certId
    UNION
    Select pd.displayName, d.title, d.id as documentId
    From portal.ProgrammeDocuments as pd 
      INNER JOIN portal.Certification as c on (c.progId = pd.progId)
      INNER JOIN Documents.Document as d on (d.id = pd.documentId)
    Where d.activeTo is null and d.parentEntityType = 'certification-prog' and d.parentEntityId = c.progId
          and c.certId = @certId;
          
END
GO


-- ----------------------------
-- procedure structure for spCertification_GetbyCompany
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spCertification_GetbyCompany]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spCertification_GetbyCompany]
GO

CREATE PROCEDURE [portal].[spCertification_GetbyCompany]
  @companyId int
AS
BEGIN
  SET NOCOUNT ON;
  
      SELECT Crt.*, C.companyName, ISNULL(P.progName, '-') as progName, ISNULL(DI.itemName, '-') as statusStr,
         FORMAT(Crt.startDate, 'dd/MM/yyyy') + '-' + FORMAT(Crt.endDate, 'dd/MM/yyyy') as period,
         isnull(CS.submissionCnt, 0) as submissionCnt
      From portal.Certification as Crt INNER JOIN portal.Company as C on (Crt.companyId=C.companyId)
      Left JOIN portal.DropdownItems as DI on (Crt.status=DI.itemId and DI.groupId=1)
      LEFT JOIN portal.Programme as P on (P.progId = Crt.progId)
      LEFT JOIN (SELECT certId, COUNT(*) AS submissionCnt 
                 FROM portal.CertFormSubmissions 
                 GROUP BY certId) AS CS on (CS.certId = Crt.certId)
      Where Crt.isDeleted = 0 and C.companyId = @companyId;

END
GO


-- ----------------------------
-- procedure structure for spUserRole_GetDDL
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spUserRole_GetDDL]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spUserRole_GetDDL]
GO

CREATE PROCEDURE [portal].[spUserRole_GetDDL]
  @companyId int = 0,
  @roleId int = null
AS
BEGIN
  -- Roles dropdown for Admin User and CLient user forms
  SET NOCOUNT ON;
  
  IF @roleId IS NULL 
    BEGIN
        SELECT id AS roleId, name AS roleName
        FROM portal.ApplicationRole 
        WHERE 
            (companyId in (0, @companyId)) 
            AND (@companyId = 0 AND roleScope IN ('admin', 'both') 
                 OR @companyId <> 0 AND roleScope IN ('client', 'both'))
        ORDER BY roleName;
    END
  ELSE
    BEGIN
        SELECT id AS roleId, name AS roleName
        FROM portal.ApplicationRole 
        WHERE 
            (
                (companyId in (0, @companyId)) 
                AND (@companyId = 0 AND roleScope IN ('admin', 'both') 
                     OR @companyId <> 0 AND roleScope IN ('client', 'both'))
            )
            OR id = @roleId
        ORDER BY roleName;
    END
END
GO


-- ----------------------------
-- procedure structure for XspCompany_GetCustDirectory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[XspCompany_GetCustDirectory]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[XspCompany_GetCustDirectory]
GO

CREATE PROCEDURE [portal].[XspCompany_GetCustDirectory]
  @userCompanyId int
AS
BEGIN
    SET NOCOUNT ON;
  
    SELECT 
        C.companyName, C.email, C.phone, C.address, C.contactName, C.jobTitle, C.description,
        CASE 
            WHEN C.industryType = 30 THEN C.industryTypeOther 
            ELSE DI.itemName 
        END AS industryTypeStr,
        DC.itemName AS country,

        -- Validate and format website
        CASE 
            WHEN C.website IS NULL OR 
                 C.website NOT LIKE '%[.][a-z]%' THEN ''
            WHEN C.website LIKE 'http%' THEN C.website
            ELSE 'http://' + C.website
        END AS website,

        -- Validate and format LinkedIn page
        CASE 
            WHEN C.linkedInPage IS NULL OR 
                 C.linkedInPage NOT LIKE '%linkedin.%' THEN ''
            WHEN C.linkedInPage LIKE 'http%' THEN C.linkedInPage
            ELSE 'https://' + C.linkedInPage
        END AS linkedInPage,

        -- Format logo with apiKey if matches required path
        CASE 
            WHEN C.logo LIKE 'https://app.neutralcarbonzone.com/uploads/%' 
                 THEN C.logo + '?apiKey=964f4219f34a79448399110d86da47f4'
            ELSE C.logo
        END AS logo

    FROM portal.CustomerDirectory as C
        -- portal.Company AS C 
        LEFT JOIN portal.DropdownItems AS DI ON C.industryType = DI.itemId
        LEFT JOIN portal.DropdownItems AS DC ON C.countryId = DC.itemId

    WHERE 
        C.isDeleted = 0 
        AND C.nczCustomerDirectory = 1 
        AND C.companyId != @userCompanyId;


END
GO


-- ----------------------------
-- procedure structure for spNCZDirectory_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spNCZDirectory_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spNCZDirectory_Get]
GO

CREATE PROCEDURE [portal].[spNCZDirectory_Get]
  @dirItemId int = null,
  @showAll bit = 0
AS
BEGIN
    SET NOCOUNT ON;
  
       SELECT 
            DISTINCT
            ND.dirItemId, ND.customerReference, ND.certTaskId, ND.isVisible,
            ND.companyName,
            ND.salesName, ND.salesEmail, ND.salesPhone, ND.esgName, ND.esgEmail, ND.esgPhone,
            ND.emissionOffset, ND.industryType, ND.companyDescription, ND.offersDiscounts,
            CASE -- 5 words
                WHEN LEN(offersDiscounts) - LEN(REPLACE(offersDiscounts, ' ', '')) + 1 > 5
                    THEN LEFT(offersDiscounts, CHARINDEX(' ', offersDiscounts + ' ', CHARINDEX(' ', offersDiscounts + ' ', CHARINDEX(' ', offersDiscounts + ' ', CHARINDEX(' ', offersDiscounts + ' ', CHARINDEX(' ', offersDiscounts + ' ') + 1) + 1) + 1) + 1)) + '...'
                ELSE offersDiscounts
            END AS shortOffersDiscounts,
            CASE -- Validate and format website
                WHEN ND.website IS NULL OR 
                     ND.website NOT LIKE '%[.][a-z]%' THEN ''
                WHEN ND.website LIKE 'http%' THEN ND.website
                ELSE 'http://' + ND.website
            END AS website,
            CASE -- Validate and format LinkedIn page
                WHEN ND.linkedInPage IS NULL OR 
                     ND.linkedInPage NOT LIKE '%linkedin.%' THEN ''
                WHEN ND.linkedInPage LIKE 'http%' THEN ND.linkedInPage
                ELSE 'https://' + ND.linkedInPage
            END AS linkedInPage,
            CASE -- Validate and format Facebook page
                WHEN ND.facebookPage IS NULL OR 
                     ND.facebookPage NOT LIKE '%facebook.%' THEN ''
                WHEN ND.facebookPage LIKE 'http%' THEN ND.facebookPage
                ELSE 'https://' + ND.facebookPage
            END AS facebookPage,
            CASE -- Validate and format Instagram page
                WHEN ND.instagramPage IS NULL OR 
                     ND.instagramPage NOT LIKE '%instagram.%' THEN ''
                WHEN ND.instagramPage LIKE 'http%' THEN ND.instagramPage
                ELSE 'https://' + ND.instagramPage
            END AS instagramPage,
            CASE -- Format logo with apiKey if matches required path
                WHEN ND.logo LIKE 'https://app.neutralcarbonzone.com/uploads/%' 
                     THEN ND.logo + '?apiKey=964f4219f34a79448399110d86da47f4'
                ELSE ND.logo
            END AS logo,
            CF.[value] as product, 
            case when (T.status = 'current certificate issued') then 1 
                 when (T.status like '%additional interest%') then 1
                 else 0
            end as isCertified
        FROM portal.NCZDirectory as ND
             LEFT JOIN clickup.CustomField AS CF ON (CF.taskId = ND.certTaskId AND CF.name = 'Product' AND CF.value IS NOT NULL)
             LEFT JOIN clickup.task AS T ON (T.id = ND.certTaskId AND T.parentId IS NULL)
        Where ( @dirItemId IS NOT NULL AND ND.dirItemId = @dirItemId )
              OR
              ( @dirItemId IS NULL AND ( @showAll = 1 OR ND.isVisible = 1 ))
        ORDER BY companyName;

END
GO


-- ----------------------------
-- procedure structure for spUser_SaveUId
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spUser_SaveUId]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spUser_SaveUId]
GO

CREATE PROCEDURE [portal].[spUser_SaveUId]
    @userId INT,
    @uId NVARCHAR(100)
AS
BEGIN
  SET NOCOUNT ON;
  
  if @userId is not NULL
    BEGIN
        UPDATE portal.Users
        SET 
            uId = @uId
        WHERE userId = @userId;
    END
    
END;
GO


-- ----------------------------
-- procedure structure for spUser_EmailVerified
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spUser_EmailVerified]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spUser_EmailVerified]
GO

CREATE PROCEDURE [portal].[spUser_EmailVerified]
    @emailVerified bit,
    @email NVARCHAR(100)
AS
BEGIN
  SET NOCOUNT ON;
  
  if @email is not NULL
    BEGIN
        UPDATE portal.Users
        SET 
            isEmailVerified = @emailVerified,
            status = case @emailVerified when 1 then 1 else 2 end
        WHERE LOWER(email) = LOWER(@email);
    END
    
  Select uId from portal.Users where LOWER(email) = LOWER(@email);
  
END;
GO


-- ----------------------------
-- procedure structure for spNCZDirectory_SaveSubmission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spNCZDirectory_SaveSubmission]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spNCZDirectory_SaveSubmission]
GO

CREATE PROCEDURE [portal].[spNCZDirectory_SaveSubmission]
    @submissionId VARCHAR(20),
    @jsonData NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM portal.NCZDirectory WHERE submissionId = @submissionId)
    BEGIN
        -- UPDATE
        UPDATE NCZDirectory
        SET 
            salesName         = JSON_VALUE(@jsonData, '$.q140_contactPerson140.first') + ' ' + JSON_VALUE(@jsonData, '$.q140_contactPerson140.last'),
            salesEmail        = JSON_VALUE(@jsonData, '$.q69_salesContact'),
            salesPhone        = JSON_VALUE(@jsonData, '$.q142_salesPhone.area') + '-' + JSON_VALUE(@jsonData, '$.q142_salesPhone.phone'),
            esgName           = JSON_VALUE(@jsonData, '$.q68_esgContact.first') + ' ' + JSON_VALUE(@jsonData, '$.q68_esgContact.last'),
            esgEmail          = JSON_VALUE(@jsonData, '$.q141_esgContact141'),
            esgPhone          = JSON_VALUE(@jsonData, '$.q70_esgPhone.area') + '-' + JSON_VALUE(@jsonData, '$.q70_esgPhone.phone'),
            website           = JSON_VALUE(@jsonData, '$.q143_companyWebsite'),
            linkedinPage      = JSON_VALUE(@jsonData, '$.q145_linkedinPage'),
            facebookPage      = JSON_VALUE(@jsonData, '$.q147_facebookPage'),
            instagramPage     = JSON_VALUE(@jsonData, '$.q146_instagramPage'),
            logo              = JSON_VALUE(@jsonData, '$.q144_companyLogo'),
            emissionOffset    = JSON_VALUE(@jsonData, '$.q150_hasYour'),
            industryType      = JSON_VALUE(@jsonData, '$.q111_whatIndustry'),
            companyDescription= JSON_VALUE(@jsonData, '$.q166_pleaseProvide166'),
            offersDiscounts   = JSON_VALUE(@jsonData, '$.q162_pleaseProvide'),
            customerReference = JSON_VALUE(@jsonData, '$.q167_pleaseEnter')
        WHERE submissionId = @submissionId;
    END
    ELSE
    BEGIN
        -- INSERT
        INSERT INTO portal.NCZDirectory (
            submissionId,
            salesName,
            salesEmail,
            salesPhone,
            esgName,
            esgEmail,
            esgPhone,
            website,
            linkedinPage,
            facebookPage,
            instagramPage,
            logo,
            emissionOffset,
            industryType,
            companyDescription,
            offersDiscounts,
            customerReference
        )
        VALUES (
            @submissionId,
            JSON_VALUE(@jsonData, '$.q140_contactPerson140.first') + ' ' + JSON_VALUE(@jsonData, '$.q140_contactPerson140.last'),
            JSON_VALUE(@jsonData, '$.q69_salesContact'),
            JSON_VALUE(@jsonData, '$.q142_salesPhone.area') + '-' + JSON_VALUE(@jsonData, '$.q142_salesPhone.phone'),
            JSON_VALUE(@jsonData, '$.q68_esgContact.first') + ' ' + JSON_VALUE(@jsonData, '$.q68_esgContact.last'),
            JSON_VALUE(@jsonData, '$.q141_esgContact141'),
            JSON_VALUE(@jsonData, '$.q70_esgPhone.area') + '-' + JSON_VALUE(@jsonData, '$.q70_esgPhone.phone'),
            JSON_VALUE(@jsonData, '$.q143_companyWebsite'),
            JSON_VALUE(@jsonData, '$.q145_linkedinPage'),
            JSON_VALUE(@jsonData, '$.q147_facebookPage'),
            JSON_VALUE(@jsonData, '$.q146_instagramPage'),
            JSON_VALUE(@jsonData, '$.q144_companyLogo'),
            JSON_VALUE(@jsonData, '$.q150_hasYour'),
            JSON_VALUE(@jsonData, '$.q111_whatIndustry'),
            JSON_VALUE(@jsonData, '$.q166_pleaseProvide166'),
            JSON_VALUE(@jsonData, '$.q162_pleaseProvide'),
            JSON_VALUE(@jsonData, '$.q167_pleaseEnter')
        );
    END
    
    Update Forms.JotformRawResponse set processFlag = 1 where submissionId = @submissionId;
END
GO


-- ----------------------------
-- procedure structure for spNCZDirectory_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spNCZDirectory_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spNCZDirectory_Save]
GO

CREATE PROCEDURE [portal].[spNCZDirectory_Save]
    @dirItemId INT,
    @customerReference NVARCHAR(20),
    @companyName NVARCHAR(50),
    @certTaskId NVARCHAR(15),
    @isVisible BIT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE portal.NCZDirectory
    SET customerReference = @customerReference,
        companyName       = @companyName,
        certTaskId        = @certTaskId,
        isVisible         = @isVisible
    WHERE dirItemId = @dirItemId;
    
    exec portal.spNCZDirectory_Get @dirItemId, 0;
END
GO


-- ----------------------------
-- procedure structure for spUser_GetbyEmail
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spUser_GetbyEmail]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spUser_GetbyEmail]
GO

CREATE PROCEDURE [portal].[spUser_GetbyEmail]
  @email nvarchar(100)
AS
BEGIN
  SET NOCOUNT ON;
  
  if not @email is null 
    BEGIN
      SELECT U.userId, U.email, U.fullName as displayName, U.status, u.uId,
            CASE WHEN U.isEmailVerified = 1 THEN 1 ELSE 0 END AS emailVerified,
            CASE WHEN U.status != 1 THEN 1 ELSE 0 END AS disabled
      From portal.Users as U
      Where U.isDeleted = 0 and lower(U.email) = lower(@email);
    END

END
GO


-- ----------------------------
-- procedure structure for spUser_CheckEmail
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spUser_CheckEmail]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spUser_CheckEmail]
GO

CREATE PROCEDURE [portal].[spUser_CheckEmail]
    @email NVARCHAR(50)
AS
BEGIN
  SET NOCOUNT ON;
  
  Select count(userId) as cnt from portal.Users where Lower(email) = Lower(@email) and isDeleted=0;
  
END;
GO


-- ----------------------------
-- procedure structure for spLocation_Delete
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[spLocation_Delete]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[portal].[spLocation_Delete]
GO

CREATE PROCEDURE [portal].[spLocation_Delete]
    @locationId INT
AS
BEGIN
    SET NOCOUNT ON;
    
    if Not EXISTS(Select * from portal.CertFormSubmissions where locationId = @locationId)
      begin
        UPDATE portal.Location set isDeleted = 1, dateUpdated = CURRENT_TIMESTAMP
        WHERE locationId = @locationId;
      end
    ELSE
      BEGIN
        Select 'NOT_ALLOWED' as result;
      END
END;
GO


-- ----------------------------
-- Auto increment value for Application
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Application]', RESEED, 1)
GO


-- ----------------------------
-- Auto increment value for ApplicationFeature
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationFeature]', RESEED, 11)
GO


-- ----------------------------
-- Auto increment value for ApplicationFeatureOption
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationFeatureOption]', RESEED, 34)
GO


-- ----------------------------
-- Auto increment value for ApplicationRole
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationRole]', RESEED, 4)
GO


-- ----------------------------
-- Auto increment value for ApplicationRoleOption
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationRoleOption]', RESEED, 38)
GO


-- ----------------------------
-- Auto increment value for ApplicationUserGrant
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationUserGrant]', RESEED, 1)
GO


-- ----------------------------
-- Auto increment value for ApplicationUserRoleGrant
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationUserRoleGrant]', RESEED, 61)
GO


-- ----------------------------
-- Auto increment value for BlueAwardSubmissions
-- ----------------------------
DBCC CHECKIDENT ('[portal].[BlueAwardSubmissions]', RESEED, 44)
GO


-- ----------------------------
-- Primary Key structure for table BlueAwardSubmissions
-- ----------------------------
ALTER TABLE [portal].[BlueAwardSubmissions] ADD CONSTRAINT [PK__BlueAwar__2D1A9A2BCB09E96C] PRIMARY KEY CLUSTERED ([bluesubmissionId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for CertFormSubmissions
-- ----------------------------
DBCC CHECKIDENT ('[portal].[CertFormSubmissions]', RESEED, 109)
GO


-- ----------------------------
-- Primary Key structure for table CertFormSubmissions
-- ----------------------------
ALTER TABLE [portal].[CertFormSubmissions] ADD CONSTRAINT [PK__Submissi__B1DEEF52892BFE63] PRIMARY KEY CLUSTERED ([certsubmissionId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Certification
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Certification]', RESEED, 20)
GO


-- ----------------------------
-- Primary Key structure for table Certification
-- ----------------------------
ALTER TABLE [portal].[Certification] ADD CONSTRAINT [PK__Certific__D2C93639D8E81FBD] PRIMARY KEY CLUSTERED ([certId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Company
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Company]', RESEED, 51)
GO


-- ----------------------------
-- Primary Key structure for table Company
-- ----------------------------
ALTER TABLE [portal].[Company] ADD CONSTRAINT [PK__Company__AD545990B7F019E0] PRIMARY KEY CLUSTERED ([companyId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for DropdownItems
-- ----------------------------
DBCC CHECKIDENT ('[portal].[DropdownItems]', RESEED, 228)
GO


-- ----------------------------
-- Auto increment value for Location
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Location]', RESEED, 20)
GO


-- ----------------------------
-- Primary Key structure for table Location
-- ----------------------------
ALTER TABLE [portal].[Location] ADD CONSTRAINT [PK__Location__30646B6EC3CED846] PRIMARY KEY CLUSTERED ([locationId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for NCZDirectory
-- ----------------------------
DBCC CHECKIDENT ('[portal].[NCZDirectory]', RESEED, 102)
GO


-- ----------------------------
-- Primary Key structure for table NCZDirectory
-- ----------------------------
ALTER TABLE [portal].[NCZDirectory] ADD CONSTRAINT [PK__NCZDirec__50A58BBE9C5DB8D3] PRIMARY KEY CLUSTERED ([dirItemId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Users
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Users]', RESEED, 66)
GO


-- ----------------------------
-- Primary Key structure for table Users
-- ----------------------------
ALTER TABLE [portal].[Users] ADD CONSTRAINT [PK__Users__CB9A1CFFF5B6B40D] PRIMARY KEY CLUSTERED ([userId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for XCertificationDocuments
-- ----------------------------
DBCC CHECKIDENT ('[portal].[XCertificationDocuments]', RESEED, 1)
GO


-- ----------------------------
-- Auto increment value for XCustomerDirectory
-- ----------------------------
DBCC CHECKIDENT ('[portal].[XCustomerDirectory]', RESEED, 170)
GO


-- ----------------------------
-- Primary Key structure for table XCustomerDirectory
-- ----------------------------
ALTER TABLE [portal].[XCustomerDirectory] ADD CONSTRAINT [PK__Company___AD54599033A4DC74] PRIMARY KEY CLUSTERED ([companyId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table XPermissions
-- ----------------------------
ALTER TABLE [portal].[XPermissions] ADD CONSTRAINT [PK__Permissi__D821329C2C0A2E69] PRIMARY KEY CLUSTERED ([permissionId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for XRoles
-- ----------------------------
DBCC CHECKIDENT ('[portal].[XRoles]', RESEED, 1)
GO


-- ----------------------------
-- Primary Key structure for table XRoles
-- ----------------------------
ALTER TABLE [portal].[XRoles] ADD CONSTRAINT [PK__Roles__CD98462A0EBD2CB9] PRIMARY KEY CLUSTERED ([roleId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for XUserAccount
-- ----------------------------
DBCC CHECKIDENT ('[portal].[XUserAccount]', RESEED, 1)
GO

