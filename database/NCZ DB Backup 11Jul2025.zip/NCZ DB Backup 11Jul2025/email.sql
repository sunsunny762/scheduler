/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : email

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:30:24
*/


-- ----------------------------
-- Table structure for Email
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[Email]') AND type IN ('U'))
	DROP TABLE [email].[Email]
GO

CREATE TABLE [email].[Email] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [subject] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [body] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [messageId] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [inbound] bit  NOT NULL,
  [activeFrom] bigint  NOT NULL,
  [minimumSendDate] bigint  NULL,
  [sentDate] bigint  NULL,
  [sendAttemptCount] int  NULL,
  [sendError] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [receivedDate] bigint  NULL,
  [executeSql] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [email].[Email] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for EmailAttachment
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[EmailAttachment]') AND type IN ('U'))
	DROP TABLE [email].[EmailAttachment]
GO

CREATE TABLE [email].[EmailAttachment] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [emailId] int  NOT NULL,
  [documentId] int  NULL
)
GO

ALTER TABLE [email].[EmailAttachment] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'documents.document.id',
'SCHEMA', N'email',
'TABLE', N'EmailAttachment',
'COLUMN', N'documentId'
GO


-- ----------------------------
-- Table structure for EmailConfigration
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[EmailConfigration]') AND type IN ('U'))
	DROP TABLE [email].[EmailConfigration]
GO

CREATE TABLE [email].[EmailConfigration] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] varchar(150) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [template] varchar(150) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [storedProcedure] varchar(150) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [recipient] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [email].[EmailConfigration] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for EmailContact
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[EmailContact]') AND type IN ('U'))
	DROP TABLE [email].[EmailContact]
GO

CREATE TABLE [email].[EmailContact] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [emailAddress] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [displayName] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [email].[EmailContact] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for EmailRecipient
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[EmailRecipient]') AND type IN ('U'))
	DROP TABLE [email].[EmailRecipient]
GO

CREATE TABLE [email].[EmailRecipient] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [emailId] int  NOT NULL,
  [emailContactId] int  NOT NULL,
  [emailRecipientTypeId] int  NOT NULL
)
GO

ALTER TABLE [email].[EmailRecipient] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for EmailReply
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[EmailReply]') AND type IN ('U'))
	DROP TABLE [email].[EmailReply]
GO

CREATE TABLE [email].[EmailReply] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [emailId] int  NOT NULL,
  [messageId] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [replyTo] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [inReplyTo] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [email].[EmailReply] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- View structure for vEmailQueue
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[vEmailQueue]') AND type IN ('V'))
	DROP VIEW [email].[vEmailQueue]
GO

CREATE VIEW [email].[vEmailQueue] AS SELECT 
		 e.[id]
		,e.[subject]
		,e.[body]
		,e.[sendAttemptCount]
		,e.[minimumSendDate]
		,er.[messageId]
		,er.[replyTo]
		,er.[inReplyTo]
		,(SELECT ec.[emailAddress]
					FROM [email].[EmailRecipient] er
					INNER JOIN [email].[EmailContact] ec on ec.[id] = er.[emailContactId]
					WHERE er.[emailId] = e.[id] AND er.[emailRecipientTypeId] = 1 
					FOR JSON AUTO) as [to]
		,(SELECT ec.[emailAddress]
					FROM [email].[EmailRecipient] er
					INNER JOIN [email].[EmailContact] ec on ec.[id] = er.[emailContactId] 
					WHERE er.[emailId] = e.[id] AND er.[emailRecipientTypeId] = 2
					FOR JSON AUTO) as [cc]
		,(SELECT ec.[emailAddress]
					FROM [email].[EmailRecipient] er
					INNER JOIN [email].[EmailContact] ec on ec.[id] = er.[emailContactId]
					WHERE er.[emailId] = e.[id] AND er.[emailRecipientTypeId] = 3 
					FOR JSON AUTO) as [bcc]
	  FROM [email].[Email] e
 LEFT JOIN [email].[EmailReply] er on er.[emailId] = e.[id]
	 WHERE [inbound] = 0 AND [sentDate] IS NULL AND IsNull([sendAttemptCount],0) < 4
GO


-- ----------------------------
-- procedure structure for spEmailQueue_DeleteForRecipient
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[spEmailQueue_DeleteForRecipient]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[email].[spEmailQueue_DeleteForRecipient]
GO

CREATE PROCEDURE [email].[spEmailQueue_DeleteForRecipient]
  @Email nvarchar(200)
AS
BEGIN
  DELETE e
    FROM [email].[Email] e
  INNER JOIN [email].[EmailRecipient] r ON r.[emailId] = e.[id]
  INNER JOIN [email].[EmailContact] c ON c.id = r.emailContactId
       WHERE c.emailAddress = @email
END
GO


-- ----------------------------
-- procedure structure for spEmailConfigration_Select
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[spEmailConfigration_Select]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[email].[spEmailConfigration_Select]
GO

CREATE PROCEDURE [email].[spEmailConfigration_Select]
	@name nvarchar(150)
AS
BEGIN
	 SELECT template = ec.template,
			recipient = ec.recipient
    FROM email.EmailConfigration ec
    WHERE ec.name= @name;
END
GO


-- ----------------------------
-- procedure structure for spEmailQueue_Select
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[spEmailQueue_Select]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[email].[spEmailQueue_Select]
GO

CREATE PROCEDURE [email].[spEmailQueue_Select]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP 10 * FROM [email].[vEmailQueue]
END
GO


-- ----------------------------
-- procedure structure for spEmailQueue_Update
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[spEmailQueue_Update]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[email].[spEmailQueue_Update]
GO

CREATE PROCEDURE [email].[spEmailQueue_Update]
	@id int
	,@messageId nvarchar (100)
	,@sendAttemptCount int
	,@error nvarchar (255) = NULL
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @now BIGINT = utilities.DatetoEpoch(null);
	DECLARE @sentDate INT
	IF @error IS NULL
		SET @sentDate = @now

	UPDATE [email].[Email]
		SET [sentDate] = @sentDate,
			[messageId] = @messageId,
			[sendAttemptCount] = @sendAttemptCount,
			[sendError] = @error
	WHERE [id] = @id

END
GO


-- ----------------------------
-- procedure structure for spEmailQueue_Add
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[spEmailQueue_Add]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[email].[spEmailQueue_Add]
GO

CREATE PROCEDURE [email].[spEmailQueue_Add]
	@subject nvarchar (255)
	,@body nvarchar (max) = NULL
	,@inbound bit = NULL
	,@minimumSendDate bigint = NULL
	,@to_JSON nvarchar(255)
	,@replyTo nvarchar(100) = NULL
	,@inReplyTo nvarchar(100) = NULL
	,@messageId nvarchar(100) = NULL
  ,@documentId int = NULL
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @now BIGINT = utilities.DatetoEpoch(null);

	DECLARE @emailID int;
	INSERT INTO [email].[Email] (
			[subject]
			,[body]
			,[inbound]
			,[minimumSendDate]
			,[activeFrom]
		) VALUES (
			@subject
			,@body
			,ISNULL(@inbound, 0)
			,@minimumSendDate
			,@now
		)
		SET @emailId = SCOPE_IDENTITY();

 -- if attachment documentId is provided
  if(@documentId is not null)
    Insert into email.EmailAttachment(emailId, documentId) values (@emailId, @documentId);

	-- Support for multiple TO. CC and BCC can be done in same way
	DECLARE @tblEmailTo TABLE(
		[id] int IDENTITY(1,1) PRIMARY KEY,
		[emailAddress] nvarchar(255), 
		[displayName] nvarchar(255)
	)
	INSERT INTO @tblEmailTo ([emailAddress], [displayName])
	SELECT ln.[emailAddress], ln.[displayName]
	  FROM OPENJSON(@To_JSON) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[emailAddress] nvarchar(255), 
		[displayName] nvarchar(255)	
	) ln;

	DECLARE @i INT = 1
	DECLARE @totalCount int = (select count(*) from @tblEmailTo)
	DECLARE @emailAddress nvarchar(255), @displayName nvarchar(255)

	WHILE ( @i <= @totalCount)
	BEGIN
		-- check if already exist, so don't duplicate data
		SELECT @emailAddress = emailAddress, @displayName = displayName from @tblEmailTo WHERE id = @i
		DECLARE @contactToId int = (SELECT [id] FROM [email].[EmailContact] WHERE [emailAddress] = @emailAddress)
		IF (@contactToId IS NULL)
		BEGIN
			INSERT INTO [email].[EmailContact] ([emailAddress],[displayName]) VALUES (@emailAddress, @displayName)
			SET @contactToId = SCOPE_IDENTITY();
		END

		INSERT INTO [email].[EmailRecipient] ([emailId],[emailContactId],[emailRecipientTypeId]) VALUES (@emailID,@contactToId, 1)
		SET @i = @i + 1
	END

	IF @messageId IS NOT NULL or @replyTo IS NOT NULL or @inReplyTo IS NOT NULL 
		INSERT INTO [email].[EmailReply] ([emailId],[messageId],[replyTo],[inReplyTo]) VALUES (@emailID, @messageId, @replyTo, @inReplyTo);

	return @emailID

END
GO


-- ----------------------------
-- procedure structure for spEmail_AddDocumentAsAttachment
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[email].[spEmail_AddDocumentAsAttachment]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[email].[spEmail_AddDocumentAsAttachment]
GO

CREATE PROCEDURE [email].[spEmail_AddDocumentAsAttachment]
	 @documentId int
	,@emailId int
AS
BEGIN
	SET NOCOUNT ON;
  
	Insert into email.EmailAttachment(emailId, documentId) VALUES (@emailId, @documentId);

	RETURN 1;

END
GO


-- ----------------------------
-- Auto increment value for Email
-- ----------------------------
DBCC CHECKIDENT ('[email].[Email]', RESEED, 708)
GO


-- ----------------------------
-- Primary Key structure for table Email
-- ----------------------------
ALTER TABLE [email].[Email] ADD CONSTRAINT [PK__Email__3213E83FFB651483] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for EmailAttachment
-- ----------------------------
DBCC CHECKIDENT ('[email].[EmailAttachment]', RESEED, 1)
GO


-- ----------------------------
-- Primary Key structure for table EmailAttachment
-- ----------------------------
ALTER TABLE [email].[EmailAttachment] ADD CONSTRAINT [PK__EmailAtt__3213E83F2D7D85C2] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for EmailConfigration
-- ----------------------------
DBCC CHECKIDENT ('[email].[EmailConfigration]', RESEED, 1)
GO


-- ----------------------------
-- Primary Key structure for table EmailConfigration
-- ----------------------------
ALTER TABLE [email].[EmailConfigration] ADD CONSTRAINT [PK__EmailCon__3213E83F55265FFD] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for EmailContact
-- ----------------------------
DBCC CHECKIDENT ('[email].[EmailContact]', RESEED, 2)
GO


-- ----------------------------
-- Primary Key structure for table EmailContact
-- ----------------------------
ALTER TABLE [email].[EmailContact] ADD CONSTRAINT [PK__EmailCon__3213E83F098CBF2E] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for EmailRecipient
-- ----------------------------
DBCC CHECKIDENT ('[email].[EmailRecipient]', RESEED, 708)
GO


-- ----------------------------
-- Primary Key structure for table EmailRecipient
-- ----------------------------
ALTER TABLE [email].[EmailRecipient] ADD CONSTRAINT [PK__EmailRec__3213E83FE1FDF440] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for EmailReply
-- ----------------------------
DBCC CHECKIDENT ('[email].[EmailReply]', RESEED, 1)
GO


-- ----------------------------
-- Primary Key structure for table EmailReply
-- ----------------------------
ALTER TABLE [email].[EmailReply] ADD CONSTRAINT [PK__EmailRep__3213E83FB450573A] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

