/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Fact

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:31:37
*/


-- ----------------------------
-- Table structure for Emission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Fact].[Emission]') AND type IN ('U'))
	DROP TABLE [Fact].[Emission]
GO

CREATE TABLE [Fact].[Emission] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [emissionActivityId] int  NOT NULL,
  [entityId] int  NOT NULL,
  [entityTypeId] int  NOT NULL,
  [submissionId] int  NULL,
  [month] int  NULL,
  [year] int  NULL,
  [reportingFrequencyId] int  NULL,
  [userInput] decimal(10,2)  NULL,
  [conversionFactor] decimal(10,4)  NULL,
  [dataUnit] nvarchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NULL,
  [questionId] int DEFAULT NULL NULL
)
GO

ALTER TABLE [Fact].[Emission] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'Forms.Question.id',
'SCHEMA', N'Fact',
'TABLE', N'Emission',
'COLUMN', N'questionId'
GO


-- ----------------------------
-- procedure structure for spEmission_Save_09Jul2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Fact].[spEmission_Save_09Jul2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Fact].[spEmission_Save_09Jul2025]
GO

CREATE PROCEDURE [Fact].[spEmission_Save_09Jul2025]
	 @entityId INT
	,@entityTypeId INT
	,@submissionId INT
	,@emissionActivityId INT
	,@userInput DECIMAL(10,2)
	,@month int
	,@conversionFactor decimal(10,4)
	,@reportingFrequencyId int
	,@dataUnit nvarchar(30)
AS
BEGIN
	SET NOCOUNT ON;

	--DECLARE @emissionId int = (SELECT TOP 1 [id] FROM [Fact].[Emission] WHERE [entityId] = @entityId AND entityTypeId = @entityTypeId AND emissionActivityId = @emissionActivityId AND [month] = @month)
	--IF @emissionId IS NULL 
	--BEGIN
		INSERT INTO [Fact].[Emission] (entityId, entityTypeId, submissionId, emissionActivityId, userInput, month, conversionFactor, reportingFrequencyId, dataUnit) 
			VALUES (@entityId, @entityTypeId, @submissionId, @emissionActivityId, @userInput, @month, @conversionFactor, @reportingFrequencyId, @dataUnit); 
		--SET @emissionId = SCOPE_IDENTITY();
	--END
	--ELSE 
	--BEGIN
		-- update user input, month, conversionFactor etc?
	--END
	 
END
GO


-- ----------------------------
-- procedure structure for spEmission_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Fact].[spEmission_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Fact].[spEmission_Save]
GO

CREATE PROCEDURE [Fact].[spEmission_Save]
	 @entityId INT
	,@entityTypeId INT
	,@submissionId INT
	,@emissionActivityId INT
	,@userInput DECIMAL(10,2)
	,@month int
	,@conversionFactor decimal(10,4)
	,@reportingFrequencyId int
	,@dataUnit nvarchar(30)
  ,@questionId int = null
AS
BEGIN
	SET NOCOUNT ON;

	--DECLARE @emissionId int = (SELECT TOP 1 [id] FROM [Fact].[Emission] WHERE [entityId] = @entityId AND entityTypeId = @entityTypeId AND emissionActivityId = @emissionActivityId AND [month] = @month)
	--IF @emissionId IS NULL 
	--BEGIN
		INSERT INTO [Fact].[Emission] (entityId, entityTypeId, submissionId, questionId, emissionActivityId, userInput, month, conversionFactor, reportingFrequencyId, dataUnit) 
                  VALUES (@entityId, @entityTypeId, @submissionId, @questionId, @emissionActivityId, @userInput, @month, @conversionFactor, @reportingFrequencyId, @dataUnit); 
		--SET @emissionId = SCOPE_IDENTITY();
	--END
	--ELSE 
	--BEGIN
		-- update user input, month, conversionFactor etc?
	--END
	 
END
GO


-- ----------------------------
-- Auto increment value for Emission
-- ----------------------------
DBCC CHECKIDENT ('[Fact].[Emission]', RESEED, 14589)
GO


-- ----------------------------
-- Primary Key structure for table Emission
-- ----------------------------
ALTER TABLE [Fact].[Emission] ADD CONSTRAINT [PK__Emission__3213E83F09F1C57A] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

