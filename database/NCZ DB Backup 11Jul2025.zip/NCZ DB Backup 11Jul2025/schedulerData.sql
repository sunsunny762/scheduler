/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : scheduler

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:39:21
*/


-- ----------------------------
-- Table structure for ScheduledJob
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[ScheduledJob]') AND type IN ('U'))
	DROP TABLE [scheduler].[ScheduledJob]
GO

CREATE TABLE [scheduler].[ScheduledJob] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [scheduleFrequencyId] int  NOT NULL,
  [environmentKey] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [runOrder] int  NULL,
  [active] bit DEFAULT 1 NOT NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [storedProcedureName] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [scheduledJobTypeId] int  NULL,
  [properties] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [scheduler].[ScheduledJob] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ScheduledJob
-- ----------------------------
SET IDENTITY_INSERT [scheduler].[ScheduledJob] ON
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'1', N'2', N'prod', N'1', N'1', N'Jotform Processing', NULL, N'Mon -Fri, every 30 mins, between 8am-6pm', N'2', N'{"jotform": {"actions": [1]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'2', N'3', N'prod', N'1', N'1', N'Clickup Processing', NULL, N'Mon-Fri, every 4 hours, between 6am-6pm', N'3', N'{"clickup": {"actions": [2,3,4,7]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'3', N'5', N'prod', N'1', N'0', N'Clickup Processing - set due date', NULL, N'Mon-Fri, at 9pm', N'3', N'{"clickup": {"actions": [8]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'4', N'4', N'prod', N'1', N'1', N'Currency Rate Updates', NULL, N'Mon-Fri, at 6am ', N'4', N'{"currency": {"actions": [1]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'5', N'6', N'prod', N'1', N'1', N'People snapshot refresh', N'[DataModel].[spPeopleSnapshot_Refresh]', N'Monday at 5am', N'1', NULL)
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'6', N'1', N'nbdev', N'1', N'0', N'Local processing', NULL, NULL, N'3', N'{"clickup": {"actions": [1,2,3,4,5,6]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'7', N'7', N'vpdev', N'1', N'0', N'Local processing', NULL, NULL, N'2', N'{"jotform": {"actions": [1]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'9', N'8', N'rbdev', N'1', N'0', N'LOCAL Portal Submissions Processing', NULL, NULL, N'2', N'{"jotform": {"actions": [2]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'10', N'8', N'rbdev', N'1', N'0', N'LOCAL Clickup Processing', NULL, NULL, N'3', N'{"clickup": {"actions": [2,3,4,7]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'11', N'2', N'prod', N'2', N'1', N'Portal submissions Processing', NULL, N'Mon -Fri, every 30 mins, between 8am-6pm', N'2', N'{"jotform": {"actions": [2]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'12', N'10', N'rbdev', N'1', N'0', N'LOCAL UK Fuel price update', NULL, N'Every Tuesday 10 am', N'6', N'{"fuelprice": {"actions": [1]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'13', N'11', N'prod', N'1', N'1', N'UK Fuel price update', NULL, N'Every Tuesday 10 am', N'6', N'{"fuelprice": {"actions": [1]}}')
GO

INSERT INTO [scheduler].[ScheduledJob] ([id], [scheduleFrequencyId], [environmentKey], [runOrder], [active], [displayName], [storedProcedureName], [description], [scheduledJobTypeId], [properties]) VALUES (N'14', N'8', N'rbdev', N'1', N'1', N'LOCAL Non-Portal Submissions Processing', NULL, NULL, N'2', N'{"jotform": {"actions": [1]}}')
GO

SET IDENTITY_INSERT [scheduler].[ScheduledJob] OFF
GO


-- ----------------------------
-- Table structure for ScheduledJobType
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[ScheduledJobType]') AND type IN ('U'))
	DROP TABLE [scheduler].[ScheduledJobType]
GO

CREATE TABLE [scheduler].[ScheduledJobType] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [scheduler].[ScheduledJobType] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ScheduledJobType
-- ----------------------------
SET IDENTITY_INSERT [scheduler].[ScheduledJobType] ON
GO

INSERT INTO [scheduler].[ScheduledJobType] ([id], [name]) VALUES (N'1', N'database')
GO

INSERT INTO [scheduler].[ScheduledJobType] ([id], [name]) VALUES (N'2', N'jotform')
GO

INSERT INTO [scheduler].[ScheduledJobType] ([id], [name]) VALUES (N'3', N'clickup')
GO

INSERT INTO [scheduler].[ScheduledJobType] ([id], [name]) VALUES (N'4', N'currency')
GO

INSERT INTO [scheduler].[ScheduledJobType] ([id], [name]) VALUES (N'5', N'powerbi')
GO

INSERT INTO [scheduler].[ScheduledJobType] ([id], [name]) VALUES (N'6', N'fuelprice')
GO

SET IDENTITY_INSERT [scheduler].[ScheduledJobType] OFF
GO


-- ----------------------------
-- Table structure for ScheduleFrequency
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[ScheduleFrequency]') AND type IN ('U'))
	DROP TABLE [scheduler].[ScheduleFrequency]
GO

CREATE TABLE [scheduler].[ScheduleFrequency] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [cronDefinition] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [environmentKey] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [logActivity] bit DEFAULT 0 NULL
)
GO

ALTER TABLE [scheduler].[ScheduleFrequency] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ScheduleFrequency
-- ----------------------------
SET IDENTITY_INSERT [scheduler].[ScheduleFrequency] ON
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'1', N'Every minute jobs', N'50 12 * * *', N'Every minute jobs', N'nbdev', N'0')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'2', N'Every 30 minutes jobs - Weekdays, Working Hours', N'*/30 8-18 * * 1-5', N'Mon -Fri, every 30 minutes, between 8am-6pm', N'prod', N'1')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'3', N'Every 4 hors  jobs - Weekdays, Working Hours', N'30 6-18/4 * * 1-5', N'Mon-Fri, every 4 hours, between 6am-6pm', N'prod', N'1')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'4', N'Early Monring jobs - 6am Weekdays', N'0 6 * * 1-5', N'Mon-Fri, at 6am ', N'prod', N'1')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'5', N'Day End Jobs - 9pm weekdays', N'0 21 * * 1-5', N'Mon-Fri, at 9pm', N'prod', N'1')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'6', N'Monday Morning Jobs', N'0 5 * * 1', N'Monday at 5am', N'prod', N'1')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'7', N'Every minute jobs', N'*/1 * * * *', N'Every minute jobs', N'vpdev', N'0')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'8', N'Every 5 minute jobs', N'*/1 * * * *', N'Every 5 mins jobs', N'rbdev', N'0')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'9', N'Daily at a time', N'12 16 * * *', N'Daily at a time', N'rbdev', N'0')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'10', N'Every Tuesday', N'11 17 * * 4', N'Every Tuesday 10 am', N'rbdev', N'0')
GO

INSERT INTO [scheduler].[ScheduleFrequency] ([id], [name], [cronDefinition], [description], [environmentKey], [logActivity]) VALUES (N'11', N'Every Tuesday', N'0 10 * * 2', N'Every Tuesday 10 am', N'prod', N'1')
GO

SET IDENTITY_INSERT [scheduler].[ScheduleFrequency] OFF
GO


-- ----------------------------
-- Auto increment value for ScheduledJob
-- ----------------------------
DBCC CHECKIDENT ('[scheduler].[ScheduledJob]', RESEED, 14)
GO


-- ----------------------------
-- Indexes structure for table ScheduledJob
-- ----------------------------
CREATE NONCLUSTERED INDEX [IDX_ScheduleFrequency_scheduleFrequencyId]
ON [scheduler].[ScheduledJob] (
  [scheduleFrequencyId] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table ScheduledJob
-- ----------------------------
ALTER TABLE [scheduler].[ScheduledJob] ADD CONSTRAINT [PK__Schedule__3213E83FF8EB66CD] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for ScheduledJobType
-- ----------------------------
DBCC CHECKIDENT ('[scheduler].[ScheduledJobType]', RESEED, 6)
GO


-- ----------------------------
-- Primary Key structure for table ScheduledJobType
-- ----------------------------
ALTER TABLE [scheduler].[ScheduledJobType] ADD CONSTRAINT [PK__Schedule__3213E83F70C2464A] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for ScheduleFrequency
-- ----------------------------
DBCC CHECKIDENT ('[scheduler].[ScheduleFrequency]', RESEED, 11)
GO


-- ----------------------------
-- Primary Key structure for table ScheduleFrequency
-- ----------------------------
ALTER TABLE [scheduler].[ScheduleFrequency] ADD CONSTRAINT [PK__Schedule__3213E83F4ED75995] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

