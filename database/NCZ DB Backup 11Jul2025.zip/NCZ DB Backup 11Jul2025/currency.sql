/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : currency

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:28:36
*/


-- ----------------------------
-- Table structure for CurrencyRate
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[currency].[CurrencyRate]') AND type IN ('U'))
	DROP TABLE [currency].[CurrencyRate]
GO

CREATE TABLE [currency].[CurrencyRate] (
  [currency] nvarchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [rate] decimal(10,2)  NOT NULL,
  [updatedDate] datetime  NULL
)
GO

ALTER TABLE [currency].[CurrencyRate] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- function structure for fnAmountToUSD
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[currency].[fnAmountToUSD]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[currency].[fnAmountToUSD]
GO

CREATE FUNCTION [currency].[fnAmountToUSD] (
  @currency NVARCHAR(10),
  @amount DECIMAL(10, 2)
)
RETURNS DECIMAL(10, 2)
AS
BEGIN

  return (Select @amount/rate from currency.CurrencyRate where currency = @currency);

END
GO


-- ----------------------------
-- procedure structure for spCurrency_AddRate
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[currency].[spCurrency_AddRate]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[currency].[spCurrency_AddRate]
GO

CREATE PROCEDURE [currency].[spCurrency_AddRate]
	@currency_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @currency TABLE(
		[currency] nvarchar(100),
		[rate] decimal(10,2)
	)
	INSERT INTO @currency ([currency], [rate])
	SELECT ln.[currency], ln.[rate]
	  FROM OPENJSON(@currency_JSON) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[currency] nvarchar(100),
		[rate] decimal(10,2)
	) ln;

	MERGE [currency].[CurrencyRate] cr
		USING @currency c
	ON (c.[currency] = cr.[currency])
	WHEN MATCHED
		THEN UPDATE
			SET cr.[currency] = c.[currency],
					cr.[rate] = c.[rate],
					cr.[updatedDate] = GETDATE()
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([currency], [rate], [updatedDate])
			 VALUES (c.[currency], c.[rate], GETDATE())
	--WHEN NOT MATCHED BY SOURCE
		-- THEN do nothing
	;

	Return 1;
END
GO


-- ----------------------------
-- Primary Key structure for table CurrencyRate
-- ----------------------------
ALTER TABLE [currency].[CurrencyRate] ADD CONSTRAINT [PK__Currency__AFC4E28581341A87] PRIMARY KEY CLUSTERED ([currency])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

