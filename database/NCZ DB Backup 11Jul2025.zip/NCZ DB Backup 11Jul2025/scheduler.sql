/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : scheduler

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:36:20
*/


-- ----------------------------
-- Table structure for ScheduledJob
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[ScheduledJob]') AND type IN ('U'))
	DROP TABLE [scheduler].[ScheduledJob]
GO

CREATE TABLE [scheduler].[ScheduledJob] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [scheduleFrequencyId] int  NOT NULL,
  [environmentKey] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [runOrder] int  NULL,
  [active] bit DEFAULT 1 NOT NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [storedProcedureName] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [scheduledJobTypeId] int  NULL,
  [properties] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [scheduler].[ScheduledJob] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for ScheduledJobRunHistory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[ScheduledJobRunHistory]') AND type IN ('U'))
	DROP TABLE [scheduler].[ScheduledJobRunHistory]
GO

CREATE TABLE [scheduler].[ScheduledJobRunHistory] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [scheduledJobId] int  NOT NULL,
  [runStartDate] datetime  NULL,
  [runEndDate] datetime  NULL,
  [status] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [error] nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [scheduleFrequencyId] int  NULL,
  [statusInfo] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [scheduler].[ScheduledJobRunHistory] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for ScheduledJobType
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[ScheduledJobType]') AND type IN ('U'))
	DROP TABLE [scheduler].[ScheduledJobType]
GO

CREATE TABLE [scheduler].[ScheduledJobType] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [scheduler].[ScheduledJobType] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for ScheduleFrequency
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[ScheduleFrequency]') AND type IN ('U'))
	DROP TABLE [scheduler].[ScheduleFrequency]
GO

CREATE TABLE [scheduler].[ScheduleFrequency] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [cronDefinition] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [environmentKey] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [logActivity] bit DEFAULT 0 NULL
)
GO

ALTER TABLE [scheduler].[ScheduleFrequency] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- procedure structure for spScheduledJob_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[spScheduledJob_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[scheduler].[spScheduledJob_Save]
GO

CREATE PROCEDURE [scheduler].[spScheduledJob_Save] 
     @id int = null
    ,@scheduleFrequencyId int 
    ,@environmentKey nvarchar(100) = null
    ,@runOrder int = null
    ,@active bit 
    ,@displayName nvarchar(100) = null
    ,@storedProcedureName nvarchar(500) = null
    ,@description nvarchar(1000) = null
		,@scheduledJobTypeId int
    ,@properties nvarchar(max) = null
AS
BEGIN
	SET NOCOUNT ON;
  
	IF @id IS NOT NULL
		UPDATE [scheduler].[ScheduledJob] SET
			 scheduleFrequencyId = @scheduleFrequencyId
			,environmentKey = @environmentKey
			,runOrder = @runOrder
			,active = @active
			,displayName = @displayName
			,storedProcedureName = @storedProcedureName
			,[description] = @description
			,[scheduledJobTypeId] = @scheduledJobTypeId
			,[properties] = @properties
		 WHERE [id] = @id
	ELSE
		INSERT INTO [scheduler].[ScheduledJob] (
			scheduleFrequencyId
			,environmentKey
			,runOrder
			,active
			,displayName
			,storedProcedureName
			,[description]
			,[scheduledJobTypeId]
			,[properties]
		) VALUES (
			@scheduleFrequencyId
			,@environmentKey
			,@runOrder
			,@active
			,@displayName
			,@storedProcedureName
			,@description
			,@scheduledJobTypeId
			,@properties
		)
END
GO


-- ----------------------------
-- procedure structure for spScheduleFrequencies_Select
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[spScheduleFrequencies_Select]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[scheduler].[spScheduleFrequencies_Select]
GO

CREATE PROCEDURE [scheduler].[spScheduleFrequencies_Select]
	@environmentKey NVARCHAR(50) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	SELECT *
	  FROM [scheduler].[ScheduleFrequency]
	 WHERE [environmentKey] IS NULL
	    OR (@environmentKey IS NOT NULL AND @environmentKey = [environmentKey])
END
GO


-- ----------------------------
-- procedure structure for spScheduledJobRunHistory_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[spScheduledJobRunHistory_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[scheduler].[spScheduledJobRunHistory_Save]
GO

CREATE PROCEDURE [scheduler].[spScheduledJobRunHistory_Save]
	@scheduledJobId INT
   ,@runStartDate DATETIME
   ,@runEndDate DATETIME
   ,@status NVARCHAR(50)
   ,@error NVARCHAR(1000) = null
   ,@scheduleFrequencyId INT = null -- gives us context about how the job was run
   ,@statusInfo nvarchar(100) = null
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO scheduler.ScheduledJobRunHistory (
		[scheduledJobId],
		[runStartDate],
		[runEndDate],
		[status],
		[error],
    [scheduleFrequencyId],
    [statusInfo]
	) VALUES (
		@scheduledJobId,
		@runStartDate,
		@runEndDate,
		@status,
		@error,
    @scheduleFrequencyId,
    @statusInfo
	)
END
GO


-- ----------------------------
-- procedure structure for spScheduledJobs_Select
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[spScheduledJobs_Select]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[scheduler].[spScheduledJobs_Select]
GO

CREATE PROCEDURE [scheduler].[spScheduledJobs_Select]
	@environmentKey NVARCHAR(50) = NULL
   ,@scheduleFrequencyId int = NULL
   ,@includeInactive bit = 0
AS
BEGIN
	SET NOCOUNT ON;
	IF @scheduleFrequencyId IS NULL
		SELECT j.*
		  FROM [scheduler].[ScheduledJob] j
		 WHERE (j.[environmentKey] IS NULL OR (@environmentKey IS NOT NULL AND @environmentKey = j.[environmentKey]))
		   AND (j.active = 1 OR @includeInactive = 1)
	  ORDER BY j.runOrder
	ELSE
		SELECT j.*
		  FROM [scheduler].[ScheduledJob] j
		 WHERE j.[scheduleFrequencyId] = @scheduleFrequencyId
		   AND ((j.[environmentKey] IS NULL OR (@environmentKey IS NOT NULL AND @environmentKey = j.[environmentKey])))
		   AND (j.active = 1 OR @includeInactive = 1)
	  ORDER BY j.runOrder
END
GO


-- ----------------------------
-- procedure structure for spScheduleFrequency_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[scheduler].[spScheduleFrequency_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[scheduler].[spScheduleFrequency_Save]
GO

CREATE PROCEDURE [scheduler].[spScheduleFrequency_Save] 
     @id int = null
    ,@name nvarchar(100)
    ,@cronDefinition nvarchar(100)
    ,@description nvarchar(1000) = null
    ,@environmentKey nvarchar(100) = null
		,@logActivity bit = 0
AS
BEGIN
  SET NOCOUNT ON;
	IF @id IS NOT NULL
		UPDATE [scheduler].[ScheduleFrequency] SET
			 [name] = @name
			,[cronDefinition] = @cronDefinition
			,[description] = @description
			,[environmentKey] = @environmentKey
			,[logActivity] = @logActivity
		 WHERE [id] = @id
	ELSE
		INSERT INTO [scheduler].[ScheduleFrequency] (
			 [name]
			,[cronDefinition]
			,[description]
			,[environmentKey]
			,[logActivity]
		) VALUES (
			 @name
			,@cronDefinition
			,@description
			,@environmentKey
			,@logActivity
		)
END
GO


-- ----------------------------
-- Auto increment value for ScheduledJob
-- ----------------------------
DBCC CHECKIDENT ('[scheduler].[ScheduledJob]', RESEED, 14)
GO


-- ----------------------------
-- Indexes structure for table ScheduledJob
-- ----------------------------
CREATE NONCLUSTERED INDEX [IDX_ScheduleFrequency_scheduleFrequencyId]
ON [scheduler].[ScheduledJob] (
  [scheduleFrequencyId] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table ScheduledJob
-- ----------------------------
ALTER TABLE [scheduler].[ScheduledJob] ADD CONSTRAINT [PK__Schedule__3213E83FF8EB66CD] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for ScheduledJobRunHistory
-- ----------------------------
DBCC CHECKIDENT ('[scheduler].[ScheduledJobRunHistory]', RESEED, 6519)
GO


-- ----------------------------
-- Indexes structure for table ScheduledJobRunHistory
-- ----------------------------
CREATE NONCLUSTERED INDEX [IDX_ScheduledJobRunHistory_scheduledJob]
ON [scheduler].[ScheduledJobRunHistory] (
  [scheduledJobId] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table ScheduledJobRunHistory
-- ----------------------------
ALTER TABLE [scheduler].[ScheduledJobRunHistory] ADD CONSTRAINT [PK__Schedule__3213E83FA55CC4AA] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for ScheduledJobType
-- ----------------------------
DBCC CHECKIDENT ('[scheduler].[ScheduledJobType]', RESEED, 6)
GO


-- ----------------------------
-- Primary Key structure for table ScheduledJobType
-- ----------------------------
ALTER TABLE [scheduler].[ScheduledJobType] ADD CONSTRAINT [PK__Schedule__3213E83F70C2464A] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for ScheduleFrequency
-- ----------------------------
DBCC CHECKIDENT ('[scheduler].[ScheduleFrequency]', RESEED, 11)
GO


-- ----------------------------
-- Primary Key structure for table ScheduleFrequency
-- ----------------------------
ALTER TABLE [scheduler].[ScheduleFrequency] ADD CONSTRAINT [PK__Schedule__3213E83F4ED75995] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

