/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Forms

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:32:12
*/


-- ----------------------------
-- Table structure for BlueAwardQuestionnaire
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[BlueAwardQuestionnaire]') AND type IN ('U'))
	DROP TABLE [Forms].[BlueAwardQuestionnaire]
GO

CREATE TABLE [Forms].[BlueAwardQuestionnaire] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [key] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [value] nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dataType] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Forms].[BlueAwardQuestionnaire] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for GoldAwardQuestionnaire
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[GoldAwardQuestionnaire]') AND type IN ('U'))
	DROP TABLE [Forms].[GoldAwardQuestionnaire]
GO

CREATE TABLE [Forms].[GoldAwardQuestionnaire] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [key] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [value] nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dataType] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Forms].[GoldAwardQuestionnaire] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for JotForm
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[JotForm]') AND type IN ('U'))
	DROP TABLE [Forms].[JotForm]
GO

CREATE TABLE [Forms].[JotForm] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [category] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [formId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Forms].[JotForm] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for JotformRawResponse
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[JotformRawResponse]') AND type IN ('U'))
	DROP TABLE [Forms].[JotformRawResponse]
GO

CREATE TABLE [Forms].[JotformRawResponse] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [formId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [data] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [processFlag] bit DEFAULT 0 NOT NULL,
  [createdDate] datetime DEFAULT getdate() NOT NULL
)
GO

ALTER TABLE [Forms].[JotformRawResponse] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for JotformSubmission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[JotformSubmission]') AND type IN ('U'))
	DROP TABLE [Forms].[JotformSubmission]
GO

CREATE TABLE [Forms].[JotformSubmission] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [submissionDate] datetime DEFAULT getdate() NOT NULL,
  [managementBasedDecision] bit  NULL,
  [optedIn] bit  NULL,
  [createdDate] datetime DEFAULT getdate() NULL
)
GO

ALTER TABLE [Forms].[JotformSubmission] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for NczForm
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[NczForm]') AND type IN ('U'))
	DROP TABLE [Forms].[NczForm]
GO

CREATE TABLE [Forms].[NczForm] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [category] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Forms].[NczForm] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Question
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[Question]') AND type IN ('U'))
	DROP TABLE [Forms].[Question]
GO

CREATE TABLE [Forms].[Question] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [reference] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [displayText] nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [questionTypeId] int  NULL,
  [inputTypeId] int  NULL,
  [formId] int  NOT NULL,
  [dataType] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [properties] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Forms].[Question] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for QuestionEmissionActivity
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[QuestionEmissionActivity]') AND type IN ('U'))
	DROP TABLE [Forms].[QuestionEmissionActivity]
GO

CREATE TABLE [Forms].[QuestionEmissionActivity] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [questionId] int  NOT NULL,
  [emissionActivityId] int  NULL,
  [rowNo] int  NULL,
  [columnNo] int  NULL
)
GO

ALTER TABLE [Forms].[QuestionEmissionActivity] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Response
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[Response]') AND type IN ('U'))
	DROP TABLE [Forms].[Response]
GO

CREATE TABLE [Forms].[Response] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] int  NOT NULL,
  [questionId] int  NOT NULL,
  [value] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Forms].[Response] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- View structure for vFormQuestions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[vFormQuestions]') AND type IN ('V'))
	DROP VIEW [Forms].[vFormQuestions]
GO

CREATE VIEW [Forms].[vFormQuestions] AS SELECT f.id as formId
			,f.name as formName
			,qp.questionId
			,q.reference
			,q.displayText
			,q.questionTypeId
      ,q.properties
			,qt.name as questionType
			,ea.id as emissionActivityId
			,ea.name as emiissionActivity, ea.Unit
			,qp.rowNo
			,qp.columnNo
FROM Forms.QuestionEmissionActivity qp
INNER JOIN Forms.Question q on q.id = qp.questionId
INNER JOIN Emissions.EmissionActivity ea on ea.id = qp.emissionActivityId
INNER JOIN Dimension.Form f on f.id = q.formId
LEFT JOIN Lookups.QuestionType qt on qt.id = q.questionTypeId
GO


-- ----------------------------
-- View structure for vFormRawResponse
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[vFormRawResponse]') AND type IN ('V'))
	DROP VIEW [Forms].[vFormRawResponse]
GO

CREATE VIEW [Forms].[vFormRawResponse] AS SELECT f.name as [formName], r.formId, r.id, r.submissionId, r.processFlag, r.createdDate
FROM Forms.JotformRawResponse r
INNER JOIN Forms.JotForm f on f.formId = r.formId
GO


-- ----------------------------
-- View structure for vJotformSubmissionMapping
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[vJotformSubmissionMapping]') AND type IN ('V'))
	DROP VIEW [Forms].[vJotformSubmissionMapping]
GO

CREATE VIEW [Forms].[vJotformSubmissionMapping] AS Select js.submissionId as jotformSubmissionId, S.id as genericSubmissionId, S.* 
from Forms.JotformSubmission as js INNER JOIN Dimension.Submission as S on (S.sourceId = js.id and S.dataSourceId=1)
GO


-- ----------------------------
-- procedure structure for spFormResponse_MarkProcessed
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spFormResponse_MarkProcessed]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spFormResponse_MarkProcessed]
GO

CREATE PROCEDURE [Forms].[spFormResponse_MarkProcessed]
	@id int
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @submissionId NVARCHAR(25), @jotformId NVARCHAR(25);

    SELECT 
      @submissionId = submissionId,
      @jotformId = formId
    FROM forms.JotformRawResponse
    WHERE id = @id;
  
   UPDATE [Forms].[JotformRawResponse] 
		 SET [processFlag] = 1
	 WHERE [id] = @id;  
   
   Update portal.CertFormSubmissions
    set isProcessed = 1
   Where submissionId = @submissionId;
   
   if(@jotformId='241290444812856') -- Company profile form then should go for update, it may be Blue Award
    begin
       Update portal.BlueAwardSubmissions
        set isProcessed = 1
       Where submissionId = @submissionId;
    end
   
END
GO


-- ----------------------------
-- procedure structure for spFormResponse_SelectToProcess_Portal_09May2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spFormResponse_SelectToProcess_Portal_09May2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spFormResponse_SelectToProcess_Portal_09May2025]
GO

CREATE PROCEDURE [Forms].[spFormResponse_SelectToProcess_Portal_09May2025]
	@max int = 500,
	@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP (@max)
						jr.id as [id]
						,f.id as [formId]
						,f.name as [formName]
						, 5 as entityTypeId --,f.[entityTypeId] -- Portal Customer
						,f.[categoryId]
						,jr.[submissionId]
            ,jr.[formId] as jotFormId
						,jr.[data]
            ,cert.progId, cert.certId, c.companyId, cert.clickupTaskId as certTaskId, c.companyName
	FROM [Forms].[JotformRawResponse] jr
	INNER JOIN [Forms].[JotForm] jf on jf.[formId] = jr.[formId]
	INNER JOIN [Dimension].[Form] f on f.[sourceId] = jf.[id] AND f.[dataSourceId] = @dataSourceId
  INNER JOIN [portal].[CertFormSubmissions] cfs ON cfs.submissionId = jr.submissionId
  INNER JOIN portal.Certification as cert on (cert.certId = cfs.certId)
  INNER JOIN portal.Company as c on (c.companyId = cert.companyId)
	WHERE jr.[processFlag] = 0 AND f.[active] = 1
       and createdDate >= DATEADD(DAY, -7, GETDATE()); -- For LIVE DB
END
GO


-- ----------------------------
-- procedure structure for spForm_SelectByExternalId
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForm_SelectByExternalId]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForm_SelectByExternalId]
GO

CREATE PROCEDURE [Forms].[spForm_SelectByExternalId]
	@formId nvarchar(50)
	,@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	IF @dataSourceId = 1 --Jotform
	BEGIN
			SELECT * 
				FROM [Forms].[JotForm]
			 WHERE [formId] = @formId AND active=1; 
	END
END
GO


-- ----------------------------
-- procedure structure for spForms_AddBlueAward
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForms_AddBlueAward]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForms_AddBlueAward]
GO

CREATE PROCEDURE [Forms].[spForms_AddBlueAward]
	@blueAwards_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @blueAwards TABLE(
		[id] uniqueidentifier,
		[submissionId] nvarchar(50),
		[key] nvarchar(250),
		[value] nvarchar(500),
		[dataType] nvarchar(250)
	)
	INSERT INTO @blueAwards ([submissionId],[key],[value],[dataType])
		SELECT [submissionId] = B.[submissionId],
		   [key] = B.[key],
		   [value] = B.[value],
		   [dataType] = B.[dataType]
		FROM OPENJSON(@blueAwards_JSON) A
		CROSS APPLY OPENJSON(A.value) 
		WITH
		(
			[submissionId] nvarchar(50),
			[key] nvarchar(250),
			[value] nvarchar(500),
			[dataType] nvarchar(250)
		) B;

	MERGE [Forms].[BlueAwardQuestionnaire] cc
		USING @blueAwards c
	ON (cc.[submissionId] = c.[submissionId] and c.[key] = cc.[key])
	WHEN MATCHED
		THEN UPDATE
			SET cc.[value] = c.[value],
				cc.[dataType] = c.[dataType]
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([submissionId],[key],[value],[dataType])
			 VALUES (c.[submissionId], c.[key], c.[value],  c.[dataType]);
	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spFormResponse_MarkProcessed_09May2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spFormResponse_MarkProcessed_09May2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spFormResponse_MarkProcessed_09May2025]
GO

CREATE PROCEDURE [Forms].[spFormResponse_MarkProcessed_09May2025]
	@id int
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE [Forms].[JotformRawResponse] 
		 SET [processFlag] = 1
	 WHERE [id] = @id;  
END
GO


-- ----------------------------
-- procedure structure for spFormResponse_SelectToProcess_Portal_Local
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spFormResponse_SelectToProcess_Portal_Local]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spFormResponse_SelectToProcess_Portal_Local]
GO

CREATE PROCEDURE [Forms].[spFormResponse_SelectToProcess_Portal_Local]
	@max int = 500,
	@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP (@max)
						jr.id as [id]
						,f.id as [formId]
						,f.name as [formName]
						, 5 as entityTypeId --,f.[entityTypeId] -- Portal Customer
						,f.[categoryId]
						,jr.[submissionId]
            ,jr.[formId] as jotFormId
						,jr.[data]
            ,cert.progId, cert.certId, c.companyId, cert.clickupTaskId as certTaskId, c.companyName,
            cntr.countryName as country, cntr.currency as currency
	FROM [Forms].[JotformRawResponse] jr
	INNER JOIN [Forms].[JotForm] jf on jf.[formId] = jr.[formId]
	INNER JOIN [Dimension].[Form] f on f.[sourceId] = jf.[id] AND f.[dataSourceId] = @dataSourceId
  INNER JOIN [portal].[CertFormSubmissions] cfs ON cfs.submissionId = jr.submissionId
  INNER JOIN portal.Certification as cert on (cert.certId = cfs.certId)
  INNER JOIN portal.Company as c on (c.companyId = cert.companyId)
  INNER JOIN Lookups.Countries as cntr on (c.countryId = cntr.countryId)
	WHERE jr.submissionId in (6264813670812174796);
  /*(6264809180814289831, 6264809760816479212, 6264810400815472383, 6264811730819079312, 6264813670812174796, 6264817060812033994, 6264817610812381099, 6264818190813506621, 6264818880819554238, 6264819470818155106, 6264820830811754274, 6264823840812989433, 6264835830811236722, 6264848670814445032, 6264849710813741588, 6264853310812303949);*/ --6262060353609154181);
                            -- 6262037193603587303);
                            -- 6261366827415905463, 6260573832219223226, 6260602862219136613) --,
                            --6260505202216845269,
                            --6258869637535939907,
                            --6259627322363709177,
                            --6259630762368417260,
                            --6259631672364246235,
                            --6259632772363730664) --(6256227804425962028) --(6254307567613906627)
END
GO


-- ----------------------------
-- procedure structure for spForm_SaveSubmission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForm_SaveSubmission]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForm_SaveSubmission]
GO

CREATE PROCEDURE [Forms].[spForm_SaveSubmission]
	 @extSubmissionId nvarchar(25)
	,@entityId INT
	,@entityTYpeId int
	,@formID int
	,@managementBasedDecision bit
	,@optedIn bit
	,@submissionDate bigint = null
	,@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @sourceId int;
	IF @dataSourceId = 1
	BEGIN
		SET @sourceId = (SELECT TOP 1 [id] FROM [Forms].[JotformSubmission] WHERE [submissionId] = @extSubmissionId)
		IF @sourceId IS NULL 
		BEGIN
			DECLARE @sDate datetime = Utilities.EpochToDate(@submissionDate);
			INSERT INTO [Forms].[JotformSubmission] ([submissionId], [submissionDate], [managementBasedDecision], [optedIn]) VALUES (@extSubmissionId, @sDate, @managementBasedDecision, @optedIn);
			SET @sourceId = SCOPE_IDENTITY();
		END
	END

	-- Update Dimension.Submission TODO Create Refresh Proc for this.
	DECLARE @submissionId int = (SELECT TOP 1 [id] FROM [Dimension].[Submission] WHERE [sourceId] = @sourceId AND [dataSourceId] = @dataSourceId)
	IF @submissionId IS NULL 
	BEGIN
		INSERT INTO [Dimension].[Submission] (entityId, entityTypeId, formId, sourceId, dataSourceId) 
			VALUES (@entityId, @entityTYpeId, @formID, @sourceId, @dataSourceId);
		SET @submissionId = SCOPE_IDENTITY();
	END
	ELSE
	BEGIN
		-- Soft delete all old emission activities for current submission
		UPDATE [Fact].[Emission] SET [active]=0 WHERE [submissionId] = @submissionId;
	END
	
	SELECT * FROM [Dimension].[Submission] WHERE [id] = @submissionId;
	 
END
GO


-- ----------------------------
-- procedure structure for XspFormResponse_SelectToProcess
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[XspFormResponse_SelectToProcess]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[XspFormResponse_SelectToProcess]
GO

CREATE PROCEDURE [Forms].[XspFormResponse_SelectToProcess]
	@max int = 500,
	@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
			SELECT TOP (@max)
						jr.id as [id]
						,f.id as [formId]
						,f.name as [formName]
						,f.[entityTypeId]
						,f.[categoryId]
						,jr.[submissionId]
            ,jr.[formId] as jotFormId
						,jr.[data]
				FROM [Forms].[JotformRawResponse] jr
	INNER JOIN [Forms].[JotForm] jf on jf.[formId] = jr.[formId]
	INNER JOIN [Dimension].[Form] f on f.[sourceId] = jf.[id] AND f.[dataSourceId] = @dataSourceId
			 WHERE jr.[processFlag] = 0 AND f.[active] = 1
       and createdDate >= DATEADD(DAY, -7, GETDATE()) -- For LIVE DB
       -- and createdDate >= '2024-09-01'
        -- and submissionId in ('6071464081128528094', '6071442523522301702')
       -- and jr.id>=5696 -- RAM
				--AND jr.id in (2667,2668,2669,2670)
				--AND f.id = 1
				-- AND jr.id in (5602,5603,5604,5618,5619,5610,5611,5609,5620,5621,5614) --and f.id < 11
END
GO


-- ----------------------------
-- procedure structure for spFormResponse_SelectToProcess_Portal_13Jun2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spFormResponse_SelectToProcess_Portal_13Jun2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spFormResponse_SelectToProcess_Portal_13Jun2025]
GO

CREATE PROCEDURE [Forms].[spFormResponse_SelectToProcess_Portal_13Jun2025]
	@max int = 500,
	@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP (@max)
						jr.id as [id]
						,f.id as [formId]
						,f.name as [formName]
						, 5 as entityTypeId --,f.[entityTypeId] -- Portal Customer
						,f.[categoryId]
						,jr.[submissionId]
            ,jr.[formId] as jotFormId
						,jr.[data]
            ,cert.progId, cert.certId, c.companyId, cert.clickupTaskId as certTaskId, c.companyName
	FROM [Forms].[JotformRawResponse] jr
	INNER JOIN [Forms].[JotForm] jf on jf.[formId] = jr.[formId]
	INNER JOIN [Dimension].[Form] f on f.[sourceId] = jf.[id] AND f.[dataSourceId] = @dataSourceId
  INNER JOIN [portal].[CertFormSubmissions] cfs ON cfs.submissionId = jr.submissionId
  INNER JOIN portal.Certification as cert on (cert.certId = cfs.certId)
  INNER JOIN portal.Company as c on (c.companyId = cert.companyId)
	WHERE cfs.isProcessed = 0 AND f.[active] = 1 And cfs.submissionId is not NULL
       and createdDate >= DATEADD(DAY, -7, GETDATE()); -- For LIVE DB
END
GO


-- ----------------------------
-- procedure structure for spForm_SaveRawResponse_02Apr2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForm_SaveRawResponse_02Apr2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForm_SaveRawResponse_02Apr2025]
GO

CREATE PROCEDURE [Forms].[spForm_SaveRawResponse_02Apr2025]
	@formID nvarchar(25)
	,@submissionID nvarchar(25)
	,@data nvarchar(max)
	,@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	IF @dataSourceId = 1 
	BEGIN
		INSERT INTO [Forms].[JotformRawResponse] (formId, SubmissionId, data) 
			VALUES (@formID, @submissionID, @data);
	END
END
GO


-- ----------------------------
-- procedure structure for spForm_SelectQuestions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForm_SelectQuestions]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForm_SelectQuestions]
GO

CREATE PROCEDURE [Forms].[spForm_SelectQuestions]
	@formId int
AS
BEGIN
	SET NOCOUNT ON;

		SELECT q.*, emissions.entries as [emissionActivities]
			FROM [Forms].[Question] q
			OUTER APPLY (
				 SELECT emissionActivityId, rowNo, columnNo 
					FROM [Forms].[QuestionEmissionActivity] 
					WHERE [questionId] = q.[id] 
					FOR JSON PATH 
			) emissions(entries)
		WHERE formId = @formId AND active = 1;
END
GO


-- ----------------------------
-- procedure structure for spForms_SelectBlueAwardSubmissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForms_SelectBlueAwardSubmissions]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForms_SelectBlueAwardSubmissions]
GO

CREATE PROCEDURE [Forms].[spForms_SelectBlueAwardSubmissions]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT [submissionId] as [SubmissionId]
	FROM [Forms].[JotformRawResponse] 
	WHERE [formId] = '241290444812856'
	
END
GO


-- ----------------------------
-- procedure structure for spForm_SaveResponseData
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForm_SaveResponseData]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForm_SaveResponseData]
GO

CREATE PROCEDURE [Forms].[spForm_SaveResponseData]
	@submissionId int,
	@responseData nvarchar(max),
	@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @data TABLE([questionId] int, [value] nvarchar(max), [submissionId] int) 
	INSERT INTO @data ([questionId], [value], [submissionId])
	SELECT *, @submissionId FROM OPENJSON(@responseData) WITH ([questionId] int '$.questionId', [value] nvarchar(max) '$.value')

	MERGE [Forms].[Response] r
	USING @data d
	ON (d.[submissionId] = r.[submissionId] AND d.[questionId] = r.[questionId])
	WHEN MATCHED
		THEN UPDATE
			SET r.[value] = d.[value]
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([questionId], [value], [submissionId])
			 VALUES (d.[questionId], d.[value], d.[submissionId])
	WHEN NOT MATCHED BY SOURCE AND r.[submissionId] = @submissionId
		THEN DELETE
	;
END
GO


-- ----------------------------
-- procedure structure for spForm_SaveRawResponse
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForm_SaveRawResponse]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForm_SaveRawResponse]
GO

CREATE PROCEDURE [Forms].[spForm_SaveRawResponse]
	@formID nvarchar(25)
	,@submissionID nvarchar(25)
	,@data nvarchar(max)
	,@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	IF @dataSourceId = 1 
	BEGIN
		INSERT INTO [Forms].[JotformRawResponse] (formId, SubmissionId, data) 
			VALUES (@formID, @submissionID, @data);
    
    if(@formID = '240292243754859') -- NCZ Partner Directory form
      begin
        exec portal.spNCZDirectory_SaveSubmission @submissionID, @data;
      end
    else -- Set SubmissionID in CertFormSubmission record in portal
      begin
        exec portal.spSubmission_Completed @formID, @submissionID, @data;
      end 
	END
END
GO


-- ----------------------------
-- procedure structure for spForm_SelectAll
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForm_SelectAll]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForm_SelectAll]
GO

CREATE PROCEDURE [Forms].[spForm_SelectAll]
	@extSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	IF @extSourceId = 1 --Jotform
	BEGIN
			SELECT * 
				FROM [Forms].[JotForm]
			 WHERE active=1; 
	END
END
GO


-- ----------------------------
-- procedure structure for spFormResponse_SelectToProcess_NonPortal_Local
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spFormResponse_SelectToProcess_NonPortal_Local]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spFormResponse_SelectToProcess_NonPortal_Local]
GO

CREATE PROCEDURE [Forms].[spFormResponse_SelectToProcess_NonPortal_Local]
	@max int = 1000,
	@dataSourceId int = 1
AS
BEGIN
  -- ******** TO PROCESS FROM LOCAL ONLY **************
	SET NOCOUNT ON;
  
   SELECT TOP (@max)
						jr.id as [id]
						,f.id as [formId]
						,f.name as [formName]
						,f.[entityTypeId]
						,f.[categoryId]
						,jr.[submissionId]
            ,jr.[formId] as jotFormId
						,jr.[data]
    FROM [Forms].[JotformRawResponse] jr
    INNER JOIN [Forms].[JotForm] jf on jf.[formId] = jr.[formId]
    INNER JOIN [Dimension].[Form] f on f.[sourceId] = jf.[id] AND f.[dataSourceId] = @dataSourceId
    where jr.submissionId in (6276944568226514626) -- jr.processFlag=0 and jr.createdDate >= '2025-01-01' and jf.formId='232102389529457'
    ORDER BY CreatedDate;
  
  /*
    SELECT TOP (@max)
						jr.id as [id]
						,f.id as [formId]
						,f.name as [formName]
						,f.[entityTypeId]
						,f.[categoryId]
						,jr.[submissionId]
						,jr.[data]
    FROM [Forms].[JotformRawResponse] jr
    INNER JOIN [Forms].[JotForm] jf on jf.[formId] = jr.[formId]
    INNER JOIN [Dimension].[Form] f on f.[sourceId] = jf.[id] AND f.[dataSourceId] = @dataSourceId
    LEFT JOIN clickup.CustomField as CF on (JR.submissionId=CF.[value] and CF.name='submissionId')
    where jr.formId!='232102389529457' and jr.processFlag=1 and CF.[value] is null and jr.createdDate >= '2024-12-01'
    ORDER BY CreatedDate;
  
			SELECT TOP (@max)
						jr.id as [id]
						,f.id as [formId]
						,f.name as [formName]
						,f.[entityTypeId]
						,f.[categoryId]
						,jr.[submissionId]
						,jr.[data]
			FROM [Forms].[JotformRawResponse] jr
      INNER JOIN [Forms].[JotForm] jf on jf.[formId] = jr.[formId]
      INNER JOIN [Dimension].[Form] f on f.[sourceId] = jf.[id] AND f.[dataSourceId] = @dataSourceId
      WHERE jr.submissionId in (6137810413519840126, 6137829726753675759, 6137837406752195626, 6137838866753616181, 6137842746755872191)
      ORDER BY jr.createdDate; */
        -- jr.[processFlag] = 0 AND f.[active] = 1 and jf.formId='232102389529457' and jr.createdDate >= '2024-11-20'
				--AND jr.id in (2667,2668,2669,2670)
				--AND f.id = 1
				--AND jr.id > 5545 and f.id < 11
END
GO


-- ----------------------------
-- procedure structure for spForm_SaveRawResponse_03Jun2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForm_SaveRawResponse_03Jun2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForm_SaveRawResponse_03Jun2025]
GO

CREATE PROCEDURE [Forms].[spForm_SaveRawResponse_03Jun2025]
	@formID nvarchar(25)
	,@submissionID nvarchar(25)
	,@data nvarchar(max)
	,@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	IF @dataSourceId = 1 
	BEGIN
		INSERT INTO [Forms].[JotformRawResponse] (formId, SubmissionId, data) 
			VALUES (@formID, @submissionID, @data);
    
    -- Set SubmissionID in CertFormSubmission record in portal
    exec portal.spSubmission_Completed @formID, @submissionID, @data;
	END
END
GO


-- ----------------------------
-- procedure structure for spForms_AddGoldAward
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spForms_AddGoldAward]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spForms_AddGoldAward]
GO

CREATE PROCEDURE [Forms].[spForms_AddGoldAward]
	@goldAwards_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @goldAwards TABLE(
		[id] uniqueidentifier,
		[submissionId] nvarchar(50),
		[key] nvarchar(250),
		[value] nvarchar(500),
		[dataType] nvarchar(250)
	)
	INSERT INTO @goldAwards ([submissionId],[key],[value],[dataType])
		SELECT [submissionId] = B.[submissionId],
		   [key] = B.[key],
		   [value] = B.[value],
		   [dataType] = B.[dataType]
		FROM OPENJSON(@goldAwards_JSON) A
		CROSS APPLY OPENJSON(A.value) 
		WITH
		(
			[submissionId] nvarchar(50),
			[key] nvarchar(250),
			[value] nvarchar(500),
			[dataType] nvarchar(250)
		) B;

	MERGE [Forms].[GoldAwardQuestionnaire] cc
		USING @goldAwards c
	ON (cc.[submissionId] = c.[submissionId] and c.[key] = cc.[key])
	WHEN MATCHED
		THEN UPDATE
			SET cc.[value] = c.[value],
				cc.[dataType] = c.[dataType]
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([submissionId],[key],[value],[dataType])
			 VALUES (c.[submissionId], c.[key], c.[value],  c.[dataType]);
	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spFormResponse_SelectToProcess_NonPortal
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spFormResponse_SelectToProcess_NonPortal]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spFormResponse_SelectToProcess_NonPortal]
GO

CREATE PROCEDURE [Forms].[spFormResponse_SelectToProcess_NonPortal]
	@max int = 500,
	@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP (@max)
						jr.id as [id]
						,f.id as [formId]
						,f.name as [formName]
						,f.[entityTypeId]
						,f.[categoryId]
						,jr.[submissionId]
            ,jr.[formId] as jotFormId
						,jr.[data]
	FROM [Forms].[JotformRawResponse] jr
	INNER JOIN [Forms].[JotForm] jf on jf.[formId] = jr.[formId]
	INNER JOIN [Dimension].[Form] f on f.[sourceId] = jf.[id] AND f.[dataSourceId] = @dataSourceId
  LEFT JOIN [portal].[CertFormSubmissions] cfs ON cfs.submissionId = jr.submissionId
	WHERE jr.[processFlag] = 0 AND f.[active] = 1
       and cfs.submissionId IS NULL
       and createdDate >= DATEADD(DAY, -7, GETDATE()) -- For LIVE DB
       -- and createdDate >= '2024-09-01'
        -- and submissionId in ('6071464081128528094', '6071442523522301702')
       -- and jr.id>=5696 -- RAM
				--AND jr.id in (2667,2668,2669,2670)
				--AND f.id = 1
				-- AND jr.id in (5602,5603,5604,5618,5619,5610,5611,5609,5620,5621,5614) --and f.id < 11
END
GO


-- ----------------------------
-- procedure structure for spFormResponse_SelectToProcess_Portal
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[spFormResponse_SelectToProcess_Portal]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Forms].[spFormResponse_SelectToProcess_Portal]
GO

CREATE PROCEDURE [Forms].[spFormResponse_SelectToProcess_Portal]
	@max int = 500,
	@dataSourceId int = 1
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP (@max)
						jr.id as [id]
						,f.id as [formId]
						,f.name as [formName]
						, 5 as entityTypeId --,f.[entityTypeId] -- Portal Customer
						,f.[categoryId]
						,jr.[submissionId]
            ,jr.[formId] as jotFormId
						,jr.[data]
            ,cert.progId, cert.certId, c.companyId, cert.clickupTaskId as certTaskId, c.companyName,
            cntr.countryName as country, cntr.currency as currency
	FROM [Forms].[JotformRawResponse] jr
	INNER JOIN [Forms].[JotForm] jf on jf.[formId] = jr.[formId]
	INNER JOIN [Dimension].[Form] f on f.[sourceId] = jf.[id] AND f.[dataSourceId] = @dataSourceId
  INNER JOIN [portal].[CertFormSubmissions] cfs ON cfs.submissionId = jr.submissionId
  INNER JOIN portal.Certification as cert on (cert.certId = cfs.certId)
  INNER JOIN portal.Company as c on (c.companyId = cert.companyId)
  INNER JOIN Lookups.Countries as cntr on (c.countryId = cntr.countryId)
	WHERE cfs.isProcessed = 0 AND f.[active] = 1 And cfs.submissionId is not NULL
       and createdDate >= DATEADD(DAY, -7, GETDATE()); -- For LIVE DB
END
GO


-- ----------------------------
-- Auto increment value for BlueAwardQuestionnaire
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[BlueAwardQuestionnaire]', RESEED, 8362)
GO


-- ----------------------------
-- Primary Key structure for table BlueAwardQuestionnaire
-- ----------------------------
ALTER TABLE [Forms].[BlueAwardQuestionnaire] ADD CONSTRAINT [PK__BlueAwar__3213E83F656A430F] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for GoldAwardQuestionnaire
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[GoldAwardQuestionnaire]', RESEED, 1678)
GO


-- ----------------------------
-- Primary Key structure for table GoldAwardQuestionnaire
-- ----------------------------
ALTER TABLE [Forms].[GoldAwardQuestionnaire] ADD CONSTRAINT [PK__GoldAwar__3213E83F33A016B9] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for JotForm
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[JotForm]', RESEED, 16)
GO


-- ----------------------------
-- Primary Key structure for table JotForm
-- ----------------------------
ALTER TABLE [Forms].[JotForm] ADD CONSTRAINT [PK__NczForm___3213E83F63FAB3B4] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for JotformRawResponse
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[JotformRawResponse]', RESEED, 13116)
GO


-- ----------------------------
-- Primary Key structure for table JotformRawResponse
-- ----------------------------
ALTER TABLE [Forms].[JotformRawResponse] ADD CONSTRAINT [PK__JotformR__3213E83FEB1C18D9] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for JotformSubmission
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[JotformSubmission]', RESEED, 6623)
GO


-- ----------------------------
-- Primary Key structure for table JotformSubmission
-- ----------------------------
ALTER TABLE [Forms].[JotformSubmission] ADD CONSTRAINT [PK__Submissi__3213E83F2D059005] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for NczForm
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[NczForm]', RESEED, 1)
GO


-- ----------------------------
-- Primary Key structure for table NczForm
-- ----------------------------
ALTER TABLE [Forms].[NczForm] ADD CONSTRAINT [PK__NczForm__3213E83FD60B8860] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Question
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[Question]', RESEED, 492)
GO


-- ----------------------------
-- Primary Key structure for table Question
-- ----------------------------
ALTER TABLE [Forms].[Question] ADD CONSTRAINT [PK__Question__3213E83F97FB3CBA] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for QuestionEmissionActivity
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[QuestionEmissionActivity]', RESEED, 1477)
GO


-- ----------------------------
-- Primary Key structure for table QuestionEmissionActivity
-- ----------------------------
ALTER TABLE [Forms].[QuestionEmissionActivity] ADD CONSTRAINT [PK__Question__3213E83FC7C1EF24] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Response
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[Response]', RESEED, 248688)
GO


-- ----------------------------
-- Primary Key structure for table Response
-- ----------------------------
ALTER TABLE [Forms].[Response] ADD CONSTRAINT [PK__Response__3213E83F7EA76B37] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

