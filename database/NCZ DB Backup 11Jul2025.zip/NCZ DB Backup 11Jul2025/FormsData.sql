/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Forms

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:33:11
*/


-- ----------------------------
-- Table structure for JotForm
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[JotForm]') AND type IN ('U'))
	DROP TABLE [Forms].[JotForm]
GO

CREATE TABLE [Forms].[JotForm] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [category] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [formId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Forms].[JotForm] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of JotForm
-- ----------------------------
SET IDENTITY_INSERT [Forms].[JotForm] ON
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'1', N'Water v1.0', N'', N'Certifications', N'231921316591454', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'2', N'Electricity v1.0', N'', N'Certifications', N'231835207128453', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'3', N'Natural Gas v1.0', N'', N'Certifications', N'231761029921959', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'4', N'Refrigerents v1.0', NULL, N'Certifications', N'231953063487462', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'5', N'Company Vehicles', NULL, N'Certifications', N'232571467469467', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'6', N'ME Carbon Footprint Impact Survey', NULL, N'Events', N'233020948970862', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'7', N'Business Travel', NULL, N'Certifications', N'231702222306037', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'8', N'Waste and Recycling', NULL, N'Certifications', N'231998306100453', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'9', N'Purchased Goods and Services', NULL, N'Certifications', N'232013593953456', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'10', N'Other Fuels v1.0', NULL, N'Certifications', N'231951471518458', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'11', N'Commuting & Home Working', NULL, N'Certifications', N'232102389529457', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'12', N'Upstream deliveries', NULL, N'Certifications', N'232408584059461', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'13', N'Downstream deliveries', NULL, N'Certifications', N'232561815184457', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'14', N'NCZ Blue Award Questionnaire', NULL, N'Certifications', N'241290444812856', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'15', N'NCZ Gold Award Questionnaire', NULL, N'Certifications', N'250151633085854', N'1')
GO

INSERT INTO [Forms].[JotForm] ([id], [name], [description], [category], [formId], [active]) VALUES (N'16', N'NCZ Partner Directory onboarding', NULL, NULL, N'240292243754859', N'1')
GO

SET IDENTITY_INSERT [Forms].[JotForm] OFF
GO


-- ----------------------------
-- Table structure for Question
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[Question]') AND type IN ('U'))
	DROP TABLE [Forms].[Question]
GO

CREATE TABLE [Forms].[Question] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [reference] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [displayText] nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [questionTypeId] int  NULL,
  [inputTypeId] int  NULL,
  [formId] int  NOT NULL,
  [dataType] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [properties] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Forms].[Question] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Question
-- ----------------------------
SET IDENTITY_INSERT [Forms].[Question] ON
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'1', N'q9_customerId', N'', N'1', N'1', N'1', N'nvarchar', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'2', N'q44_haveYou', N'', NULL, N'1', N'1', N'nvarchar', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'4', N'q5_howWould', N'', NULL, N'1', N'1', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'5', N'q39_whichUnit', N'', N'9', N'1', N'1', N'nvarchar', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'6', N'q4_typeA', N'', N'5', N'6', N'1', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'7', N'q6_typeA6', N'', N'6', N'6', N'1', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'8', N'q45_typeA45', N'', N'7', N'5', N'1', N'string', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'9', N'q46_typeA46', N'', N'4', N'6', N'1', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'11', N'q27_doYou', N'', NULL, NULL, N'1', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'12', N'q58_reportingFrequency', N'', N'2', NULL, N'1', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'13', N'q59_optinPreference', N'', N'3', NULL, N'1', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'14', N'q60_managementBasedDecision', N'', N'8', NULL, N'1', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'15', N'q57_conversionFactor', N'', N'10', NULL, N'1', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'18', N'q9_customerId', N'', N'1', NULL, N'2', N'nvarchar', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'19', N'q40_haveYou', N'', NULL, N'1', N'2', N'nvarchar', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'20', N'q19_howWould19', N'', NULL, N'1', N'2', N'nvarchar', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'21', N'q41_typeA41', N'', N'7', N'1', N'2', N'string', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'22', N'q42_typeA42', N'', N'4', NULL, N'2', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'23', N'q4_typeA', N'', N'5', N'1', N'2', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'24', N'q6_typeA6', N'', N'6', N'1', N'2', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'25', N'q24_areThere', N'', NULL, N'1', N'2', N'nvarchar', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'26', N'q5_howWould', N'', NULL, NULL, N'2', N'nvarchar', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'27', N'q52_reportingFrequency', N'', N'2', NULL, N'2', N'int', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'28', N'q54_optinPreference', N'', N'3', NULL, N'2', N'int', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'29', N'q51_managementBased51', N'', N'8', NULL, N'2', N'int', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'30', N'q53_conversionFactor', N'', N'10', NULL, N'2', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'31', N'q55_typeA55', N'', N'9', NULL, N'2', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'32', N'q9_customerId', N'', N'1', NULL, N'3', N'nvarchar', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'33', N'q71_haveYou', N'', NULL, NULL, N'3', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'34', N'q28_howWould', N'', NULL, NULL, N'3', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'35', N'q45_wouldYou', N'', NULL, NULL, N'3', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'36', N'q44_monthlyUsage', N'', N'5', N'0', N'3', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'37', N'q46_annualisedUsage', N'', N'6', N'0', N'3', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'38', N'q67_selectMonth', N'', N'7', N'0', N'3', N'string', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'39', N'q66_monthly', N'', N'4', N'0', N'3', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'40', N'q83_reportingFrequency', N'', N'2', NULL, N'3', N'int', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'41', N'q85_optinPreference', N'', N'3', NULL, N'3', N'int', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'42', N'q82_managementBased82', N'', N'8', NULL, N'3', N'int', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'43', N'q84_conversionFactor', N'', N'10', NULL, N'3', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'48', N'q9_customerId', NULL, N'1', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'49', N'q457_haveYou', NULL, NULL, NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'50', N'q458_howWould', NULL, NULL, NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'51', N'q496_typeA496', NULL, N'2', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'52', N'q54_typeA54', N'Kyto Protocol - Monthly', N'4', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'53', N'q461_selectA', NULL, N'7', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'54', N'q462_annualiseEnter', N'Kyto Protocol - Annaul', N'6', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'55', N'q463_enterThe463', N'Kyto Protocol - Jan to Jun', N'11', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'56', N'q464_enterThe464', N'Kyto Protocol - Jul to Dec', N'12', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'57', N'q112_enterThe112', N'Blend - Monthly', N'4', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'58', N'q467_enterThe467', N'Blend - Annual', N'6', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'59', N'q468_enterThe468', N'Blend - Jan to Jun', N'11', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'60', N'q469_enterThe469', N'Blend - Jul to Dec', N'12', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'61', N'q361_typeA', N'Montreal protocol - Monthly', N'4', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'62', N'q470_enterThe470', N'Montreal protocol - Annually', N'6', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'63', N'q471_annualisemonthly471', N'Montreal protocol - Jan to Jun', N'11', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'64', N'q472_annualisemonthly472', N'Montreal protocol - Jul to Dec', N'12', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'65', N'q407_typeA407', N'Fluorinated ethers - Monthly', N'4', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'66', N'q473_enterThe', N'Fluorinated ethers - Annually', N'6', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'67', N'q474_enterThe474', N'Fluorinated ethers - Jan to Jun', N'11', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'68', N'q475_enterThe475', N'Fluorinated ethers - Jul to Dec', N'12', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'69', N'q439_typeA439', N'Other products - Monthly', N'4', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'70', N'q478_enterThe478', N'Other products - Annually', N'6', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'71', N'q479_enterThe479', N'Other products - Jan to Jun', N'11', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'72', N'q480_enterThe480', N'Other products - Jul to Dec', N'12', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'73', N'q87_dataUnit', NULL, N'9', NULL, N'3', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'74', N'q497_optinPreference', NULL, N'3', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'75', N'q500_dataUnit', NULL, N'9', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'76', N'q379_pleaseEnter', NULL, N'1', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'77', N'q470_howWould470', NULL, NULL, NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'78', N'q610_typeA610', NULL, N'2', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'79', N'q473_selectA', NULL, N'7', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'80', N'q603_conversionFactor', NULL, N'10', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'81', N'q342_whichUnit342', NULL, N'9', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'82', N'q609_typeA609', NULL, N'3', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'83', N'q85_enterMonthly', N'Passenger car petrol - Monthly', N'4', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'84', N'q484_enterAnnual', N'Passenger car petrol - Annually', N'6', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'85', N'q472_enterAnnual472', N'Passenger car petrol - AnnaulByMonths', N'5', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'86', N'q110_travelUnits110', N'Passenger car diesel - Monthly', N'4', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'87', N'q485_enterAnnual485', N'Passenger car diesel - Annually', N'6', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'88', N'q474_enterDistance474', N'Passenger car diesel - AnnaulByMonths', N'5', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'89', N'q159_enterMonthly159', N'Passenger car Hybrid - Monthly', N'4', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'90', N'q486_enterAnnual486', N'Passenger car Hybrid - Annually', N'6', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'91', N'q475_enterDistance475', N'Passenger car Hybrid - AnnaulByMonths', N'5', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'92', N'q181_enterMonthly181', N'Passenger car Electric - Monthly', N'4', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q583_ChargingPercentWorkPlace", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'93', N'q487_enterAnnual487', N'Passenger car Electric - Annually', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q583_ChargingPercentWorkPlace", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'94', N'q477_enterDistance477', N'Passenger car Electric - AnnaulByMonths', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q583_ChargingPercentWorkPlace", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'95', N'q563_enterMonthly563', N'Passenger car Hybrid Electric - Monthly', N'4', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q589_ChargingPercentWorkPlace589", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'96', N'q564_enterAnnual564', N'Passenger car Hybrid Electric - Annually', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q589_ChargingPercentWorkPlace589", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'97', N'q565_enterAnnual565', N'Passenger car Hybrid Electric - AnnaulByMonths', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q589_ChargingPercentWorkPlace589", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'98', N'q538_enterMonthly538', N'Vans Petrol Monthly', N'4', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'99', N'q539_enterAnnual539', N'Vans Petrol Annually', N'6', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'100', N'q540_enterAnnual540', N'Vans Petrol Annual By Months', N'5', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'101', N'q548_enterMonthly548', N'Vans Diesel Monthly', N'4', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'102', N'q549_enterAnnual549', N'Vans Diesel Annually', N'6', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'103', N'q550_enterAnnual550', N'Vans Diesel Annual By Months', N'5', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'105', N'q552_enterMonthly552', N'Vans Batter Electric Monthly', N'4', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q590_ChargingPercentWorkPlace590", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'106', N'q553_enterAnnual553', N'Vans Batter Electric Annually', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q590_ChargingPercentWorkPlace590", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'107', N'q554_enterAnnual554', N'Vans Batter Electric Annual By Months', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q590_ChargingPercentWorkPlace590", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'108', N'q543_enterMonthly543', N'HGVs Montly', N'4', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'109', N'q544_enterAnnual544', N'HGVs Annually', N'6', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'110', N'q545_enterAnnual545', N'HGVs Annual By Months', N'5', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'111', N'q391_enterMonthly391', N'No of litre Petrol Monthly', N'4', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q612_dataUnit", "questionTypeId": 9},{"reference": "q613_conversionFactor613", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'112', N'q489_passengerCar489', N'No of litre Petrol Annual', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q612_dataUnit", "questionTypeId": 9},{"reference": "q613_conversionFactor613", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'114', N'q480_enterDistance480', N'No of litre Petrol Annual By Months', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q612_dataUnit", "questionTypeId": 9},{"reference": "q613_conversionFactor613", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'115', N'q407_enterMonthly407', N'No of litre Diesel Monthly', N'4', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q614_dataUnit614", "questionTypeId": 9},{"reference": "q615_conversionFactor615", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'116', N'q490_enterAnnual490', N'No of litre Diesel Annual', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q614_dataUnit614", "questionTypeId": 9},{"reference": "q615_conversionFactor615", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'117', N'q481_enterDistance481', N'No of litre Diesel Annual By Months', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q614_dataUnit614", "questionTypeId": 9},{"reference": "q615_conversionFactor615", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'118', N'q414_enterMonthly414', N'Amount spent on Petrol', N'4', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q616_dataUnit616", "questionTypeId": 9},{"reference": "q617_conversionFactor617", "questionTypeId": 10}],"conversion":"AmountToLitre-Petrol"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'119', N'q491_enterPassenger491', N'Amount spent on Petrol', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q616_dataUnit616", "questionTypeId": 9},{"reference": "q617_conversionFactor617", "questionTypeId": 10}],"conversion":"AmountToLitre-Petrol"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'120', N'q482_enterDistance482', N'Amount spent on Petrol', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q616_dataUnit616", "questionTypeId": 9},{"reference": "q617_conversionFactor617", "questionTypeId": 10}],"conversion":"AmountToLitre-Petrol"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'121', N'q529_enterMonthly529', N'Amount spent on Diesel', N'4', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q618_dataUnit618", "questionTypeId": 9},{"reference": "q619_conversionFactor619", "questionTypeId": 10}],"conversion":"AmountToLitre-Diesel"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'122', N'q530_enterAnnual530', N'Amount spent on Diesel', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q618_dataUnit618", "questionTypeId": 9},{"reference": "q619_conversionFactor619", "questionTypeId": 10}],"conversion":"AmountToLitre-Diesel"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'123', N'q531_enterAnnual531', N'Amount spent on Diesel', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q618_dataUnit618", "questionTypeId": 9},{"reference": "q619_conversionFactor619", "questionTypeId": 10}],"conversion":"AmountToLitre-Diesel"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'124', N'q534_enterMonthly534', N'Amount spent on other fuel', N'4', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'125', N'q535_enterAnnual535', N'Amount spent on other fuel', N'6', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'126', N'q536_enterAnnual536', N'Amount spent on other fuel', N'5', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'127', N'q96_eId', NULL, N'1', NULL, N'6', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'128', N'q3_yourName', N'user name', NULL, NULL, N'6', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'129', N'q4_email', N'user email', NULL, NULL, N'6', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'130', N'q10_travel', N'Travel data', N'6', NULL, N'6', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'131', N'q17_hotels', N'Hotel data', N'6', NULL, N'6', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'132', N'q112_noofemailsent', N'Emails sent', N'13', NULL, N'6', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'133', N'q113_noofpagesprinted', N'Pages printed', N'13', NULL, N'6', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'134', N'q379_pleaseEnter', N'Customer Reference', N'1', NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'135', N'q542_optinPreference', N'Optin Preference', N'3', NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'138', N'q470_howWould470', N'Reporting Frequency', NULL, NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'140', N'q541_reportingFrequency', N'Reporting Frequency Id', N'2', NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'141', N'q473_selectA', N'Select month', N'7', NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'142', N'q350_howWould350', N'Distance travelled', NULL, NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'143', N'q351_whichUnit351', N'Regular Taxi Data Unit ', N'9', NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'144', N'q130_enterMonthly130', N'Regular Taxi Monthly Input', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q351_whichUnit351", "questionTypeId": 9},{"reference": "q554_conversionFactor554", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'150', N'q341_howWould', N'How would you like to provide the information for Passenger Cars?', NULL, NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'152', N'q85_enterMonthly', N'Passenger Car Petrol - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'159', N'q484_enterAnnual', N'passenger Car Petrol - Annually', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'161', N'q472_enterAnnual472', N'Passenger Car Petrol -AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'163', N'q110_travelUnits110', N'Passenger Car - Diesel_ Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'164', N'q485_enterAnnual485', N'Passenger Car - Diesel_Annualy', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'168', N'q474_enterDistance474', N'Passenger Car - Diesel_AnnualyByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'171', N'q159_enterMonthly159', N'Passenger Car - Hybrid_Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'172', N'q486_enterAnnual486', N'Passenger Car -  Hybrid_Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'173', N'q475_enterDistance475', N'Passenger Car -Hybrid_AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'174', N'q181_enterMonthly181', N'Passenger Car - Electric_Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'175', N'q487_enterAnnual487', N'Passenger Car - Electric_Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'176', N'q477_enterDistance477', N'Passenger Car - Electric_AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'177', N'q222_enterMonthly222', N'Motorbike_Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'178', N'q488_enterAnnual488', N'Motorbike_Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'179', N'q479_enterDistance479', N'Motorbike_AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q342_whichUnit342", "questionTypeId": 9},{"reference": "q544_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'180', N'q391_enterMonthly391', N'Passenger Car - Petrol (no of litre)_Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q545_dataUnit", "questionTypeId": 9},{"reference": "q546_conversionFactor546", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'181', N'q489_passengerCar489', N'Passenger Car - Petrol (no of litre)_Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q545_dataUnit", "questionTypeId": 9},{"reference": "q546_conversionFactor546", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'182', N'q480_enterDistance480', N'Passenger Car - Petrol (no of litre)_AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q545_dataUnit", "questionTypeId": 9},{"reference": "q546_conversionFactor546", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'183', N'q407_enterMonthly407', N'Passenger Car - Diesel (no of litre) - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q547_dataUnit547", "questionTypeId": 9},{"reference": "q548_conversionfactor548", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'184', N'q490_enterAnnual490', N'Passenger Car - Diesel (no of litre) - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q547_dataUnit547", "questionTypeId": 9},{"reference": "q548_conversionfactor548", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'185', N'q481_enterDistance481', N'Passenger Car - Diesel (no of litre) - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q547_dataUnit547", "questionTypeId": 9},{"reference": "q548_conversionfactor548", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'186', N'q414_enterMonthly414', N'Passenger Car (Amount spend) - monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q549_dataUnit549", "questionTypeId": 9},{"reference": "q550_conversionfactor550", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'188', N'q491_enterPassenger491', N'Passenger Car (Amount spend) - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q549_dataUnit549", "questionTypeId": 9},{"reference": "q550_conversionfactor550", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'190', N'q482_enterDistance482', N'Passenger Car (Amount spend) - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q549_dataUnit549", "questionTypeId": 9},{"reference": "q550_conversionfactor550", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'191', N'q254_enterMonthly254', N'Train - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q347_whichUnit347", "questionTypeId": 9},{"reference": "q551_conversionFactor551", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'193', N'q492_enterAnnual492', N'Train - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q347_whichUnit347", "questionTypeId": 9},{"reference": "q551_conversionFactor551", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'194', N'q483_enterDistance483', N'Train - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q347_whichUnit347", "questionTypeId": 9},{"reference": "q551_conversionFactor551", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'197', N'q422_enterMonthly422', N'Train (Amount spend) - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q552_dataUnit552", "questionTypeId": 9},{"reference": "q553_conversionFactor553", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'198', N'q515_enterTrain515', N'Train (Amount spend) - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q552_dataUnit552", "questionTypeId": 9},{"reference": "q553_conversionFactor553", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'199', N'q493_enterDistance493', N'Train (Amount spend) - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q552_dataUnit552", "questionTypeId": 9},{"reference": "q553_conversionFactor553", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'200', N'q516_enterAnnual516', N'Taxi - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q351_whichUnit351", "questionTypeId": 9},{"reference": "q554_conversionFactor554", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'201', N'q494_enterDistance494', N'Taxi - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q351_whichUnit351", "questionTypeId": 9},{"reference": "q554_conversionFactor554", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'202', N'q430_trainUnits430', N'Taxi (Amount spend) - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q555_dataUnit555", "questionTypeId": 9},{"reference": "q556_conversionFactor556", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'203', N'q517_enterTaxi517', N'Taxi (Amount spend) - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q555_dataUnit555", "questionTypeId": 9},{"reference": "q556_conversionFactor556", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'204', N'q495_enterDistance495', N'Taxi (Amount spend) - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q555_dataUnit555", "questionTypeId": 9},{"reference": "q556_conversionFactor556", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'205', N'q139_travelUnits139', N'Local Bus - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q355_whichUnit355", "questionTypeId": 9},{"reference": "q557_conversionFactor557", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'206', N'q518_enterAnnual518', N'Local Bus - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q355_whichUnit355", "questionTypeId": 9},{"reference": "q557_conversionFactor557", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'207', N'q496_enterDistance496', N'Local Bus - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q355_whichUnit355", "questionTypeId": 9},{"reference": "q557_conversionFactor557", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'209', N'q147_travelUnits147', N'Coach Bus - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q355_whichUnit355", "questionTypeId": 9},{"reference": "q557_conversionFactor557", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'210', N'q519_enterAnnual519', N'Coach Bus - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q355_whichUnit355", "questionTypeId": 9},{"reference": "q557_conversionFactor557", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'212', N'q497_enterDistance497', N'Coach Bus - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q355_whichUnit355", "questionTypeId": 9},{"reference": "q557_conversionFactor557", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'213', N'q438_enterMonthly438', N'Bus (Amount spend) - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q558_dataUnit558", "questionTypeId": 9},{"reference": "q559_conversionFactor559", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'214', N'q520_enterAnnual520', N'Bus (Amount spend) - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q558_dataUnit558", "questionTypeId": 9},{"reference": "q559_conversionFactor559", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'215', N'q498_enterDistance498', N'Bus (Amount spend) - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q558_dataUnit558", "questionTypeId": 9},{"reference": "q559_conversionFactor559", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'216', N'q283_travelUnits283', N'Domestic Flights - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q359_whichUnit359", "questionTypeId": 9},{"reference": "q560_conversionFactor560", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'218', N'q521_enterAnnual521', N'Domestic Flights - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q359_whichUnit359", "questionTypeId": 9},{"reference": "q560_conversionFactor560", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'219', N'q499_enterDistance499', N'Domestic Flights - Annual', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q359_whichUnit359", "questionTypeId": 9},{"reference": "q560_conversionFactor560", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'220', N'q291_travelUnits291', N'Short-Haul Flights - Month', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q359_whichUnit359", "questionTypeId": 9},{"reference": "q560_conversionFactor560", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'222', N'q522_enterAnnual522', N'Short-Haul Flights - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q359_whichUnit359", "questionTypeId": 9},{"reference": "q560_conversionFactor560", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'223', N'q500_enterDistance500', N'Short-Haul Flights - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q359_whichUnit359", "questionTypeId": 9},{"reference": "q560_conversionFactor560", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'225', N'q315_travelUnits315', N'Long-Haul Flights - Month', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q359_whichUnit359", "questionTypeId": 9},{"reference": "q560_conversionFactor560", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'226', N'q523_enterAnnual523', N'Long-Haul Flights  - Annualy', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q359_whichUnit359", "questionTypeId": 9},{"reference": "q560_conversionFactor560", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'227', N'q501_enterDistance501', N'Long-Haul Flights  - AnnualyByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q359_whichUnit359", "questionTypeId": 9},{"reference": "q560_conversionFactor560", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'228', N'q446_enterMonthly446', N'Flight (Amount spend) - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q561_dataUnit561", "questionTypeId": 9},{"reference": "q562_conversionFactor562", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'229', N'q524_enterAnnual524', N'Flight (Amount spend) - Annualy', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q561_dataUnit561", "questionTypeId": 9},{"reference": "q562_conversionFactor562", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'230', N'q507_enterDistance507', N'Flight (Amount spend) - AnnualyByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q561_dataUnit561", "questionTypeId": 9},{"reference": "q562_conversionFactor562", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'231', N'q368_enterMonthly368', N'Hotel  - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q563_dataUnit563", "questionTypeId": 9},{"reference": "q564_conversionFactor564", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'232', N'q528_enterAnnual528', N'Hotel - Annual', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q563_dataUnit563", "questionTypeId": 9},{"reference": "q564_conversionFactor564", "questionTypeId": 10}]}', N'0')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'233', N'q511_enterDistance511', N'Hotel - AnnualByMonth', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q563_dataUnit563", "questionTypeId": 9},{"reference": "q564_conversionFactor564", "questionTypeId": 10}]}', N'0')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'234', N'q454_enterMonthly454', N'Hotel (Amount spend) - Monthly', N'4', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q565_dataUnit565", "questionTypeId": 9},{"reference": "q566_conversionFactor566", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'235', N'q527_enterAnnual527', N'Hotel (Amount spend) - Annualy', N'6', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q565_dataUnit565", "questionTypeId": 9},{"reference": "q566_conversionFactor566", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'236', N'q513_enterDistance513', N'Hotel (Amount spend) - AnnualyByMont', N'5', NULL, N'7', NULL, N'{"linkedQuestions": [{"reference": "q565_dataUnit565", "questionTypeId": 9},{"reference": "q566_conversionFactor566", "questionTypeId": 10}],"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'237', N'q9_customerId', NULL, N'1', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'238', N'q49_enterThe', N'Construction Waste - AnnualByMonth', N'5', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'239', N'q50_enterThe', N'Construction Waste - Annual', N'6', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'240', N'q67_monthly', N'Construction Waste - Month', N'4', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'241', N'q77_monthlyData77', N'Landfill - AnnualByMonth - JAN_JUN', N'11', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'242', N'q79_enterWaste', N'Landfill - AnnualByMonth - JUL_DEC', N'12', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'243', N'q142_reportingFrequency', NULL, N'2', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'245', N'q143_managementbaseddecision', NULL, N'8', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'246', N'q74_enterAnnual', N'Landfill - Annual', N'6', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'247', N'q76_enterData', N'Landfill - Month', N'4', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'248', N'q4_typeA', N'General Recycling - AnnualByMonth', N'5', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'249', N'q6_typeA6', N'General Recycling - Annual', N'6', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'250', N'q65_typeA65', N'General Recycling - Monthly', N'4', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'251', N'q9_customerId', NULL, N'1', NULL, N'9', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'254', N'q266_reportingFrequency', NULL, N'2', NULL, N'9', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'255', N'q325_optIn', NULL, N'3', NULL, N'9', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'256', N'q324_managementBased', NULL, N'8', NULL, N'9', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'257', N'q326_conversionFactor', NULL, N'10', NULL, N'9', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'258', N'q6_typeA6', N'Agriculture - month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'259', N'q290_enterAnnual290', N'Agriculture -Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'260', N'q271_enterAnnual271', N'Agriculture -AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'261', N'q72_typeA', N'Energy  and Extractive Industries - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'262', N'q291_enterAnnual291', N'Energy  and Extractive Industries - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'263', N'q272_enterAnnual272', N'Energy  and Extractive Industries - AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'264', N'q80_enterMonthly', N'Utilities - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'266', N'q292_enterAnnual292', N'Utilities - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'267', N'q273_enterAnnual273', N'Utilities - AnnualBymonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'268', N'q112_inputTable112', N'Construction - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'269', N'q293_enterAnnual293', N'Construction - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'270', N'q274_enterAnnual274', N'Construction - AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'271', N'q115_manufacturing115', N'Wholesale and Retail Trade - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'272', N'q294_enterAnnual294', N'Wholesale and Retail Trade - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'275', N'q267_enterThe267', N'Wholesale and Retail Trade - AnnualByMonth - JAN_JUN', N'11', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'276', N'q269_enterThe269', N'Wholesale and Retail Trade - AnnualByMonth - JUL_DEC', N'12', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'277', N'q124_inputTable124', N'Transportation and Warehousing - Monthly', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'278', N'q295_enterAnnual295', N'Transportation and Warehousing - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'279', N'q275_enterUtilities275', N'Transportation and Warehousing - AnnualByMonth JAN_JUN', N'11', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'280', N'q286_enterThe', N'Transportation and Warehousing - AnnualByMonth JUL_DEC', N'12', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'281', N'q130_inputTable130', N'Publishing, Media, and Telecommunications - Monthly', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'283', N'q296_enterAnnual296', N'Publishing, Media, and Telecommunications - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'284', N'q276_enterAnnual276', N'Publishing, Media, and Telecommunications - AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'285', N'q133_inputTable133', N'Information Services - Monthly', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'286', N'q297_enterAnnual297', N'Information Services - Annaul', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'287', N'q277_enterConstruction277', N'Information Services - AnnaulByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'288', N'q157_inputTable157', N'Financial Services - Monthly', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'289', N'q298_enterAnnual298', N'Financial Services - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'290', N'q278_enterConstruction278', N'Financial Services - AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'291', N'q136_inputTable136', N'Rental and Leasing - Monthly', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'292', N'q299_enterAnnual299', N'Rental and Leasing - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'293', N'q279_enterConstruction279', N'Rental and Leasing - AnnualBymonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'294', N'q139_inputTable139', N'Professional and Business Services - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'295', N'q300_enterAnnual300', N'Professional and Business Services - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'296', N'enterConstruction280', N'Professional and Business Services - AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'297', N'q142_inputTable142', N'Waste & Environmental Services - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'298', N'q301_enterAnnual301', N'Waste & Environmental Services - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'299', N'q281_enterConstruction281', N'Waste & Environmental Services - AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'300', N'q145_inputTable145', N'Education and Healthcare - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'304', N'q302_enterAnnual302', N'Education and Healthcare - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'305', N'q282_enterConstruction282', N'Education and Healthcare - AnnaulByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'306', N'q148_inputTable148', N'Arts, Entertainment, and Recreation - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'307', N'q303_enterAnnual303', N'Arts, Entertainment, and Recreation - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'309', N'q283_enterConstruction283', N'Arts, Entertainment, and Recreation - AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'310', N'q151_enterThe151', N'Accommodation - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'311', N'q304_enterAnnual304', N'Accommodation - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'312', N'q284_enterConstruction284', N'Accommodation - AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'313', N'q154_enterThe154', N' Real Estate - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'314', N'q305_enterAnnual305', N' Real Estate - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'315', N'q285_enterConstruction285', N' Real Estate - AnnualByMonth', N'5', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'316', N'q310_enterMonthly310', N'Manufacturing - Month', N'4', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'317', N'q311_enterAnnual', N'Manufacturing - Annual', N'6', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'319', N'q314_enterThe314', N'Manufacturing - AnnualByMonth JAN_JUN', N'11', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'320', N'q316_enterThe316', N'Manufacturing - AnnualByMonth JUL_DEC', N'12', NULL, N'9', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'321', N'q327_dataUnit', N'spend - Data Unit', N'9', NULL, N'9', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'322', N'q265_selectA', NULL, N'7', NULL, N'9', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'323', N'q9_customerId', NULL, N'1', NULL, N'10', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'325', N'q261_selectA', NULL, N'7', NULL, N'10', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'327', N'q314_typeA314', N'', N'2', NULL, N'10', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'328', N'q315_typeA315', NULL, N'3', NULL, N'10', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'329', N'q317_typeA317', NULL, N'10', NULL, N'10', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'344', N'q297_dataunit', N'Data Unit', N'9', NULL, N'10', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'345', N'q138_selectMonth', N'Month', N'7', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'346', N'q169_typeA169', N'Data Unit', N'9', NULL, N'8', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'347', N'q283_name', N'Name', NULL, NULL, N'11', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'348', N'q284_workEmail', N'Email', NULL, NULL, N'11', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'349', N'q9_cId', N'Customer Reference', N'1', NULL, N'11', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'350', N'q247_doYou247', N'Do you commute to work, work from home, or a bit of both? Please select one or both options as applicable', NULL, NULL, N'11', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'351', N'q172_typeA172', N'How do you commute to your workplace? (Chose more than one if required)', NULL, NULL, N'11', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'352', N'q478_TotalPetrolCarSmall', N'Small Petrol car total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'353', N'q481_TotalPetrolCarMedium', N'Medium Petrol car total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'354', N'q482_TotalPetrolCarLarge', N'Large Petrol car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'356', N'q483_TotalDieselCarSmall', N'Small diesel car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'357', N'q484_TotalDieselCarMedium', N'Medium diesel car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'358', N'q485_TotalDieselCarLarge', N'Large diesel car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'359', N'q486_TotalHybridCarSmall', N'Small Hybrid car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'360', N'q487_TotalHybridCarMedium', N'Medium Hybrid car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'361', N'q488_TotalHybridCarLarge', N'Large Hybrid car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'362', N'q489_TotalElecCarSmall', N'Small Electric car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10},{"reference": "q439_ChargingPercentWorkPlace", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'363', N'q490_TotalElecCarMedium', N'Medium Electric car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10},{"reference": "q439_ChargingPercentWorkPlace", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'364', N'q491_TotalElecCarLarge', N'Large Electric car total kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10},{"reference": "q439_ChargingPercentWorkPlace", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'365', N'q492_TotalPlgElecCarSmall', N'Small car Plug In Ele Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10},{"reference": "q550_ChargingPercentWorkPlace550", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'366', N'q493_TotalPlgElecCarMedium', N'Med car Plug In Ele Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10},{"reference": "q550_ChargingPercentWorkPlace550", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'367', N'q494_TotalPlgElecCarLarge', N'Large car Plug In Ele Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q74_typeOf", "questionTypeId": 9}, {"reference": "q479_conversionFactor", "questionTypeId": 10},{"reference": "q550_ChargingPercentWorkPlace550", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'368', N'q495_TotalTrainNatRail', N'National rail', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q174_whichUnit", "questionTypeId": 9}, {"reference": "q502_conversionFactorTrain", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'369', N'q496_TotalTrainMetro', N'Metro and/or tram', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q174_whichUnit", "questionTypeId": 9}, {"reference": "q502_conversionFactorTrain", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'370', N'q497_TotalTrainUndGrd', N'Underground', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q174_whichUnit", "questionTypeId": 9}, {"reference": "q502_conversionFactorTrain", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'371', N'q498_TotalTaxi', N'Regular taxi', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q203_whichUnit203", "questionTypeId": 9}, {"reference": "q504_conversionFactorTaxi", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'372', N'q499_TotalBus', N'Local Bus', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q220_whichUnit220", "questionTypeId": 9}, {"reference": "q505_conversionFactorBus", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'373', N'q500_TotalCycle', N'Cycling', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q273_whichUnit273", "questionTypeId": 9}, {"reference": "q506_conversionFactorCycle", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'374', N'q501_TotalWalk', N'Walking', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q277_whichUnit277", "questionTypeId": 9}, {"reference": "q507_conversionFactorWalk", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'375', N'q509_TotalVanPetrolCls1', N'Petrol Van Class I Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q376_whichUnit376", "questionTypeId": 9},{"reference": "q508_conversionFactorVan", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'376', N'q510_TotalVanPetrolCls2', N'Petrol Van Class II Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q376_whichUnit376", "questionTypeId": 9},{"reference": "q508_conversionFactorVan", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'377', N'q511_TotalVanPetrolCls3', N'Petrol Van Class III Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q376_whichUnit376", "questionTypeId": 9},{"reference": "q508_conversionFactorVan", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'378', N'q512_TotalVanDieselCls1', N'Diesel Van Class I Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q376_whichUnit376", "questionTypeId": 9},{"reference": "q508_conversionFactorVan", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'379', N'q513_TotalVanDieselCls2', N'Diesel Van Class II Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q376_whichUnit376", "questionTypeId": 9},{"reference": "q508_conversionFactorVan", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'380', N'q514_TotalVanDieselCls3', N'Diesel Van Class III Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q376_whichUnit376", "questionTypeId": 9},{"reference": "q508_conversionFactorVan", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'381', N'q515_TotalVanElecCls1', N'Electric Van Class I Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q376_whichUnit376", "questionTypeId": 9},{"reference": "q508_conversionFactorVan", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'382', N'q516_TotalVanElecCls2', N'Electric Van Class II Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q376_whichUnit376", "questionTypeId": 9},{"reference": "q508_conversionFactorVan", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'383', N'q517_TotalVanElecCls3', N'Electric Van Class III Total Kms', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q376_whichUnit376", "questionTypeId": 9},{"reference": "q508_conversionFactorVan", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'384', N'q518_TotalElectricity', N'Electricity Total', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q524_DataUnitHW", "questionTypeId": 9}, {"reference": "q525_conversionFactorHW", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'385', N'q519_TotalGas', N'Gas Total', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q524_DataUnitHW", "questionTypeId": 9}, {"reference": "q525_conversionFactorHW", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'386', N'q9_customerId', N'Customer Reference', N'1', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'387', N'q333_optinPreference', N'OptIn Preference', N'3', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'388', N'q338_totalOf', N'Total of Vans', N'13', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'389', N'q339_totalOf339', N'Total of Truck', N'13', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'390', N'q340_totalOf340', N'Total of Rail', N'13', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'392', N'q341_totalOf341', N'Total of Short Haul', N'13', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'393', N'q342_totalOf342', N'Total of Long Haul', N'13', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'394', N'q343_totalOf343', N'Total of Cargo Sea Freight', N'13', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'395', N'q9_customerId', N'Customer Reference', N'1', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'396', N'q328_optinPreference', N'OptIn Preference', N'3', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'397', N'q337_totalOf', N'Total of Vans', N'13', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'398', N'q338_totalOf338', N'Total of Truck', N'13', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'399', N'q339_totalOf339', N'Total of Rail', N'13', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'400', N'q340_totalOf340', N'Total of Short Haul', N'13', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'401', N'q341_totalOf341', N'Total of Long Haul', N'13', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'402', N'q342_totalOf342', N'Total of Cargo Sea Freight', N'13', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'403', N'q326_typeA326', N'Itemised Entries', N'14', NULL, N'13', NULL, N'{"vehicleEmissions":  [{ "type": "Van", "emissionActivityId": 360, "spendAmountEmissionActivityId": 296 }, { "type": "Truck", "emissionActivityId": 361, "spendAmountEmissionActivityId": 293 }, { "type": "Rail", "emissionActivityId": 362, "spendAmountEmissionActivityId": 291 }, { "type": "Short Haul", "emissionActivityId": 363, "spendAmountEmissionActivityId": 290 },{ "type": "Long Haul", "emissionActivityId": 364, "spendAmountEmissionActivityId": 290 },{ "type": "Cargo", "emissionActivityId": 365, "spendAmountEmissionActivityId": 292 }], "conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'404', N'q326_typeA326', N'Itemised Entries', N'14', NULL, N'12', N'', N'{"vehicleEmissions":  [{ "type": "Van", "emissionActivityId": 360, "spendAmountEmissionActivityId": 296 }, { "type": "Truck", "emissionActivityId": 361, "spendAmountEmissionActivityId": 293 }, { "type": "Rail", "emissionActivityId": 362, "spendAmountEmissionActivityId": 291 }, { "type": "Short Haul", "emissionActivityId": 363, "spendAmountEmissionActivityId": 290 },{ "type": "Long Haul", "emissionActivityId": 364, "spendAmountEmissionActivityId": 290 },{ "type": "Cargo", "emissionActivityId": 365, "spendAmountEmissionActivityId": 292 }], "conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'411', N'q460_howMany460', N'How many days a week do you work at office?', NULL, NULL, N'11', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'412', N'q461_howMany461', N'How many hours a day do you work when at office?', NULL, NULL, N'11', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'413', N'q520_TotalOil', N'Oil heating total hours', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q524_DataUnitHW", "questionTypeId": 9}, {"reference": "q525_conversionFactorHW", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'414', N'q54_email', NULL, N'15', NULL, N'1', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'415', N'q49_email', N'', N'15', NULL, N'2', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'416', N'q80_email', N'', N'15', NULL, N'3', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'417', N'q493_email', N'', N'15', NULL, N'4', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'418', N'q588_email', N'', N'15', NULL, N'5', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'419', N'q538_email', N'', N'15', NULL, N'7', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'420', N'q140_email', N'', N'15', NULL, N'8', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'421', N'q322_email', N'', N'15', NULL, N'9', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'422', N'q299_email', N'', N'15', NULL, N'10', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'423', N'q331_email', N'', N'15', NULL, N'12', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'424', N'q330_email', N'', N'15', NULL, N'13', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'426', N'q144_conversionFactor', N'Conversion Factor', N'10', NULL, N'8', N'decimal', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'427', N'q145_optinPreference', NULL, N'3', NULL, N'8', N'', NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'428', N'q307_typeA307', NULL, N'16', NULL, N'10', NULL, N'{"fuelConfigurations":[{"emissionActivityId":"378","Fuel Type":"Butane","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"326","Fuel Type":"Butane","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"379","Fuel Type":"Butane","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"380","Fuel Type":"Butane","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"381","Fuel Type":"CNG","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"327","Fuel Type":"CNG","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"382","Fuel Type":"CNG","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"383","Fuel Type":"CNG","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"406","Fuel Type":"LNG","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"328","Fuel Type":"LNG","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"407","Fuel Type":"LNG","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"408","Fuel Type":"LNG","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"409","Fuel Type":"LPG","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"329","Fuel Type":"LPG","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"410","Fuel Type":"LPG","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"411","Fuel Type":"LPG","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"425","Fuel Type":"Natural gas","Unit":"cubic metres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"424","Fuel Type":"Natural gas","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"3","Fuel Type":"Natural Gas","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"426","Fuel Type":"Natural gas","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"428","Fuel Type":"Natural gas (100% mineral blend)","Unit":"cubic metres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"427","Fuel Type":"Natural gas (100% mineral blend)","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"331","Fuel Type":"Natural gas (100% mineral blend)","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"429","Fuel Type":"Natural gas (100% mineral blend)","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"430","Fuel Type":"Other petroleum gas","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"332","Fuel Type":"Other petroleum gas","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"431","Fuel Type":"Other petroleum gas","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"432","Fuel Type":"Other petroleum gas","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"447","Fuel Type":"Propane","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"333","Fuel Type":"Propane","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"448","Fuel Type":"Propane","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"449","Fuel Type":"Propane","Unit":"tonnes","Parent_Type":"Gaseous fuels"}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'429', N'q308_pleaseEnter', NULL, N'16', NULL, N'10', NULL, N'{"fuelConfigurations":[{"emissionActivityId":"378","Fuel Type":"Butane","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"326","Fuel Type":"Butane","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"379","Fuel Type":"Butane","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"380","Fuel Type":"Butane","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"381","Fuel Type":"CNG","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"327","Fuel Type":"CNG","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"382","Fuel Type":"CNG","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"383","Fuel Type":"CNG","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"406","Fuel Type":"LNG","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"328","Fuel Type":"LNG","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"407","Fuel Type":"LNG","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"408","Fuel Type":"LNG","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"409","Fuel Type":"LPG","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"329","Fuel Type":"LPG","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"410","Fuel Type":"LPG","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"411","Fuel Type":"LPG","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"425","Fuel Type":"Natural gas","Unit":"cubic metres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"424","Fuel Type":"Natural gas","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"3","Fuel Type":"Natural Gas","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"426","Fuel Type":"Natural gas","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"428","Fuel Type":"Natural gas (100% mineral blend)","Unit":"cubic metres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"427","Fuel Type":"Natural gas (100% mineral blend)","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"331","Fuel Type":"Natural gas (100% mineral blend)","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"429","Fuel Type":"Natural gas (100% mineral blend)","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"430","Fuel Type":"Other petroleum gas","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"332","Fuel Type":"Other petroleum gas","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"431","Fuel Type":"Other petroleum gas","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"432","Fuel Type":"Other petroleum gas","Unit":"tonnes","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"447","Fuel Type":"Propane","Unit":"kWh (Gross CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"333","Fuel Type":"Propane","Unit":"kWh (Net CV)","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"448","Fuel Type":"Propane","Unit":"litres","Parent_Type":"Gaseous fuels"},{"emissionActivityId":"449","Fuel Type":"Propane","Unit":"tonnes","Parent_Type":"Gaseous fuels"}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'430', N'q309_pleaseEnter309', NULL, N'16', NULL, N'10', NULL, N'{"fuelConfigurations":[{"emissionActivityId":"371","Fuel Type":"Aviation spirit","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"334","Fuel Type":"Aviation spirit","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"369","Fuel Type":"Aviation spirit","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"370","Fuel Type":"Aviation spirit","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"372","Fuel Type":"Aviation turbine fuel","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"335","Fuel Type":"Aviation turbine fuel","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"373","Fuel Type":"Aviation turbine fuel","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"374","Fuel Type":"Aviation turbine fuel","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"375","Fuel Type":"Burning oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"336","Fuel Type":"Burning oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"376","Fuel Type":"Burning oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"377","Fuel Type":"Burning oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"394","Fuel Type":"Diesel (100% mineral diesel)","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"338","Fuel Type":"Diesel (100% mineral diesel)","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"395","Fuel Type":"Diesel (100% mineral diesel)","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"396","Fuel Type":"Diesel (100% mineral diesel)","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"397","Fuel Type":"Diesel (average biofuel blend)","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"337","Fuel Type":"Diesel (average biofuel blend)","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"398","Fuel Type":"Diesel (average biofuel blend)","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"399","Fuel Type":"Diesel (average biofuel blend)","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"400","Fuel Type":"Fuel oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"339","Fuel Type":"Fuel oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"401","Fuel Type":"Fuel oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"402","Fuel Type":"Fuel oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"403","Fuel Type":"Gas oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"340","Fuel Type":"Gas oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"404","Fuel Type":"Gas oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"405","Fuel Type":"Gas oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"412","Fuel Type":"Lubricants","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"341","Fuel Type":"Lubricants","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"413","Fuel Type":"Lubricants","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"414","Fuel Type":"Lubricants","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"415","Fuel Type":"Marine fuel oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"350","Fuel Type":"Marine fuel oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"416","Fuel Type":"Marine fuel oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"417","Fuel Type":"Marine fuel oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"418","Fuel Type":"Marine gas oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"349","Fuel Type":"Marine gas oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"419","Fuel Type":"Marine gas oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"420","Fuel Type":"Marine gas oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"421","Fuel Type":"Naphtha","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"342","Fuel Type":"Naphtha","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"422","Fuel Type":"Naphtha","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"423","Fuel Type":"Naphtha","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"433","Fuel Type":"Petrol (100% mineral petrol)","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"344","Fuel Type":"Petrol (100% mineral petrol)","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"434","Fuel Type":"Petrol (100% mineral petrol)","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"435","Fuel Type":"Petrol (100% mineral petrol)","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"436","Fuel Type":"Petrol (average biofuel blend)","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"343","Fuel Type":"Petrol (average biofuel blend)","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"437","Fuel Type":"Petrol (average biofuel blend)","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"438","Fuel Type":"Petrol (average biofuel blend)","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"441","Fuel Type":"Processed fuel oils - distillate oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"346","Fuel Type":"Processed fuel oils - distillate oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"442","Fuel Type":"Processed fuel oils - distillate oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"443","Fuel Type":"Processed fuel oils - distillate oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"444","Fuel Type":"Processed fuel oils - residual oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"345","Fuel Type":"Processed fuel oils - residual oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"445","Fuel Type":"Processed fuel oils - residual oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"446","Fuel Type":"Processed fuel oils - residual oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"451","Fuel Type":"Refinery miscellaneous","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"347","Fuel Type":"Refinery miscellaneous","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"450","Fuel Type":"Refinery miscellaneous","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"452","Fuel Type":"Refinery miscellaneous","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"453","Fuel Type":"Waste oils","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"454","Fuel Type":"Waste oils","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"455","Fuel Type":"Waste oils","Unit":"tonnes","Parent_Type":"Liquid fuels"}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'431', N'q310_pleaseEnter310', NULL, N'16', NULL, N'10', NULL, N'{"fuelConfigurations":[{"emissionActivityId":"371","Fuel Type":"Aviation spirit","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"334","Fuel Type":"Aviation spirit","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"369","Fuel Type":"Aviation spirit","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"370","Fuel Type":"Aviation spirit","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"372","Fuel Type":"Aviation turbine fuel","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"335","Fuel Type":"Aviation turbine fuel","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"373","Fuel Type":"Aviation turbine fuel","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"374","Fuel Type":"Aviation turbine fuel","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"375","Fuel Type":"Burning oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"336","Fuel Type":"Burning oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"376","Fuel Type":"Burning oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"377","Fuel Type":"Burning oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"394","Fuel Type":"Diesel (100% mineral diesel)","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"338","Fuel Type":"Diesel (100% mineral diesel)","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"395","Fuel Type":"Diesel (100% mineral diesel)","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"396","Fuel Type":"Diesel (100% mineral diesel)","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"397","Fuel Type":"Diesel (average biofuel blend)","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"337","Fuel Type":"Diesel (average biofuel blend)","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"398","Fuel Type":"Diesel (average biofuel blend)","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"399","Fuel Type":"Diesel (average biofuel blend)","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"400","Fuel Type":"Fuel oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"339","Fuel Type":"Fuel oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"401","Fuel Type":"Fuel oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"402","Fuel Type":"Fuel oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"403","Fuel Type":"Gas oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"340","Fuel Type":"Gas oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"404","Fuel Type":"Gas oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"405","Fuel Type":"Gas oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"412","Fuel Type":"Lubricants","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"341","Fuel Type":"Lubricants","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"413","Fuel Type":"Lubricants","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"414","Fuel Type":"Lubricants","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"415","Fuel Type":"Marine fuel oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"350","Fuel Type":"Marine fuel oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"416","Fuel Type":"Marine fuel oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"417","Fuel Type":"Marine fuel oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"418","Fuel Type":"Marine gas oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"349","Fuel Type":"Marine gas oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"419","Fuel Type":"Marine gas oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"420","Fuel Type":"Marine gas oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"421","Fuel Type":"Naphtha","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"342","Fuel Type":"Naphtha","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"422","Fuel Type":"Naphtha","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"423","Fuel Type":"Naphtha","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"433","Fuel Type":"Petrol (100% mineral petrol)","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"344","Fuel Type":"Petrol (100% mineral petrol)","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"434","Fuel Type":"Petrol (100% mineral petrol)","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"435","Fuel Type":"Petrol (100% mineral petrol)","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"436","Fuel Type":"Petrol (average biofuel blend)","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"343","Fuel Type":"Petrol (average biofuel blend)","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"437","Fuel Type":"Petrol (average biofuel blend)","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"438","Fuel Type":"Petrol (average biofuel blend)","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"441","Fuel Type":"Processed fuel oils - distillate oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"346","Fuel Type":"Processed fuel oils - distillate oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"442","Fuel Type":"Processed fuel oils - distillate oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"443","Fuel Type":"Processed fuel oils - distillate oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"444","Fuel Type":"Processed fuel oils - residual oil","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"345","Fuel Type":"Processed fuel oils - residual oil","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"445","Fuel Type":"Processed fuel oils - residual oil","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"446","Fuel Type":"Processed fuel oils - residual oil","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"451","Fuel Type":"Refinery miscellaneous","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"347","Fuel Type":"Refinery miscellaneous","Unit":"kWh (Net CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"450","Fuel Type":"Refinery miscellaneous","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"452","Fuel Type":"Refinery miscellaneous","Unit":"tonnes","Parent_Type":"Liquid fuels"},{"emissionActivityId":"453","Fuel Type":"Waste oils","Unit":"kWh (Gross CV)","Parent_Type":"Liquid fuels"},{"emissionActivityId":"454","Fuel Type":"Waste oils","Unit":"litres","Parent_Type":"Liquid fuels"},{"emissionActivityId":"455","Fuel Type":"Waste oils","Unit":"tonnes","Parent_Type":"Liquid fuels"}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'432', N'q311_pleaseEnter311', NULL, N'16', NULL, N'10', NULL, N'{"fuelConfigurations":[{"emissionActivityId":"384","Fuel Type":"Coal (domestic)","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"353","Fuel Type":"Coal (domestic)","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"385","Fuel Type":"Coal (domestic)","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"386","Fuel Type":"Coal (electricity generation - home produced coal only)","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"356","Fuel Type":"Coal (electricity generation - home produced coal only)","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"387","Fuel Type":"Coal (electricity generation - home produced coal only)","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"388","Fuel Type":"Coal (electricity generation)","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"352","Fuel Type":"Coal (electricity generation)","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"389","Fuel Type":"Coal (electricity generation)","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"390","Fuel Type":"Coal (industrial)","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"351","Fuel Type":"Coal (industrial)","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"391","Fuel Type":"Coal (industrial)","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"392","Fuel Type":"Coking coal","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"354","Fuel Type":"Coking coal","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"393","Fuel Type":"Coking coal","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"439","Fuel Type":"Petroleum coke","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"355","Fuel Type":"Petroleum coke","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"440","Fuel Type":"Petroleum coke","Unit":"tonnes","Parent_Type":"Solid fuels"}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'433', N'q312_pleaseEnter312', NULL, N'16', NULL, N'10', NULL, N'{"fuelConfigurations":[{"emissionActivityId":"384","Fuel Type":"Coal (domestic)","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"353","Fuel Type":"Coal (domestic)","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"385","Fuel Type":"Coal (domestic)","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"386","Fuel Type":"Coal (electricity generation - home produced coal only)","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"356","Fuel Type":"Coal (electricity generation - home produced coal only)","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"387","Fuel Type":"Coal (electricity generation - home produced coal only)","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"388","Fuel Type":"Coal (electricity generation)","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"352","Fuel Type":"Coal (electricity generation)","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"389","Fuel Type":"Coal (electricity generation)","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"390","Fuel Type":"Coal (industrial)","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"351","Fuel Type":"Coal (industrial)","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"391","Fuel Type":"Coal (industrial)","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"392","Fuel Type":"Coking coal","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"354","Fuel Type":"Coking coal","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"393","Fuel Type":"Coking coal","Unit":"tonnes","Parent_Type":"Solid fuels"},{"emissionActivityId":"439","Fuel Type":"Petroleum coke","Unit":"kWh (Gross CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"355","Fuel Type":"Petroleum coke","Unit":"kWh (Net CV)","Parent_Type":"Solid fuels"},{"emissionActivityId":"440","Fuel Type":"Petroleum coke","Unit":"tonnes","Parent_Type":"Solid fuels"}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'434', N'q592_enterAnnual592', N'Passenger car Hybrid Electric (kWh) - Annually', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q620_dataUnit620", "questionTypeId": 9},{"reference": "q621_conversionFactor621", "questionTypeId": 10},{"reference": "q600_ChargingPercentWorkPlace600", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'435', N'q593_enterAnnual593', N'Passenger car Hybrid Electric (kWh) - AnnaulByMonths', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q620_dataUnit620", "questionTypeId": 9},{"reference": "q621_conversionFactor621", "questionTypeId": 10},{"reference": "q600_ChargingPercentWorkPlace600", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'436', N'q594_enterAnnual594', N'Vans Battery Electric (kWh) Annually', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q620_dataUnit620", "questionTypeId": 9},{"reference": "q621_conversionFactor621", "questionTypeId": 10},{"reference": "q599_ChargingPercentWorkPlace599", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'437', N'q595_enterAnnual595', N'Vans Battery Electric (kWh) Annual By Months', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q620_dataUnit620", "questionTypeId": 9},{"reference": "q621_conversionFactor621", "questionTypeId": 10},{"reference": "q599_ChargingPercentWorkPlace599", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'438', N'q605_enterAnnual605', N'Passenger car Electric (kWh) - Annually', N'6', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q620_dataUnit620", "questionTypeId": 9},{"reference": "q621_conversionFactor621", "questionTypeId": 10},{"reference": "q607_ChargingPercentWorkPlace607", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'439', N'q606_enterAnnual606', N'Passenger car Electric (kWh) - AnnaulByMonths', N'5', NULL, N'5', NULL, N'{"linkedQuestions": [{"reference": "q620_dataUnit620", "questionTypeId": 9},{"reference": "q621_conversionFactor621", "questionTypeId": 10},{"reference": "q607_ChargingPercentWorkPlace607", "questionTypeId": 21}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'440', N'q498_managementBased', NULL, N'8', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'441', N'q499_typeA499', NULL, N'10', NULL, N'4', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'442', N'q611_typeA611', NULL, N'8', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'443', N'q543_ManagementBasedDecision', NULL, N'8', NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'444', N'q316_typeA316', NULL, N'8', NULL, N'10', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'445', N'q334_conversionFactor', NULL, N'10', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'446', N'q335_reportingFrequency', NULL, N'2', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'447', N'q336_dataUnit', NULL, N'9', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'448', N'q337_managementBased', NULL, N'8', NULL, N'12', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'449', N'q334_conversionFactor', NULL, N'10', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'450', N'q335_reportingFrequency', NULL, N'2', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'451', N'q336_dataUnit', NULL, N'9', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'452', N'q333_managementBased', NULL, N'8', NULL, N'13', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'454', N'q569_HotelNightStayItemisedAnnual', N'Hotel stay by country, Itemised entry', N'17', NULL, N'7', NULL, N'{
"linkedQuestions": [{"reference": "q563_dataUnit563", "questionTypeId": 9},{"reference": "q564_conversionFactor564", "questionTypeId": 10}],
"hotelEmissions": [
{ "country": "UK", "emissionActivityId": 457 },
{ "country": "UK (London)", "emissionActivityId": 458 },
{ "country": "Australia", "emissionActivityId": 459 },
{ "country": "Belgium", "emissionActivityId": 460 },
{ "country": "Brazil", "emissionActivityId": 461 },
{ "country": "Canada", "emissionActivityId": 462 },
{ "country": "Chile", "emissionActivityId": 463 },
{ "country": "China", "emissionActivityId": 464 },
{ "country": "Colombia", "emissionActivityId": 465 },
{ "country": "Costa Rica", "emissionActivityId": 466 },
{ "country": "Egypt", "emissionActivityId": 467 },
{ "country": "France", "emissionActivityId": 468 },
{ "country": "Germany", "emissionActivityId": 469 },
{ "country": "Hong Kong (China)", "emissionActivityId": 470 },
{ "country": "India", "emissionActivityId": 471 },
{ "country": "Indonesia", "emissionActivityId": 472 },
{ "country": "Italy", "emissionActivityId": 473 },
{ "country": "Japan", "emissionActivityId": 474 },
{ "country": "Jordan", "emissionActivityId": 475 },
{ "country": "Korea", "emissionActivityId": 476 },
{ "country": "Malaysia", "emissionActivityId": 477 },
{ "country": "Maldives", "emissionActivityId": 478 },
{ "country": "Mexico", "emissionActivityId": 479 },
{ "country": "Netherlands", "emissionActivityId": 480 },
{ "country": "Oman", "emissionActivityId": 481 },
{ "country": "Philippines", "emissionActivityId": 482 },
{ "country": "Portugal", "emissionActivityId": 483 },
{ "country": "Qatar", "emissionActivityId": 484 },
{ "country": "Russian Federation", "emissionActivityId": 485 },
{ "country": "Saudi Arabia", "emissionActivityId": 486 },
{ "country": "Singapore", "emissionActivityId": 487 },
{ "country": "South Africa", "emissionActivityId": 488 },
{ "country": "Spain", "emissionActivityId": 489 },
{ "country": "Switzerland", "emissionActivityId": 490 },
{ "country": "Thailand", "emissionActivityId": 491 },
{ "country": "Turkey", "emissionActivityId": 492 },
{ "country": "United Arab Emirates", "emissionActivityId": 493 },
{ "country": "United States", "emissionActivityId": 494 },
{ "country": "Vietnam", "emissionActivityId": 495 }
]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'455', N'q570_HotelNightStayItemisedMonthly', N'Hotel stay by country, Itemised entry', N'17', NULL, N'7', NULL, N'{
"linkedQuestions": [{"reference": "q563_dataUnit563", "questionTypeId": 9},{"reference": "q564_conversionFactor564", "questionTypeId": 10}],
"hotelEmissions": [
{ "country": "UK", "emissionActivityId": 457 },
{ "country": "UK (London)", "emissionActivityId": 458 },
{ "country": "Australia", "emissionActivityId": 459 },
{ "country": "Belgium", "emissionActivityId": 460 },
{ "country": "Brazil", "emissionActivityId": 461 },
{ "country": "Canada", "emissionActivityId": 462 },
{ "country": "Chile", "emissionActivityId": 463 },
{ "country": "China", "emissionActivityId": 464 },
{ "country": "Colombia", "emissionActivityId": 465 },
{ "country": "Costa Rica", "emissionActivityId": 466 },
{ "country": "Egypt", "emissionActivityId": 467 },
{ "country": "France", "emissionActivityId": 468 },
{ "country": "Germany", "emissionActivityId": 469 },
{ "country": "Hong Kong (China)", "emissionActivityId": 470 },
{ "country": "India", "emissionActivityId": 471 },
{ "country": "Indonesia", "emissionActivityId": 472 },
{ "country": "Italy", "emissionActivityId": 473 },
{ "country": "Japan", "emissionActivityId": 474 },
{ "country": "Jordan", "emissionActivityId": 475 },
{ "country": "Korea", "emissionActivityId": 476 },
{ "country": "Malaysia", "emissionActivityId": 477 },
{ "country": "Maldives", "emissionActivityId": 478 },
{ "country": "Mexico", "emissionActivityId": 479 },
{ "country": "Netherlands", "emissionActivityId": 480 },
{ "country": "Oman", "emissionActivityId": 481 },
{ "country": "Philippines", "emissionActivityId": 482 },
{ "country": "Portugal", "emissionActivityId": 483 },
{ "country": "Qatar", "emissionActivityId": 484 },
{ "country": "Russian Federation", "emissionActivityId": 485 },
{ "country": "Saudi Arabia", "emissionActivityId": 486 },
{ "country": "Singapore", "emissionActivityId": 487 },
{ "country": "South Africa", "emissionActivityId": 488 },
{ "country": "Spain", "emissionActivityId": 489 },
{ "country": "Switzerland", "emissionActivityId": 490 },
{ "country": "Thailand", "emissionActivityId": 491 },
{ "country": "Turkey", "emissionActivityId": 492 },
{ "country": "United Arab Emirates", "emissionActivityId": 493 },
{ "country": "United States", "emissionActivityId": 494 },
{ "country": "Vietnam", "emissionActivityId": 495 }
]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'456', N'q349_SpendAmountCargo', N'Amount Spend on Sea freight cargo', N'6', NULL, N'12', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'457', N'q348_SpendAmountAir', N'Amount Spend on Air cargo', N'6', NULL, N'12', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'458', N'q347_SpendAmountRail', N'Amount Spend on Rail cargo', N'6', NULL, N'12', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'459', N'q346_SpendAmountRoad', N'Amount Spend on Road cargo', N'6', NULL, N'12', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'460', N'q348_SpendAmountCargo', N'Amount Spend on Sea freight cargo', N'6', NULL, N'13', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'461', N'q347_SpendAmountAir', N'Amount Spend on Air cargo', N'6', NULL, N'13', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'462', N'q346_SpendAmountRail', N'Amount Spend on Rail cargo', N'6', NULL, N'13', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'463', N'q345_SpendAmountRoad', N'Amount Spend on Road cargo', N'6', NULL, N'13', NULL, N'{"conversion":"AmountToUSD"}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'464', N'q534_escooterTotal', N'E-Scooter', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q532_whichUnit532", "questionTypeId": 9}, {"reference": "q535_conversionFactorescooter", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'465', N'q540_mopedscooterTotal', N'Moped/Scooter', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q538_whichUnit538", "questionTypeId": 9}, {"reference": "q541_conversionFactormopedscooter", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'466', N'q548_motorcycleTotal', N'Motorcycle', N'13', NULL, N'11', NULL, N'{"linkedQuestions": [{"reference": "q546_whichUnit546", "questionTypeId": 9}, {"reference": "q549_conversionFactormotorcycle", "questionTypeId": 10}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'470', N'q571_FlightDomesticItemisedAnnual', N'Flight Domestic Annual-itemised', N'18', NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'471', N'q572_FlightDomesticItemisedMonthly', N'Flight Domestic Monthly-itemised', N'18', NULL, N'7', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'472', N'q573_FlightShortItemisedAnnual', N'Flight Short-Haul Annual-itemised', N'19', NULL, N'7', NULL, N'{"flightEmissions":[{"type": "Average Passenger Short-Haul", "emissionActivityId": 234}, { "type": "Economy Class Short-Haul", "emissionActivityId": 235}, { "type": "Business Class Short-Haul", "emissionActivityId": 236}]}
', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'473', N'q574_FlightShortItemisedMonthly', N'Flight Short-Haul Monthly-itemised', N'19', NULL, N'7', NULL, N'{"flightEmissions":[{"type": "Average Passenger Short-Haul", "emissionActivityId": 234}, { "type": "Economy Class Short-Haul", "emissionActivityId": 235}, { "type": "Business Class Short-Haul", "emissionActivityId": 236}]}
', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'474', N'q576_FlightLongItemisedAnnual', N'Flight Long-Haul Annual-itemised', N'20', NULL, N'7', NULL, N'{"flightEmissions": [{"type": "Average Passenger Long-Haul", "emissionActivityId": 237},{ "type": "Economy Class Long-Haul", "emissionActivityId": 238}, { "type": "Premium Economy Class Long-Haul", "emissionActivityId": 239}, { "type": "Business Class Long-Haul", "emissionActivityId": 240}, { "type": "First Class Long-Haul", "emissionActivityId": 241}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'475', N'q577_FlightLongItemisedMonthly', N'Flight Long-Haul Monthly-itemised', N'20', NULL, N'7', NULL, N'{"flightEmissions": [{"type": "Average Passenger Long-Haul", "emissionActivityId": 237},{ "type": "Economy Class Long-Haul", "emissionActivityId": 238}, { "type": "Premium Economy Class Long-Haul", "emissionActivityId": 239}, { "type": "Business Class Long-Haul", "emissionActivityId": 240}, { "type": "First Class Long-Haul", "emissionActivityId": 241}]}', N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'477', N'q583_ChargingPercentWorkPlace', N'Passenger Car Electric (Distance) - Charging % at Work Place', N'21', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'480', N'q589_ChargingPercentWorkPlace589', N'Passenger Car Hybrid Electric (Distance) - Charging % at Work Place', N'21', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'483', N'q590_ChargingPercentWorkPlace590', N'Vans Electric (Distance) - Charging % at Work Place', N'21', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'484', N'q607_ChargingPercentWorkPlace607', N'Passanger car Electric (kwh) - Charging % at Work Place', N'21', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'485', N'q600_ChargingPercentWorkPlace600', N'Passanger car Hybrid Electric (kwh) - Charging % at Work Place', N'21', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'487', N'q599_ChargingPercentWorkPlace599', N'Vans - Electric (kwh) - Charging % at Work Place', N'21', NULL, N'5', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'488', N'q439_ChargingPercentWorkPlace', N'Passenger Car Electric (Distance) - Charging % at Work Place', N'21', NULL, N'11', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'490', N'q550_ChargingPercentWorkPlace550', N'Passenger Car Hybrid Electric (Distance) - Charging % at Work Place', N'21', NULL, N'11', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'491', N'q50_typeA50', N'Sites Tariffs itemise input', N'22', NULL, N'2', NULL, NULL, N'1')
GO

INSERT INTO [Forms].[Question] ([id], [reference], [displayText], [questionTypeId], [inputTypeId], [formId], [dataType], [properties], [active]) VALUES (N'492', N'q526_doYou526', N'Home working OR on site', N'13', NULL, N'11', NULL, NULL, N'1')
GO

SET IDENTITY_INSERT [Forms].[Question] OFF
GO


-- ----------------------------
-- Table structure for QuestionEmissionActivity
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[QuestionEmissionActivity]') AND type IN ('U'))
	DROP TABLE [Forms].[QuestionEmissionActivity]
GO

CREATE TABLE [Forms].[QuestionEmissionActivity] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [questionId] int  NOT NULL,
  [emissionActivityId] int  NULL,
  [rowNo] int  NULL,
  [columnNo] int  NULL
)
GO

ALTER TABLE [Forms].[QuestionEmissionActivity] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of QuestionEmissionActivity
-- ----------------------------
SET IDENTITY_INSERT [Forms].[QuestionEmissionActivity] ON
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1', N'52', N'4', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'2', N'52', N'5', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'3', N'52', N'6', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'4', N'52', N'7', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'5', N'52', N'8', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'6', N'52', N'9', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'7', N'52', N'10', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'8', N'52', N'11', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'9', N'52', N'12', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'10', N'52', N'13', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'11', N'52', N'14', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'12', N'52', N'15', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'13', N'52', N'16', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'14', N'52', N'17', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'15', N'52', N'18', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'16', N'52', N'19', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'17', N'52', N'20', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'18', N'52', N'21', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'19', N'52', N'22', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'20', N'52', N'23', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'21', N'52', N'24', N'20', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'22', N'52', N'25', N'21', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'23', N'52', N'26', N'22', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'24', N'52', N'27', N'23', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'25', N'52', N'28', N'24', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'26', N'52', N'29', N'25', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'27', N'52', N'30', N'26', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'28', N'52', N'31', N'27', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'29', N'52', N'32', N'28', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'30', N'52', N'33', N'29', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'31', N'52', N'34', N'30', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'32', N'52', N'35', N'31', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'33', N'52', N'36', N'32', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'34', N'54', N'4', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'35', N'54', N'5', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'36', N'54', N'6', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'37', N'54', N'7', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'38', N'54', N'8', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'39', N'54', N'9', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'40', N'54', N'10', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'41', N'54', N'11', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'42', N'54', N'12', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'43', N'54', N'13', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'44', N'54', N'14', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'45', N'54', N'15', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'46', N'54', N'16', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'47', N'54', N'17', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'48', N'54', N'18', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'49', N'54', N'19', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'50', N'54', N'20', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'51', N'54', N'21', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'52', N'54', N'22', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'53', N'54', N'23', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'54', N'54', N'24', N'20', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'55', N'54', N'25', N'21', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'56', N'54', N'26', N'22', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'57', N'54', N'27', N'23', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'58', N'54', N'28', N'24', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'59', N'54', N'29', N'25', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'60', N'54', N'30', N'26', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'61', N'54', N'31', N'27', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'62', N'54', N'32', N'28', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'63', N'54', N'33', N'29', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'64', N'54', N'34', N'30', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'65', N'54', N'35', N'31', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'66', N'54', N'36', N'32', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'67', N'55', N'4', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'68', N'55', N'5', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'69', N'55', N'6', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'70', N'55', N'7', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'71', N'55', N'8', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'72', N'55', N'9', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'73', N'55', N'10', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'74', N'55', N'11', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'75', N'55', N'12', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'76', N'55', N'13', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'77', N'55', N'14', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'78', N'55', N'15', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'79', N'55', N'16', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'80', N'55', N'17', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'81', N'55', N'18', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'82', N'55', N'19', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'83', N'55', N'20', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'84', N'55', N'21', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'85', N'55', N'22', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'86', N'55', N'23', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'87', N'55', N'24', N'20', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'88', N'55', N'25', N'21', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'89', N'55', N'26', N'22', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'90', N'55', N'27', N'23', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'91', N'55', N'28', N'24', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'92', N'55', N'29', N'25', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'93', N'55', N'30', N'26', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'94', N'55', N'31', N'27', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'95', N'55', N'32', N'28', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'96', N'55', N'33', N'29', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'97', N'55', N'34', N'30', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'98', N'55', N'35', N'31', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'99', N'55', N'36', N'32', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'100', N'56', N'4', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'101', N'56', N'5', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'102', N'56', N'6', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'103', N'56', N'7', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'104', N'56', N'8', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'105', N'56', N'9', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'106', N'56', N'10', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'107', N'56', N'11', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'108', N'56', N'12', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'109', N'56', N'13', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'110', N'56', N'14', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'111', N'56', N'15', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'112', N'56', N'16', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'113', N'56', N'17', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'114', N'56', N'18', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'115', N'56', N'19', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'116', N'56', N'20', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'117', N'56', N'21', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'118', N'56', N'22', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'119', N'56', N'23', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'120', N'56', N'24', N'20', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'121', N'56', N'25', N'21', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'122', N'56', N'26', N'22', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'123', N'56', N'27', N'23', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'124', N'56', N'28', N'24', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'125', N'56', N'29', N'25', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'126', N'56', N'30', N'26', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'127', N'56', N'31', N'27', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'128', N'56', N'32', N'28', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'129', N'56', N'33', N'29', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'130', N'56', N'34', N'30', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'131', N'56', N'35', N'31', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'132', N'56', N'36', N'32', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'133', N'57', N'37', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'134', N'57', N'38', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'135', N'57', N'39', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'136', N'57', N'40', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'137', N'57', N'41', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'138', N'57', N'42', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'139', N'57', N'43', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'140', N'57', N'44', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'141', N'57', N'45', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'142', N'57', N'46', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'143', N'57', N'47', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'144', N'57', N'48', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'145', N'57', N'49', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'146', N'57', N'50', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'147', N'57', N'51', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'148', N'57', N'52', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'149', N'57', N'53', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'150', N'57', N'54', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'151', N'57', N'55', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'152', N'57', N'56', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'153', N'57', N'57', N'20', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'154', N'57', N'58', N'21', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'155', N'57', N'59', N'22', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'156', N'57', N'60', N'23', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'157', N'57', N'61', N'24', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'158', N'57', N'62', N'25', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'159', N'57', N'63', N'26', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'160', N'57', N'64', N'27', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'161', N'57', N'65', N'28', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'162', N'57', N'66', N'29', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'163', N'57', N'67', N'30', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'164', N'57', N'68', N'31', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'165', N'57', N'69', N'32', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'166', N'57', N'70', N'33', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'167', N'57', N'71', N'34', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'168', N'57', N'72', N'35', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'169', N'57', N'73', N'36', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'170', N'57', N'74', N'37', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'171', N'57', N'75', N'38', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'172', N'57', N'76', N'39', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'173', N'57', N'77', N'40', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'174', N'57', N'78', N'41', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'175', N'57', N'79', N'42', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'176', N'57', N'80', N'43', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'177', N'57', N'81', N'44', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'178', N'57', N'82', N'45', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'179', N'57', N'83', N'46', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'180', N'57', N'84', N'47', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'181', N'57', N'85', N'48', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'182', N'57', N'86', N'49', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'183', N'57', N'87', N'50', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'184', N'57', N'88', N'51', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'185', N'57', N'89', N'52', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'186', N'57', N'90', N'53', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'187', N'57', N'91', N'54', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'188', N'57', N'92', N'55', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'189', N'57', N'93', N'56', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'190', N'57', N'94', N'57', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'191', N'57', N'95', N'58', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'192', N'57', N'96', N'59', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'193', N'57', N'97', N'60', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'194', N'57', N'98', N'61', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'195', N'57', N'99', N'62', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'196', N'57', N'100', N'63', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'197', N'57', N'101', N'64', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'198', N'57', N'102', N'65', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'199', N'57', N'103', N'66', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'200', N'57', N'104', N'67', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'201', N'57', N'105', N'68', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'202', N'57', N'106', N'69', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'203', N'57', N'107', N'70', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'204', N'57', N'108', N'71', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'205', N'57', N'109', N'72', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'206', N'57', N'110', N'73', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'207', N'57', N'111', N'74', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'208', N'57', N'112', N'75', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'209', N'57', N'113', N'76', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'210', N'57', N'114', N'77', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'211', N'57', N'115', N'78', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'212', N'57', N'116', N'79', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'213', N'57', N'117', N'80', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'214', N'57', N'118', N'81', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'215', N'58', N'37', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'216', N'58', N'38', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'217', N'58', N'39', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'218', N'58', N'40', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'219', N'58', N'41', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'220', N'58', N'42', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'221', N'58', N'43', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'222', N'58', N'44', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'223', N'58', N'45', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'224', N'58', N'46', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'225', N'58', N'47', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'226', N'58', N'48', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'227', N'58', N'49', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'228', N'58', N'50', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'229', N'58', N'51', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'230', N'58', N'52', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'231', N'58', N'53', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'232', N'58', N'54', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'233', N'58', N'55', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'234', N'58', N'56', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'235', N'58', N'57', N'20', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'236', N'58', N'58', N'21', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'237', N'58', N'59', N'22', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'238', N'58', N'60', N'23', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'239', N'58', N'61', N'24', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'240', N'58', N'62', N'25', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'241', N'58', N'63', N'26', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'242', N'58', N'64', N'27', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'243', N'58', N'65', N'28', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'244', N'58', N'66', N'29', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'245', N'58', N'67', N'30', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'246', N'58', N'68', N'31', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'247', N'58', N'69', N'32', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'248', N'58', N'70', N'33', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'249', N'58', N'71', N'34', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'250', N'58', N'72', N'35', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'251', N'58', N'73', N'36', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'252', N'58', N'74', N'37', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'253', N'58', N'75', N'38', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'254', N'58', N'76', N'39', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'255', N'58', N'77', N'40', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'256', N'58', N'78', N'41', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'257', N'58', N'79', N'42', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'258', N'58', N'80', N'43', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'259', N'58', N'81', N'44', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'260', N'58', N'82', N'45', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'261', N'58', N'83', N'46', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'262', N'58', N'84', N'47', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'263', N'58', N'85', N'48', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'264', N'58', N'86', N'49', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'265', N'58', N'87', N'50', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'266', N'58', N'88', N'51', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'267', N'58', N'89', N'52', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'268', N'58', N'90', N'53', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'269', N'58', N'91', N'54', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'270', N'58', N'92', N'55', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'271', N'58', N'93', N'56', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'272', N'58', N'94', N'57', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'273', N'58', N'95', N'58', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'274', N'58', N'96', N'59', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'275', N'58', N'97', N'60', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'276', N'58', N'98', N'61', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'277', N'58', N'99', N'62', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'278', N'58', N'100', N'63', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'279', N'58', N'101', N'64', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'280', N'58', N'102', N'65', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'281', N'58', N'103', N'66', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'282', N'58', N'104', N'67', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'283', N'58', N'105', N'68', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'284', N'58', N'106', N'69', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'285', N'58', N'107', N'70', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'286', N'58', N'108', N'71', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'287', N'58', N'109', N'72', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'288', N'58', N'110', N'73', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'289', N'58', N'111', N'74', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'290', N'58', N'112', N'75', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'291', N'58', N'113', N'76', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'292', N'58', N'114', N'77', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'293', N'58', N'115', N'78', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'294', N'58', N'116', N'79', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'295', N'58', N'117', N'80', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'296', N'58', N'118', N'81', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'297', N'58', N'119', N'82', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'298', N'58', N'120', N'83', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'299', N'59', N'37', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'300', N'59', N'38', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'301', N'59', N'39', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'302', N'59', N'40', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'303', N'59', N'41', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'304', N'59', N'42', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'305', N'59', N'43', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'306', N'59', N'44', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'307', N'59', N'45', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'308', N'59', N'46', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'309', N'59', N'47', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'310', N'59', N'48', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'311', N'59', N'49', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'312', N'59', N'50', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'313', N'59', N'51', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'314', N'59', N'52', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'315', N'59', N'53', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'316', N'59', N'54', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'317', N'59', N'55', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'318', N'59', N'56', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'319', N'59', N'57', N'20', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'320', N'59', N'58', N'21', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'321', N'59', N'59', N'22', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'322', N'59', N'60', N'23', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'323', N'59', N'61', N'24', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'324', N'59', N'62', N'25', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'325', N'59', N'63', N'26', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'326', N'59', N'64', N'27', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'327', N'59', N'65', N'28', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'328', N'59', N'66', N'29', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'329', N'59', N'67', N'30', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'330', N'59', N'68', N'31', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'331', N'59', N'69', N'32', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'332', N'59', N'70', N'33', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'333', N'59', N'71', N'34', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'334', N'59', N'72', N'35', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'335', N'59', N'73', N'36', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'336', N'59', N'74', N'37', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'337', N'59', N'75', N'38', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'338', N'59', N'76', N'39', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'339', N'59', N'77', N'40', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'340', N'59', N'78', N'41', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'341', N'59', N'79', N'42', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'342', N'59', N'80', N'43', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'343', N'59', N'81', N'44', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'344', N'59', N'82', N'45', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'345', N'59', N'83', N'46', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'346', N'59', N'84', N'47', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'347', N'59', N'85', N'48', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'348', N'59', N'86', N'49', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'349', N'59', N'87', N'50', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'350', N'59', N'88', N'51', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'351', N'59', N'89', N'52', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'352', N'59', N'90', N'53', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'353', N'59', N'91', N'54', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'354', N'59', N'92', N'55', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'355', N'59', N'93', N'56', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'356', N'59', N'94', N'57', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'357', N'59', N'95', N'58', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'358', N'59', N'96', N'59', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'359', N'59', N'97', N'60', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'360', N'59', N'98', N'61', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'361', N'59', N'99', N'62', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'362', N'59', N'100', N'63', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'363', N'59', N'101', N'64', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'364', N'59', N'102', N'65', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'365', N'59', N'103', N'66', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'366', N'59', N'104', N'67', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'367', N'59', N'105', N'68', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'368', N'59', N'106', N'69', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'369', N'59', N'107', N'70', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'370', N'59', N'108', N'71', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'371', N'59', N'109', N'72', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'372', N'59', N'110', N'73', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'373', N'59', N'111', N'74', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'374', N'59', N'112', N'75', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'375', N'59', N'113', N'76', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'376', N'59', N'114', N'77', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'377', N'59', N'115', N'78', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'378', N'59', N'116', N'79', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'379', N'59', N'117', N'80', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'380', N'59', N'118', N'81', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'381', N'59', N'119', N'82', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'382', N'59', N'120', N'83', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'383', N'60', N'37', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'384', N'60', N'38', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'385', N'60', N'39', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'386', N'60', N'40', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'387', N'60', N'41', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'388', N'60', N'42', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'389', N'60', N'43', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'390', N'60', N'44', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'391', N'60', N'45', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'392', N'60', N'46', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'393', N'60', N'47', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'394', N'60', N'48', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'395', N'60', N'49', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'396', N'60', N'50', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'397', N'60', N'51', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'398', N'60', N'52', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'399', N'60', N'53', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'400', N'60', N'54', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'401', N'60', N'55', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'402', N'60', N'56', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'403', N'60', N'57', N'20', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'404', N'60', N'58', N'21', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'405', N'60', N'59', N'22', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'406', N'60', N'60', N'23', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'407', N'60', N'61', N'24', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'408', N'60', N'62', N'25', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'409', N'60', N'63', N'26', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'410', N'60', N'64', N'27', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'411', N'60', N'65', N'28', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'412', N'60', N'66', N'29', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'413', N'60', N'67', N'30', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'414', N'60', N'68', N'31', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'415', N'60', N'69', N'32', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'416', N'60', N'70', N'33', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'417', N'60', N'71', N'34', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'418', N'60', N'72', N'35', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'419', N'60', N'73', N'36', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'420', N'60', N'74', N'37', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'421', N'60', N'75', N'38', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'422', N'60', N'76', N'39', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'423', N'60', N'77', N'40', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'424', N'60', N'78', N'41', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'425', N'60', N'79', N'42', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'426', N'60', N'80', N'43', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'427', N'60', N'81', N'44', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'428', N'60', N'82', N'45', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'429', N'60', N'83', N'46', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'430', N'60', N'84', N'47', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'431', N'60', N'85', N'48', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'432', N'60', N'86', N'49', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'433', N'60', N'87', N'50', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'434', N'60', N'88', N'51', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'435', N'60', N'89', N'52', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'436', N'60', N'90', N'53', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'437', N'60', N'91', N'54', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'438', N'60', N'92', N'55', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'439', N'60', N'93', N'56', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'440', N'60', N'94', N'57', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'441', N'60', N'95', N'58', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'442', N'60', N'96', N'59', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'443', N'60', N'97', N'60', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'444', N'60', N'98', N'61', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'445', N'60', N'99', N'62', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'446', N'60', N'100', N'63', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'447', N'60', N'101', N'64', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'448', N'60', N'102', N'65', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'449', N'60', N'103', N'66', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'450', N'60', N'104', N'67', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'451', N'60', N'105', N'68', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'452', N'60', N'106', N'69', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'453', N'60', N'107', N'70', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'454', N'60', N'108', N'71', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'455', N'60', N'109', N'72', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'456', N'60', N'110', N'73', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'457', N'60', N'111', N'74', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'458', N'60', N'112', N'75', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'459', N'60', N'113', N'76', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'460', N'60', N'114', N'77', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'461', N'60', N'115', N'78', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'462', N'60', N'116', N'79', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'463', N'60', N'117', N'80', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'464', N'60', N'118', N'81', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'465', N'60', N'119', N'82', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'466', N'60', N'120', N'83', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'467', N'61', N'121', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'468', N'61', N'122', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'469', N'61', N'123', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'470', N'61', N'124', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'471', N'61', N'125', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'472', N'61', N'126', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'473', N'61', N'127', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'474', N'61', N'128', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'475', N'61', N'129', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'476', N'61', N'130', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'477', N'61', N'131', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'478', N'61', N'132', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'479', N'61', N'133', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'480', N'61', N'134', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'481', N'61', N'135', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'482', N'61', N'136', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'483', N'61', N'137', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'484', N'61', N'138', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'485', N'61', N'139', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'486', N'61', N'140', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'487', N'62', N'121', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'488', N'62', N'122', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'489', N'62', N'123', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'490', N'62', N'124', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'491', N'62', N'125', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'492', N'62', N'126', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'493', N'62', N'127', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'494', N'62', N'128', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'495', N'62', N'129', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'496', N'62', N'130', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'497', N'62', N'131', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'498', N'62', N'132', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'499', N'62', N'133', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'500', N'62', N'134', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'501', N'62', N'135', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'502', N'62', N'136', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'503', N'62', N'137', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'504', N'62', N'138', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'505', N'62', N'139', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'506', N'62', N'140', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'507', N'63', N'121', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'508', N'63', N'122', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'509', N'63', N'123', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'510', N'63', N'124', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'511', N'63', N'125', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'512', N'63', N'126', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'513', N'63', N'127', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'514', N'63', N'128', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'515', N'63', N'129', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'516', N'63', N'130', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'517', N'63', N'131', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'518', N'63', N'132', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'519', N'63', N'133', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'520', N'63', N'134', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'521', N'63', N'135', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'522', N'63', N'136', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'523', N'63', N'137', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'524', N'63', N'138', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'525', N'63', N'139', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'526', N'63', N'140', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'527', N'64', N'121', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'528', N'64', N'122', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'529', N'64', N'123', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'530', N'64', N'124', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'531', N'64', N'125', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'532', N'64', N'126', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'533', N'64', N'127', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'534', N'64', N'128', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'535', N'64', N'129', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'536', N'64', N'130', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'537', N'64', N'131', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'538', N'64', N'132', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'539', N'64', N'133', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'540', N'64', N'134', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'541', N'64', N'135', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'542', N'64', N'136', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'543', N'64', N'137', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'544', N'64', N'138', N'17', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'545', N'64', N'139', N'18', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'546', N'64', N'140', N'19', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'547', N'65', N'141', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'548', N'65', N'142', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'549', N'65', N'143', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'550', N'65', N'144', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'551', N'65', N'145', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'552', N'65', N'146', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'553', N'65', N'147', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'554', N'65', N'148', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'555', N'65', N'149', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'556', N'65', N'150', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'557', N'66', N'141', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'558', N'66', N'142', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'559', N'66', N'143', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'560', N'66', N'144', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'561', N'66', N'145', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'562', N'66', N'146', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'563', N'66', N'147', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'564', N'66', N'148', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'565', N'66', N'149', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'566', N'66', N'150', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'567', N'67', N'141', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'568', N'67', N'142', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'569', N'67', N'143', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'570', N'67', N'144', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'571', N'67', N'145', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'572', N'67', N'146', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'573', N'67', N'147', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'574', N'67', N'148', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'575', N'67', N'149', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'576', N'67', N'150', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'577', N'68', N'141', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'578', N'68', N'142', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'579', N'68', N'143', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'580', N'68', N'144', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'581', N'68', N'145', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'582', N'68', N'146', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'583', N'68', N'147', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'584', N'68', N'148', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'585', N'68', N'149', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'586', N'68', N'150', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'587', N'69', N'156', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'588', N'69', N'157', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'589', N'69', N'158', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'590', N'69', N'159', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'591', N'69', N'160', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'592', N'69', N'161', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'593', N'69', N'162', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'594', N'69', N'163', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'595', N'69', N'164', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'596', N'69', N'165', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'597', N'69', N'166', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'598', N'69', N'167', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'599', N'69', N'168', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'600', N'69', N'169', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'601', N'70', N'156', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'602', N'70', N'157', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'603', N'70', N'158', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'604', N'70', N'159', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'605', N'70', N'160', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'606', N'70', N'161', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'607', N'70', N'162', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'608', N'70', N'163', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'609', N'70', N'164', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'610', N'70', N'165', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'611', N'70', N'166', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'612', N'70', N'167', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'613', N'70', N'168', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'614', N'70', N'169', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'615', N'71', N'156', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'616', N'71', N'157', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'617', N'71', N'158', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'618', N'71', N'159', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'619', N'71', N'160', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'620', N'71', N'161', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'621', N'71', N'162', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'622', N'71', N'163', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'623', N'71', N'164', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'624', N'71', N'165', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'625', N'71', N'166', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'626', N'71', N'167', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'627', N'71', N'168', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'628', N'71', N'169', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'629', N'72', N'156', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'630', N'72', N'157', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'631', N'72', N'158', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'632', N'72', N'159', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'633', N'72', N'160', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'634', N'72', N'161', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'635', N'72', N'162', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'636', N'72', N'163', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'637', N'72', N'164', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'638', N'72', N'165', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'639', N'72', N'166', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'640', N'72', N'167', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'641', N'72', N'168', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'642', N'72', N'169', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'643', N'6', N'1', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'644', N'7', N'1', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'645', N'9', N'1', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'646', N'22', N'2', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'647', N'23', N'2', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'648', N'24', N'2', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'649', N'36', N'3', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'650', N'37', N'3', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'651', N'39', N'3', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'652', N'83', N'170', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'653', N'83', N'171', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'654', N'83', N'172', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'655', N'86', N'173', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'656', N'86', N'174', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'657', N'86', N'175', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'658', N'89', N'176', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'659', N'89', N'177', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'660', N'89', N'178', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'661', N'92', N'179', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'662', N'92', N'180', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'663', N'92', N'181', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'664', N'95', N'182', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'665', N'95', N'183', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'666', N'95', N'184', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'667', N'98', N'185', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'668', N'98', N'186', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'669', N'98', N'187', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'670', N'101', N'188', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'671', N'101', N'189', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'672', N'101', N'190', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'673', N'105', N'192', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'674', N'105', N'193', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'675', N'105', N'194', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'676', N'108', N'195', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'677', N'108', N'196', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'678', N'108', N'197', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'679', N'108', N'198', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'680', N'108', N'199', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'681', N'108', N'200', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'682', N'108', N'201', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'683', N'111', N'202', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'684', N'115', N'203', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'685', N'118', N'202', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'686', N'121', N'203', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'687', N'124', N'206', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'688', N'84', N'170', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'689', N'84', N'171', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'690', N'84', N'172', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'691', N'87', N'173', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'692', N'87', N'174', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'693', N'87', N'175', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'694', N'90', N'176', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'695', N'90', N'177', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'696', N'90', N'178', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'697', N'93', N'179', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'698', N'93', N'180', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'699', N'93', N'181', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'700', N'96', N'182', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'701', N'96', N'183', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'702', N'96', N'184', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'703', N'99', N'185', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'704', N'99', N'186', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'705', N'99', N'187', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'706', N'102', N'188', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'707', N'102', N'189', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'708', N'102', N'190', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'709', N'106', N'192', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'710', N'106', N'193', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'711', N'106', N'194', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'712', N'109', N'195', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'713', N'109', N'196', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'714', N'109', N'197', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'715', N'109', N'198', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'716', N'109', N'199', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'717', N'109', N'200', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'718', N'109', N'201', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'719', N'112', N'202', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'720', N'116', N'203', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'721', N'119', N'202', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'722', N'122', N'203', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'723', N'125', N'206', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'724', N'85', N'170', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'725', N'85', N'171', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'726', N'85', N'172', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'727', N'88', N'173', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'728', N'88', N'174', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'729', N'88', N'175', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'730', N'91', N'176', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'731', N'91', N'177', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'732', N'91', N'178', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'733', N'94', N'179', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'734', N'94', N'180', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'735', N'94', N'181', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'736', N'97', N'182', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'737', N'97', N'183', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'738', N'97', N'184', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'739', N'100', N'185', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'740', N'100', N'186', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'741', N'100', N'187', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'742', N'103', N'188', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'743', N'103', N'189', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'744', N'103', N'190', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'745', N'107', N'192', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'746', N'107', N'193', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'747', N'107', N'194', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'748', N'110', N'195', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'749', N'110', N'196', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'750', N'110', N'197', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'751', N'110', N'198', N'0', N'3')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'752', N'110', N'199', N'0', N'4')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'753', N'110', N'200', N'0', N'5')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'754', N'110', N'201', N'0', N'6')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'755', N'114', N'202', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'756', N'117', N'203', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'757', N'120', N'202', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'758', N'123', N'203', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'759', N'126', N'206', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'761', N'130', N'172', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'762', N'130', N'171', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'763', N'130', N'208', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'764', N'130', N'209', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'765', N'130', N'211', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'766', N'130', N'212', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'767', N'130', N'213', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'768', N'130', N'214', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'769', N'130', N'215', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'770', N'130', N'216', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'771', N'130', N'217', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'772', N'130', N'218', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'773', N'130', N'219', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'774', N'130', N'220', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'775', N'130', N'221', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'776', N'131', N'222', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'777', N'132', N'223', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'778', N'133', N'224', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'788', N'144', N'215', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'789', N'152', N'170', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'790', N'152', N'171', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'791', N'152', N'172', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'792', N'159', N'170', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'793', N'159', N'171', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'794', N'159', N'172', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'795', N'161', N'170', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'796', N'161', N'171', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'797', N'161', N'172', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'798', N'163', N'173', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'799', N'163', N'174', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'800', N'163', N'175', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'801', N'164', N'173', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'802', N'164', N'174', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'803', N'164', N'175', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'804', N'168', N'173', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'805', N'168', N'174', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'806', N'168', N'175', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'807', N'171', N'176', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'808', N'171', N'177', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'809', N'171', N'178', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'810', N'172', N'176', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'811', N'172', N'177', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'812', N'172', N'178', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'813', N'173', N'176', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'814', N'173', N'177', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'815', N'173', N'178', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'816', N'174', N'179', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'817', N'174', N'180', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'818', N'174', N'181', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'819', N'175', N'179', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'820', N'175', N'180', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'821', N'175', N'181', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'822', N'176', N'179', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'823', N'176', N'180', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'824', N'176', N'181', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'825', N'177', N'225', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'826', N'177', N'226', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'827', N'177', N'227', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'828', N'178', N'225', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'829', N'178', N'226', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'830', N'178', N'227', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'831', N'179', N'225', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'832', N'179', N'226', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'833', N'179', N'227', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'834', N'180', N'202', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'835', N'181', N'202', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'836', N'182', N'202', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'837', N'183', N'203', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'838', N'184', N'203', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'839', N'185', N'203', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'840', N'186', N'294', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'841', N'188', N'294', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'842', N'190', N'294', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'843', N'191', N'213', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'844', N'191', N'228', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'845', N'191', N'229', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'846', N'191', N'214', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'847', N'193', N'213', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'848', N'193', N'228', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'849', N'193', N'229', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'850', N'193', N'214', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'851', N'194', N'213', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'852', N'194', N'228', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'853', N'194', N'229', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'854', N'194', N'214', N'0', N'3')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'855', N'197', N'291', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'856', N'198', N'291', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'857', N'199', N'291', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'858', N'200', N'215', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'859', N'201', N'215', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'860', N'202', N'294', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'861', N'203', N'294', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'862', N'205', N'216', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'863', N'206', N'216', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'864', N'209', N'232', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'865', N'210', N'232', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'866', N'212', N'232', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'867', N'213', N'294', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'868', N'214', N'294', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'869', N'215', N'294', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'870', N'216', N'217', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'871', N'218', N'217', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'872', N'219', N'217', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'873', N'220', N'234', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'874', N'220', N'235', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'875', N'220', N'236', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'876', N'222', N'234', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'877', N'222', N'235', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'878', N'222', N'236', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'879', N'223', N'234', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'880', N'223', N'235', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'881', N'223', N'236', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'882', N'225', N'237', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'883', N'225', N'238', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'884', N'225', N'239', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'885', N'225', N'240', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'886', N'225', N'241', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'887', N'226', N'237', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'888', N'226', N'238', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'889', N'226', N'239', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'890', N'226', N'240', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'891', N'226', N'241', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'892', N'227', N'237', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'893', N'227', N'238', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'894', N'227', N'239', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'895', N'227', N'240', N'0', N'3')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'896', N'227', N'241', N'0', N'4')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'897', N'228', N'290', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'898', N'229', N'290', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'899', N'230', N'290', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'900', N'231', N'222', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'901', N'232', N'222', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'902', N'233', N'222', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'903', N'234', N'321', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'904', N'235', N'321', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'905', N'236', N'321', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'906', N'238', N'245', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'907', N'239', N'245', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'908', N'240', N'245', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'909', N'241', N'246', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'910', N'241', N'247', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'911', N'241', N'248', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'912', N'241', N'249', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'913', N'241', N'250', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'914', N'241', N'251', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'915', N'241', N'252', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'916', N'241', N'253', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'917', N'241', N'254', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'918', N'241', N'255', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'919', N'241', N'256', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'920', N'241', N'257', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'921', N'241', N'258', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'922', N'241', N'259', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'923', N'242', N'246', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'924', N'242', N'247', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'925', N'242', N'248', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'926', N'242', N'249', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'927', N'242', N'250', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'928', N'242', N'251', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'929', N'242', N'252', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'930', N'242', N'253', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'931', N'242', N'254', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'932', N'242', N'255', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'933', N'242', N'256', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'934', N'242', N'257', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'935', N'242', N'258', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'936', N'242', N'259', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'937', N'246', N'246', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'938', N'246', N'247', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'939', N'246', N'248', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'940', N'246', N'249', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'941', N'246', N'250', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'942', N'246', N'251', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'943', N'246', N'252', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'944', N'246', N'253', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'945', N'246', N'254', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'946', N'246', N'255', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'947', N'246', N'256', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'948', N'246', N'257', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'949', N'246', N'258', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'950', N'246', N'259', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'951', N'247', N'246', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'952', N'247', N'247', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'953', N'247', N'248', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'954', N'247', N'249', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'955', N'247', N'250', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'956', N'247', N'251', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'957', N'247', N'252', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'958', N'247', N'253', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'959', N'247', N'254', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'960', N'247', N'255', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'961', N'247', N'256', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'962', N'247', N'257', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'963', N'247', N'258', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'964', N'247', N'259', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'965', N'248', N'244', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'966', N'249', N'244', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'967', N'250', N'244', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'968', N'258', N'260', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'969', N'258', N'261', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'970', N'259', N'260', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'971', N'259', N'261', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'972', N'260', N'260', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'973', N'260', N'261', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'974', N'261', N'262', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'975', N'261', N'263', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'976', N'261', N'264', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'977', N'262', N'262', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'978', N'262', N'263', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'979', N'262', N'264', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'980', N'263', N'262', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'981', N'263', N'263', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'982', N'263', N'264', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'983', N'264', N'265', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'984', N'266', N'265', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'985', N'267', N'265', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'986', N'268', N'266', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'987', N'269', N'266', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'988', N'270', N'266', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'989', N'271', N'280', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'990', N'271', N'281', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'991', N'271', N'282', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'992', N'271', N'283', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'993', N'271', N'284', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'994', N'271', N'285', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'995', N'271', N'286', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'996', N'271', N'287', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'997', N'271', N'288', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'998', N'271', N'289', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'999', N'271', N'298', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1000', N'271', N'322', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1001', N'272', N'280', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1002', N'272', N'281', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1003', N'272', N'282', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1004', N'272', N'283', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1005', N'272', N'284', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1006', N'272', N'285', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1007', N'272', N'286', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1008', N'272', N'287', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1009', N'272', N'288', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1010', N'272', N'289', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1011', N'272', N'298', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1012', N'272', N'322', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1015', N'275', N'280', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1016', N'275', N'281', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1017', N'275', N'282', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1018', N'275', N'283', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1019', N'275', N'284', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1020', N'275', N'285', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1021', N'275', N'286', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1022', N'275', N'287', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1023', N'275', N'288', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1024', N'275', N'289', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1025', N'275', N'298', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1026', N'275', N'322', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1027', N'276', N'280', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1028', N'276', N'281', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1029', N'276', N'282', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1030', N'276', N'283', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1031', N'276', N'284', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1032', N'276', N'285', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1033', N'276', N'286', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1034', N'276', N'287', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1035', N'276', N'288', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1036', N'276', N'289', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1037', N'276', N'298', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1038', N'276', N'322', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1039', N'277', N'290', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1040', N'277', N'291', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1041', N'277', N'292', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1042', N'277', N'293', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1043', N'277', N'294', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1044', N'277', N'295', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1045', N'277', N'296', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1046', N'277', N'297', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1047', N'278', N'290', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1048', N'278', N'291', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1049', N'278', N'292', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1050', N'278', N'293', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1051', N'278', N'294', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1052', N'278', N'295', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1053', N'278', N'296', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1054', N'278', N'297', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1055', N'279', N'290', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1056', N'279', N'291', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1057', N'279', N'292', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1058', N'279', N'293', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1059', N'279', N'294', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1060', N'279', N'295', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1061', N'279', N'296', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1062', N'279', N'297', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1063', N'280', N'290', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1064', N'280', N'291', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1065', N'280', N'292', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1066', N'280', N'293', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1067', N'280', N'294', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1068', N'280', N'295', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1069', N'280', N'296', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1070', N'280', N'297', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1071', N'281', N'299', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1072', N'281', N'300', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1073', N'281', N'301', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1074', N'283', N'299', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1075', N'283', N'300', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1076', N'283', N'301', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1077', N'284', N'299', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1078', N'284', N'300', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1079', N'284', N'301', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1134', N'285', N'302', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1135', N'286', N'302', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1137', N'287', N'302', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1138', N'288', N'303', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1139', N'288', N'304', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1140', N'288', N'305', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1141', N'288', N'306', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1142', N'289', N'303', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1143', N'289', N'304', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1144', N'289', N'305', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1145', N'289', N'306', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1146', N'290', N'303', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1147', N'290', N'304', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1148', N'290', N'305', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1149', N'290', N'306', N'0', N'3')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1150', N'291', N'307', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1151', N'292', N'307', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1152', N'293', N'307', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1153', N'294', N'308', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1154', N'294', N'309', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1155', N'294', N'310', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1156', N'294', N'311', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1157', N'294', N'312', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1158', N'294', N'323', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1159', N'295', N'308', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1160', N'295', N'309', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1161', N'295', N'310', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1162', N'295', N'311', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1163', N'295', N'312', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1164', N'295', N'323', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1165', N'296', N'308', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1166', N'296', N'309', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1167', N'296', N'310', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1168', N'296', N'311', N'0', N'3')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1169', N'296', N'312', N'0', N'4')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1170', N'296', N'323', N'0', N'5')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1171', N'297', N'313', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1172', N'298', N'313', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1173', N'299', N'313', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1174', N'300', N'314', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1175', N'300', N'315', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1176', N'300', N'316', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1177', N'300', N'317', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1178', N'300', N'318', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1179', N'304', N'314', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1180', N'304', N'315', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1181', N'304', N'316', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1182', N'304', N'317', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1183', N'304', N'318', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1184', N'305', N'314', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1185', N'305', N'315', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1186', N'305', N'316', N'0', N'2')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1187', N'305', N'317', N'0', N'3')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1188', N'305', N'318', N'0', N'4')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1189', N'306', N'319', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1190', N'306', N'320', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1191', N'307', N'319', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1192', N'307', N'320', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1193', N'309', N'319', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1194', N'309', N'320', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1195', N'310', N'321', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1196', N'311', N'321', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1197', N'312', N'321', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1198', N'313', N'324', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1199', N'313', N'325', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1200', N'314', N'324', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1201', N'314', N'325', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1202', N'315', N'324', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1203', N'315', N'325', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1204', N'316', N'267', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1205', N'316', N'268', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1206', N'316', N'269', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1207', N'316', N'270', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1208', N'316', N'271', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1209', N'316', N'272', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1210', N'316', N'273', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1211', N'316', N'274', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1212', N'316', N'275', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1213', N'316', N'276', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1214', N'316', N'277', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1215', N'316', N'278', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1216', N'316', N'279', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1217', N'317', N'267', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1218', N'317', N'268', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1219', N'317', N'269', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1220', N'317', N'270', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1221', N'317', N'271', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1222', N'317', N'272', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1223', N'317', N'273', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1224', N'317', N'274', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1225', N'317', N'275', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1226', N'317', N'276', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1227', N'317', N'277', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1228', N'317', N'278', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1229', N'317', N'279', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1230', N'319', N'267', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1231', N'319', N'268', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1232', N'319', N'269', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1233', N'319', N'270', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1234', N'319', N'271', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1235', N'319', N'272', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1236', N'319', N'273', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1237', N'319', N'274', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1238', N'319', N'275', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1239', N'319', N'276', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1240', N'319', N'277', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1241', N'319', N'278', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1242', N'319', N'279', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1243', N'320', N'267', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1244', N'320', N'268', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1245', N'320', N'269', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1246', N'320', N'270', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1247', N'320', N'271', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1248', N'320', N'272', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1249', N'320', N'273', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1250', N'320', N'274', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1251', N'320', N'275', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1252', N'320', N'276', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1253', N'320', N'277', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1254', N'320', N'278', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1255', N'320', N'279', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1256', N'330', N'326', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1257', N'330', N'327', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1258', N'330', N'328', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1259', N'330', N'329', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1260', N'330', N'330', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1261', N'330', N'331', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1262', N'330', N'332', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1263', N'330', N'333', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1264', N'331', N'326', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1265', N'331', N'327', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1266', N'331', N'328', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1267', N'331', N'329', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1268', N'331', N'330', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1269', N'331', N'331', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1270', N'331', N'332', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1271', N'331', N'333', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1272', N'332', N'326', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1273', N'332', N'327', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1274', N'332', N'328', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1275', N'332', N'329', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1276', N'332', N'330', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1277', N'332', N'331', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1278', N'332', N'332', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1279', N'332', N'333', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1280', N'333', N'326', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1281', N'333', N'327', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1282', N'333', N'328', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1283', N'333', N'329', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1284', N'333', N'330', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1285', N'333', N'331', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1286', N'333', N'332', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1287', N'333', N'333', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1288', N'334', N'334', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1289', N'334', N'335', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1290', N'334', N'336', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1291', N'334', N'337', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1292', N'334', N'338', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1293', N'334', N'339', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1294', N'334', N'340', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1295', N'334', N'341', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1296', N'334', N'342', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1297', N'334', N'343', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1298', N'334', N'344', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1299', N'334', N'345', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1300', N'334', N'346', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1301', N'334', N'347', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1302', N'334', N'348', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1303', N'334', N'349', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1304', N'334', N'350', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1305', N'335', N'334', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1306', N'335', N'335', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1307', N'335', N'336', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1308', N'335', N'337', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1309', N'335', N'338', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1310', N'335', N'339', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1311', N'335', N'340', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1312', N'335', N'341', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1313', N'335', N'342', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1314', N'335', N'343', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1315', N'335', N'344', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1316', N'335', N'345', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1317', N'335', N'346', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1318', N'335', N'347', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1319', N'335', N'348', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1320', N'335', N'349', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1321', N'335', N'350', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1322', N'336', N'334', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1323', N'336', N'335', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1324', N'336', N'336', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1325', N'336', N'337', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1326', N'336', N'338', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1327', N'336', N'339', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1328', N'336', N'340', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1329', N'336', N'341', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1330', N'336', N'342', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1331', N'336', N'343', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1332', N'336', N'344', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1333', N'336', N'345', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1334', N'336', N'346', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1335', N'336', N'347', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1336', N'336', N'348', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1337', N'336', N'349', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1338', N'336', N'350', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1339', N'337', N'334', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1340', N'337', N'335', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1341', N'337', N'336', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1342', N'337', N'337', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1343', N'337', N'338', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1344', N'337', N'339', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1345', N'337', N'340', N'6', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1346', N'337', N'341', N'7', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1347', N'337', N'342', N'8', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1348', N'337', N'343', N'9', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1349', N'337', N'344', N'10', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1350', N'337', N'345', N'11', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1351', N'337', N'346', N'12', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1352', N'337', N'347', N'13', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1353', N'337', N'348', N'14', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1354', N'337', N'349', N'15', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1355', N'337', N'350', N'16', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1356', N'339', N'351', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1357', N'339', N'352', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1358', N'339', N'353', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1359', N'339', N'354', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1360', N'339', N'355', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1361', N'339', N'356', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1362', N'340', N'351', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1363', N'340', N'352', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1364', N'340', N'353', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1365', N'340', N'354', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1366', N'340', N'355', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1367', N'340', N'356', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1368', N'341', N'351', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1369', N'341', N'352', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1370', N'341', N'353', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1371', N'341', N'354', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1372', N'341', N'355', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1373', N'341', N'356', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1374', N'342', N'351', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1375', N'342', N'352', N'1', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1376', N'342', N'353', N'2', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1377', N'342', N'354', N'3', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1378', N'342', N'355', N'4', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1379', N'342', N'356', N'5', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1380', N'207', N'216', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1381', N'352', N'170', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1382', N'353', N'171', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1383', N'354', N'172', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1384', N'356', N'173', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1385', N'357', N'174', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1386', N'358', N'175', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1387', N'359', N'176', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1388', N'360', N'177', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1389', N'361', N'178', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1390', N'362', N'179', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1391', N'363', N'180', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1392', N'364', N'181', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1393', N'365', N'182', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1394', N'366', N'183', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1395', N'367', N'184', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1396', N'368', N'213', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1397', N'369', N'229', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1398', N'370', N'214', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1399', N'371', N'215', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1400', N'372', N'216', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1401', N'373', N'220', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1402', N'374', N'221', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1403', N'375', N'185', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1404', N'376', N'186', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1405', N'377', N'187', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1406', N'378', N'188', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1407', N'379', N'189', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1408', N'380', N'190', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1409', N'381', N'192', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1410', N'382', N'193', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1411', N'383', N'194', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1412', N'384', N'357', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1413', N'385', N'358', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1414', N'388', N'360', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1415', N'389', N'361', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1416', N'390', N'362', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1417', N'392', N'363', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1418', N'393', N'364', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1419', N'394', N'365', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1420', N'404', N'366', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1421', N'397', N'360', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1422', N'398', N'361', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1423', N'399', N'362', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1424', N'400', N'363', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1425', N'401', N'364', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1426', N'402', N'365', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1427', N'403', N'366', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1428', N'413', N'359', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1429', N'57', N'119', N'82', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1430', N'57', N'120', N'83', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1431', N'57', N'367', N'84', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1432', N'57', N'368', N'85', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1433', N'58', N'367', N'84', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1434', N'58', N'368', N'85', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1435', N'59', N'367', N'84', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1436', N'59', N'368', N'85', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1437', N'60', N'367', N'84', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1438', N'60', N'368', N'84', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1439', N'428', N'456', NULL, NULL)
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1440', N'429', N'456', NULL, NULL)
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1441', N'430', N'456', NULL, NULL)
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1442', N'431', N'456', NULL, NULL)
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1443', N'432', N'456', NULL, NULL)
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1444', N'433', N'456', NULL, NULL)
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1445', N'434', N'2', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1446', N'435', N'2', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1447', N'436', N'2', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1448', N'437', N'2', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1449', N'438', N'2', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1450', N'439', N'2', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1451', N'454', N'496', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1452', N'455', N'496', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1453', N'465', N'225', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1454', N'466', N'212', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1455', N'464', N'498', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1456', N'456', N'292', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1457', N'457', N'290', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1458', N'458', N'291', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1459', N'459', N'296', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1460', N'459', N'293', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1461', N'460', N'292', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1462', N'461', N'290', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1463', N'462', N'291', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1464', N'463', N'296', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1465', N'463', N'293', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1466', N'461', N'290', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1467', N'457', N'290', N'0', N'1')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1468', N'470', N'217', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1469', N'471', N'217', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1470', N'472', N'234', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1471', N'473', N'234', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1472', N'474', N'234', N'0', N'0')
GO

INSERT INTO [Forms].[QuestionEmissionActivity] ([id], [questionId], [emissionActivityId], [rowNo], [columnNo]) VALUES (N'1473', N'475', N'237', N'0', N'0')
GO

SET IDENTITY_INSERT [Forms].[QuestionEmissionActivity] OFF
GO


-- ----------------------------
-- Auto increment value for JotForm
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[JotForm]', RESEED, 16)
GO


-- ----------------------------
-- Primary Key structure for table JotForm
-- ----------------------------
ALTER TABLE [Forms].[JotForm] ADD CONSTRAINT [PK__NczForm___3213E83F63FAB3B4] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Question
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[Question]', RESEED, 492)
GO


-- ----------------------------
-- Primary Key structure for table Question
-- ----------------------------
ALTER TABLE [Forms].[Question] ADD CONSTRAINT [PK__Question__3213E83F97FB3CBA] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for QuestionEmissionActivity
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[QuestionEmissionActivity]', RESEED, 1477)
GO


-- ----------------------------
-- Primary Key structure for table QuestionEmissionActivity
-- ----------------------------
ALTER TABLE [Forms].[QuestionEmissionActivity] ADD CONSTRAINT [PK__Question__3213E83FC7C1EF24] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

