/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Documents

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:30:07
*/


-- ----------------------------
-- Table structure for Document
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[Document]') AND type IN ('U'))
	DROP TABLE [Documents].[Document]
GO

CREATE TABLE [Documents].[Document] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [parentEntityId] int  NOT NULL,
  [parentEntityType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [customerId] int  NULL,
  [container] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [blobName] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [title] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [singleInstance] bit DEFAULT 0 NULL,
  [canEmbed] bit DEFAULT 0 NULL,
  [modifiedDate] bigint  NULL,
  [mimeType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [activeTo] bigint  NULL,
  [size] int DEFAULT 0 NOT NULL,
  [userAccountId] int  NULL
)
GO

ALTER TABLE [Documents].[Document] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Document
-- ----------------------------
SET IDENTITY_INSERT [Documents].[Document] ON
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'2', N'1', N'powerbi', N'1', N'powerbi-reports', N'report001', N'Report-001.pdf', N'0', N'0', NULL, N'application/pdf', NULL, N'12348641', N'1')
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'12', N'2', N'certification-prog', N'1', N'certification-docs', N'certification-prog-2-bcbffbe3-3159-4ce5-b7d1-610e90473398', N'Silver_Award_Document_1.pdf', N'0', N'0', N'1747828682', N'application/pdf', NULL, N'2037', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'13', N'2', N'certification-prog', N'2', N'certification-docs', N'certification-prog-2-66fabd2f-43b9-4107-9d19-722fc34ddc69', N'Silver_Award_Document_2.pdf', N'0', N'0', N'1747828684', N'application/pdf', NULL, N'2037', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'14', N'2', N'certification-prog', N'3', N'certification-docs', N'certification-prog-2-b91dadd9-7af6-4a88-ad8f-0ff5695bfd28', N'Silver_Award_Document_3.pdf', N'0', N'0', N'1747828685', N'application/pdf', NULL, N'2037', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'15', N'3', N'certification-prog', N'1', N'certification-docs', N'certification-prog-3-5e5d14da-41b6-4f50-8ae1-1dfe678a1759', N'Gold_Award_Document_1.pdf', N'0', N'0', N'1747828686', N'application/pdf', NULL, N'2041', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'16', N'3', N'certification-prog', N'2', N'certification-docs', N'certification-prog-3-64a0b2e1-9eb6-4ce1-9e25-750ca0305b21', N'Gold_Award_Document_2.pdf', N'0', N'0', N'1747828687', N'application/pdf', NULL, N'2041', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'17', N'3', N'certification-prog', N'3', N'certification-docs', N'certification-prog-3-b23ce04a-31bb-48ff-8a71-f9389d699ccc', N'Gold_Award_Document_3.pdf', N'0', N'0', N'1747828688', N'application/pdf', NULL, N'2041', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'18', N'4', N'certification-prog', N'1', N'certification-docs', N'certification-prog-4-6d277319-a075-4fbc-88d4-56f212bd92f2', N'Platinum_Award_Document_1.pdf', N'0', N'0', N'1747828689', N'application/pdf', NULL, N'2053', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'19', N'4', N'certification-prog', N'2', N'certification-docs', N'certification-prog-4-5d489607-3a7d-4650-94e0-4c1e4d7be486', N'Platinum_Award_Document_2.pdf', N'0', N'0', N'1747828690', N'application/pdf', NULL, N'2053', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'20', N'4', N'certification-prog', N'3', N'certification-docs', N'certification-prog-4-8327f6bf-d3f7-4f2b-a98d-55df9ee8f770', N'Platinum_Award_Document_3.pdf', N'0', N'0', N'1747828691', N'application/pdf', NULL, N'2053', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'24', N'2', N'certification', N'2', N'certifications', N'certification-2-e781a462-14ca-4d48-bdcb-db5c0c6b900a', N'Silver Report.pdf', N'0', N'0', N'1749462013', N'application/pdf', NULL, N'1324556', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'25', N'1', N'certification', N'1', N'certifications', N'certification-1-3dcd9a4e-e893-48ed-9dde-abe9617a7698', N'Silver Award 2025.pdf', N'0', N'0', N'1749466620', N'application/pdf', NULL, N'1224', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'26', N'2', N'certification', N'2', N'certifications', N'certification-2-ba3caf07-9bbb-4fbe-a8f6-5c57af38deeb', N'Gold Award 2025.pdf', N'0', N'0', N'1749466680', N'application/pdf', NULL, N'1226', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'27', N'4', N'certification', N'3', N'certifications', N'certification-4-9e0a5339-0c6a-4a5e-9ab1-924fe6e1305b', N'Gold Award 2025.pdf', N'0', N'0', N'1749466720', N'application/pdf', NULL, N'1223', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'28', N'1', N'certification', N'1', N'certifications', N'certification-1-ad48a10d-7616-401d-93bb-8753b5f10fba', N'Silver Report 2.pdf', N'0', N'0', N'1749528567', N'application/pdf', NULL, N'1324556', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'29', N'1', N'certification', N'1', N'certifications', N'certification-1-b09898be-59f1-45d8-8c7f-81b4392845b2', N'Blue Report 2025.pdf', N'0', N'0', N'1749531230', N'application/pdf', NULL, N'1324556', NULL)
GO

INSERT INTO [Documents].[Document] ([id], [parentEntityId], [parentEntityType], [customerId], [container], [blobName], [title], [singleInstance], [canEmbed], [modifiedDate], [mimeType], [activeTo], [size], [userAccountId]) VALUES (N'30', N'9', N'certification', N'21', N'certifications', N'certification-9-4a4cde23-966c-4e89-8130-bbdc6609c6c9', N'Phi Tech Gold award 2025.pdf', N'0', N'0', N'1749532860', N'application/pdf', NULL, N'1223', NULL)
GO

SET IDENTITY_INSERT [Documents].[Document] OFF
GO


-- ----------------------------
-- procedure structure for spDocument_Delete
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_Delete]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_Delete]
GO

CREATE PROCEDURE [Documents].[spDocument_Delete]
    @id INT
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @now bigint = [utilities].DateToEpoch(null);
	UPDATE [documents].[Document] SET [activeTo] = @now WHERE [id] = @id;

END
GO


-- ----------------------------
-- procedure structure for spDocument_CreateVersion
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_CreateVersion]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_CreateVersion]
GO

CREATE PROCEDURE [Documents].[spDocument_CreateVersion]
   @documentId int
	,@parentDocId int
	,@uid nvarchar(50) = NULL
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @now BIGINT = utilities.DatetoEpoch(GetDate());
	DECLARE @version int = (SELECT ISNULL([version], 0) FROM [documents].[DocumentVersion] WHERE [documentId] = @parentDocId)
	
	DECLARE @userACcountId INT = NULL
	IF @uid IS NOT NULL 
		SET @userAccountId = (SELECT [id] FROM [registrations].[UserAccount] WHERE [uid] = @uid)

	INSERT INTO [documents].[DocumentVersion] (
			[documentId]
			,[parentDocId]
			,[version]
			,[createdDate]
			,[createdBy]
		) VALUES (
			@documentId
			,@parentDocId
			,ISNULL(@version, 0) + 1
			,@now
			,@userACcountId
		)

	RETURN 1;

END
GO


-- ----------------------------
-- procedure structure for spDocument_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_Save]
GO

CREATE PROCEDURE [Documents].[spDocument_Save]
        @parentEntityId INT
        ,@parentEntityType NVARCHAR(100)
        ,@customerId INT = null
        ,@container NVARCHAR(100)
        ,@blobName NVARCHAR(500) = null
        ,@title NVARCHAR(100)
        ,@mimeType [nvarchar](100)
        ,@singleInstance BIT = NULL
        ,@canEmbed BIT -- we can embed image types for instance
        ,@size INT = NULL
        ,@uid nvarchar(50) = NULL
        ,@ownerName nvarchar(100) = NULL
        ,@reviewDate bigint = NULL
		,@reference nvarchar(50) = NULL
AS
BEGIN

	SET NOCOUNT ON;
  
	DECLARE @id int = NULL
	IF @singleInstance = 1 
	BEGIN
		SELECT TOP 1 @id = [id] FROM [documents].[document] WHERE [parentEntityId] = @parentEntityId AND [parentEntityType] = @parentEntityType
	END
	
	DECLARE @userACcountId INT = NULL
	IF @uid IS NOT NULL 
		SET @userAccountId = (SELECT [id] FROM [registrations].[UserAccount] WHERE [uid] = @uid)

	DECLARE @now BIGINT = utilities.DatetoEpoch(GetDate());
	IF @id IS NULL
	BEGIN
		INSERT INTO [documents].[Document] (
			 [parentEntityId]
			,[parentEntityType]
			,[customerId] 
			,[container]
			,[blobName]
			,[title]
			,[mimeType]
			,[singleInstance]
			,[canEmbed]
			,[modifiedDate]
			,[size]
			,[userAccountId]
		) VALUES (
			 @parentEntityId
			,@parentEntityType
			,@customerId
			,@container
			,@blobName
			,@title
			,@mimeType
			,@singleInstance
			,@canEmbed
			,@now
			,ISNULL(@size, 0)
			,@userAccountId
		)
		SET @id = (SCOPE_IDENTITY())
		IF @ownerName IS NOT NULL OR @reviewDate IS NOT NULL OR @reference IS NOT NULL
		BEGIN
			INSERT INTO [documents].[DocumentInfo] ([documentId], [owner], [reviewDate], [reference]) VALUES (@id, @ownerName, @reviewDate, @reference)
		END
	END
	ELSE
		UPDATE [documents].[Document]
		   SET [modifiedDate] = @now
				,[title] = @title
				,[container] = @container
				,[blobName] = @blobName
				,[size] = ISNULL(@size, 0)
				,[userAccountId] = @userAccountId
		 WHERE [id] = @id
	
	SELECT *
	  FROM [documents].[Document]
	 WHERE [id] = @id
END
GO


-- ----------------------------
-- procedure structure for spDocument_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_Get]
GO

CREATE PROCEDURE [Documents].[spDocument_Get]
   @documentId int
AS
BEGIN
	SET NOCOUNT ON;
  
	SELECT d.* FROM [documents].[document] d
  WHERE d.[id] = @documentId AND d.[activeTo] IS NULL;

END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectByBlobName
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectByBlobName]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_SelectByBlobName]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectByBlobName]
    @blobName nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT TOP 1 d.*
			,ISNULL(f.sectionId, d.parentEntityId) as sectionId --When there is no folder, we use sectionId as parentEntityId
	  FROM [documents].[document] d
 LEFT JOIN [documents].[Folder] f on f.id = d.parentEntityId AND d.parentEntityType = 'folder'
	 WHERE [blobName] = @blobName;

END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectByIds
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectByIds]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_SelectByIds]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectByIds]
   @ids NVARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT d.*
		,u.displayName as [userDisplayName]
		,u.picture as [userPicture]
		,u.email as [userEmail]
		,di.owner as [ownerName]
		,di.reviewDate
	  FROM [documents].[document] d
	LEFT JOIN [registrations].[UserAccount] u on u.[id] = d.[userAccountId]
	LEFT JOIN [documents].[DocumentInfo] di on di.[documentId] = d.[id]
	 WHERE d.[id] in (SELECT [value] FROM STRING_SPLIT(@ids, ','))
		 AND d.[activeTo] IS NULL
		ORDER BY d.[modifiedDate] DESC
END
GO


-- ----------------------------
-- procedure structure for spDocumentsByContainer
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocumentsByContainer]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocumentsByContainer]
GO

CREATE PROCEDURE [Documents].[spDocumentsByContainer]
  @container NVARCHAR(100) 
AS
BEGIN
	SELECT d.[id]
        ,d.[blobName]
        ,d.[title]
        ,d.[modifiedDate]
        ,d.[mimeType]
        ,df.[name] as [folderName]
        ,dpf.[name] as [parentFolderName]
     FROM [documents].[Document] d 
     LEFT JOIN [documents].[Folder] df ON d.[parentEntityId] = df.[id] AND d.[parentEntityType] = 'folder'
     LEFT JOIN [documents].[Folder] dpf ON df.[parentFolderId] = dpf.[id]
     WHERE d.[container] = @container
     AND d.[activeTo] IS NULL
     AND d.[mimeType] NOT LIKE 'image%'
END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectVersions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectVersions]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_SelectVersions]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectVersions]	
	@documentId INT
AS
BEGIN
  	
	SET NOCOUNT ON;
	
	;With docs as
		(
			SELECT [documentId], [parentDocId] FROM [documents].[DocumentVersion]
			 WHERE [documentId] = @documentId
			 UNION ALL
			SELECT dv.[documentId], dv.[parentDocId] FROM [documents].[DocumentVersion] dv
			 -- Will allow matching to all documents in the upstream hieracrhy
			 INNER JOIN docs d ON dv.[documentId] = d.[parentDocId]
		)

		SELECT d.*
				,u.displayName as [userDisplayName]
				,u.picture as [userPicture]
				,u.email as [userEmail]
	  FROM [documents].[document] d
	LEFT JOIN [registrations].[UserAccount] u on u.[id] = d.[userAccountId]
	 WHERE d.[id] in (select [parentDocId] FROM docs)
		ORDER BY d.[modifiedDate] DESC

END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectForEntity
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectForEntity]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_SelectForEntity]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectForEntity]
    @parentEntityId INT
   ,@parentEntityType NVARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT d.*
                ,u.displayName as [userDisplayName]
                ,u.picture as [userPicture]
                ,u.email as [userEmail]
                ,di.owner as [ownerName]
                ,di.reviewDate
	  FROM [documents].[document] d
	LEFT JOIN [registrations].[UserAccount] u on u.[id] = d.[userAccountId]
	LEFT JOIN [documents].[DocumentInfo] di on di.[documentId] = d.[id]
	 WHERE d.[parentEntityId] = @parentEntityId 
	   AND d.[parentEntityType] = @parentEntityType
		 AND d.[activeTo] IS NULL
		ORDER BY d.[modifiedDate] DESC
END
GO


-- ----------------------------
-- Auto increment value for Document
-- ----------------------------
DBCC CHECKIDENT ('[Documents].[Document]', RESEED, 30)
GO


-- ----------------------------
-- Indexes structure for table Document
-- ----------------------------
CREATE NONCLUSTERED INDEX [IDX_Document_parent]
ON [Documents].[Document] (
  [parentEntityId] ASC,
  [parentEntityType] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table Document
-- ----------------------------
ALTER TABLE [Documents].[Document] ADD CONSTRAINT [PK__Document__3213E83F31DADF25] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

