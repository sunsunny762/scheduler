/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : clickup

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 11/07/2025 10:28:08
*/


-- ----------------------------
-- Table structure for Assignee
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[Assignee]') AND type IN ('U'))
	DROP TABLE [clickup].[Assignee]
GO

CREATE TABLE [clickup].[Assignee] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [taskId] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [userId] bigint  NOT NULL
)
GO

ALTER TABLE [clickup].[Assignee] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for CertificationBuyer
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[CertificationBuyer]') AND type IN ('U'))
	DROP TABLE [clickup].[CertificationBuyer]
GO

CREATE TABLE [clickup].[CertificationBuyer] (
  [certificationTaskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [buyerTaskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [clickup].[CertificationBuyer] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for CompanyCertification
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[CompanyCertification]') AND type IN ('U'))
	DROP TABLE [clickup].[CompanyCertification]
GO

CREATE TABLE [clickup].[CompanyCertification] (
  [companyTaskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [certificationTaskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [clickup].[CompanyCertification] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Configuration
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[Configuration]') AND type IN ('U'))
	DROP TABLE [clickup].[Configuration]
GO

CREATE TABLE [clickup].[Configuration] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [listId] bigint  NOT NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [clickup].[Configuration] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for CustomField
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[CustomField]') AND type IN ('U'))
	DROP TABLE [clickup].[CustomField]
GO

CREATE TABLE [clickup].[CustomField] (
  [id] uniqueidentifier  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [value] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [taskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [type] nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [clickup].[CustomField] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Folder
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[Folder]') AND type IN ('U'))
	DROP TABLE [clickup].[Folder]
GO

CREATE TABLE [clickup].[Folder] (
  [id] bigint  NOT NULL,
  [name] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [clickup].[Folder] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for List
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[List]') AND type IN ('U'))
	DROP TABLE [clickup].[List]
GO

CREATE TABLE [clickup].[List] (
  [id] bigint  NOT NULL,
  [name] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [clickup].[List] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for PersonCompany
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[PersonCompany]') AND type IN ('U'))
	DROP TABLE [clickup].[PersonCompany]
GO

CREATE TABLE [clickup].[PersonCompany] (
  [personTaskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [companyTaskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [clickup].[PersonCompany] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Space
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[Space]') AND type IN ('U'))
	DROP TABLE [clickup].[Space]
GO

CREATE TABLE [clickup].[Space] (
  [id] bigint  NOT NULL,
  [name] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [clickup].[Space] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for StatusHistory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[StatusHistory]') AND type IN ('U'))
	DROP TABLE [clickup].[StatusHistory]
GO

CREATE TABLE [clickup].[StatusHistory] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [taskId] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [status] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [type] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dateCreated] bigint  NOT NULL,
  [durationInMinutes] int  NULL
)
GO

ALTER TABLE [clickup].[StatusHistory] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Task
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[Task]') AND type IN ('U'))
	DROP TABLE [clickup].[Task]
GO

CREATE TABLE [clickup].[Task] (
  [id] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [name] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [folderId] bigint  NULL,
  [listId] bigint  NULL,
  [spaceId] bigint  NULL,
  [status] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [createdBy] int  NULL,
  [startDate] bigint  NULL,
  [dueDate] bigint  NULL,
  [dateCreated] bigint  NULL,
  [dateUpdated] bigint  NULL,
  [dateDone] bigint  NULL,
  [isArchived] bit  NULL,
  [parentId] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [activeTo] bigint  NULL
)
GO

ALTER TABLE [clickup].[Task] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for TasksCreatedWebhook
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[TasksCreatedWebhook]') AND type IN ('U'))
	DROP TABLE [clickup].[TasksCreatedWebhook]
GO

CREATE TABLE [clickup].[TasksCreatedWebhook] (
  [taskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [isImported] bit DEFAULT 0 NULL,
  [receivedOn] datetime  NULL,
  [importedOn] datetime DEFAULT NULL NULL
)
GO

ALTER TABLE [clickup].[TasksCreatedWebhook] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for TaskStatus
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[TaskStatus]') AND type IN ('U'))
	DROP TABLE [clickup].[TaskStatus]
GO

CREATE TABLE [clickup].[TaskStatus] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [statusName] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [friendlyName] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [category] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [groupName] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [orderNo] int  NULL
)
GO

ALTER TABLE [clickup].[TaskStatus] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for User
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[User]') AND type IN ('U'))
	DROP TABLE [clickup].[User]
GO

CREATE TABLE [clickup].[User] (
  [id] bigint  NOT NULL,
  [name] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [email] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [clickup].[User] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- View structure for vCertification
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[vCertification]') AND type IN ('V'))
	DROP VIEW [clickup].[vCertification]
GO

CREATE VIEW [clickup].[vCertification] AS SELECT t.id
			,t.name
FROM [clickup].[Task] t
WHERE t.listId = '901200207978' 
	AND t.parentId IS NULL 
	AND (t.activeTo > [Utilities].[DateToEpoch](GetDate()) OR t.activeTo is NULL);
GO


-- ----------------------------
-- View structure for vCompany
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[vCompany]') AND type IN ('V'))
	DROP VIEW [clickup].[vCompany]
GO

CREATE VIEW [clickup].[vCompany] AS SELECT t.id
			,t.name
			,t.description
			,t.status
			--,pc.personTaskId 
			,cc.certificationTaskId
FROM [clickup].[Task] t 
--LEFT JOIN [clickup].[PersonCompany] pc on pc.companyTaskId = t.id
LEFT JOIN [clickup].[CompanyCertification] cc on cc.companyTaskId = t.id
WHERE t.listId = '901201812237' AND t.parentId is NULL AND (t.activeTo > [Utilities].[DateToEpoch](GetDate()) OR t.activeTo is NULL);
GO


-- ----------------------------
-- View structure for vParentTasks
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[vParentTasks]') AND type IN ('V'))
	DROP VIEW [clickup].[vParentTasks]
GO

CREATE VIEW [clickup].[vParentTasks] AS SELECT t.id
			,t.name
			,t.description
			,t.status
			,u.name as [createdBy]
			,Utilities.EpochToDate(t.dueDate) as [dueDate]
			,Utilities.EpochToDate(t.dateCreated) as [dateCreated]
			,Utilities.EpochToDate(t.dateUpdated) as [dateUpdated]
			,cf_uniqueId.BAQUniqueId as [BAQUniqueId]
			,cf_submissionId.submissionId as [submissionId]
			,cf_formId.formId as [formId]
			,t.isArchived,
      t.listId
FROM clickup.Task t 
LEFT JOIN clickup.[User] u ON u.id = t.createdBy
 OUTER APPLY (
	SELECT [value] as [BAQUniqueId]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'BAQ uniqueId'
) as cf_uniqueId(BAQUniqueId)
OUTER APPLY (
	SELECT [value] as [formId]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'formId'
) as cf_formId(formId)
OUTER APPLY (
	SELECT [value] as [submissionId]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'submissionId'
) as cf_submissionId(submissionId)

WHERE t.parentId is NULL AND (t.activeTo > [Utilities].[DateToEpoch](GetDate()) OR t.activeTo is NULL);
GO


-- ----------------------------
-- View structure for vPeople
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[vPeople]') AND type IN ('V'))
	DROP VIEW [clickup].[vPeople]
GO

CREATE VIEW [clickup].[vPeople] AS SELECT DISTINCT t.id, 
			t.name,
			cf_email.email as [email],
			cf_contacttitle.contacttitle AS [title],
			ISNULL(comp.name,cf_company.company) AS company,
			cf_leadsource.leadsource AS leadSource,
			cf_product.product AS product,
			cf_value.value AS taskValue,
			[Utilities].[EpochToDate](t.DateCreated) AS CreatedDate,
			CASE WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 7 THEN 'Less than 07 days'
				 WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 14 THEN 'Less than 14 days'
				 WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 28 THEN 'Less than 28 days'
				 WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 56 THEN 'Less than 56 days'
				 WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 84 THEN 'Less than 84 days'
				 ELSE 'More than 86 days'
					END AS TimeSinceCreated,
			CASE WHEN t.DueDate IS NULL THEN NULL ELSE [Utilities].[EpochToDate](t.dueDate) END AS DueDate,
			CASE WHEN [Utilities].[EpochToDate](t.dueDate) < GETDATE() THEN 'Yes' ELSE 'No' END AS Overdue,
			ISNULL(ts.friendlyName,t.status) AS status,
			DATEDIFF(DAY,ISNULL(his.movedToStatus,[Utilities].[EpochToDate](t.DateCreated)),GETDATE()) AS timeInStatus,
			ts.description AS statusDescription,
			ts.category,
			ts.groupName,
			orderNo,
			u.name AS assignee,
			CASE WHEN cf_value.value IS NULL THEN '{Missing Value}' ELSE '' END +
			CASE WHEN t.dueDate IS NULL AND ISNULL(ts.friendlyName,t.status) NOT IN ('Unsubscribed') THEN '{Missing Due Date}' ELSE '' END +
			CASE WHEN cf_leadsource.leadsource IS NULL THEN '{Missing Lead Source}' ELSE '' END +
			CASE WHEN cf_product.product IS NULL THEN '{Missing Product}' ELSE '' END +
			CASE WHEN cf_contacttitle.contacttitle IS NULL THEN '{Missing Title}' ELSE '' END +
			CASE WHEN u.name IS NULL THEN '{Missing Assignee}' ELSE '' END AS Exceptions,

			CASE WHEN cf_value.value IS NULL THEN 1 ELSE 0 END +
			CASE WHEN t.dueDate IS NULL AND ISNULL(ts.friendlyName,t.status) NOT IN ('Unsubscribed') THEN 1 ELSE 0 END +
			CASE WHEN cf_leadsource.leadsource IS NULL THEN 1 ELSE 0 END +
			CASE WHEN cf_product.product IS NULL THEN 1 ELSE 0 END +
			CASE WHEN cf_contacttitle.contacttitle IS NULL THEN 1 ELSE 0 END +
			CASE WHEN u.name IS NULL THEN 1 ELSE 0 END AS ExceptionCount,
			pc.companyTaskId,
			ISNULL(comp.name,cf_company.company) AS companyName,
			cc.certificationTaskId,
      cert.activeTo as certActiveTo,
      cert.dateCreated as certDateCreated
 FROM clickup.Task t 
  LEFT JOIN clickup.TaskStatus ts ON t.status = ts.statusName
  LEFT JOIN (SELECT taskId,status, MAX(utilities.EpochToDate(dateCreated)) AS movedToStatus FROM clickup.StatusHistory GROUP BY taskId,status) his ON his.taskid = t.id AND his.[status] = t.[status]
  LEFT JOIN clickup.assignee a ON a.taskId = t.id
  LEFT JOIN clickup.[user] u ON u.id = a.userid
  LEFT JOIN clickup.personcompany pc ON pc.persontaskid = t.id
  LEFT JOIN clickup.task comp ON comp.id = pc.companytaskid
	LEFT JOIN clickup.CompanyCertification cc on cc.companyTaskId = pc.companyTaskId
  LEFT JOIN clickup.task cert on (cert.id = cc.certificationTaskId)
  OUTER APPLY (
	SELECT [value] as [email]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Email'
) as cf_email(email)
  OUTER APPLY (
	SELECT [value] as [company]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Company Name'
) as cf_company(company)
  OUTER APPLY (
	SELECT [value] as [value]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Current Task Value'
) as cf_value(value)
  OUTER APPLY (
	SELECT [value] as [leadsource]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Lead Source'
) as cf_leadsource(leadsource)
  OUTER APPLY (
	SELECT [value] as [contacttitle]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Contact Title'
) as cf_contacttitle(contacttitle) 
  OUTER APPLY (
	SELECT [value] as [product]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Product'
) as cf_product(product)
  WHERE t.listid in (901201812211, 901205740963) -- People, Blue incomplete (for RJM)
    AND t.parentId IS NULL
	AND (t.activeTo IS NULL OR [utilities].[EpochToDate](t.activeTo) >= GETDATE())
	--AND t.id = '869407ekq'
GO


-- ----------------------------
-- View structure for vPeople_18Feb2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[vPeople_18Feb2025]') AND type IN ('V'))
	DROP VIEW [clickup].[vPeople_18Feb2025]
GO

CREATE VIEW [clickup].[vPeople_18Feb2025] AS SELECT DISTINCT t.id, 
			t.name,
			cf_email.email as [email],
			cf_contacttitle.contacttitle AS [title],
			ISNULL(comp.name,cf_company.company) AS company,
			cf_leadsource.leadsource AS leadSource,
			cf_product.product AS product,
			cf_value.value AS taskValue,
			[Utilities].[EpochToDate](t.DateCreated) AS CreatedDate,
			CASE WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 7 THEN 'Less than 07 days'
				 WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 14 THEN 'Less than 14 days'
				 WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 28 THEN 'Less than 28 days'
				 WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 56 THEN 'Less than 56 days'
				 WHEN DATEDIFF(DAY,[Utilities].[EpochToDate](t.DateCreated),GETDATE()) < 84 THEN 'Less than 84 days'
				 ELSE 'More than 86 days'
					END AS TimeSinceCreated,
			CASE WHEN t.DueDate IS NULL THEN NULL ELSE [Utilities].[EpochToDate](t.dueDate) END AS DueDate,
			CASE WHEN [Utilities].[EpochToDate](t.dueDate) < GETDATE() THEN 'Yes' ELSE 'No' END AS Overdue,
			ISNULL(ts.friendlyName,t.status) AS status,
			DATEDIFF(DAY,ISNULL(his.movedToStatus,[Utilities].[EpochToDate](t.DateCreated)),GETDATE()) AS timeInStatus,
			ts.description AS statusDescription,
			ts.category,
			ts.groupName,
			orderNo,
			u.name AS assignee,
			CASE WHEN cf_value.value IS NULL THEN '{Missing Value}' ELSE '' END +
			CASE WHEN t.dueDate IS NULL AND ISNULL(ts.friendlyName,t.status) NOT IN ('Unsubscribed') THEN '{Missing Due Date}' ELSE '' END +
			CASE WHEN cf_leadsource.leadsource IS NULL THEN '{Missing Lead Source}' ELSE '' END +
			CASE WHEN cf_product.product IS NULL THEN '{Missing Product}' ELSE '' END +
			CASE WHEN cf_contacttitle.contacttitle IS NULL THEN '{Missing Title}' ELSE '' END +
			CASE WHEN u.name IS NULL THEN '{Missing Assignee}' ELSE '' END AS Exceptions,

			CASE WHEN cf_value.value IS NULL THEN 1 ELSE 0 END +
			CASE WHEN t.dueDate IS NULL AND ISNULL(ts.friendlyName,t.status) NOT IN ('Unsubscribed') THEN 1 ELSE 0 END +
			CASE WHEN cf_leadsource.leadsource IS NULL THEN 1 ELSE 0 END +
			CASE WHEN cf_product.product IS NULL THEN 1 ELSE 0 END +
			CASE WHEN cf_contacttitle.contacttitle IS NULL THEN 1 ELSE 0 END +
			CASE WHEN u.name IS NULL THEN 1 ELSE 0 END AS ExceptionCount,
			pc.companyTaskId,
			ISNULL(comp.name,cf_company.company) AS companyName,
			cc.certificationTaskId
 FROM clickup.Task t 
  LEFT JOIN clickup.TaskStatus ts ON t.status = ts.statusName
  LEFT JOIN (SELECT taskId,status, MAX(utilities.EpochToDate(dateCreated)) AS movedToStatus FROM clickup.StatusHistory GROUP BY taskId,status) his ON his.taskid = t.id AND his.[status] = t.[status]
  LEFT JOIN clickup.assignee a ON a.taskId = t.id
  LEFT JOIN clickup.[user] u ON u.id = a.userid
  LEFT JOIN clickup.personcompany pc ON pc.persontaskid = t.id
  LEFT JOIN clickup.task comp ON comp.id = pc.companytaskid
	LEFT JOIN clickup.CompanyCertification cc on cc.companyTaskId = pc.companyTaskId
  OUTER APPLY (
	SELECT [value] as [email]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Email'
) as cf_email(email)
  OUTER APPLY (
	SELECT [value] as [company]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Company Name'
) as cf_company(company)
  OUTER APPLY (
	SELECT [value] as [value]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Current Task Value'
) as cf_value(value)
  OUTER APPLY (
	SELECT [value] as [leadsource]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Lead Source'
) as cf_leadsource(leadsource)
  OUTER APPLY (
	SELECT [value] as [contacttitle]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Contact Title'
) as cf_contacttitle(contacttitle) 
  OUTER APPLY (
	SELECT [value] as [product]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = t.[id] AND cf.[name] = 'Product'
) as cf_product(product)
  WHERE t.listid in (901201812211, 901205740963) -- People, Blue incomplete (for RJM)
    AND t.parentId IS NULL
	AND (t.activeTo IS NULL OR [utilities].[EpochToDate](t.activeTo) >= GETDATE())
	--AND t.id = '869407ekq'
GO


-- ----------------------------
-- View structure for vTaskHistory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[vTaskHistory]') AND type IN ('V'))
	DROP VIEW [clickup].[vTaskHistory]
GO

CREATE VIEW [clickup].[vTaskHistory] AS SELECT h.taskId, 
		[utilities].[EpochToDate](dateCreated) AS createdDate,
		s.statusName,
		h.durationInMinutes / 1440.0 AS statusDurationDays,
		s.friendlyname,
		s.category,
		s.groupName,
		s.orderNo
 FROM clickup.StatusHistory h 
 JOIN clickup.TaskStatus s ON h.status = s.statusname
 WHERE [utilities].[EpochToDate](dateCreated) >= '2024-04-01'
GO


-- ----------------------------
-- View structure for vTasks
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[vTasks]') AND type IN ('V'))
	DROP VIEW [clickup].[vTasks]
GO

CREATE VIEW [clickup].[vTasks] AS SELECT t.id
			,t.name
			,t.description
			,t.status
			,u.name as [createdBy]
			,Utilities.EpochToDate(t.dueDate) as [dueDate]
			,Utilities.EpochToDate(t.dateCreated) as [dateCreated]
			,Utilities.EpochToDate(t.dateUpdated) as [dateUpdated]
			,st.id as [subtaskId]
			,st.name AS [subTaskName]
			,st.status AS [subTaskStatus]
			,CASE WHEN st.status = 'subtask Complete' THEN 1 ELSE 0 END AS [subTaskComplete]
			,CASE WHEN st.status = 'subtask Complete' THEN 'Yes' ELSE 'No' END AS [subTaskCompleteName]
			,cf_uniqueId.BAQUniqueId as [BAQUniqueId]
			,cf_submissionId.submissionId as [submissionId]
			,cf_formId.formId as [formId]
			--,Utilities.EpochToDate(sh.dateCreated) AS [statusHistoryDate]
			--,sh.status AS [statusHistory]
			--,sh.type AS [statusHistoryType]
			,t.isArchived
FROM clickup.Task t 
LEFT JOIN clickup.[User] u ON u.id = t.createdBy
LEFT JOIN clickup.Task st ON st.parentId = t.id
--LEFT JOIN clickup.StatusHistory sh ON sh.taskId = t.id
 OUTER APPLY (
	SELECT [value] as [BAQUniqueId]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = st.[id] AND cf.[name] = 'BAQ uniqueId'
) as cf_uniqueId(BAQUniqueId)
OUTER APPLY (
	SELECT [value] as [formId]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = st.[id] AND cf.[name] = 'formId'
) as cf_formId(formId)
OUTER APPLY (
	SELECT [value] as [submissionId]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = st.[id] AND cf.[name] = 'submissionId'
) as cf_submissionId(submissionId)

WHERE t.parentId is NULL AND (t.activeTo > [Utilities].[DateToEpoch](GetDate()) OR t.activeTo is NULL);
GO


-- ----------------------------
-- procedure structure for spClickup_GetCertificationTaskByPersonEmail_18Feb2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_GetCertificationTaskByPersonEmail_18Feb2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_GetCertificationTaskByPersonEmail_18Feb2025]
GO

CREATE PROCEDURE [clickup].[spClickup_GetCertificationTaskByPersonEmail_18Feb2025]
	@email nvarchar(100)
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @certTaskId nvarchar(25), @companyName nvarchar(250), @listId bigint
	
	SELECT top 1 @certTaskId = [certificationTaskId], @companyName = [companyName]
		FROM [clickup].[vPeople] 
	 WHERE RIGHT(email, CHARINDEX('@', REVERSE(email)) - 1) = RIGHT(@email, CHARINDEX('@', REVERSE(@email)) - 1);
		
	IF @certTaskId IS NULL
		 SET @certTaskId = '8694174h3'; -- create subtask under default - Customer Certification Journey
     
  Select @listId = listId from clickup.Task where id = @certTaskId; -- Get ListId of certification Task, as task may have been moved to another list

	SELECT @certTaskId as [certificationTaskId], @companyName as [companyName], 'SUBTASK COMPLETE' as [status], ISNULL( @listId, '901200207978') as [listId] 

END
GO


-- ----------------------------
-- procedure structure for spClickup_AddCertificationBuyer
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_AddCertificationBuyer]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_AddCertificationBuyer]
GO

CREATE PROCEDURE [clickup].[spClickup_AddCertificationBuyer]
	@data_JSON NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @tblData TABLE(
		 [certificationTaskId] nvarchar(36)
		,[buyerTaskId] nvarchar(36)
	)
	INSERT INTO @tblData ([certificationTaskId], [buyerTaskId])
	SELECT ln.[certificationTaskId], ln.[buyerTaskId]
	FROM OPENJSON(@data_JSON) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[certificationTaskId] nvarchar(36),
		[buyerTaskId] nvarchar(36)
	) ln;

	MERGE INTO [clickup].[CertificationBuyer] AS target
    USING @tblData AS source
    ON target.certificationTaskId = source.[certificationTaskId] AND target.buyerTaskId = source.[buyerTaskId]
    WHEN NOT MATCHED THEN
        INSERT (certificationTaskId, buyerTaskId) VALUES (source.[certificationTaskId], source.[buyerTaskId]);
		
	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spClickup_GetAllParentTasks
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_GetAllParentTasks]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_GetAllParentTasks]
GO

CREATE PROCEDURE [clickup].[spClickup_GetAllParentTasks]
AS
BEGIN
	 SELECT * FROM [clickup].[Task] WHERE parentId is null AND (activeTo > [Utilities].[DateToEpoch](GetDate()) OR activeTo is NULL);
END
GO


-- ----------------------------
-- procedure structure for spTask_SetCustomFieldValue
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spTask_SetCustomFieldValue]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spTask_SetCustomFieldValue]
GO

CREATE PROCEDURE [clickup].[spTask_SetCustomFieldValue]
	@taskId nvarchar(25)
	,@fieldName nvarchar(25)
  ,@fieldValue nvarchar(25)
AS
BEGIN
	SET NOCOUNT ON;
  
  Update clickup.CustomField set [value] = @fieldValue where name = @fieldName and taskId = @taskId;
	
	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spTask_TaskCreatedExists
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spTask_TaskCreatedExists]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spTask_TaskCreatedExists]
GO

CREATE PROCEDURE [clickup].[spTask_TaskCreatedExists]
  @taskId nvarchar(25)
AS
BEGIN
  -- If Task posted from Webhook exists in DB
  SET NOCOUNT ON;
  
  IF EXISTS( Select 1 from clickup.Task where Id = @taskId)
    Select 1 as cnt;
  ELSE
    BEGIN
      INSERT into clickup.TasksCreatedWebhook (taskId, receivedOn) values (@taskId, GETDATE());
      Select 0 as cnt;
    END
END
GO


-- ----------------------------
-- procedure structure for spTask_TaskCreatedMarkImported
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spTask_TaskCreatedMarkImported]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spTask_TaskCreatedMarkImported]
GO

CREATE PROCEDURE [clickup].[spTask_TaskCreatedMarkImported]
  @taskId nvarchar(25),
  @isImported bit
AS
BEGIN
  -- Mark taskCreated as imported in DB
  SET NOCOUNT ON;
  
  Update clickup.TasksCreatedWebhook set isImported = @isImported, importedOn = GETDATE() where taskId = @taskId;
END
GO


-- ----------------------------
-- procedure structure for spClickup_GetPersonTaskByEmail
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_GetPersonTaskByEmail]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_GetPersonTaskByEmail]
GO

CREATE PROCEDURE [clickup].[spClickup_GetPersonTaskByEmail]
	@email nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT Id as personTaskId  FROM [clickup].[vPeople] 
	 WHERE RIGHT(email, CHARINDEX('@', REVERSE(email)) - 1) = RIGHT(@email, CHARINDEX('@', REVERSE(@email)) - 1);
	
END
GO


-- ----------------------------
-- procedure structure for spClickup_GetCompanyTaskByName
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_GetCompanyTaskByName]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_GetCompanyTaskByName]
GO

CREATE PROCEDURE [clickup].[spClickup_GetCompanyTaskByName]
	@name nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT Id as companyTaskId FROM [clickup].[vCompany]  WHERE LOWER(name) = LOWER(@name);
	
END
GO


-- ----------------------------
-- procedure structure for spCustomField_SelectByTypeName
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spCustomField_SelectByTypeName]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spCustomField_SelectByTypeName]
GO

CREATE PROCEDURE [clickup].[spCustomField_SelectByTypeName]
	@type nvarchar(50),
	@name nvarchar(50),
	@listId bigint
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN
			SELECT CF.* FROM [clickup].[CustomField] CF INNER JOIN [clickup].[Task] CT ON CT.[id] = CF.[taskId]
			 WHERE CF.[name] = @name AND CF.[type] = @type AND (CT.activeTo > [Utilities].[DateToEpoch](GetDate()) OR CT.activeTo is NULL)
			 AND CT.[listId] = @listId; 
	END
END
GO


-- ----------------------------
-- procedure structure for spClickup_AddPersonCompany
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_AddPersonCompany]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_AddPersonCompany]
GO

CREATE PROCEDURE [clickup].[spClickup_AddPersonCompany]
	@task_personcompany_json NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	
	DECLARE @task_personcompanyTable TABLE(
		[personTaskId] nvarchar(36),
		[companyTaskId] nvarchar(36)
	)
	INSERT INTO @task_personcompanyTable ([personTaskId], [companyTaskId])
	SELECT ln.[taskId], ln.[parentId]
	FROM OPENJSON(@task_personcompany_json) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[taskId] nvarchar(36),
		[parentId] nvarchar(36)
	) ln;

	MERGE INTO [clickup].[PersonCompany] AS target
    USING @task_personcompanyTable AS source
    ON target.personTaskId = source.personTaskId AND target.companyTaskId = source.companyTaskId
    WHEN NOT MATCHED THEN
        INSERT (personTaskId, companyTaskId) VALUES (source.personTaskId, source.companyTaskId);

	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spClickup_AddCompanyCertifications
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_AddCompanyCertifications]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_AddCompanyCertifications]
GO

CREATE PROCEDURE [clickup].[spClickup_AddCompanyCertifications]
	@task_companycertifications_json NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @task_companycertificationsTable TABLE(
		[companyTaskId] nvarchar(36),
		[certificationTaskId] nvarchar(36)
	)
	INSERT INTO @task_companycertificationsTable ([companyTaskId], [certificationTaskId])
	SELECT ln.[taskId], ln.[parentId]
	FROM OPENJSON(@task_companycertifications_json) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[taskId] nvarchar(36),
		[parentId] nvarchar(36)
	) ln;

	MERGE INTO [clickup].[CompanyCertification] AS target
    USING @task_companycertificationsTable AS source
    ON target.companyTaskId = source.[companyTaskId] AND target.certificationTaskId = source.[certificationTaskId]
    WHEN NOT MATCHED THEN
        INSERT (companyTaskId, certificationTaskId) VALUES (source.[companyTaskId], source.[certificationTaskId]);

	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spConfigration_Select
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spConfigration_Select]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spConfigration_Select]
GO

CREATE PROCEDURE [clickup].[spConfigration_Select]
AS
BEGIN
	 SELECT *
    FROM [clickup].[Configuration] c
	 WHERE c.active = 1;
END
GO


-- ----------------------------
-- procedure structure for spClickup_AddTasks
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_AddTasks]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_AddTasks]
GO

CREATE PROCEDURE [clickup].[spClickup_AddTasks]
	@tasks_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @lastProcessedOn bigint =  [Utilities].[DateToEpoch](GetDate());

	DECLARE @tasks TABLE(
		[id] nvarchar(15), 
		[name] nvarchar(250),
		[description] nvarchar(MAX), 
		[parentId] nvarchar(15),
		[folderId] bigint,
		[listId]bigint,
		[spaceId] bigint,
		[status] nvarchar(50),
		[createdBy] int,
		[startDate] bigint,
		[dueDate] bigint,
		[dateCreated] bigint,
		[dateUpdated] bigint,
		[dateDone] bigint,
		[isArchived] bit,
		[status_JSON] nvarchar(max),
		[creator_JSON] nvarchar(max),
		[assignees_JSON] nvarchar(max),
		[customFields_JSON] nvarchar(max)
	)
	INSERT INTO @tasks ([id], [name], [description], [parentId], [folderId], [listId], [spaceId], [status], [createdBy], [startDate], [dueDate], [dateCreated], 
											[dateUpdated], [dateDone], [isArchived], [status_JSON], [creator_JSON], [assignees_JSON], [customFields_JSON])
	SELECT ln.[id], ln.[name], ln.[description], ln.[parentId], ln.[folderId], ln.[listId], ln.[spaceId], ln.[status], ln.[createdBy], ln.[startDate], ln.[dueDate],
					ln.[dateCreated], ln.[dateUpdated], ln.[dateDone], ln.[isArchived], ln.[status_JSON], ln.[creator_JSON], ln.[assignees_JSON], ln.[customFields_JSON]
	  FROM OPENJSON(@tasks_JSON) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[id] nvarchar(15), 
		[name] nvarchar(250),
		[description] nvarchar(MAX), 
		[parentId] nvarchar(15),
		[folderId] bigint,
		[listId]bigint,
		[spaceId] bigint,
		[status] nvarchar(50),
		[createdBy] int,
		[startDate] bigint,
		[dueDate] bigint,
		[dateCreated] bigint,
		[dateUpdated] bigint,
		[dateDone] bigint,
		[isArchived] bit,
		[status_JSON] nvarchar(max),
		[creator_JSON] nvarchar(max),
		[assignees_JSON] nvarchar(max),
		[customFields_JSON] nvarchar(max)
	) ln;

	MERGE [clickup].[Task] ct
		USING @tasks t
	ON (t.[id] = ct.[id])
	WHEN MATCHED
		THEN UPDATE
				SET ct.[name] = t.[name]
					,ct.[description] = t.[description]
					,ct.[status] = t.[status]
					,ct.[startDate] = t.[startDate]
					,ct.[dueDate] = t.[dueDate]
					,ct.[dateCreated] = t.[dateCreated]
					,ct.[dateUpdated] = t.[dateUpdated]
					,ct.[dateDone] = t.[dateDone]
					,ct.[isArchived] = t.[isArchived]
					,ct.[parentId] = t.[parentId]
					,ct.[folderId] = t.[folderId]
					,ct.[listId] = t.[listId]
					,ct.[spaceId] = t.[spaceId]
					,ct.[activeTo] = null
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([id], [name], [description], [parentId], [folderId], [listId], [spaceId], [status], [createdBy], [startDate], [dueDate], [dateCreated], [dateUpdated], [dateDone], [isArchived] , [activeTo])
			 VALUES (t.[id], t.[name], t.[description], t.[parentId], t.[folderId], t.[listId], t.[spaceId], t.[status], t.[createdBy], t.[startDate], t.[dueDate], t.[dateCreated], t.[dateUpdated], t.[dateDone], t.[isArchived] , null)
	--WHEN NOT MATCHED BY SOURCE 
	--THEN Update SET t.[active] = 0 where [ct].[id] = t.[id]
	;

	-- For each tasks, add assignees and custom fields
	DECLARE @taskId nvarchar(50)
	DECLARE @assignees_JSON nvarchar(max)
	DECLARE @creator_JSON nvarchar(max)
	DECLARE @status_JSON nvarchar(max)
	DECLARE @customFields_JSON nvarchar(max)
	DECLARE cur CURSOR for
		SELECT [id], [assignees_JSON], [creator_JSON], [status_JSON], [customFields_JSON] FROM @tasks
	OPEN cur
	FETCH NEXT FROM cur INTO @taskId, @assignees_JSON, @creator_JSON, @status_JSON, @customFields_JSON
	WHILE @@FETCH_STATUS = 0 BEGIN
				EXEC [clickup].[spClickup_AddAssignees] @taskId, @assignees_JSON
				EXEC [clickup].[spClickup_AddUsers] @assignees_JSON
				EXEC [clickup].[spClickup_AddUsers] @creator_JSON
			--	EXEC [clickup].[spClickup_AddStatusHistory] @taskId, @status_JSON
				EXEC [clickup].[spClickup_AddCustomFields] @taskId, @customFields_JSON
			FETCH NEXT FROM cur INTO @taskId, @assignees_JSON, @creator_JSON, @status_JSON, @customFields_JSON
	END
	CLOSE cur
	DEALLOCATE cur

	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spClickup_AddAssignees
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_AddAssignees]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_AddAssignees]
GO

CREATE PROCEDURE [clickup].[spClickup_AddAssignees]
	@taskId nvarchar(25)
	,@assignees_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @assignees TABLE(
		[id] bigint,
		[name] nvarchar(100),
		[email] nvarchar(100)
	)
	INSERT INTO @assignees ([id], [name], [email])
	SELECT ln.[id], ln.[name], ln.[email]
	  FROM OPENJSON(@assignees_JSON) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[id] bigint,
		[name] nvarchar(100),
		[email] nvarchar(100)
	) ln;

	MERGE [clickup].[Assignee] ca
		USING @assignees a
	ON (ca.[taskId] = @taskId and a.[id] = ca.[userId])
	--WHEN MATCHED
		-- THEN do nothing
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([taskId], [userId])
			 VALUES (@taskId, a.[id])
	WHEN NOT MATCHED BY SOURCE AND ca.taskId = @taskId
		THEN DELETE
	;

	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spJotForm_PopulateCustomer
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spJotForm_PopulateCustomer]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spJotForm_PopulateCustomer]
GO

CREATE PROCEDURE [clickup].[spJotForm_PopulateCustomer]
AS
BEGIN
    MERGE INTO [Dimension].[Customer] AS target
    USING (
        SELECT * from [clickup].[vCompany] where status = 'active'
    ) AS source
    ON (target.code = source.id) 
    WHEN NOT MATCHED THEN
        INSERT (name, code, description , active)
        VALUES (source.name, source.id, source.description ,1)
	WHEN NOT MATCHED BY SOURCE THEN
		UPDATE SET target.active = 0;
END;
GO


-- ----------------------------
-- procedure structure for spClickup_GetCertificationTaskByPersonEmail_20Nov2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_GetCertificationTaskByPersonEmail_20Nov2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_GetCertificationTaskByPersonEmail_20Nov2024]
GO

CREATE PROCEDURE [clickup].[spClickup_GetCertificationTaskByPersonEmail_20Nov2024]
	@email nvarchar(100)
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @certTaskId nvarchar(25), @companyName nvarchar(250)
	
	SELECT @certTaskId = [certificationTaskId], @companyName = [companyName]
		FROM [clickup].[vPeople] 
	 WHERE [email] = @email;
		
	IF @certTaskId IS NULL
		 SET @certTaskId = '8694174h3'; -- create subtask under default - Customer Certification Journey

	SELECT @certTaskId as [certificationTaskId], @companyName as [companyName], 'SUBTASK COMPLETE' as [status], '901200207978' as [listId] 

END
GO


-- ----------------------------
-- procedure structure for spClickup_GetCertificationTaskByPersonEmail
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_GetCertificationTaskByPersonEmail]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_GetCertificationTaskByPersonEmail]
GO

CREATE PROCEDURE [clickup].[spClickup_GetCertificationTaskByPersonEmail]
	@email nvarchar(100)
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @certTaskId nvarchar(25), @companyName nvarchar(250), @listId bigint
	
	SELECT top 1 @certTaskId = [certificationTaskId], @companyName = [companyName]
		FROM [clickup].[vPeople] 
	 WHERE RIGHT(email, CHARINDEX('@', REVERSE(email)) - 1) = RIGHT(@email, CHARINDEX('@', REVERSE(@email)) - 1)
   and certActiveTo is null
   ORDER BY certDateCreated desc;
		
	IF @certTaskId IS NULL
		 SET @certTaskId = '8694174h3'; -- create subtask under default - Customer Certification Journey
     
  Select @listId = listId from clickup.Task where id = @certTaskId; -- Get ListId of certification Task, as task may have been moved to another list

	SELECT @certTaskId as [certificationTaskId], @companyName as [companyName], 'SUBTASK COMPLETE' as [status], ISNULL( @listId, '901200207978') as [listId] 

END
GO


-- ----------------------------
-- procedure structure for spClickup_GetTasksWithDueDate
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_GetTasksWithDueDate]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_GetTasksWithDueDate]
GO

CREATE PROCEDURE [clickup].[spClickup_GetTasksWithDueDate]
AS
BEGIN
	 SELECT id
				 ,[Utilities].EpochToDate(dueDate) as dueDate 
		FROM [clickup].[Task] 
	 WHERE listId  = '901201812211' --People
		 AND dueDate is not null 
		 AND (activeTo > [Utilities].[DateToEpochTZ](GetDate()) OR activeTo is NULL)
		 AND (
					CAST([Utilities].EpochToDate(dueDate) as time) not between '10:00:00' AND '16:00:00'  
					OR 
					DATEPART(dw,[Utilities].EpochToDate(dueDate)) IN (1,7) --Weekeend
			)
END
GO


-- ----------------------------
-- procedure structure for spClickup_AddStatusHistory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_AddStatusHistory]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_AddStatusHistory]
GO

CREATE PROCEDURE [clickup].[spClickup_AddStatusHistory]
	@taskId nvarchar(25)
	,@status_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @status TABLE(
		[status] nvarchar(100),
		[type] nvarchar(100),
		[durationInMinutes] int,
		[dateCreated] bigint
	)
	INSERT INTO @status ([status], [type], [durationInMinutes] ,[dateCreated])
	SELECT ln.[status], ln.[type] , ln.[durationInMinutes] , ln.[dateCreated]
	  FROM OPENJSON(@status_JSON) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[status] nvarchar(100),
		[type] nvarchar(100),
		[durationInMinutes] int,
		[dateCreated] bigint
	) ln;

	MERGE [clickup].[statusHistory] cs
		USING @status s
	ON (cs.[taskId] = @taskId and s.[status] = cs.[status] and s.[dateCreated] = cs.[dateCreated])
	--WHEN MATCHED
		-- THEN do nothing
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([taskId], [status], [type], [dateCreated] ,[durationInMinutes])
			 VALUES (@taskId, s.[status], s.[type], s.[dateCreated], s.[durationInMinutes])
	--WHEN NOT MATCHED BY SOURCE AND cs.taskId = @taskId
		--THEN do nothing
	;

	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spClickup_DeleteTasks
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_DeleteTasks]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_DeleteTasks]
GO

CREATE PROCEDURE [clickup].[spClickup_DeleteTasks]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @activeTo bigint =  [Utilities].[DateToEpoch](DateAdd(MINUTE,30,GetDate()));
	
	Update [clickup].[Task] set activeTo = @activeTo where activeTo IS NULL;

END
GO


-- ----------------------------
-- procedure structure for spClickup_AddUsers
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_AddUsers]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_AddUsers]
GO

CREATE PROCEDURE [clickup].[spClickup_AddUsers]
	@users_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @users TABLE(
		[id] bigint,
		[username] nvarchar(100),
		[email] nvarchar(100)
	)
	INSERT INTO @users ([id], [username], [email])
	SELECT DISTINCT ln.[id], ln.[username], ln.[email]
	  FROM OPENJSON(@users_JSON) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[id] bigint,
		[username] nvarchar(100),
		[email] nvarchar(100)
	) ln;

	MERGE [clickup].[User] cu
		USING @users u
	ON (u.[id] = cu.[id])
	WHEN MATCHED
		THEN UPDATE
			SET cu.[name] = u.[username],
					cu.[email] = u.[email]
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([id], [name], [email])
			 VALUES (u.[id], u.[username], u.[email])
	--WHEN NOT MATCHED BY SOURCE
		-- THEN do nothing
	;

	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spClickup_GetCompanyTask
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_GetCompanyTask]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_GetCompanyTask]
GO

CREATE PROCEDURE [clickup].[spClickup_GetCompanyTask]
	@name nvarchar(100),
  @email nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
  Declare @companyTaskId nvarchar(25);
  
	SELECT @companyTaskId = companyTaskId FROM [clickup].[vPeople] 
	 WHERE RIGHT(email, CHARINDEX('@', REVERSE(email)) - 1) = RIGHT(@email, CHARINDEX('@', REVERSE(@email)) - 1);
 
  if(@companyTaskId is null)
    SELECT @companyTaskId = Id FROM [clickup].[vCompany]  WHERE LOWER(name) = LOWER(@name);
    
  Select @companyTaskId as companyTaskId;
	
END
GO


-- ----------------------------
-- procedure structure for spTask_AddCompany
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spTask_AddCompany]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spTask_AddCompany]
GO

CREATE PROCEDURE [clickup].[spTask_AddCompany]
	@companyTaskId NVARCHAR(25),
  @name NVARCHAR(100),
  @description NVARCHAR(250)
AS
BEGIN
  -- While creation of BAQ Task Company, Person, Certification. make direct entry in DB
	SET NOCOUNT ON;
	
  if(NOT EXISTS (Select * from [Dimension].[Customer] where name=@name and code=@companyTaskId and description=@description))
  BEGIN
    INSERT into [Dimension].[Customer] (name, code, description , active) VALUES (@name, @companyTaskId, @description, 1);
  END
  else
  BEGIN
    Update [Dimension].[Customer] set active=1 where name=@name and code=@companyTaskId and description=@description;
  END
    
	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spClickupJob_AddAssignees
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickupJob_AddAssignees]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickupJob_AddAssignees]
GO

CREATE PROCEDURE [clickup].[spClickupJob_AddAssignees]
    @tasks_JSON nvarchar(max)  -- JSON array containing taskId and assignees_JSON
AS
BEGIN
    SET NOCOUNT ON;

    -- Table variable to store extracted task-assignee data
    DECLARE @taskAssignees TABLE(
        [taskId] nvarchar(25),
        [userId] bigint
    );

    -- Extract taskId and assignees_JSON from the JSON array
    WITH TaskData AS 
    (
        SELECT 
            taskId, 
            assignees_JSON
        FROM OPENJSON(@tasks_JSON) 
        WITH (
            taskId nvarchar(25),
            assignees_JSON nvarchar(max) -- AS JSON
        )
    )
    -- Extract assignees for each taskId
    INSERT INTO @taskAssignees ([taskId], [userId])
    SELECT 
        t.taskId, 
        a.[id]
    FROM TaskData t
    CROSS APPLY OPENJSON(t.assignees_JSON)
    WITH (
        [id] bigint,
        [name] nvarchar(100),
        [email] nvarchar(100)
    ) a;

    -- Merge into Assignee table to update assignments
    MERGE [clickup].[Assignee] ca
    USING @taskAssignees ta
    ON (ca.[taskId] = ta.[taskId] AND ca.[userId] = ta.[userId])
    WHEN NOT MATCHED BY TARGET 
        THEN INSERT ([taskId], [userId]) VALUES (ta.[taskId], ta.[userId])
    WHEN NOT MATCHED BY SOURCE AND ca.taskId IN (SELECT DISTINCT taskId FROM @taskAssignees)
        THEN DELETE;

    RETURN 1;
END;
GO


-- ----------------------------
-- procedure structure for spClickupJob_AddCustomFields
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickupJob_AddCustomFields]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickupJob_AddCustomFields]
GO

CREATE PROCEDURE [clickup].[spClickupJob_AddCustomFields]
    @tasks_JSON nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;
    
    CREATE TABLE #customFields(
        [taskId] nvarchar(25),
        [id] uniqueidentifier,
        [name] nvarchar(50),
        [value] nvarchar(max),
        [type] nvarchar(250)
    );
    
    CREATE INDEX IX_CustomFields_TaskId ON #customFields([taskId]);
    CREATE INDEX IX_CustomFields_Id ON #customFields([id]);
    
    INSERT INTO #customFields ([taskId], [id], [name], [value], [type])
    SELECT 
        t.taskId, 
        TRY_CONVERT(uniqueidentifier, JSON_VALUE(c.value, '$.id')), 
        ISNULL(JSON_VALUE(c.value, '$.name'), ''), 
        CASE 
            WHEN ISJSON(JSON_QUERY(c.value, '$.value')) = 1 THEN JSON_QUERY(c.value, '$.value') 
            ELSE JSON_VALUE(c.value, '$.value') 
        END, 
        JSON_VALUE(c.value, '$.type')
    FROM OPENJSON(@tasks_JSON) 
    WITH (
        taskId nvarchar(25),
        customFields_JSON nvarchar(max) AS JSON
    ) t
    CROSS APPLY OPENJSON(t.customFields_JSON) c
    OPTION (OPTIMIZE FOR (@tasks_JSON UNKNOWN));
      
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;
    
    MERGE [clickup].[CustomField] WITH (TABLOCK) AS cc
    USING #customFields AS cf
    ON (cc.[taskId] = cf.[taskId] AND cc.[id] = cf.[id])
    WHEN MATCHED THEN 
        UPDATE SET 
            cc.[name] = cf.[name],
            cc.[value] = cf.[value],
            cc.[type] = cf.[type]
    WHEN NOT MATCHED BY TARGET THEN 
        INSERT ([id], [taskId], [name], [value], [type])
        VALUES (cf.[id], cf.[taskId], cf.[name], cf.[value], cf.[type]);
    -- WHEN NOT MATCHED BY SOURCE AND cc.taskId IN (SELECT DISTINCT taskId FROM #customFields) THEN
    --    DELETE;
    
    COMMIT TRANSACTION;
    
    DROP TABLE #customFields;
    
    RETURN 1;
END;
GO


-- ----------------------------
-- procedure structure for spClickupJob_AddTasks
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickupJob_AddTasks]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickupJob_AddTasks]
GO

CREATE PROCEDURE [clickup].[spClickupJob_AddTasks]
	@tasks_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @lastProcessedOn bigint =  [Utilities].[DateToEpoch](GetDate());

	DECLARE @tasks TABLE(
		[id] nvarchar(15), 
		[name] nvarchar(250),
		[description] nvarchar(MAX), 
		[parentId] nvarchar(15),
		[folderId] bigint,
		[listId]bigint,
		[spaceId] bigint,
		[status] nvarchar(50),
		[createdBy] int,
		[startDate] bigint,
		[dueDate] bigint,
		[dateCreated] bigint,
		[dateUpdated] bigint,
		[dateDone] bigint,
		[isArchived] bit,
		[status_JSON] nvarchar(max),
		[creator_JSON] nvarchar(max),
		[assignees_JSON] nvarchar(max),
		[customFields_JSON] nvarchar(max)
	)
	INSERT INTO @tasks ([id], [name], [description], [parentId], [folderId], [listId], [spaceId], [status], [createdBy], [startDate], [dueDate], [dateCreated], 
											[dateUpdated], [dateDone], [isArchived], [status_JSON], [creator_JSON], [assignees_JSON], [customFields_JSON])
	SELECT ln.[id], ln.[name], ln.[description], ln.[parentId], ln.[folderId], ln.[listId], ln.[spaceId], ln.[status], ln.[createdBy], ln.[startDate], ln.[dueDate],
					ln.[dateCreated], ln.[dateUpdated], ln.[dateDone], ln.[isArchived], ln.[status_JSON], ln.[creator_JSON], ln.[assignees_JSON], ln.[customFields_JSON]
	  FROM OPENJSON(@tasks_JSON) A
	CROSS APPLY OPENJSON(A.value) 
	WITH
	(
		[id] nvarchar(15), 
		[name] nvarchar(250),
		[description] nvarchar(MAX), 
		[parentId] nvarchar(15),
		[folderId] bigint,
		[listId]bigint,
		[spaceId] bigint,
		[status] nvarchar(50),
		[createdBy] int,
		[startDate] bigint,
		[dueDate] bigint,
		[dateCreated] bigint,
		[dateUpdated] bigint,
		[dateDone] bigint,
		[isArchived] bit,
		[status_JSON] nvarchar(max),
		[creator_JSON] nvarchar(max),
		[assignees_JSON] nvarchar(max),
		[customFields_JSON] nvarchar(max)
	) ln;

	MERGE [clickup].[Task] ct
		USING @tasks t
	ON (t.[id] = ct.[id])
	WHEN MATCHED
		THEN UPDATE
				SET ct.[name] = t.[name]
					,ct.[description] = t.[description]
					,ct.[status] = t.[status]
					,ct.[startDate] = t.[startDate]
					,ct.[dueDate] = t.[dueDate]
					,ct.[dateCreated] = t.[dateCreated]
					,ct.[dateUpdated] = t.[dateUpdated]
					,ct.[dateDone] = t.[dateDone]
					,ct.[isArchived] = t.[isArchived]
					,ct.[parentId] = t.[parentId]
					,ct.[folderId] = t.[folderId]
					,ct.[listId] = t.[listId]
					,ct.[spaceId] = t.[spaceId]
					,ct.[activeTo] = null
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([id], [name], [description], [parentId], [folderId], [listId], [spaceId], [status], [createdBy], [startDate], [dueDate], [dateCreated], [dateUpdated], [dateDone], [isArchived] , [activeTo])
			 VALUES (t.[id], t.[name], t.[description], t.[parentId], t.[folderId], t.[listId], t.[spaceId], t.[status], t.[createdBy], t.[startDate], t.[dueDate], t.[dateCreated], t.[dateUpdated], t.[dateDone], t.[isArchived] , null);


	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spTask_DeleteTask
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spTask_DeleteTask]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spTask_DeleteTask]
GO

CREATE PROCEDURE [clickup].[spTask_DeleteTask]
  @taskId nvarchar(25)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @activeTo bigint =  [Utilities].[DateToEpoch](DateAdd(MINUTE,30,GetDate()));
	
	Update [clickup].[Task] set activeTo = @activeTo where id = @taskId;

END
GO


-- ----------------------------
-- procedure structure for spCustomField_SelectForCertificationLink
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spCustomField_SelectForCertificationLink]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spCustomField_SelectForCertificationLink]
GO

CREATE PROCEDURE [clickup].[spCustomField_SelectForCertificationLink]
  
AS
BEGIN

  WITH CF_Values (name, [value], taskId)
  AS
  (
    Select CF.name, CF.[value], CF.taskId
    From clickup.CustomField as CF INNER JOIN clickup.Task as T on (CF.taskId = T.id)
          INNER JOIN clickup.Configuration as C on (C.listId = T.listId and C.active = 1 and C.description='CERTIFICATION')
    Where CF.name in ('Company', IsNull('Person','Main Contact')) and CF.type='tasks' and CF.[value] is not null
  )

  Select C.taskId as certificationTaskId, C.name, C.[value] as companyTask, P.name, P.[value] as personTask 
  From CF_Values as C LEFT JOIN CF_Values as P on (C.taskId = P.taskId and P.name = IsNull('Person','Main Contact'))
  Where C.name='Company'
  ORDER BY certificationTaskId;


END
GO


-- ----------------------------
-- procedure structure for spTask_AddCompanyCertifications
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spTask_AddCompanyCertifications]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spTask_AddCompanyCertifications]
GO

CREATE PROCEDURE [clickup].[spTask_AddCompanyCertifications]
	@companyTaskId NVARCHAR(25),
  @certificationTaskId NVARCHAR(25)
AS
BEGIN
  -- While creation of BAQ Task Company, Person, Certification. make direct entry in DB
	SET NOCOUNT ON;
	
  if(Not exists (Select * from clickup.CompanyCertification where certificationTaskId=@certificationTaskId and companyTaskId=@companyTaskId))
    INSERT into clickup.CompanyCertification (companyTaskId, certificationTaskId) VALUES (@companyTaskId, @certificationTaskId);

	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spClickup_AddCustomFields
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_AddCustomFields]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_AddCustomFields]
GO

CREATE PROCEDURE [clickup].[spClickup_AddCustomFields]
	@taskId nvarchar(25)
	,@customFields_JSON nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @customFields TABLE(
		[id] uniqueidentifier,
		[name] nvarchar(50),
		[value] nvarchar(max),
		[type] nvarchar(250)
	)
	INSERT INTO @customFields ([id], [name], [value],[type])
		SELECT [id] = B.id,
		   [name] = B.name,
		   [value] = B.[value],
		   [type] = B.type
		FROM OPENJSON(@customFields_JSON) A
		CROSS APPLY (
			SELECT [id] = JSON_VALUE(A.value, '$.id'),
				   [name] = COALESCE(JSON_VALUE(A.value, '$.name'), ''),
				   [value] = CASE
								WHEN ISJSON(JSON_QUERY(A.value, '$.value')) = 1 THEN JSON_QUERY(A.value, '$.value')
								ELSE JSON_VALUE(A.value, '$.value')
							END,
				   [type] = JSON_VALUE(A.value, '$.type')
		) B;

	MERGE [clickup].[CustomField] cc
		USING @customFields c
	ON (cc.[taskId] = @taskId and c.[id] = cc.[id])
	WHEN MATCHED
		THEN UPDATE
			SET cc.[name] = c.[name],
				cc.[value] = c.[value],
				cc.[type] = c.[type]
	WHEN NOT MATCHED BY TARGET
		THEN INSERT ([id], [taskId], [name], [value], [type])
			 VALUES (c.[id], @taskId, c.[name], c.[value], c.[type])
	WHEN NOT MATCHED BY SOURCE AND cc.taskId = @taskId
		THEN DELETE
	;

	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spTask_AddPersonCompany
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spTask_AddPersonCompany]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spTask_AddPersonCompany]
GO

CREATE PROCEDURE [clickup].[spTask_AddPersonCompany]
	@companyTaskId NVARCHAR(25),
  @personTaskId NVARCHAR(25)
AS
BEGIN
  -- While creation of BAQ Task Company, Person, Certification. make direct entry in DB
	SET NOCOUNT ON;
	
  if(Not exists (Select * from clickup.PersonCompany where personTaskId=@personTaskId and companyTaskId=@companyTaskId))
    INSERT into clickup.PersonCompany (personTaskId, companyTaskId) VALUES (@personTaskId, @companyTaskId);

	Return 1;
END
GO


-- ----------------------------
-- procedure structure for spTask_MoveTask
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spTask_MoveTask]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spTask_MoveTask]
GO

CREATE PROCEDURE [clickup].[spTask_MoveTask]
  @taskId nvarchar(25),
  @moveToListId nvarchar(25),
  @moveToFolderId nvarchar(25),
  @moveToSpaceId nvarchar(25)
AS
BEGIN
	SET NOCOUNT ON;

	Update [clickup].[Task] set listId = @moveToListId, folderId = @moveToFolderId, spaceId = @moveToSpaceId where id = @taskId;

END
GO


-- ----------------------------
-- procedure structure for spClickup_GetTaskDetails
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickup_GetTaskDetails]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickup_GetTaskDetails]
GO

CREATE PROCEDURE [clickup].[spClickup_GetTaskDetails]
	@taskId nvarchar(15)
AS
BEGIN

	SET NOCOUNT ON;
	
  Select listId, 'SUBTASK COMPLETE' as status from clickup.Task where id = @taskId;
  
END
GO


-- ----------------------------
-- procedure structure for spClickupJob_AddCustomFields_12Feb2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spClickupJob_AddCustomFields_12Feb2025]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spClickupJob_AddCustomFields_12Feb2025]
GO

CREATE PROCEDURE [clickup].[spClickupJob_AddCustomFields_12Feb2025]
    @tasks_JSON nvarchar(max)  -- JSON array containing taskId and customFields_JSON
AS
BEGIN
    SET NOCOUNT ON;

    -- Table variable to store extracted task custom field data
    DECLARE @customFields TABLE(
        [taskId] nvarchar(25),
        [id] uniqueidentifier,
        [name] nvarchar(50),
        [value] nvarchar(max),
        [type] nvarchar(250)
    );

    -- Extract taskId and customFields_JSON from the JSON array
    WITH TaskData AS 
    (
        SELECT 
            taskId, 
            customFields_JSON
        FROM OPENJSON(@tasks_JSON) 
        WITH (
            taskId nvarchar(25),
            customFields_JSON nvarchar(max) -- AS JSON
        )
    )
    -- Extract custom fields for each taskId
    INSERT INTO @customFields ([taskId], [id], [name], [value], [type])
    SELECT 
        t.taskId, 
        JSON_VALUE(c.value, '$.id'), 
        COALESCE(JSON_VALUE(c.value, '$.name'), ''), 
        CASE 
            WHEN ISJSON(JSON_QUERY(c.value, '$.value')) = 1 THEN JSON_QUERY(c.value, '$.value') 
            ELSE JSON_VALUE(c.value, '$.value') 
        END, 
        JSON_VALUE(c.value, '$.type')
    FROM TaskData t
    CROSS APPLY OPENJSON(t.customFields_JSON) c;

    -- Merge operation to insert/update/delete custom fields
    MERGE [clickup].[CustomField] cc
    USING @customFields cf
    ON (cc.[taskId] = cf.[taskId] AND cc.[id] = cf.[id])
    WHEN MATCHED
        THEN UPDATE SET 
            cc.[name] = cf.[name],
            cc.[value] = cf.[value],
            cc.[type] = cf.[type]
    WHEN NOT MATCHED BY TARGET 
        THEN INSERT ([id], [taskId], [name], [value], [type])
             VALUES (cf.[id], cf.[taskId], cf.[name], cf.[value], cf.[type])
    WHEN NOT MATCHED BY SOURCE AND cc.taskId IN (SELECT DISTINCT taskId FROM @customFields)
        THEN DELETE;

    RETURN 1;
END;
GO


-- ----------------------------
-- procedure structure for spCustomField_GetUniqueIdByEmail
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spCustomField_GetUniqueIdByEmail]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spCustomField_GetUniqueIdByEmail]
GO

CREATE PROCEDURE [clickup].[spCustomField_GetUniqueIdByEmail]
	@BAQ_UniqueId nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
  Declare @email nvarchar(100) = 
         (Select top 1 BAQ_Email from DataModel.BlueAwardSubmissionData 
          where BAQ_UniqueId = @BAQ_UniqueId);
          
  if(@email is null)
    set @email = (Select top 1 CFE.[value] from clickup.CustomField as CFU 
                  INNER JOIN clickup.CustomField as CFE on (CFU.taskId = CFE.taskId and CFU.name='BAQ uniqueId' and CFE.name='Email') 
                  Where CFU.value = @BAQ_UniqueId);
          
	DECLARE @customerCode nvarchar(50) = 
         (SELECT top 1 [companyTaskId] FROM [clickup].[vPeople] 
          WHERE RIGHT(email, CHARINDEX('@', REVERSE(email)) - 1) = RIGHT(@email, CHARINDEX('@', REVERSE(@email)) - 1));
	IF @customerCode IS NOT NULL
	BEGIN
		SELECT TOP 1 [id] FROM [Dimension].[Customer] WHERE code = @customerCode 
	END
	
END
GO


-- ----------------------------
-- procedure structure for spCustomField_GetCertificationUniqueId
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[clickup].[spCustomField_GetCertificationUniqueId]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[clickup].[spCustomField_GetCertificationUniqueId]
GO

CREATE PROCEDURE [clickup].[spCustomField_GetCertificationUniqueId]
	@email nvarchar(50)
AS
BEGIN
	SET NOCOUNT ON;
  Declare @certTaskId nvarchar(50);

  SELECT top 1 @certTaskId = [certificationTaskId]
	FROM [clickup].[vPeople] 
	WHERE RIGHT(email, CHARINDEX('@', REVERSE(email)) - 1) = RIGHT(@email, CHARINDEX('@', REVERSE(@email)) - 1);

  IF @certTaskId IS NOT NULL
    Select top 1 CFU.[value], taskId from clickup.CustomField as CFU Where CFU.name='BAQ uniqueId' and CFU.taskId = @certTaskId;
  
END
GO


-- ----------------------------
-- Auto increment value for Assignee
-- ----------------------------
DBCC CHECKIDENT ('[clickup].[Assignee]', RESEED, 1711)
GO


-- ----------------------------
-- Primary Key structure for table Assignee
-- ----------------------------
ALTER TABLE [clickup].[Assignee] ADD CONSTRAINT [PK__Assignee__3213E83FDEFEA998] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table CertificationBuyer
-- ----------------------------
ALTER TABLE [clickup].[CertificationBuyer] ADD CONSTRAINT [PK__Certific__EA9A88EA1A0E0E45] PRIMARY KEY CLUSTERED ([certificationTaskId], [buyerTaskId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table CompanyCertification
-- ----------------------------
ALTER TABLE [clickup].[CompanyCertification] ADD CONSTRAINT [PK__CompanyC__729E1D8F0BD1022C] PRIMARY KEY CLUSTERED ([companyTaskId], [certificationTaskId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Configuration
-- ----------------------------
DBCC CHECKIDENT ('[clickup].[Configuration]', RESEED, 12)
GO


-- ----------------------------
-- Primary Key structure for table Configuration
-- ----------------------------
ALTER TABLE [clickup].[Configuration] ADD CONSTRAINT [PK__Configur__3213E83F51CBE2A4] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Indexes structure for table CustomField
-- ----------------------------
CREATE NONCLUSTERED INDEX [IX_CustomField_TaskId_Id]
ON [clickup].[CustomField] (
  [taskId] ASC,
  [id] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table Folder
-- ----------------------------
ALTER TABLE [clickup].[Folder] ADD CONSTRAINT [PK__Folder__3213E83F4AA194D0] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table List
-- ----------------------------
ALTER TABLE [clickup].[List] ADD CONSTRAINT [PK__Folder_c__3213E83F564187E7] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table PersonCompany
-- ----------------------------
ALTER TABLE [clickup].[PersonCompany] ADD CONSTRAINT [PK__PersonCo__973D3D387842A41F] PRIMARY KEY CLUSTERED ([personTaskId], [companyTaskId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table Space
-- ----------------------------
ALTER TABLE [clickup].[Space] ADD CONSTRAINT [PK__List_cop__3213E83FB63422E7] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for StatusHistory
-- ----------------------------
DBCC CHECKIDENT ('[clickup].[StatusHistory]', RESEED, 9161)
GO


-- ----------------------------
-- Primary Key structure for table StatusHistory
-- ----------------------------
ALTER TABLE [clickup].[StatusHistory] ADD CONSTRAINT [PK__StatusHi__3213E83FF8BDEBF5] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table Task
-- ----------------------------
ALTER TABLE [clickup].[Task] ADD CONSTRAINT [PK__Task__3213E83FEA3B28D1] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for TaskStatus
-- ----------------------------
DBCC CHECKIDENT ('[clickup].[TaskStatus]', RESEED, 26)
GO


-- ----------------------------
-- Primary Key structure for table TaskStatus
-- ----------------------------
ALTER TABLE [clickup].[TaskStatus] ADD CONSTRAINT [PK__TaskStat__3213E83FCAFD104E] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table User
-- ----------------------------
ALTER TABLE [clickup].[User] ADD CONSTRAINT [PK__User__3213E83F23214E96] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

