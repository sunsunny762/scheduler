/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Fact

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 10:44:15
*/


-- ----------------------------
-- Table structure for Emission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Fact].[Emission]') AND type IN ('U'))
	DROP TABLE [Fact].[Emission]
GO

CREATE TABLE [Fact].[Emission] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [emissionActivityId] int  NOT NULL,
  [entityId] int  NOT NULL,
  [entityTypeId] int  NOT NULL,
  [submissionId] int  NULL,
  [month] int  NULL,
  [year] int  NULL,
  [reportingFrequencyId] int  NULL,
  [userInput] decimal(10,2)  NULL,
  [conversionFactor] decimal(10,4)  NULL,
  [dataUnit] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NULL
)
GO

ALTER TABLE [Fact].[Emission] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- procedure structure for spEmission_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Fact].[spEmission_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Fact].[spEmission_Save]
GO

CREATE PROCEDURE [Fact].[spEmission_Save]
	 @entityId INT
	,@entityTypeId INT
	,@submissionId INT
	,@emissionActivityId INT
	,@userInput DECIMAL(10,2)
	,@month int
	,@conversionFactor decimal(10,4)
	,@reportingFrequencyId int
	,@dataUnit nvarchar(25)
AS
BEGIN
	SET NOCOUNT ON;

	--DECLARE @emissionId int = (SELECT TOP 1 [id] FROM [Fact].[Emission] WHERE [entityId] = @entityId AND entityTypeId = @entityTypeId AND emissionActivityId = @emissionActivityId AND [month] = @month)
	--IF @emissionId IS NULL 
	--BEGIN
		INSERT INTO [Fact].[Emission] (entityId, entityTypeId, submissionId, emissionActivityId, userInput, month, conversionFactor, reportingFrequencyId, dataUnit) 
			VALUES (@entityId, @entityTypeId, @submissionId, @emissionActivityId, @userInput, @month, @conversionFactor, @reportingFrequencyId, @dataUnit); 
		--SET @emissionId = SCOPE_IDENTITY();
	--END
	--ELSE 
	--BEGIN
		-- update user input, month, conversionFactor etc?
	--END
	 
END
GO


-- ----------------------------
-- Auto increment value for Emission
-- ----------------------------
DBCC CHECKIDENT ('[Fact].[Emission]', RESEED, 13690)
GO


-- ----------------------------
-- Primary Key structure for table Emission
-- ----------------------------
ALTER TABLE [Fact].[Emission] ADD CONSTRAINT [PK__Emission__3213E83F09F1C57A] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

