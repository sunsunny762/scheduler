/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Lookups

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 11:16:07
*/


-- ----------------------------
-- Table structure for DataSource
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[DataSource]') AND type IN ('U'))
	DROP TABLE [Lookups].[DataSource]
GO

CREATE TABLE [Lookups].[DataSource] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Lookups].[DataSource] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of DataSource
-- ----------------------------
INSERT INTO [Lookups].[DataSource] ([id], [name]) VALUES (N'1', N'JotForm')
GO

INSERT INTO [Lookups].[DataSource] ([id], [name]) VALUES (N'2', N'NczForm')
GO


-- ----------------------------
-- Table structure for EntityType
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[EntityType]') AND type IN ('U'))
	DROP TABLE [Lookups].[EntityType]
GO

CREATE TABLE [Lookups].[EntityType] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [Lookups].[EntityType] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of EntityType
-- ----------------------------
INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'1', N'CustomerProfile')
GO

INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'2', N'Event')
GO

INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'3', N'Meeting')
GO

INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'4', N'Customer')
GO

INSERT INTO [Lookups].[EntityType] ([id], [name]) VALUES (N'5', N'Portal Customer')
GO


-- ----------------------------
-- Table structure for FormCategory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[FormCategory]') AND type IN ('U'))
	DROP TABLE [Lookups].[FormCategory]
GO

CREATE TABLE [Lookups].[FormCategory] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [Lookups].[FormCategory] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of FormCategory
-- ----------------------------
INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'1', N'Certification')
GO

INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'2', N'Event')
GO

INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'3', N'Meeting')
GO

INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'4', N'Blue Award Questionnaire')
GO

INSERT INTO [Lookups].[FormCategory] ([id], [name]) VALUES (N'5', N'Gold Award Questionnaire')
GO


-- ----------------------------
-- Table structure for PowerBIExportStatus
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[PowerBIExportStatus]') AND type IN ('U'))
	DROP TABLE [Lookups].[PowerBIExportStatus]
GO

CREATE TABLE [Lookups].[PowerBIExportStatus] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Lookups].[PowerBIExportStatus] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of PowerBIExportStatus
-- ----------------------------

-- ----------------------------
-- Table structure for QuestionInputType
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[QuestionInputType]') AND type IN ('U'))
	DROP TABLE [Lookups].[QuestionInputType]
GO

CREATE TABLE [Lookups].[QuestionInputType] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Lookups].[QuestionInputType] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of QuestionInputType
-- ----------------------------
INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'1', N'TextBox')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'2', N'TextArea')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'3', N'Date')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'4', N'Time')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'5', N'Select')
GO

INSERT INTO [Lookups].[QuestionInputType] ([id], [name]) VALUES (N'6', N'Number')
GO


-- ----------------------------
-- Table structure for QuestionType
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[QuestionType]') AND type IN ('U'))
	DROP TABLE [Lookups].[QuestionType]
GO

CREATE TABLE [Lookups].[QuestionType] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Lookups].[QuestionType] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of QuestionType
-- ----------------------------
INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'1', N'EntityReference')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'2', N'ReportingFrequency')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'3', N'OptInPreference')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'4', N'UserInputByMonth')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'5', N'UserInputAnnualByMonth')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'6', N'UserInputAnnual')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'7', N'Month')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'8', N'ManagementBasedDecision')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'9', N'DataUnit')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'10', N'ConversionFactor')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'11', N'UserInputAnnualFromJanToJun')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'12', N'UnserInputAnnualFromJulToDec')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'13', N'UserInputTextBox')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'14', N'DeliveriesItemiseInput')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'15', N'EmailEntityReference')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'16', N'OtherItemiseInput')
GO

INSERT INTO [Lookups].[QuestionType] ([id], [name]) VALUES (N'17', N'HotelStayItemiseInput')
GO


-- ----------------------------
-- Table structure for ReportingFrequency
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Lookups].[ReportingFrequency]') AND type IN ('U'))
	DROP TABLE [Lookups].[ReportingFrequency]
GO

CREATE TABLE [Lookups].[ReportingFrequency] (
  [id] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [Lookups].[ReportingFrequency] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ReportingFrequency
-- ----------------------------
INSERT INTO [Lookups].[ReportingFrequency] ([id], [name]) VALUES (N'1', N'weekly')
GO

INSERT INTO [Lookups].[ReportingFrequency] ([id], [name]) VALUES (N'2', N'monthly')
GO

INSERT INTO [Lookups].[ReportingFrequency] ([id], [name]) VALUES (N'3', N'annualised_monthly')
GO

INSERT INTO [Lookups].[ReportingFrequency] ([id], [name]) VALUES (N'4', N'annualised')
GO


-- ----------------------------
-- Primary Key structure for table DataSource
-- ----------------------------
ALTER TABLE [Lookups].[DataSource] ADD CONSTRAINT [PK__DataSour__3213E83F71CB05E6] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table EntityType
-- ----------------------------
ALTER TABLE [Lookups].[EntityType] ADD CONSTRAINT [PK__DataSour__3213E83FEF413F5F] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table FormCategory
-- ----------------------------
ALTER TABLE [Lookups].[FormCategory] ADD CONSTRAINT [PK__EntityTy__3213E83F6ED58800] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table PowerBIExportStatus
-- ----------------------------
ALTER TABLE [Lookups].[PowerBIExportStatus] ADD CONSTRAINT [PK__PowerBIE__3213E83F5F0817CC] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table QuestionInputType
-- ----------------------------
ALTER TABLE [Lookups].[QuestionInputType] ADD CONSTRAINT [PK__Question__3213E83F2F517493] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table QuestionType
-- ----------------------------
ALTER TABLE [Lookups].[QuestionType] ADD CONSTRAINT [PK__DataSour__3213E83F3A6C84F0] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table ReportingFrequency
-- ----------------------------
ALTER TABLE [Lookups].[ReportingFrequency] ADD CONSTRAINT [PK__Reportin__3213E83F94E0C394] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

