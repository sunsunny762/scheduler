/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Utilities

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 11:24:08
*/


-- ----------------------------
-- Table structure for ErrorLogs
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[ErrorLogs]') AND type IN ('U'))
	DROP TABLE [Utilities].[ErrorLogs]
GO

CREATE TABLE [Utilities].[ErrorLogs] (
  [Id] int  IDENTITY(1,1) NOT NULL,
  [dateTime] datetime DEFAULT getdate() NOT NULL,
  [functionName] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [errorMessage] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [errorDetails] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [formId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [environmentKey] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isArchived] int DEFAULT 0 NULL
)
GO

ALTER TABLE [Utilities].[ErrorLogs] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- function structure for CalculateEf
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[CalculateEf]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[CalculateEf]
GO

CREATE FUNCTION [Utilities].[CalculateEf]
( 
	@emissionActivityId INT
	,@emissionProfileId INT
	,@userInput decimal(10,2)
	,@conversionFactor decimal(10,4)
)
RETURNS DECIMAL(10,2)
AS
BEGIN
  DECLARE @ef decimal(10,5), @id INT;
	DECLARE @profileId int = @emissionProfileId;	

	IF NOT EXISTS(SELECT * FROM [Emissions].[EmissionFactor]  WHERE [activityId] = @emissionActivityId AND [emissionProfileId] = @emissionProfileId)
			SET @profileId = (SELECT ISNULL(defaultProfileId, id) FROM Emissions.EmissionProfile WHERE id = @emissionProfileId)

	SELECT TOP 1 @id = id, @ef = ef 
			FROM [Emissions].[EmissionFactor] 
		 WHERE [activityId] = @emissionActivityId
			 AND [emissionProfileId] = @profileId

	DECLARE @result DECIMAL(10,2)
	IF @id IS NULL 
		SET @result = 0;
	ELSE
		SET @result = @userInput * @conversionFactor * cast(ISNULL(@ef, 0) as decimal(10,5)) 

	RETURN @result;

END
GO


-- ----------------------------
-- function structure for CalculateTotalEmission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[CalculateTotalEmission]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[CalculateTotalEmission]
GO

CREATE FUNCTION [Utilities].[CalculateTotalEmission]
( 
	@emissionActivityId INT
	,@emissionProfileId INT
	,@userInput decimal(10,2)
	,@conversionFactor decimal(10,5)
)
RETURNS DECIMAL(15,2)
AS
BEGIN
  DECLARE @ef decimal(10,5), @wtt decimal(10,5), @tnd decimal(10,5), @tndWtt decimal(10,5), @id INT;

	SELECT TOP 1 @id = id
				,@ef = ef 
				,@wtt = wtt 
				,@tnd = tnd 
				,@tndWtt = tndWtt 
		FROM [Emissions].[EmissionFactor] 
	 WHERE [activityId] = @emissionActivityId
		 AND [emissionProfileId] = @emissionProfileId

	DECLARE @result DECIMAL(15,5)
	IF @id IS NULL 
		SET @result = 0;
	ELSE
	BEGIN
		DECLARE @effectiveInput DECIMAL(15, 5) = @userInput * @conversionFactor 
		SET @result = (@effectiveInput * cast(ISNULL(@ef, 0) as decimal(15,5)))
								+ (@effectiveInput * cast(ISNULL(@wtt, 0) as decimal(15,5)))
								+ (@effectiveInput * cast(ISNULL(@tnd, 0) as decimal(10,5)))
								+ (@effectiveInput * cast(ISNULL(@tndWtt, 0) as decimal(10,5)))
	END
	RETURN ROUND(@result, 2);

END
GO


-- ----------------------------
-- function structure for CalculateWtt
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[CalculateWtt]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[CalculateWtt]
GO

CREATE FUNCTION [Utilities].[CalculateWtt]
( 
	@emissionActivityId INT
	,@emissionProfileId INT
	,@userInput decimal(10,2)
	,@conversionFactor decimal(10,4)
)
RETURNS DECIMAL(10,2)
AS
BEGIN
  DECLARE @wtt decimal(10,5), @id INT;
	DECLARE @profileId int = @emissionProfileId;	

	IF NOT EXISTS(SELECT * FROM [Emissions].[EmissionFactor]  WHERE [activityId] = @emissionActivityId AND [emissionProfileId] = @emissionProfileId)
			SET @profileId = (SELECT ISNULL(defaultProfileId, id) FROM Emissions.EmissionProfile WHERE id = @emissionProfileId)

	SELECT TOP 1 @id = id, @wtt = wtt 
		FROM [Emissions].[EmissionFactor] 
	 WHERE [activityId] = @emissionActivityId
		 AND [emissionProfileId] = @profileId

	DECLARE @result DECIMAL(10,2)
	IF @id IS NULL 
		SET @result = 0;
	ELSE
		SET @result = @userInput * @conversionFactor * cast(ISNULL(@wtt, 0) as decimal(10,5)) 

	RETURN @result;

END
GO


-- ----------------------------
-- procedure structure for spLog_GetPrevDayErrors
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[spLog_GetPrevDayErrors]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Utilities].[spLog_GetPrevDayErrors]
GO

CREATE PROCEDURE [Utilities].[spLog_GetPrevDayErrors]
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @HTMLContent nvarchar(max);

    SELECT @HTMLContent = STRING_AGG(
                                    '<tr>' +
                                    '<td>' + CAST(dateTime AS NVARCHAR(MAX)) + '</td>' +
                                    '<td>' + functionName + '</td>' +
                                    '<td>' + errorMessage + '</td>' +
                                    '<td>' + errorDetails + '</td>' +
                                    '</tr>','')
    FROM Utilities.ErrorLogs
    Where CAST(dateTime as DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE);

    SELECT '<table border="1">' +
           '<tr><th>DateTime</th><th>Function Name</th><th>Error Message</th><th>Error Details</th></tr>'+
           @HTMLContent +'</table>' AS HTMLContent;
END;
GO


-- ----------------------------
-- function structure for GetProductCosts
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[GetProductCosts]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[GetProductCosts]
GO

CREATE FUNCTION [Utilities].[GetProductCosts] (@date DATE, @product NVARCHAR(64), @costName NVARCHAR(64) = NULL)
RETURNS NUMERIC(10,2) -- or whatever precision and scale you need
AS
BEGIN
    DECLARE @amount NUMERIC(10,2);

    SELECT @amount = SUM(pc.amount)
    FROM DataModel.Products p 
    LEFT JOIN DataModel.ProductCosts pc ON p.id = pc.productId
    WHERE @date BETWEEN pc.validFrom AND ISNULL(pc.ValidTo, @date)
      AND @date BETWEEN p.validFrom AND ISNULL(p.ValidTo, @date)
      AND p.name = @product
	  AND (pc.costName = @costname OR @costname IS NULL);

    RETURN ISNULL(@amount, 0); -- Returns 0 if no costs are found
END;
GO


-- ----------------------------
-- function structure for GetCommissionCosts
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[GetCommissionCosts]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[GetCommissionCosts]
GO

CREATE FUNCTION [Utilities].[GetCommissionCosts] (@date DATE, @product NVARCHAR(64), @commissionName NVARCHAR(64) = NULL, @profit NUMERIC(10,2))
RETURNS NUMERIC(10,2) -- or whatever precision and scale you need
AS
BEGIN
    DECLARE @amount NUMERIC(10,2);

    SELECT @amount = SUM(@profit*pc.commission)
    FROM DataModel.Products p 
    LEFT JOIN DataModel.Commissions pc ON p.id = pc.productId
    WHERE @date BETWEEN pc.validFrom AND ISNULL(pc.ValidTo, @date)
      AND @date BETWEEN p.validFrom AND ISNULL(p.ValidTo, @date)
      AND p.name = @product
	  AND (pc.Name = @commissionName OR @commissionName IS NULL);

    RETURN ISNULL(@amount, 0); -- Returns 0 if no costs are found
END;
GO


-- ----------------------------
-- function structure for CalculateTnd
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[CalculateTnd]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[CalculateTnd]
GO

CREATE FUNCTION [Utilities].[CalculateTnd]
( 
	@emissionActivityId INT
	,@emissionProfileId INT
	,@userInput decimal(10,2)
	,@conversionFactor decimal(10,4)
)
RETURNS DECIMAL(10,2)
AS
BEGIN
  DECLARE @tnd decimal(10,5), @id INT;
	DECLARE @profileId int = @emissionProfileId;	

	IF NOT EXISTS(SELECT * FROM [Emissions].[EmissionFactor]  WHERE [activityId] = @emissionActivityId AND [emissionProfileId] = @emissionProfileId)
			SET @profileId = (SELECT ISNULL(defaultProfileId, id) FROM Emissions.EmissionProfile WHERE id = @emissionProfileId)

	SELECT TOP 1 @id = id, @tnd = tnd 
		FROM [Emissions].[EmissionFactor] 
	 WHERE [activityId] = @emissionActivityId
		 AND [emissionProfileId] = @profileId

	DECLARE @result DECIMAL(10,2)
	IF @id IS NULL 
		SET @result = 0;
	ELSE
		SET @result = @userInput * @conversionFactor * cast(ISNULL(@tnd, 0) as decimal(10,5)) 

	RETURN @result;

END
GO


-- ----------------------------
-- function structure for CalculateTndWtt
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[CalculateTndWtt]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[CalculateTndWtt]
GO

CREATE FUNCTION [Utilities].[CalculateTndWtt]
( 
	@emissionActivityId INT
	,@emissionProfileId INT
	,@userInput decimal(10,2)
	,@conversionFactor decimal(10,4)
)
RETURNS DECIMAL(10,2)
AS
BEGIN
  DECLARE @tndWtt decimal(10,5), @id INT;
	DECLARE @profileId int = @emissionProfileId;	

	IF NOT EXISTS(SELECT * FROM [Emissions].[EmissionFactor]  WHERE [activityId] = @emissionActivityId AND [emissionProfileId] = @emissionProfileId)
			SET @profileId = (SELECT ISNULL(defaultProfileId, id) FROM Emissions.EmissionProfile WHERE id = @emissionProfileId)

	SELECT TOP 1 @id = id, @tndWtt = tndWtt 
		FROM [Emissions].[EmissionFactor] 
	 WHERE [activityId] = @emissionActivityId
		 AND [emissionProfileId] = @profileId

	DECLARE @result DECIMAL(10,2)
	IF @id IS NULL 
		SET @result = 0;
	ELSE
		SET @result = @userInput * @conversionFactor * cast(ISNULL(@tndWtt, 0) as decimal(10,5)) 

	RETURN @result;

END
GO


-- ----------------------------
-- function structure for DateToEpoch
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[DateToEpoch]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[DateToEpoch]
GO

CREATE FUNCTION [Utilities].[DateToEpoch]
(
	@dt datetime
)
RETURNS bigint
AS
BEGIN
	RETURN DATEDIFF(SECOND,'1970-01-01', IsNull(@dt, GetDate()))
END
GO


-- ----------------------------
-- function structure for DateToEpochTZ
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[DateToEpochTZ]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[DateToEpochTZ]
GO

CREATE FUNCTION [Utilities].[DateToEpochTZ]
(
    @dt datetime
)
RETURNS bigint
AS
BEGIN
    DECLARE @offset INT = DATEPART(tz, IsNull(@dt, GetDate()) AT TIME ZONE 'GMT Standard Time')
    DECLARE @d DATETIME = DATEADD(MINUTE, @offset*-1, IsNull(@dt, GetDate())) 
    RETURN DATEDIFF(SECOND,'1970-01-01', IsNull(@d, GetDate()))
END
GO


-- ----------------------------
-- function structure for EpochToDate
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[EpochToDate]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[EpochToDate]
GO

CREATE FUNCTION [Utilities].[EpochToDate]
(
	@ep BIGINT = NULL
)
RETURNS DATETIME
AS
BEGIN
	IF @ep IS NULL
	BEGIN
		RETURN GETUTCDATE()
	END
	DECLARE @unadjustedDate datetime = DATEADD(SECOND, @ep,'1970-01-01')
	RETURN DateAdd(Minute, DatePart(tz, @unadjustedDate AT TIME ZONE 'GMT Standard Time'), @unadjustedDate)
END
GO


-- ----------------------------
-- function structure for GetEF
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[GetEF]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[GetEF]
GO

CREATE FUNCTION [Utilities].[GetEF]
( 
	@emissionActivityId INT
	,@emissionProfileId INT
)
RETURNS DECIMAL(10,5)
AS
BEGIN
  DECLARE @ef decimal(10,5), @id INT;
	DECLARE @profileId int = @emissionProfileId;	

	IF NOT EXISTS(SELECT * FROM [Emissions].[EmissionFactor]  WHERE [activityId] = @emissionActivityId AND [emissionProfileId] = @emissionProfileId)
			SET @profileId = (SELECT ISNULL(defaultProfileId, id) FROM Emissions.EmissionProfile WHERE id = @emissionProfileId)

	SELECT TOP 1 @ef = ef 
			FROM [Emissions].[EmissionFactor] 
		 WHERE [activityId] = @emissionActivityId
			 AND [emissionProfileId] = @profileId

	RETURN @ef;

END
GO


-- ----------------------------
-- function structure for MinutesToDuration
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[MinutesToDuration]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[MinutesToDuration]
GO

CREATE FUNCTION [Utilities].[MinutesToDuration]
(
    @minutes int 
)
RETURNS nvarchar(30)

AS
BEGIN

    declare @days int = floor(@minutes/(24*60));
    set @minutes = @minutes-(@days*(24*60));
    DECLARE @hours int = FLOOR(@minutes/60);
    set @minutes = @minutes - (@hours*60);

  return CAST((case @days when 0 then '' else cast(@days as varchar(5))+'d ' end)+
              (case @hours when 0 then '' else cast(@hours as varchar(2))+'h ' end)+
              (case @minutes when 0 then '' else cast(@minutes as varchar(2))+'m ' end) as VARCHAR(30));
END
GO


-- ----------------------------
-- function structure for GetWTT
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[GetWTT]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[GetWTT]
GO

CREATE FUNCTION [Utilities].[GetWTT]
( 
	@emissionActivityId INT
	,@emissionProfileId INT
)
RETURNS DECIMAL(10,5)
AS
BEGIN
  DECLARE @wtt decimal(10,5), @id INT;
	DECLARE @profileId int = @emissionProfileId;	

	IF NOT EXISTS(SELECT * FROM [Emissions].[EmissionFactor]  WHERE [activityId] = @emissionActivityId AND [emissionProfileId] = @emissionProfileId)
			SET @profileId = (SELECT ISNULL(defaultProfileId, id) FROM Emissions.EmissionProfile WHERE id = @emissionProfileId)

	SELECT TOP 1 @wtt = wtt 
			FROM [Emissions].[EmissionFactor] 
		 WHERE [activityId] = @emissionActivityId
			 AND [emissionProfileId] = @profileId

	RETURN @wtt;

END
GO


-- ----------------------------
-- function structure for GetTND
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[GetTND]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[GetTND]
GO

CREATE FUNCTION [Utilities].[GetTND]
( 
	@emissionActivityId INT
	,@emissionProfileId INT
)
RETURNS DECIMAL(10,5)
AS
BEGIN
  DECLARE @tnd decimal(10,5), @id INT;
	DECLARE @profileId int = @emissionProfileId;	

	IF NOT EXISTS(SELECT * FROM [Emissions].[EmissionFactor]  WHERE [activityId] = @emissionActivityId AND [emissionProfileId] = @emissionProfileId)
			SET @profileId = (SELECT ISNULL(defaultProfileId, id) FROM Emissions.EmissionProfile WHERE id = @emissionProfileId)

	SELECT TOP 1 @tnd = tnd 
			FROM [Emissions].[EmissionFactor] 
		 WHERE [activityId] = @emissionActivityId
			 AND [emissionProfileId] = @profileId

	RETURN @tnd;

END
GO


-- ----------------------------
-- function structure for GetTNDWTT
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[GetTNDWTT]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Utilities].[GetTNDWTT]
GO

CREATE FUNCTION [Utilities].[GetTNDWTT]
( 
	@emissionActivityId INT
	,@emissionProfileId INT
)
RETURNS DECIMAL(10,5)
AS
BEGIN
  DECLARE @tndWtt decimal(10,5), @id INT;
	DECLARE @profileId int = @emissionProfileId;	

	IF NOT EXISTS(SELECT * FROM [Emissions].[EmissionFactor]  WHERE [activityId] = @emissionActivityId AND [emissionProfileId] = @emissionProfileId)
			SET @profileId = (SELECT ISNULL(defaultProfileId, id) FROM Emissions.EmissionProfile WHERE id = @emissionProfileId)

	SELECT TOP 1 @tndWtt = tndWtt 
			FROM [Emissions].[EmissionFactor] 
		 WHERE [activityId] = @emissionActivityId
			 AND [emissionProfileId] = @profileId

	RETURN @tndWtt;

END
GO


-- ----------------------------
-- procedure structure for spLog_Error
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Utilities].[spLog_Error]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Utilities].[spLog_Error]
GO

CREATE PROCEDURE [Utilities].[spLog_Error]
    @functionName NVARCHAR(255),
    @errorMessage NVARCHAR(MAX),
    @errorDetails NVARCHAR(MAX),
    @environmentKey NVARCHAR(20),
    @formId NVARCHAR(25) = NULL,
    @submissionId NVARCHAR(25) = NULL
AS
BEGIN
    INSERT INTO Utilities.ErrorLogs (functionName, errorMessage, errorDetails, environmentKey, formId, submissionId)
    VALUES (@functionName, @errorMessage, @errorDetails, @environmentKey, @formId, @submissionId);
END;
GO


-- ----------------------------
-- Auto increment value for ErrorLogs
-- ----------------------------
DBCC CHECKIDENT ('[Utilities].[ErrorLogs]', RESEED, 10037)
GO

