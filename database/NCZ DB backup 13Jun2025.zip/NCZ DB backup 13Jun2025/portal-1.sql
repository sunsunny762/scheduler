/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : portal

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 11:19:19
*/


-- ----------------------------
-- Table structure for Application
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Application]') AND type IN ('U'))
	DROP TABLE [portal].[Application]
GO

CREATE TABLE [portal].[Application] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [path] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[Application] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Application
-- ----------------------------
SET IDENTITY_INSERT [portal].[Application] ON
GO

INSERT INTO [portal].[Application] ([id], [name], [description], [path], [displayName]) VALUES (N'1', N'nczportal', NULL, NULL, NULL)
GO

SET IDENTITY_INSERT [portal].[Application] OFF
GO


-- ----------------------------
-- Table structure for ApplicationFeature
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationFeature]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationFeature]
GO

CREATE TABLE [portal].[ApplicationFeature] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationId] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[ApplicationFeature] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ApplicationFeature
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationFeature] ON
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'1', N'1', N'adm-dashboard', N'Admin only', N'Dashboard (Admin)')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'2', N'1', N'adm-companies', N'Admin only', N'Companies  (Admin)')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'3', N'1', N'adm-certifications', N'Admin only', N'Certifications  (Admin)')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'4', N'1', N'submissions', NULL, N'Submissions')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'5', N'1', N'adm-users', N'Admin only', N'Users  (Admin)')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'7', N'1', N'dashboard', NULL, N'Dashboard')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'8', N'1', N'certifications', NULL, N'Certifications')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'9', N'1', N'users', NULL, N'Users')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'10', N'1', N'locations', NULL, N'Locations')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'11', N'1', N'ncz-directory', NULL, N'NCZ Directory')
GO

INSERT INTO [portal].[ApplicationFeature] ([id], [applicationId], [name], [description], [displayName]) VALUES (N'6', N'1', N'adm-settings', N'Admin only', N'Settings (Admin)')
GO

SET IDENTITY_INSERT [portal].[ApplicationFeature] OFF
GO


-- ----------------------------
-- Table structure for ApplicationFeatureOption
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationFeatureOption]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationFeatureOption]
GO

CREATE TABLE [portal].[ApplicationFeatureOption] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationFeatureId] int  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[ApplicationFeatureOption] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ApplicationFeatureOption
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationFeatureOption] ON
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'1', N'1', N'availableFromMainMenu', N'Show Dashboard link in menu', N'Show Dashboard on menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'2', N'2', N'availableFromMainMenu', N'Show Companies', N'Show Companies on menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'5', N'2', N'add', N'Add Comapany', N'Add Company')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'6', N'2', N'edit', N'Edit Company', N'Edit Company')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'7', N'2', N'delete', N'Delete Company', N'Delete Company')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'9', N'3', N'add', N'Add Certification', N'Add Certification')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'10', N'3', N'edit', N'Edit Certification', N'Edit Certification')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'11', N'3', N'delete', N'Delete Certification', N'Delete Certification')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'12', N'3', N'availableFromMainMenu', N'Show Certifications', N'Show Certifications on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'13', N'4', N'add', N'Add Submission', N'Add Submission')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'14', N'5', N'add', N'Add User', N'Add User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'15', N'5', N'edit', N'Edit User', N'Edit User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'16', N'5', N'delete', N'Delete User', N'Delete User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'18', N'5', N'availableFromMainMenu', N'Show Users', N'Show Users on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'21', N'7', N'availableFromMainMenu', N'Show Dashboard link in menu', N'Show Dashboard on menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'22', N'8', N'availableFromMainMenu', N'Show Certifications', N'Show Certifications on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'23', N'9', N'availableFromMainMenu', N'Show Users', N'Show Users on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'24', N'9', N'add', N'Add User', N'Add User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'25', N'9', N'edit', N'Edit User', N'Edit User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'26', N'9', N'delete', N'Delete User', N'Delete User')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'27', N'10', N'add', N'Add Location', N'Add Location')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'28', N'10', N'edit', N'Edit Location', N'Edit Location')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'29', N'10', N'delete', N'Delete Location', N'Delete Location')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'30', N'10', N'availableFromMainMenu', N'Show Locations on menu', N'Show Locations on Menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'31', N'4', N'delete', N'Delete Submission', N'Delete Submission')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'32', N'11', N'availableFromMainMenu', N'Show Customer directory on menu', N'Show Customer directory on menu')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'33', N'11', N'settings', N'Change settings of NCZ directory item', N'Change settings of NCZ directory item')
GO

INSERT INTO [portal].[ApplicationFeatureOption] ([id], [applicationFeatureId], [name], [description], [displayName]) VALUES (N'34', N'3', N'uploadDocument', N'Upload Document for Certification', N'Upload Document for Certification')
GO

SET IDENTITY_INSERT [portal].[ApplicationFeatureOption] OFF
GO


-- ----------------------------
-- Table structure for ApplicationRole
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationRole]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationRole]
GO

CREATE TABLE [portal].[ApplicationRole] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationId] int  NOT NULL,
  [applicationAccessId] int  NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [roleScope] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [companyId] int DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[ApplicationRole] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'admin, client, both',
'SCHEMA', N'portal',
'TABLE', N'ApplicationRole',
'COLUMN', N'roleScope'
GO

EXEC sp_addextendedproperty
'MS_Description', N'0 = available to all companies',
'SCHEMA', N'portal',
'TABLE', N'ApplicationRole',
'COLUMN', N'companyId'
GO


-- ----------------------------
-- Records of ApplicationRole
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationRole] ON
GO

INSERT INTO [portal].[ApplicationRole] ([id], [applicationId], [applicationAccessId], [name], [description], [roleScope], [companyId]) VALUES (N'1', N'1', NULL, N'Super Admin', N'NCZ Admin ', N'admin', N'0')
GO

INSERT INTO [portal].[ApplicationRole] ([id], [applicationId], [applicationAccessId], [name], [description], [roleScope], [companyId]) VALUES (N'2', N'1', NULL, N'Admin', N'Client''s Admin user', N'client', N'0')
GO

INSERT INTO [portal].[ApplicationRole] ([id], [applicationId], [applicationAccessId], [name], [description], [roleScope], [companyId]) VALUES (N'3', N'1', NULL, N'Operator', NULL, N'client', N'0')
GO

INSERT INTO [portal].[ApplicationRole] ([id], [applicationId], [applicationAccessId], [name], [description], [roleScope], [companyId]) VALUES (N'4', N'1', NULL, N'Standard', NULL, N'admin', N'0')
GO

SET IDENTITY_INSERT [portal].[ApplicationRole] OFF
GO


-- ----------------------------
-- Table structure for ApplicationRoleOption
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationRoleOption]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationRoleOption]
GO

CREATE TABLE [portal].[ApplicationRoleOption] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationRoleId] int  NOT NULL,
  [applicationFeatureOptionId] int  NOT NULL,
  [available] bit  NOT NULL,
  [assignable] bit  NOT NULL
)
GO

ALTER TABLE [portal].[ApplicationRoleOption] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ApplicationRoleOption
-- ----------------------------
SET IDENTITY_INSERT [portal].[ApplicationRoleOption] ON
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'1', N'1', N'1', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'3', N'1', N'2', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'4', N'1', N'5', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'5', N'2', N'22', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'6', N'2', N'23', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'10', N'1', N'6', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'11', N'1', N'7', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'12', N'1', N'9', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'13', N'1', N'10', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'14', N'1', N'11', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'15', N'1', N'12', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'16', N'1', N'13', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'17', N'1', N'14', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'18', N'1', N'15', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'19', N'1', N'16', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'20', N'1', N'18', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'21', N'2', N'24', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'22', N'2', N'25', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'23', N'2', N'26', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'25', N'2', N'13', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'26', N'1', N'27', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'27', N'1', N'28', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'28', N'1', N'29', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'29', N'2', N'27', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'30', N'2', N'28', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'31', N'2', N'29', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'32', N'2', N'30', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'34', N'1', N'31', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'35', N'1', N'32', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'36', N'2', N'32', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'37', N'1', N'33', N'1', N'0')
GO

INSERT INTO [portal].[ApplicationRoleOption] ([id], [applicationRoleId], [applicationFeatureOptionId], [available], [assignable]) VALUES (N'38', N'1', N'34', N'1', N'0')
GO

SET IDENTITY_INSERT [portal].[ApplicationRoleOption] OFF
GO


-- ----------------------------
-- Table structure for DropdownItems
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[DropdownItems]') AND type IN ('U'))
	DROP TABLE [portal].[DropdownItems]
GO

CREATE TABLE [portal].[DropdownItems] (
  [itemId] int  IDENTITY(1,1) NOT NULL,
  [itemName] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [groupId] int  NULL,
  [isDeleted] bit  NULL
)
GO

ALTER TABLE [portal].[DropdownItems] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of DropdownItems
-- ----------------------------
SET IDENTITY_INSERT [portal].[DropdownItems] ON
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'1', N'Data collection pending', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'2', N'Data collection complete', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'3', N'Report under process', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'4', N'Report generated', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'5', N'Certificate issued', N'1', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'6', N'Financial', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'7', N'Security', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'8', N'Recruitment', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'9', N'Engineering', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'10', N'Retail', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'11', N'Hospitality', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'12', N'Cleaning', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'13', N'Construction', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'14', N'Trades', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'15', N'Facilities Management', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'16', N'Sustainability', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'17', N'Graphics/Branding/Design', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'18', N'Technical/Digital/Telecoms', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'19', N'Education/Healthcare', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'20', N'Plant/Equipment/Haulage', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'21', N'Portals/Procurement Platforms', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'22', N'Retailer', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'23', N'logistics', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'24', N'Insurance', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'25', N'Charity', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'26', N'Legal', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'27', N'Pest Control', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'28', N'Window Cleaning', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'29', N'Consultancy', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'30', N'Other', N'2', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'32', N'United Kingdom', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'33', N'United States', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'34', N'United Arab Emirates', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'35', N'India', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'36', N'Canada', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'37', N'Australia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'38', N'Germany', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'39', N'France', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'40', N'China', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'41', N'Japan', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'42', N'Brazil', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'43', N'Mexico', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'44', N'South Korea', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'45', N'Italy', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'46', N'Spain', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'47', N'Netherlands', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'48', N'Russia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'49', N'Singapore', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'50', N'South Africa', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'51', N'Switzerland', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'52', N'Afghanistan', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'53', N'Albania', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'54', N'Algeria', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'55', N'American Samoa', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'56', N'Andorra', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'57', N'Angola', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'58', N'Anguilla', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'59', N'Antigua and Barbuda', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'60', N'Argentina', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'61', N'Armenia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'62', N'Aruba', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'63', N'Austria', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'64', N'Azerbaijan', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'65', N'The Bahamas', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'66', N'Bahrain', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'67', N'Bangladesh', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'68', N'Barbados', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'69', N'Belarus', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'70', N'Belgium', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'71', N'Belize', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'72', N'Benin', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'73', N'Bermuda', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'74', N'Bhutan', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'75', N'Bolivia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'76', N'Bosnia and Herzegovina', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'77', N'Botswana', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'78', N'Brunei', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'79', N'Bulgaria', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'80', N'Burkina Faso', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'81', N'Burundi', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'82', N'Cambodia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'83', N'Cameroon', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'84', N'Cape Verde', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'85', N'Cayman Islands', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'86', N'Central African Republic', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'87', N'Chad', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'88', N'Chile', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'89', N'Christmas Island', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'90', N'Cocos (Keeling) Islands', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'91', N'Colombia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'92', N'Comoros', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'93', N'Congo', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'94', N'Cook Islands', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'95', N'Costa Rica', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'96', N'Cote d''Ivoire', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'97', N'Croatia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'98', N'Cuba', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'99', N'Curaçao', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'100', N'Cyprus', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'101', N'Czech Republic', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'102', N'Democratic Republic of the Congo', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'103', N'Denmark', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'104', N'Djibouti', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'105', N'Dominica', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'106', N'Dominican Republic', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'107', N'Ecuador', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'108', N'Egypt', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'109', N'El Salvador', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'110', N'Equatorial Guinea', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'111', N'Eritrea', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'112', N'Estonia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'113', N'Ethiopia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'114', N'Falkland Islands', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'115', N'Faroe Islands', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'116', N'Fiji', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'117', N'Finland', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'118', N'French Polynesia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'119', N'Gabon', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'120', N'The Gambia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'121', N'Georgia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'122', N'Ghana', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'123', N'Gibraltar', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'124', N'Greece', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'125', N'Greenland', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'126', N'Grenada', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'127', N'Guadeloupe', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'128', N'Guam', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'129', N'Guatemala', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'130', N'Guernsey', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'131', N'Guinea', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'132', N'Guinea-Bissau', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'133', N'Guyana', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'134', N'Haiti', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'135', N'Honduras', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'136', N'Hong Kong', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'137', N'Hungary', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'138', N'Iceland', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'139', N'Indonesia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'140', N'Iran', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'141', N'Iraq', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'142', N'Ireland', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'143', N'Israel', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'144', N'Jamaica', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'145', N'Jersey', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'146', N'Jordan', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'147', N'Kazakhstan', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'148', N'Kenya', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'149', N'Kiribati', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'150', N'North Korea', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'151', N'Kosovo', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'152', N'Kuwait', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'153', N'Kyrgyzstan', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'154', N'Laos', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'155', N'Latvia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'156', N'Lebanon', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'157', N'Lesotho', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'158', N'Liberia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'159', N'Libya', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'160', N'Liechtenstein', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'161', N'Lithuania', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'162', N'Luxembourg', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'163', N'Macau', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'164', N'Macedonia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'165', N'Madagascar', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'166', N'Malawi', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'167', N'Malaysia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'168', N'Maldives', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'169', N'Mali', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'170', N'Malta', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'171', N'Marshall Islands', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'172', N'Martinique', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'173', N'Mauritania', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'174', N'Mauritius', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'175', N'Mayotte', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'176', N'Micronesia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'177', N'Moldova', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'178', N'Monaco', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'179', N'Mongolia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'180', N'Montenegro', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'181', N'Montserrat', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'182', N'Morocco', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'183', N'Mozambique', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'184', N'Myanmar', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'185', N'Nagorno-Karabakh', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'186', N'Namibia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'187', N'Nauru', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'188', N'Nepal', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'189', N'Netherlands Antilles', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'190', N'New Caledonia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'191', N'New Zealand', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'192', N'Nicaragua', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'193', N'Niger', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'194', N'Nigeria', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'195', N'Niue', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'196', N'Norfolk Island', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'197', N'Turkish Republic of Northern Cyprus', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'198', N'Northern Mariana', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'199', N'Norway', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'200', N'Oman', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'201', N'Pakistan', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'202', N'Palau', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'203', N'Palestine', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'204', N'Panama', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'205', N'Papua New Guinea', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'206', N'Paraguay', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'207', N'Peru', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'208', N'Philippines', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'209', N'Pitcairn Islands', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'210', N'Poland', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'211', N'Portugal', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'212', N'Puerto Rico', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'213', N'Qatar', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'214', N'Republic of the Congo', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'215', N'Romania', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'216', N'Rwanda', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'217', N'Saint Barthelemy', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'218', N'Saint Helena', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'219', N'Saint Kitts and Nevis', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'220', N'Saint Lucia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'221', N'Saint Martin', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'222', N'Saint Pierre and Miquelon', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'223', N'Saint Vincent and the Grenadines', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'224', N'Samoa', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'225', N'San Marino', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'226', N'Sao Tome and Principe', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'227', N'Saudi Arabia', N'3', N'0')
GO

INSERT INTO [portal].[DropdownItems] ([itemId], [itemName], [groupId], [isDeleted]) VALUES (N'228', N'Senegal', N'3', N'0')
GO

SET IDENTITY_INSERT [portal].[DropdownItems] OFF
GO


-- ----------------------------
-- Table structure for Programme
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Programme]') AND type IN ('U'))
	DROP TABLE [portal].[Programme]
GO

CREATE TABLE [portal].[Programme] (
  [progId] int  NOT NULL,
  [progName] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isActive] bit  NULL,
  [description] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[Programme] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Programme
-- ----------------------------
INSERT INTO [portal].[Programme] ([progId], [progName], [isActive], [description]) VALUES (N'1', N'Blue Award', N'1', NULL)
GO

INSERT INTO [portal].[Programme] ([progId], [progName], [isActive], [description]) VALUES (N'2', N'Silver Award', N'1', NULL)
GO

INSERT INTO [portal].[Programme] ([progId], [progName], [isActive], [description]) VALUES (N'3', N'Gold Award', N'1', NULL)
GO

INSERT INTO [portal].[Programme] ([progId], [progName], [isActive], [description]) VALUES (N'4', N'Platinum Award', N'1', NULL)
GO


-- ----------------------------
-- Table structure for ProgrammeForms
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ProgrammeForms]') AND type IN ('U'))
	DROP TABLE [portal].[ProgrammeForms]
GO

CREATE TABLE [portal].[ProgrammeForms] (
  [progId] int  NOT NULL,
  [jotformId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayOrder] smallint DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[ProgrammeForms] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ProgrammeForms
-- ----------------------------
INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'1', N'241290444812856', N'NCZ Blue Award Questionnaire', N'1')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231702222306037', N'Business Travel', N'7')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231761029921959', N'Natural Gas', N'4')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231835207128453', N'Electricity', N'2')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231921316591454', N'Water', N'3')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231951471518458', N'Other Fuels', N'5')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231953063487462', N'Refrigerents', N'8')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'231998306100453', N'Waste and Recycling', N'10')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232013593953456', N'Purchased Goods & Services', N'9')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232102389529457', N'Commuting & Home Working', N'13')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232408584059461', N'Upstream deliveries', N'11')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232561815184457', N'Downstream deliveries', N'12')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'232571467469467', N'Company Vehicles', N'6')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'2', N'241290444812856', N'Company Profile', N'1')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231702222306037', N'Business Travel', N'10')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231761029921959', N'Natural Gas', N'4')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231835207128453', N'Electricity', N'2')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231921316591454', N'Water', N'3')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231951471518458', N'Other Fuels', N'5')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231953063487462', N'Refrigerents', N'7')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'231998306100453', N'Waste and Recycling', N'8')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232013593953456', N'Purchased Goods and Services', N'11')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232102389529457', N'Commuting & Home Working', N'9')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232408584059461', N'Upstream deliveries', N'13')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232561815184457', N'Downstream deliveries', N'12')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'232571467469467', N'Company Vehicles', N'6')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'3', N'250151633085854', N'Company Profile', N'1')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231702222306037', N'Business Travel', N'10')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231761029921959', N'Natural Gas', N'4')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231835207128453', N'Electricity', N'2')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231921316591454', N'Water', N'3')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231951471518458', N'Other Fuels', N'5')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231953063487462', N'Refrigerents', N'7')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'231998306100453', N'Waste and Recycling', N'8')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232013593953456', N'Purchased Goods and Services', N'11')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232102389529457', N'Commuting & Home Working', N'9')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232408584059461', N'Upstream deliveries', N'13')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232561815184457', N'Downstream deliveries', N'12')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'232571467469467', N'Company Vehicles', N'6')
GO

INSERT INTO [portal].[ProgrammeForms] ([progId], [jotformId], [displayName], [displayOrder]) VALUES (N'4', N'250151633085854', N'Company Profile', N'1')
GO


-- ----------------------------
-- Auto increment value for Application
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Application]', RESEED, 1)
GO


-- ----------------------------
-- Auto increment value for ApplicationFeature
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationFeature]', RESEED, 11)
GO


-- ----------------------------
-- Auto increment value for ApplicationFeatureOption
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationFeatureOption]', RESEED, 34)
GO


-- ----------------------------
-- Auto increment value for ApplicationRole
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationRole]', RESEED, 4)
GO


-- ----------------------------
-- Auto increment value for ApplicationRoleOption
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationRoleOption]', RESEED, 38)
GO


-- ----------------------------
-- Auto increment value for DropdownItems
-- ----------------------------
DBCC CHECKIDENT ('[portal].[DropdownItems]', RESEED, 228)
GO

