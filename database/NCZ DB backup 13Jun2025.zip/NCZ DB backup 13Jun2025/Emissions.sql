/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Emissions

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 10:42:33
*/


-- ----------------------------
-- Table structure for EmissionActivity
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[EmissionActivity]') AND type IN ('U'))
	DROP TABLE [Emissions].[EmissionActivity]
GO

CREATE TABLE [Emissions].[EmissionActivity] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [parentId] int  NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NOT NULL,
  [Unit] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Emissions].[EmissionActivity] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of EmissionActivity
-- ----------------------------
SET IDENTITY_INSERT [Emissions].[EmissionActivity] ON
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'1', NULL, N'Water', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'2', NULL, N'Electricity', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'3', NULL, N'Natural Gas', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'4', NULL, N'Carbon dioxide', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'5', NULL, N'Methane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'6', NULL, N'Nitrous oxide', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'7', NULL, N'HFC-23', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'8', NULL, N'HFC-32', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'9', NULL, N'HFC-41', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'10', NULL, N'HFC-125', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'11', NULL, N'HFC-134', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'12', NULL, N'HFC-134a', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'13', NULL, N'HFC-143', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'14', NULL, N'HFC-143a', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'15', NULL, N'HFC-152a', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'16', NULL, N'HFC-227ea', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'17', NULL, N'HFC-236fa', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'18', NULL, N'HFC-245fa', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'19', NULL, N'HFC-43-I0mee', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'20', NULL, N'Perfluoromethane (PFC-14)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'21', NULL, N'Perfluoroethane (PFC-116)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'22', NULL, N'Perfluoropropane (PFC-218)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'23', NULL, N'Perfluorocyclobutane (PFC-318)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'24', NULL, N'Perfluorobutane (PFC-3-1-10)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'25', NULL, N'Perfluoropentane (PFC-4-1-12)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'26', NULL, N'Perfluorohexane (PFC-5-1-14)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'27', NULL, N'PFC-9-1-18', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'28', NULL, N'Perfluorocyclopropane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'29', NULL, N'Sulphur hexafluoride (SF6)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'30', NULL, N'HFC-152', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'31', NULL, N'HFC-161', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'32', NULL, N'HFC-236cb', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'33', NULL, N'HFC-236ea', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'34', NULL, N'HFC-245ca', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'35', NULL, N'HFC-365mfc', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'36', NULL, N'Nitrogen trifluoride', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'37', NULL, N'R401A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'38', NULL, N'R401B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'39', NULL, N'R401C', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'40', NULL, N'R402A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'41', NULL, N'R402B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'42', NULL, N'R403A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'43', NULL, N'R403B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'44', NULL, N'R404A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'45', NULL, N'R405A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'46', NULL, N'R406A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'47', NULL, N'R407A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'48', NULL, N'R407B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'49', NULL, N'R407C', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'50', NULL, N'R407D', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'51', NULL, N'R407E', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'52', NULL, N'R407F', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'53', NULL, N'R408A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'54', NULL, N'R409A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'55', NULL, N'R409B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'56', NULL, N'R410A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'57', NULL, N'R410B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'58', NULL, N'R411A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'59', NULL, N'R411B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'60', NULL, N'R412A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'61', NULL, N'R413A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'62', NULL, N'R414A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'63', NULL, N'R414B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'64', NULL, N'R415A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'65', NULL, N'R415B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'66', NULL, N'R416A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'67', NULL, N'R417A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'68', NULL, N'R417B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'69', NULL, N'R417C', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'70', NULL, N'R418A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'71', NULL, N'R419A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'72', NULL, N'R419B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'73', NULL, N'R420A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'74', NULL, N'R421A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'75', NULL, N'R421B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'76', NULL, N'R422A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'77', NULL, N'R422B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'78', NULL, N'R422C', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'79', NULL, N'R422D', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'80', NULL, N'R422E', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'81', NULL, N'R423A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'82', NULL, N'R424A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'83', NULL, N'R425A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'84', NULL, N'R426A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'85', NULL, N'R427A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'86', NULL, N'R428A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'87', NULL, N'R429A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'88', NULL, N'R430A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'89', NULL, N'R431A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'90', NULL, N'R432A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'91', NULL, N'R433A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'92', NULL, N'R433B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'93', NULL, N'R433C', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'94', NULL, N'R434A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'95', NULL, N'R435A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'96', NULL, N'R436A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'97', NULL, N'R436B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'98', NULL, N'R437A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'99', NULL, N'R438A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'100', NULL, N'R439A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'101', NULL, N'R440A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'102', NULL, N'R441A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'103', NULL, N'R442A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'104', NULL, N'R443A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'105', NULL, N'R444A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'106', NULL, N'R445A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'107', NULL, N'R500', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'108', NULL, N'R501', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'109', NULL, N'R502', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'110', NULL, N'R503', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'111', NULL, N'R504', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'112', NULL, N'R505', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'113', NULL, N'R506', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'114', NULL, N'R507A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'115', NULL, N'R508A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'116', NULL, N'R508B', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'117', NULL, N'R509A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'118', NULL, N'R510A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'119', NULL, N'R511A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'120', NULL, N'R512A', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'121', NULL, N'CFC-11/R11 = trichlorofluoromethane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'122', NULL, N'CFC-12/R12 = dichlorodifluoromethane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'123', NULL, N'CFC-13', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'124', NULL, N'CFC-113', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'125', NULL, N'CFC-114', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'126', NULL, N'CFC-115', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'127', NULL, N'Halon-1211', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'128', NULL, N'Halon-1301', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'129', NULL, N'Halon-2402', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'130', NULL, N'Carbon tetrachloride', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'131', NULL, N'Methyl bromide', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'132', NULL, N'Methyl chloroform', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'133', NULL, N'HCFC-22/R22 = chlorodifluoromethane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'134', NULL, N'HCFC-123', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'135', NULL, N'HCFC-124', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'136', NULL, N'HCFC-141b', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'137', NULL, N'HCFC-142b', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'138', NULL, N'HCFC-225ca', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'139', NULL, N'HCFC-225cb', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'140', NULL, N'HCFC-21', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'141', NULL, N'HFE-125', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'142', NULL, N'HFE-134', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'143', NULL, N'HFE-143a', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'144', NULL, N'HCFE-235da2', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'145', NULL, N'HFE-245cb2', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'146', NULL, N'HFE-245fa2', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'147', NULL, N'HFE-254cb2', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'148', NULL, N'HFE-347mcc3', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'149', NULL, N'HFE-347pcf2', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'150', NULL, N'HFE-356pcc3', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'151', NULL, N'HFE-449sl (HFE-7100)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'152', NULL, N'HFE-569sf2 (HFE-7200)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'153', NULL, N'HFE-43-10pccc124 (H-Galden1040x)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'154', NULL, N'HFE-236ca12 (HG-10)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'155', NULL, N'HFE-338pcc13 (HG-01)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'156', NULL, N'Trifluoromethyl sulphur pentafluoride', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'157', NULL, N'PFPMIE', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'158', NULL, N'Dimethylether', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'159', NULL, N'Methylene chloride', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'160', NULL, N'Methyl chloride', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'161', NULL, N'R290 = propane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'162', NULL, N'R600A = isobutane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'163', NULL, N'R600 = butane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'164', NULL, N'R601 = pentane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'165', NULL, N'R601A = isopentane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'166', NULL, N'R170 = ethane', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'167', NULL, N'R1270 = propene', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'168', NULL, N'R1234yf*', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'169', NULL, N'R1234ze*', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'170', N'1', N'Small Car Petrol', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'171', N'1', N'Medium Car Petrol', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'172', N'1', N'Large Car Petrol', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'173', N'1', N'Small car diesel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'174', N'1', N'Medium car diesel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'175', N'1', N'Large car diesel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'176', N'1', N'Small car hybrid', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'177', N'1', N'Medium car hybrid', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'178', N'1', N'Large car hybrid', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'179', N'1', N'Small car electric', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'180', N'1', N'Medium car electric', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'181', N'1', N'Large car electric', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'182', N'1', N'Small car plug in hybrid', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'183', N'1', N'Medium car plug in hybrid', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'184', N'1', N'Large car plug in hybrid', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'185', NULL, N'Class I Vans Petrol', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'186', NULL, N'Class II Vans Petrol', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'187', NULL, N'Class III Vans Petrol', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'188', NULL, N'Class I Vans Diesel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'189', NULL, N'Class II Vans Diesel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'190', NULL, N'Class III Vans Diesel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'192', NULL, N'Class I Vans Battery Electric', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'193', NULL, N'Class II Vans Battery Electric', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'194', NULL, N'Class III Vans Battery Electric', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'195', NULL, N'HGVs - Rigid (>3.5-7.5t)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'196', NULL, N'HGVs - Rigid (>7.5-17t)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'197', NULL, N'HGVs - Rigid (>17t)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'198', NULL, N'HGVs - Avg Rigids', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'199', NULL, N'HGVs - Articulated (>3.5-33t)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'200', NULL, N'HGVs - Articulated (>33t)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'201', NULL, N'HGVs - Avg Artics', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'202', NULL, N'No of litre - Petrol', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'203', NULL, N'No of litre - Diesel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'204', NULL, N'Amount spent on Petrol', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'205', NULL, N'Amount spent on Diesel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'206', NULL, N'Amount spent on other fuel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'207', N'1', N'Average car petrol', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'208', N'1', N'Average car diesel', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'209', N'1', N'Average car hybrid', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'210', N'1', N'Average  car plug-in hybrid', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'211', N'1', N'Average car electric', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'212', N'1', N'Average Motorbike', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'213', N'1', N'Train - National', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'214', N'1', N'Train - Underground', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'215', N'1', N'Regular Taxi', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'216', N'1', N'Local Bus', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'217', N'1', N'Flight - Domestic Avg Passenger', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'218', N'1', N'Flight - Short haul Avg Passenger', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'219', N'1', N'Flight - Long haul Avg Passenger', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'220', N'1', N'Cycling', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'221', N'1', N'Walking', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'222', N'2', N'Hotel stay', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'223', N'3', N'Email sent', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'224', N'3', N'Pages printed', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'225', N'0', N'Motorbike - Small', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'226', NULL, N'Motorbike - Medium ', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'227', NULL, N'Motorbike  - Large ', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'228', NULL, N'Train - International ', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'229', NULL, N'Train - Metro and/or tram', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'230', NULL, N'Train (Amount spend)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'231', NULL, N'Taxi (Amount spend)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'232', NULL, N'Bus Coach', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'233', NULL, N'Bus (Amount spend) ', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'234', NULL, N'Average Passenger -Short-Haul Flights', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'235', NULL, N'Economy Class - Short-Haul Flights', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'236', NULL, N'Business Class - Short-Haul Flights', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'237', NULL, N'Average Passenger Long Haul', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'238', NULL, N'Economy Class  Long Haul', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'239', NULL, N'Premium Economy Class  Long Haul', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'240', NULL, N'Business Class  Long Haul', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'241', NULL, N'First Class  Long Haul', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'242', NULL, N'Flight (Amount spend)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'243', NULL, N'Hotel (Amount spend) ', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'244', NULL, N'General Recycling', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'245', NULL, N'Construction Waste', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'246', NULL, N'Domestic waste', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'247', NULL, N'Organic: food and drink waste', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'248', NULL, N'Organic: garden waste', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'249', NULL, N'Organic: mixed food and garden waste', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'250', NULL, N'Commercial and industrial waste', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'251', NULL, N'Aggregates, Asphalt, Bricks, Concrete and Insulation', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'252', NULL, N'Asbestos', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'253', NULL, N'Metals', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'254', NULL, N'Soils', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'255', NULL, N'Plasterboard', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'256', NULL, N'Wood', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'257', NULL, N'Glass, Metal, Plastics and Electrical Items', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'258', NULL, N'Clothing', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'259', NULL, N'Paper', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'260', NULL, N'Farms', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'261', NULL, N'Forestry, fishing, and related activities', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'262', NULL, N'Oil and gas extraction', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'263', NULL, N'Mining, except oil and gas', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'264', NULL, N'Support activities for mining', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'265', NULL, N'Utilities', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'266', NULL, N'Construction', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'267', NULL, N'Food and beverage and tobacco products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'268', NULL, N'Textile mills and textile product mills', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'269', NULL, N'Apparel and leather and allied products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'270', NULL, N'Wood products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'271', NULL, N'Paper products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'272', NULL, N'Printing and related support activities', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'273', NULL, N'Petroleum and coal products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'274', NULL, N'Chemical products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'275', NULL, N'Plastics and rubber products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'276', NULL, N'Nonmetallic mineral products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'277', NULL, N'Primary metals', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'278', NULL, N'Fabricated metal products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'279', NULL, N'Machinery', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'280', NULL, N'Computer and electronic products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'281', NULL, N'Electrical equipment, appliances, and components', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'282', NULL, N'Motor vehicles, bodies and trailers, and parts', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'283', NULL, N'Other transportation equipment', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'284', NULL, N'Furniture and related products', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'285', NULL, N'Miscellaneous manufacturing', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'286', NULL, N'Wholesale trade', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'287', NULL, N'Motor vehicle and parts dealers', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'288', NULL, N'Food and beverage stores', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'289', NULL, N'General merchandise stores', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'290', NULL, N'Air transportation', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'291', NULL, N'Rail transportation', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'292', NULL, N'Water transportation', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'293', NULL, N'Truck transportation', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'294', NULL, N'Transit and ground passenger transportation', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'295', NULL, N'Pipeline transportation', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'296', NULL, N'Other transportation and support activities', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'297', NULL, N'Warehousing and storage', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'298', NULL, N'Other retail', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'299', NULL, N'Publishing industries, except internet (includes software)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'300', NULL, N'Motion picture and sound recording industries', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'301', NULL, N'Broadcasting and telecommunications', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'302', NULL, N'Data processing, internet publishing, and other information services', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'303', NULL, N'Federal Reserve banks, credit intermediation, and related activities', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'304', NULL, N'Securities, commodity contracts, and investments', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'305', NULL, N'Insurance carriers and related activities', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'306', NULL, N'Funds, trusts, and other financial vehicles', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'307', NULL, N'Rental and leasing services and lessors of intangible assets', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'308', NULL, N'Legal services', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'309', NULL, N'Miscellaneous professional, scientific, and technical services', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'310', NULL, N'Computer systems design and related services', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'311', NULL, N'Management of companies and enterprises', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'312', NULL, N'Administrative and support services', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'313', NULL, N'Waste management and remediation services', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'314', NULL, N'Educational services', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'315', NULL, N'Ambulatory health care services', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'316', NULL, N'Hospitals', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'317', NULL, N'Nursing and residential care facilities', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'318', NULL, N'Social assistance', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'319', NULL, N'Performing arts, spectator sports, museums, and related activities', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'320', NULL, N'Amusements, gambling, and recreation industries', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'321', NULL, N'Accommodation', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'322', NULL, N'Food services and drinking places', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'323', NULL, N'Other services, except government', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'324', NULL, N'Housing', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'325', NULL, N'Other real estate', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'326', NULL, N'Butane', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'327', NULL, N'CNG', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'328', NULL, N'LNG', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'329', NULL, N'LPG', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'330', NULL, N'Natural gas', NULL, N'0', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'331', NULL, N'Natural gas (100% mineral blend)', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'332', NULL, N'Other petroleum gas', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'333', NULL, N'Propane', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'334', NULL, N'Aviation spirit', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'335', NULL, N'Aviation turbine fuel', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'336', NULL, N'Burning oil', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'337', NULL, N'Diesel (average biofuel blend)', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'338', NULL, N'Diesel (100% mineral diesel)', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'339', NULL, N'Fuel oil', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'340', NULL, N'Gas oil', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'341', NULL, N'Lubricants', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'342', NULL, N'Naphtha', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'343', NULL, N'Petrol (average biofuel blend)', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'344', NULL, N'Petrol (100% mineral petrol)', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'345', NULL, N'Processed fuel oils - residual oil', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'346', NULL, N'Processed fuel oils - distillate oil', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'347', NULL, N'Refinery miscellaneous', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'348', NULL, N'Waste oils', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'349', NULL, N'Marine gas oil', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'350', NULL, N'Marine fuel oil', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'351', NULL, N'Coal (industrial)', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'352', NULL, N'Coal (electricity generation)', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'353', NULL, N'Coal (domestic)', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'354', NULL, N'Coking coal', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'355', NULL, N'Petroleum coke', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'356', NULL, N'Coal (electricity generation - home produced coal only)', NULL, N'1', N'kWh (Net CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'357', NULL, N'Electricity for home working', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'358', NULL, N'Gas heating for home working', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'359', NULL, N'Oil heating for home working', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'360', NULL, N'Deliveries by Van', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'361', NULL, N'Deliveries by Truck', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'362', NULL, N'Deliveries by Rail', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'363', NULL, N'Deliveries by Short Haul', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'364', NULL, N'Deliveries by Long Haul', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'365', NULL, N'Deliveries by Sea Cargo', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'366', NULL, N'Deliveries Itemised Entry (multiple activities)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'367', NULL, N'R22', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'368', NULL, N'R32', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'369', NULL, N'Aviation spirit', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'370', NULL, N'Aviation spirit', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'371', NULL, N'Aviation spirit', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'372', NULL, N'Aviation turbine fuel', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'373', NULL, N'Aviation turbine fuel', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'374', NULL, N'Aviation turbine fuel', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'375', NULL, N'Burning oil', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'376', NULL, N'Burning oil', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'377', NULL, N'Burning oil', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'378', NULL, N'Butane', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'379', NULL, N'Butane', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'380', NULL, N'Butane', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'381', NULL, N'CNG', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'382', NULL, N'CNG', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'383', NULL, N'CNG', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'384', NULL, N'Coal (domestic)', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'385', NULL, N'Coal (domestic)', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'386', NULL, N'Coal (electricity generation - home produced coal only)', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'387', NULL, N'Coal (electricity generation - home produced coal only)', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'388', NULL, N'Coal (electricity generation)', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'389', NULL, N'Coal (electricity generation)', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'390', NULL, N'Coal (industrial)', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'391', NULL, N'Coal (industrial)', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'392', NULL, N'Coking coal', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'393', NULL, N'Coking coal', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'394', NULL, N'Diesel (100% mineral diesel)', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'395', NULL, N'Diesel (100% mineral diesel)', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'396', NULL, N'Diesel (100% mineral diesel)', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'397', NULL, N'Diesel (average biofuel blend)', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'398', NULL, N'Diesel (average biofuel blend)', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'399', NULL, N'Diesel (average biofuel blend)', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'400', NULL, N'Fuel oil', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'401', NULL, N'Fuel oil', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'402', NULL, N'Fuel oil', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'403', NULL, N'Gas oil', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'404', NULL, N'Gas oil', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'405', NULL, N'Gas oil', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'406', NULL, N'LNG', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'407', NULL, N'LNG', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'408', NULL, N'LNG', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'409', NULL, N'LPG', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'410', NULL, N'LPG', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'411', NULL, N'LPG', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'412', NULL, N'Lubricants', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'413', NULL, N'Lubricants', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'414', NULL, N'Lubricants', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'415', NULL, N'Marine fuel oil', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'416', NULL, N'Marine fuel oil', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'417', NULL, N'Marine fuel oil', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'418', NULL, N'Marine gas oil', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'419', NULL, N'Marine gas oil', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'420', NULL, N'Marine gas oil', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'421', NULL, N'Naphtha', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'422', NULL, N'Naphtha', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'423', NULL, N'Naphtha', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'424', NULL, N'Natural gas', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'425', NULL, N'Natural gas', NULL, N'1', N'cubic metres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'426', NULL, N'Natural gas', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'427', NULL, N'Natural gas (100% mineral blend)', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'428', NULL, N'Natural gas (100% mineral blend)', NULL, N'1', N'cubic metres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'429', NULL, N'Natural gas (100% mineral blend)', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'430', NULL, N'Other petroleum gas', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'431', NULL, N'Other petroleum gas', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'432', NULL, N'Other petroleum gas', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'433', NULL, N'Petrol (100% mineral petrol)', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'434', NULL, N'Petrol (100% mineral petrol)', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'435', NULL, N'Petrol (100% mineral petrol)', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'436', NULL, N'Petrol (average biofuel blend)', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'437', NULL, N'Petrol (average biofuel blend)', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'438', NULL, N'Petrol (average biofuel blend)', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'439', NULL, N'Petroleum coke', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'440', NULL, N'Petroleum coke', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'441', NULL, N'Processed fuel oils - distillate oil', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'442', NULL, N'Processed fuel oils - distillate oil', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'443', NULL, N'Processed fuel oils - distillate oil', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'444', NULL, N'Processed fuel oils - residual oil', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'445', NULL, N'Processed fuel oils - residual oil', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'446', NULL, N'Processed fuel oils - residual oil', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'447', NULL, N'Propane', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'448', NULL, N'Propane', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'449', NULL, N'Propane', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'450', NULL, N'Refinery miscellaneous', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'451', NULL, N'Refinery miscellaneous', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'452', NULL, N'Refinery miscellaneous', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'453', NULL, N'Waste oils', NULL, N'1', N'kWh (Gross CV)')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'454', NULL, N'Waste oils', NULL, N'1', N'litres')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'455', NULL, N'Waste oils', NULL, N'1', N'tonnes')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'456', NULL, N'Other Itemised Entry (multiple activities)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'457', NULL, N'Hotel stay - UK', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'458', NULL, N'Hotel stay - UK (London)', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'459', NULL, N'Hotel stay - Australia', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'460', NULL, N'Hotel stay - Belgium', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'461', NULL, N'Hotel stay - Brazil', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'462', NULL, N'Hotel stay - Canada', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'463', NULL, N'Hotel stay - Chile', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'464', NULL, N'Hotel stay - China', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'465', NULL, N'Hotel stay - Colombia', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'466', NULL, N'Hotel stay - Costa Rica', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'467', NULL, N'Hotel stay - Egypt', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'468', NULL, N'Hotel stay - France', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'469', NULL, N'Hotel stay - Germany', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'470', NULL, N'Hotel stay - Hong Kong (China)', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'471', NULL, N'Hotel stay - India', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'472', NULL, N'Hotel stay - Indonesia', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'473', NULL, N'Hotel stay - Italy', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'474', NULL, N'Hotel stay - Japan', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'475', NULL, N'Hotel stay - Jordan', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'476', NULL, N'Hotel stay - Korea', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'477', NULL, N'Hotel stay - Malaysia', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'478', NULL, N'Hotel stay - Maldives', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'479', NULL, N'Hotel stay - Mexico', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'480', NULL, N'Hotel stay - Netherlands', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'481', NULL, N'Hotel stay - Oman', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'482', NULL, N'Hotel stay - Philippines', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'483', NULL, N'Hotel stay - Portugal', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'484', NULL, N'Hotel stay - Qatar', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'485', NULL, N'Hotel stay - Russian Federation', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'486', NULL, N'Hotel stay - Saudi Arabia', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'487', NULL, N'Hotel stay - Singapore', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'488', NULL, N'Hotel stay - South Africa', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'489', NULL, N'Hotel stay - Spain', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'490', NULL, N'Hotel stay - Switzerland', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'491', NULL, N'Hotel stay - Thailand', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'492', NULL, N'Hotel stay - Turkey', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'493', NULL, N'Hotel stay - United Arab Emirates', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'494', NULL, N'Hotel stay - United States', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'495', NULL, N'Hotel stay - Vietnam', NULL, N'1', N'No of Nights - Hotel')
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'496', NULL, N'Hotel stay Itemised Entry (multiple countries)', NULL, N'1', NULL)
GO

INSERT INTO [Emissions].[EmissionActivity] ([id], [parentId], [name], [description], [active], [Unit]) VALUES (N'498', NULL, N'E-Scooter', NULL, N'1', NULL)
GO

SET IDENTITY_INSERT [Emissions].[EmissionActivity] OFF
GO


-- ----------------------------
-- Table structure for EmissionActivitySourceMapping
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[EmissionActivitySourceMapping]') AND type IN ('U'))
	DROP TABLE [Emissions].[EmissionActivitySourceMapping]
GO

CREATE TABLE [Emissions].[EmissionActivitySourceMapping] (
  [activityId] int  NOT NULL,
  [srcId] varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [factorType] varchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Emissions].[EmissionActivitySourceMapping] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'Emission ActivityId',
'SCHEMA', N'Emissions',
'TABLE', N'EmissionActivitySourceMapping',
'COLUMN', N'activityId'
GO

EXEC sp_addextendedproperty
'MS_Description', N'SourceId from import file',
'SCHEMA', N'Emissions',
'TABLE', N'EmissionActivitySourceMapping',
'COLUMN', N'srcId'
GO

EXEC sp_addextendedproperty
'MS_Description', N'EF, WTT, TND, TNDWTT',
'SCHEMA', N'Emissions',
'TABLE', N'EmissionActivitySourceMapping',
'COLUMN', N'factorType'
GO


-- ----------------------------
-- Records of EmissionActivitySourceMapping
-- ----------------------------
INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'370', N'1_101_1008_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'369', N'1_101_1008_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'334', N'1_101_1008_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'371', N'1_101_1008_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'370', N'11_101_1008_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'369', N'11_101_1008_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'334', N'11_101_1008_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'371', N'11_101_1008_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'374', N'11_101_1009_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'373', N'11_101_1009_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'335', N'11_101_1009_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'372', N'11_101_1009_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'374', N'1_101_1009_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'373', N'1_101_1009_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'335', N'1_101_1009_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'372', N'1_101_1009_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'377', N'1_101_1010_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'376', N'1_101_1010_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'336', N'1_101_1010_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'375', N'1_101_1010_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'377', N'11_101_1010_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'376', N'11_101_1010_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'336', N'11_101_1010_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'375', N'11_101_1010_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'380', N'1_100_1000_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'379', N'1_100_1000_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'326', N'1_100_1000_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'378', N'1_100_1000_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'380', N'11_100_1000_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'379', N'11_100_1000_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'326', N'11_100_1000_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'378', N'11_100_1000_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'383', N'11_100_1001_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'382', N'11_100_1001_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'327', N'11_100_1001_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'381', N'11_100_1001_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'383', N'1_100_1001_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'382', N'1_100_1001_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'327', N'1_100_1001_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'381', N'1_100_1001_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'385', N'1_102_1027_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'353', N'1_102_1027_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'384', N'1_102_1027_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'385', N'11_102_1027_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'353', N'11_102_1027_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'384', N'11_102_1027_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'387', N'11_102_1030_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'356', N'11_102_1030_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'386', N'11_102_1030_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'387', N'1_102_1030_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'356', N'1_102_1030_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'386', N'1_102_1030_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'389', N'1_102_1026_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'352', N'1_102_1026_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'388', N'1_102_1026_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'389', N'11_102_1026_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'352', N'11_102_1026_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'388', N'11_102_1026_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'391', N'1_102_1025_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'351', N'1_102_1025_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'390', N'1_102_1025_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'391', N'11_102_1025_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'351', N'11_102_1025_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'390', N'11_102_1025_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'393', N'11_102_1028_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'354', N'11_102_1028_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'392', N'11_102_1028_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'393', N'1_102_1028_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'354', N'1_102_1028_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'392', N'1_102_1028_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'396', N'1_101_1012_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'395', N'1_101_1012_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'338', N'1_101_1012_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'394', N'1_101_1012_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'396', N'11_101_1012_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'395', N'11_101_1012_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'338', N'11_101_1012_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'394', N'11_101_1012_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'399', N'11_101_1011_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'398', N'11_101_1011_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'337', N'11_101_1011_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'397', N'11_101_1011_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'399', N'1_101_1011_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'398', N'1_101_1011_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'337', N'1_101_1011_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'397', N'1_101_1011_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'402', N'1_101_1013_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'401', N'1_101_1013_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'339', N'1_101_1013_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'400', N'1_101_1013_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'402', N'11_101_1013_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'401', N'11_101_1013_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'339', N'11_101_1013_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'400', N'11_101_1013_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'405', N'11_101_1014_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'404', N'11_101_1014_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'340', N'11_101_1014_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'403', N'11_101_1014_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'405', N'1_101_1014_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'404', N'1_101_1014_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'340', N'1_101_1014_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'403', N'1_101_1014_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'408', N'1_100_1002_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'407', N'1_100_1002_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'328', N'1_100_1002_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'406', N'1_100_1002_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'408', N'11_100_1002_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'407', N'11_100_1002_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'328', N'11_100_1002_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'406', N'11_100_1002_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'411', N'11_100_1003_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'410', N'11_100_1003_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'329', N'11_100_1003_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'409', N'11_100_1003_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'411', N'1_100_1003_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'410', N'1_100_1003_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'329', N'1_100_1003_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'409', N'1_100_1003_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'414', N'1_101_1015_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'413', N'1_101_1015_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'341', N'1_101_1015_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'412', N'1_101_1015_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'414', N'11_101_1015_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'413', N'11_101_1015_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'341', N'11_101_1015_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'412', N'11_101_1015_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'417', N'11_101_1024_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'416', N'11_101_1024_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'350', N'11_101_1024_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'415', N'11_101_1024_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'417', N'1_101_1024_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'416', N'1_101_1024_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'350', N'1_101_1024_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'415', N'1_101_1024_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'420', N'1_101_1023_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'419', N'1_101_1023_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'349', N'1_101_1023_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'418', N'1_101_1023_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'420', N'11_101_1023_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'419', N'11_101_1023_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'349', N'11_101_1023_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'418', N'11_101_1023_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'423', N'11_101_1016_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'422', N'11_101_1016_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'342', N'11_101_1016_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'421', N'11_101_1016_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'423', N'1_101_1016_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'422', N'1_101_1016_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'342', N'1_101_1016_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'421', N'1_101_1016_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'426', N'1_100_1004_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'425', N'1_100_1004_1_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'424', N'1_100_1004_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'426', N'11_100_1004_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'425', N'11_100_1004_1_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'424', N'11_100_1004_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'429', N'11_100_1005_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'428', N'11_100_1005_1_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'331', N'11_100_1005_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'427', N'11_100_1005_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'429', N'1_100_1005_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'428', N'1_100_1005_1_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'331', N'1_100_1005_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'427', N'1_100_1005_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'432', N'1_100_1006_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'431', N'1_100_1006_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'332', N'1_100_1006_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'430', N'1_100_1006_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'432', N'11_100_1006_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'431', N'11_100_1006_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'332', N'11_100_1006_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'430', N'11_100_1006_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'435', N'1_101_1018_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'434', N'1_101_1018_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'344', N'1_101_1018_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'433', N'1_101_1018_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'435', N'11_101_1018_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'434', N'11_101_1018_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'344', N'11_101_1018_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'433', N'11_101_1018_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'438', N'11_101_1017_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'437', N'11_101_1017_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'343', N'11_101_1017_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'436', N'11_101_1017_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'438', N'1_101_1017_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'437', N'1_101_1017_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'343', N'1_101_1017_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'436', N'1_101_1017_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'440', N'1_102_1029_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'355', N'1_102_1029_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'439', N'1_102_1029_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'440', N'11_102_1029_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'355', N'11_102_1029_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'439', N'11_102_1029_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'443', N'11_101_1020_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'442', N'11_101_1020_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'346', N'11_101_1020_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'441', N'11_101_1020_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'443', N'1_101_1020_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'442', N'1_101_1020_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'346', N'1_101_1020_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'441', N'1_101_1020_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'446', N'1_101_1019_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'445', N'1_101_1019_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'345', N'1_101_1019_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'444', N'1_101_1019_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'446', N'11_101_1019_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'445', N'11_101_1019_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'345', N'11_101_1019_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'444', N'11_101_1019_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'449', N'11_100_1007_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'448', N'11_100_1007_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'333', N'11_100_1007_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'447', N'11_100_1007_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'449', N'1_100_1007_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'448', N'1_100_1007_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'333', N'1_100_1007_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'447', N'1_100_1007_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'452', N'1_101_1021_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'450', N'1_101_1021_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'347', N'1_101_1021_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'451', N'1_101_1021_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'452', N'11_101_1021_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'450', N'11_101_1021_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'347', N'11_101_1021_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'451', N'11_101_1021_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'455', N'11_101_1022_15_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'454', N'11_101_1022_8_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'453', N'11_101_1022_6_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'455', N'1_101_1022_15_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'454', N'1_101_1022_8_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'453', N'1_101_1022_6_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'4', N'3_200_2002_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'130', N'3_202_2380_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'121', N'3_202_2353_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'124', N'3_202_2362_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'125', N'3_202_2365_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'126', N'3_202_2368_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'122', N'3_202_2356_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'123', N'3_202_2359_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'158', N'3_204_2464_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'127', N'3_202_2371_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'128', N'3_202_2374_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'129', N'3_202_2377_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'134', N'3_202_2392_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'135', N'3_202_2395_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'136', N'3_202_2398_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'137', N'3_202_2401_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'140', N'3_202_2410_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'133', N'3_202_2389_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'138', N'3_202_2404_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'139', N'3_202_2407_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'144', N'3_203_2422_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'10', N'3_200_2020_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'11', N'3_200_2023_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'12', N'3_200_2026_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'13', N'3_200_2029_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'14', N'3_200_2032_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'30', N'3_200_2080_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'15', N'3_200_2035_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'31', N'3_200_2083_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'16', N'3_200_2038_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'7', N'3_200_2011_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'32', N'3_200_2086_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'33', N'3_200_2089_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'17', N'3_200_2041_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'34', N'3_200_2092_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'18', N'3_200_2044_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'8', N'3_200_2014_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'35', N'3_200_2095_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'9', N'3_200_2017_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'19', N'3_200_2047_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'141', N'3_203_2413_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'142', N'3_203_2416_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'143', N'3_203_2419_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'154', N'3_203_2452_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'145', N'3_203_2425_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'146', N'3_203_2428_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'147', N'3_203_2431_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'155', N'3_203_2455_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'148', N'3_203_2434_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'149', N'3_203_2437_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'150', N'3_203_2440_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'153', N'3_203_2449_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'151', N'3_203_2443_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'152', N'3_203_2446_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'5', N'3_200_2005_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'131', N'3_202_2383_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'160', N'3_204_2470_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'132', N'3_202_2386_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'159', N'3_204_2467_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'36', N'3_200_2098_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'6', N'3_200_2008_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'24', N'3_200_2062_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'23', N'3_200_2059_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'28', N'3_200_2074_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'21', N'3_200_2053_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'26', N'3_200_2068_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'20', N'3_200_2050_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'25', N'3_200_2065_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'22', N'3_200_2056_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'27', N'3_200_2071_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'157', N'3_204_2461_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'168', N'3_204_2494_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'169', N'3_204_2497_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'167', N'3_204_2491_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'166', N'3_204_2488_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'161', N'3_204_2473_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'37', N'3_201_2101_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'38', N'3_201_2104_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'39', N'3_201_2107_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'40', N'3_201_2110_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'41', N'3_201_2113_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'42', N'3_201_2116_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'43', N'3_201_2119_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'44', N'3_201_2122_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'45', N'3_201_2125_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'46', N'3_201_2128_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'47', N'3_201_2131_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'48', N'3_201_2134_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'49', N'3_201_2137_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'50', N'3_201_2140_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'51', N'3_201_2143_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'52', N'3_201_2146_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'53', N'3_201_2149_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'54', N'3_201_2152_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'55', N'3_201_2155_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'56', N'3_201_2158_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'57', N'3_201_2161_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'58', N'3_201_2164_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'59', N'3_201_2167_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'60', N'3_201_2170_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'61', N'3_201_2173_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'62', N'3_201_2176_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'63', N'3_201_2179_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'64', N'3_201_2182_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'65', N'3_201_2185_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'66', N'3_201_2188_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'67', N'3_201_2191_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'68', N'3_201_2194_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'69', N'3_201_2197_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'70', N'3_201_2200_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'71', N'3_201_2203_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'72', N'3_201_2206_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'73', N'3_201_2209_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'74', N'3_201_2212_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'75', N'3_201_2215_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'76', N'3_201_2218_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'77', N'3_201_2221_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'78', N'3_201_2224_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'79', N'3_201_2227_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'80', N'3_201_2230_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'81', N'3_201_2233_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'82', N'3_201_2236_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'83', N'3_201_2239_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'84', N'3_201_2242_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'85', N'3_201_2245_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'86', N'3_201_2248_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'87', N'3_201_2251_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'88', N'3_201_2254_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'89', N'3_201_2257_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'90', N'3_201_2260_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'91', N'3_201_2263_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'92', N'3_201_2266_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'93', N'3_201_2269_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'94', N'3_201_2272_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'95', N'3_201_2275_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'96', N'3_201_2278_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'97', N'3_201_2281_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'98', N'3_201_2284_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'99', N'3_201_2287_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'100', N'3_201_2290_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'101', N'3_201_2293_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'102', N'3_201_2296_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'103', N'3_201_2299_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'104', N'3_201_2302_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'105', N'3_201_2305_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'106', N'3_201_2308_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'107', N'3_201_2311_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'108', N'3_201_2314_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'109', N'3_201_2317_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'110', N'3_201_2320_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'111', N'3_201_2323_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'112', N'3_201_2326_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'113', N'3_201_2329_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'114', N'3_201_2332_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'115', N'3_201_2335_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'116', N'3_201_2338_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'117', N'3_201_2341_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'118', N'3_201_2344_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'119', N'3_201_2347_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'120', N'3_201_2350_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'163', N'3_204_2479_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'162', N'3_204_2476_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'164', N'3_204_2482_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'165', N'3_204_2485_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'29', N'3_200_2077_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'156', N'3_204_2458_3_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'3', N'1_100_1004_7_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'3', N'11_100_1004_7_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'215', N'25_313_3141_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'215', N'26_909_3141_4_1
', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'348', N'1_101_1022_7_1
', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'348', N'11_101_1022_7_1
', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'210', N'25_301_3075_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'208', N'25_301_3069_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'211', N'25_301_3076_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'209', N'25_301_3071_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'207', N'25_301_3070_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'212', N'25_302_3080_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'237', N'21_316_3168_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'234', N'21_316_3162_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'232', N'25_314_3146_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'240', N'21_316_3174_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'236', N'21_316_3166_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'192', N'27_303_3087_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'188', N'27_303_3081_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'185', N'27_303_3082_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'193', N'27_303_3094_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'189', N'27_303_3088_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'186', N'27_303_3089_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'194', N'27_303_3101_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'190', N'27_303_3095_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'187', N'27_303_3096_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'238', N'21_316_3170_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'235', N'21_316_3164_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'241', N'21_316_3176_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'217', N'21_316_3160_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'219', N'21_316_3168_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'218', N'21_316_3162_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'199', N'27_304_3128_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'200', N'27_304_3132_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'197', N'27_306_3120_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'195', N'27_306_3112_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'196', N'27_306_3116_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'175', N'25_301_3061_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'181', N'25_301_3068_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'178', N'25_301_3063_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'172', N'25_301_3062_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'184', N'25_301_3067_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'216', N'25_314_3144_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'174', N'25_301_3053_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'180', N'25_301_3060_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'177', N'25_301_3055_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'171', N'25_301_3054_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'183', N'25_301_3059_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'227', N'25_302_3079_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'226', N'25_302_3078_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'225', N'25_302_3077_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'239', N'21_316_3172_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'173', N'25_301_3045_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'179', N'25_301_3052_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'176', N'25_301_3047_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'170', N'25_301_3046_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'182', N'25_301_3051_4_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'228', N'25_315_3148_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'229', N'25_315_3149_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'213', N'25_315_3147_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'214', N'25_315_3150_11_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'210', N'26_904_3075_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'208', N'26_904_3069_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'211', N'26_904_3076_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'209', N'26_904_3071_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'207', N'26_904_3070_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'212', N'26_905_3080_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'237', N'22_912_3168_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'234', N'22_912_3162_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'232', N'26_910_3146_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'240', N'22_912_3174_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'236', N'22_912_3166_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'192', N'28_906_3087_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'188', N'28_906_3081_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'185', N'28_906_3082_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'193', N'28_906_3094_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'189', N'28_906_3088_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'186', N'28_906_3089_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'194', N'28_906_3101_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'190', N'28_906_3095_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'187', N'28_906_3096_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'238', N'22_912_3170_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'235', N'22_912_3164_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'241', N'22_912_3176_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'217', N'22_912_3160_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'219', N'22_912_3168_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'218', N'22_912_3162_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'199', N'28_907_3128_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'200', N'28_907_3132_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'197', N'28_907_3120_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'195', N'28_907_3112_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'196', N'28_907_3116_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'175', N'26_904_3061_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'181', N'26_904_3068_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'178', N'26_904_3063_9_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'172', N'26_904_3062_9_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'184', N'26_904_3067_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'216', N'26_910_3144_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'174', N'26_904_3053_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'180', N'26_904_3060_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'177', N'26_904_3055_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'171', N'26_904_3054_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'183', N'26_904_3059_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'227', N'26_905_3079_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'226', N'26_905_3078_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'225', N'26_905_3077_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'239', N'22_912_3172_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'173', N'26_904_3045_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'179', N'26_904_3052_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'176', N'26_904_3047_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'170', N'26_904_3046_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'182', N'26_904_3051_4_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'228', N'26_911_3148_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'229', N'26_911_3149_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'213', N'26_911_3147_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'214', N'26_911_3150_11_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'1', N'17_404_4005_1_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'2', N'7_400_4000_5_1', N'EF')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'2', N'13_402_4000_5_1', N'TND')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'2', N'15_917_4000_5_1', N'WTT')
GO

INSERT INTO [Emissions].[EmissionActivitySourceMapping] ([activityId], [srcId], [factorType]) VALUES (N'2', N'15_918_4000_5_1', N'TNDWTT')
GO


-- ----------------------------
-- Table structure for EmissionCategory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[EmissionCategory]') AND type IN ('U'))
	DROP TABLE [Emissions].[EmissionCategory]
GO

CREATE TABLE [Emissions].[EmissionCategory] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [parentId] int  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Emissions].[EmissionCategory] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of EmissionCategory
-- ----------------------------
SET IDENTITY_INSERT [Emissions].[EmissionCategory] ON
GO

INSERT INTO [Emissions].[EmissionCategory] ([id], [name], [description], [parentId], [active]) VALUES (N'1', N'Travel', NULL, NULL, N'1')
GO

INSERT INTO [Emissions].[EmissionCategory] ([id], [name], [description], [parentId], [active]) VALUES (N'2', N'Accomodation', NULL, NULL, N'1')
GO

INSERT INTO [Emissions].[EmissionCategory] ([id], [name], [description], [parentId], [active]) VALUES (N'3', N'Other', NULL, NULL, N'1')
GO

SET IDENTITY_INSERT [Emissions].[EmissionCategory] OFF
GO


-- ----------------------------
-- Table structure for EmissionFactor
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[EmissionFactor]') AND type IN ('U'))
	DROP TABLE [Emissions].[EmissionFactor]
GO

CREATE TABLE [Emissions].[EmissionFactor] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [activityId] int  NOT NULL,
  [ef] decimal(10,5)  NULL,
  [wtt] decimal(10,5)  NULL,
  [tnd] decimal(10,5)  NULL,
  [tndWtt] decimal(10,5)  NULL,
  [year] int  NULL,
  [emissionProfileId] int  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Emissions].[EmissionFactor] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of EmissionFactor
-- ----------------------------
SET IDENTITY_INSERT [Emissions].[EmissionFactor] ON
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'1', N'1', N'0.14900', N'0.27200', NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'2', N'2', N'0.19340', N'0.04630', NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'3', N'3', N'0.18292', N'0.03021', NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5', N'4', N'1.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6', N'5', N'25.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'7', N'6', N'298.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'14', N'7', N'14800.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'15', N'8', N'675.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'16', N'9', N'92.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'17', N'10', N'3500.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'18', N'11', N'1100.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'19', N'12', N'1430.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'20', N'13', N'353.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'21', N'14', N'4470.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'22', N'15', N'124.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'23', N'16', N'3220.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'24', N'17', N'9810.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'25', N'18', N'1030.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'26', N'19', N'1640.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'27', N'20', N'7390.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'28', N'21', N'12200.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'29', N'22', N'8830.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'30', N'23', N'10300.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'31', N'24', N'8860.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'32', N'25', N'9160.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'33', N'26', N'9300.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'34', N'27', N'7500.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'35', N'28', N'17340.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'36', N'29', N'22800.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'37', N'30', N'53.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'38', N'31', N'12.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'39', N'32', N'1340.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'40', N'33', N'1370.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'41', N'34', N'693.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'42', N'35', N'794.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'43', N'36', N'17200.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'44', N'37', N'1182.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'45', N'38', N'1288.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'46', N'39', N'933.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'47', N'40', N'2788.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'48', N'41', N'2416.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'49', N'42', N'3124.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'50', N'43', N'4457.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'51', N'44', N'3922.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'52', N'45', N'4716.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'53', N'46', N'1943.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'54', N'47', N'2107.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'55', N'48', N'2804.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'56', N'49', N'1774.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'57', N'50', N'1627.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'58', N'51', N'1552.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'59', N'52', N'1825.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'60', N'53', N'3152.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'61', N'54', N'1585.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'62', N'55', N'1560.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'63', N'56', N'2088.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'64', N'57', N'2229.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'65', N'58', N'1597.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'66', N'59', N'1705.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'67', N'60', N'2286.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'68', N'61', N'2053.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'69', N'62', N'1478.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'70', N'63', N'1362.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'71', N'64', N'1507.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'72', N'65', N'546.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'73', N'66', N'1084.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'74', N'67', N'2346.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'75', N'68', N'3027.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'76', N'69', N'1809.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'77', N'70', N'1741.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'78', N'71', N'2967.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'79', N'72', N'2384.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'80', N'73', N'1536.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'81', N'74', N'2631.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'82', N'75', N'3190.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'83', N'76', N'3143.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'84', N'77', N'2526.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'85', N'78', N'3085.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'86', N'79', N'2729.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'87', N'80', N'2592.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'88', N'81', N'2280.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'89', N'82', N'2440.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'90', N'83', N'1505.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'91', N'84', N'1508.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'92', N'85', N'2138.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'93', N'86', N'3607.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'94', N'87', N'14.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'95', N'88', N'95.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'96', N'89', N'38.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'97', N'90', N'2.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'98', N'91', N'3.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'99', N'92', N'3.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'100', N'93', N'3.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'101', N'94', N'3245.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'102', N'95', N'26.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'103', N'96', N'3.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'104', N'97', N'3.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'105', N'98', N'1805.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'106', N'99', N'2265.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'107', N'100', N'1983.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'108', N'101', N'144.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'109', N'102', N'3.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'110', N'103', N'1888.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'111', N'104', N'2.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'112', N'105', N'88.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'113', N'106', N'130.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'114', N'107', N'8077.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'115', N'108', N'4083.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'116', N'109', N'4657.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'117', N'110', N'14560.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'118', N'111', N'4143.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'119', N'112', N'8502.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'120', N'113', N'4490.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'121', N'114', N'3985.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'122', N'115', N'13214.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'123', N'116', N'13396.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'124', N'117', N'5741.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'125', N'118', N'1.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'126', N'119', N'9.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'127', N'120', N'189.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'128', N'121', N'4750.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'129', N'122', N'10900.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'130', N'123', N'14400.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'131', N'124', N'6130.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'132', N'125', N'10000.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'133', N'126', N'7370.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'134', N'127', N'1890.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'135', N'128', N'7140.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'136', N'129', N'1640.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'137', N'130', N'1400.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'138', N'131', N'5.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'139', N'132', N'146.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'140', N'133', N'1810.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'141', N'134', N'77.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'142', N'135', N'609.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'143', N'136', N'725.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'144', N'137', N'2310.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'145', N'138', N'122.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'146', N'139', N'595.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'147', N'140', N'151.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'148', N'141', N'14900.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'149', N'142', N'6320.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'150', N'143', N'756.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'151', N'144', N'350.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'152', N'145', N'708.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'153', N'146', N'659.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'154', N'147', N'359.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'155', N'148', N'575.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'156', N'149', N'580.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'157', N'150', N'110.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'158', N'151', N'297.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'159', N'152', N'59.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'160', N'153', N'1870.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'161', N'154', N'2800.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'162', N'155', N'1500.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'163', N'156', N'17700.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'164', N'157', N'10300.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'165', N'158', N'1.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'166', N'159', N'9.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'167', N'160', N'13.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'168', N'161', N'3.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'169', N'162', N'3.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'170', N'163', N'4.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'171', N'164', N'5.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'172', N'165', N'5.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'173', N'166', N'6.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'174', N'167', N'2.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'175', N'168', N'1.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'176', N'169', N'1.00000', NULL, NULL, NULL, N'2022', N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'181', N'170', N'0.14652', N'0.04186', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'182', N'171', N'0.18470', N'0.06737', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'183', N'172', N'0.27639', N'0.05266', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'184', N'173', N'0.13989', N'0.03344', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'185', N'174', N'0.16800', N'0.05381', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'186', N'175', N'0.20953', N'0.04018', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'187', N'176', N'0.10332', N'0.02808', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'188', N'177', N'0.10999', N'0.04519', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'189', N'178', N'0.15491', N'0.02857', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'190', N'179', N'0.04416', N'0.04625', N'0.00369', N'0.00423', NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'191', N'180', N'0.04878', N'0.04625', N'0.00596', N'0.00423', NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'192', N'181', N'0.05550', N'0.04625', N'0.00410', N'0.00423', NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'193', N'182', N'0.02163', N'0.01317', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'194', N'183', N'0.06144', N'0.02220', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'195', N'184', N'0.03884', N'0.02635', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'196', N'185', NULL, NULL, NULL, NULL, NULL, N'1', N'0')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'197', N'185', N'0.19687', N'0.05603', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'198', N'186', N'0.20461', N'0.05556', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'199', N'187', N'0.32607', N'0.08788', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'200', N'188', N'0.14189', N'0.03568', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'201', N'189', N'0.17513', N'0.04467', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'202', N'190', N'0.25481', N'0.06491', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'203', N'192', N'0.00000', N'0.01030', N'0.00303', NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'204', N'193', N'0.00000', N'0.01422', N'0.00473', NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'205', N'194', N'0.00000', N'0.01995', N'0.00782', NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'206', N'195', N'0.49758', N'0.11660', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'207', N'196', N'0.60793', N'0.14220', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'208', N'197', N'0.99337', N'0.23228', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'209', N'198', N'0.84061', N'0.19479', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'210', N'199', N'0.78111', N'0.18579', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'211', N'200', N'0.93004', N'0.22106', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'212', N'201', N'0.92391', N'0.21962', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'213', N'202', N'2.10000', N'0.58094', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'214', N'203', N'2.51000', N'0.61101', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'215', N'204', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'216', N'205', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'217', N'206', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'218', N'207', N'0.17048', N'0.04885', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'219', N'208', N'0.17082', N'0.04104', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'220', N'209', N'0.12004', N'0.03132', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'221', N'210', N'0.06840', N'0.00210', N'0.00210', NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'222', N'211', N'0.00000', N'0.01426', N'0.00431', NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'223', N'212', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'224', N'213', N'0.03549', N'0.00892', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'225', N'214', N'0.02781', N'0.00724', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'226', N'215', N'0.14876', N'0.03632', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'227', N'216', N'0.09650', N'0.02494', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'228', N'217', N'0.24587', N'0.02691', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'229', N'218', N'0.15353', N'0.01681', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'230', N'219', N'0.19309', N'0.02114', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'231', N'220', N'0.00000', N'0.00000', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'232', N'221', N'0.00000', N'0.00000', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'233', N'222', N'63.80000', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'234', N'223', N'0.00300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'235', N'224', N'0.00423', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'236', N'225', N'0.08306', N'0.02277', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'237', N'226', N'0.10090', N'0.02765', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'238', N'227', N'0.13245', N'0.03678', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'239', N'228', N'0.00446', N'0.00116', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'240', N'229', N'0.02861', N'0.00745', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'241', N'230', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'242', N'231', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'243', N'232', N'0.02733', N'0.00646', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'244', N'233', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'245', N'234', N'0.18592', N'0.02286', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'246', N'235', N'0.18287', N'0.02249', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'247', N'236', N'0.27430', N'0.03373', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'248', N'237', N'0.26128', N'0.03213', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'249', N'238', N'0.20011', N'0.02461', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'250', N'239', N'0.32016', N'0.03937', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'251', N'240', N'0.58029', N'0.07137', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'252', N'241', N'0.80040', N'0.09844', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'253', N'242', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'254', N'243', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'255', N'244', N'0.98500', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'256', N'245', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'257', N'246', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'258', N'247', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'259', N'248', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'260', N'249', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'261', N'250', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'262', N'251', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'263', N'252', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'264', N'253', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'265', N'254', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'266', N'255', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'267', N'256', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'268', N'257', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'269', N'258', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'270', N'259', NULL, NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'271', N'260', N'1.76300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'272', N'261', N'0.30000', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'273', N'262', N'1.27300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'274', N'263', N'1.32900', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'275', N'264', N'0.77400', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'276', N'265', N'3.01900', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'277', N'266', N'0.32900', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'278', N'267', N'0.84100', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'279', N'268', N'0.37700', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'280', N'269', N'0.43500', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'281', N'270', N'0.25300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'282', N'271', N'0.39600', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'283', N'272', N'0.25900', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'284', N'273', N'1.22800', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'285', N'274', N'0.33000', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'286', N'275', N'0.20900', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'287', N'276', N'0.59200', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'288', N'277', N'0.08100', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'289', N'278', N'0.27200', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'290', N'279', N'0.25300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'291', N'280', N'0.07900', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'292', N'281', N'0.26800', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'293', N'282', N'0.23200', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'294', N'283', N'0.09500', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'295', N'284', N'0.29200', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'296', N'285', N'0.25700', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'297', N'286', N'0.14100', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'298', N'287', N'0.14700', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'299', N'288', N'0.24800', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'300', N'289', N'0.17700', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'301', N'290', N'0.92300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'302', N'291', N'0.72200', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'303', N'292', N'0.74200', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'304', N'293', N'1.38900', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'305', N'294', N'0.34300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'306', N'295', N'1.79100', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'307', N'296', N'0.42600', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'308', N'297', N'0.45500', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'309', N'298', N'0.17500', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'310', N'299', N'0.05700', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'311', N'300', N'0.05600', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'312', N'301', N'0.08400', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'313', N'302', N'0.08500', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'314', N'303', N'0.07000', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'315', N'304', N'0.10300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'316', N'305', N'0.04300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'317', N'306', N'0.20900', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'318', N'307', N'0.09300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'319', N'308', N'0.05900', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'320', N'309', N'0.13800', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'321', N'310', N'0.06400', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'322', N'311', N'0.10400', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'323', N'312', N'0.11700', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'324', N'313', N'1.38700', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'325', N'314', N'0.20400', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'326', N'315', N'0.09100', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'327', N'316', N'0.17200', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'328', N'317', N'0.17000', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'329', N'318', N'0.16400', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'330', N'319', N'0.07400', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'331', N'320', N'0.38000', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'332', N'321', N'0.18500', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'333', N'322', N'0.22500', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'334', N'323', N'0.15300', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'335', N'324', N'0.02200', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'336', N'325', N'0.43400', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'337', N'326', N'0.24110', N'0.02719', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'338', N'327', N'0.20230', N'0.04282', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'339', N'328', N'0.20390', N'0.07055', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'340', N'329', N'0.23030', N'0.02719', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'341', N'330', N'0.20230', N'0.03446', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'342', N'331', N'0.20390', N'0.03446', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'343', N'332', N'0.19920', N'0.02352', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'344', N'333', N'0.23260', N'0.02719', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'345', N'334', N'0.25660', N'0.06552', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'346', N'335', N'0.26090', N'0.05400', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'347', N'336', N'0.25980', N'0.05400', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'348', N'337', N'0.25630', N'0.06109', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'349', N'338', N'0.26940', N'0.06264', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'350', N'339', N'0.28530', N'0.06264', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'351', N'340', N'0.27320', N'0.06264', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'352', N'341', N'0.28100', N'0.07280', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'353', N'342', N'0.24900', N'0.05076', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'354', N'343', N'0.23960', N'0.06774', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'355', N'344', N'0.25430', N'0.06552', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'356', N'345', N'0.28530', N'0.07384', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'357', N'346', N'0.27320', N'0.07010', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'358', N'347', N'0.25970', N'0.03058', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'359', N'348', N'0.27500', N'0.07029', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'360', N'349', N'0.27490', N'0.06264', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'361', N'350', N'0.27910', N'0.06264', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'362', N'351', N'0.34170', N'0.05571', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'363', N'352', N'0.33820', N'0.05571', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'364', N'353', N'0.36280', N'0.05571', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'365', N'354', N'0.37680', N'0.05571', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'366', N'355', N'0.35890', N'0.04231', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'367', N'356', N'0.33820', N'0.05571', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'368', N'357', N'0.19338', N'0.04625', N'0.01769', NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'369', N'358', N'0.20000', N'0.03446', NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'370', N'367', N'1810.00000', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'371', N'368', N'677.00000', NULL, NULL, NULL, NULL, N'1', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4513', N'3', N'0.20227', N'0.03021', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4514', N'3', N'0.20227', N'0.03446', NULL, NULL, N'2022', N'3', N'0')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4515', N'3', N'0.20267', N'0.03021', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4516', N'3', N'0.20267', N'0.03446', NULL, NULL, N'2023', N'2', N'0')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4517', N'3', N'0.20297', N'0.03021', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4518', N'3', N'0.20297', N'0.03446', NULL, NULL, N'2021', N'4', N'0')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4519', N'3', N'0.20374', N'0.03021', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4520', N'3', N'0.20374', N'0.03446', NULL, NULL, N'2020', N'5', N'0')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4521', N'4', N'1.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4522', N'4', N'1.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4523', N'4', N'1.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4524', N'4', N'1.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4525', N'5', N'25.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4526', N'5', N'25.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4527', N'5', N'25.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4528', N'5', N'28.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4529', N'6', N'265.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4530', N'6', N'298.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4531', N'6', N'298.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4532', N'6', N'298.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4533', N'7', N'12400.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4534', N'7', N'14800.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4535', N'7', N'14800.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4536', N'7', N'14800.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4537', N'8', N'675.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4538', N'8', N'675.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4539', N'8', N'675.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4540', N'8', N'677.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4541', N'9', N'92.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4542', N'9', N'92.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4543', N'9', N'92.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4544', N'9', N'116.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4545', N'10', N'3170.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4546', N'10', N'3500.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4547', N'10', N'3500.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4548', N'10', N'3500.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4549', N'11', N'1100.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4550', N'11', N'1100.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4551', N'11', N'1100.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4552', N'11', N'1120.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4553', N'12', N'1300.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4554', N'12', N'1430.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4555', N'12', N'1430.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4556', N'12', N'1430.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4557', N'13', N'328.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4558', N'13', N'353.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4559', N'13', N'353.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4560', N'13', N'353.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4561', N'14', N'4470.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4562', N'14', N'4470.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4563', N'14', N'4470.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4564', N'14', N'4800.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4565', N'15', N'124.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4566', N'15', N'124.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4567', N'15', N'124.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4568', N'15', N'138.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4569', N'16', N'3220.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4570', N'16', N'3220.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4571', N'16', N'3220.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4572', N'16', N'3350.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4573', N'17', N'8060.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4574', N'17', N'9810.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4575', N'17', N'9810.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4576', N'17', N'9810.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4577', N'18', N'858.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4578', N'18', N'1030.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4579', N'18', N'1030.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4580', N'18', N'1030.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4581', N'19', N'1640.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4582', N'19', N'1640.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4583', N'19', N'1640.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4584', N'19', N'1650.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4585', N'20', N'6630.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4586', N'20', N'7390.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4587', N'20', N'7390.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4588', N'20', N'7390.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4589', N'21', N'11100.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4590', N'21', N'12200.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4591', N'21', N'12200.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4592', N'21', N'12200.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4593', N'22', N'8830.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4594', N'22', N'8830.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4595', N'22', N'8830.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4596', N'22', N'8900.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4597', N'23', N'9540.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4598', N'23', N'10300.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4599', N'23', N'10300.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4600', N'23', N'10300.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4601', N'24', N'8860.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4602', N'24', N'8860.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4603', N'24', N'8860.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4604', N'24', N'9200.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4605', N'25', N'8550.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4606', N'25', N'9160.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4607', N'25', N'9160.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4608', N'25', N'9160.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4609', N'26', N'7910.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4610', N'26', N'9300.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4611', N'26', N'9300.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4612', N'26', N'9300.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4613', N'27', N'7190.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4614', N'27', N'7500.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4615', N'27', N'7500.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4616', N'27', N'7500.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4617', N'28', N'9200.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4618', N'28', N'17340.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4619', N'28', N'17340.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4620', N'28', N'17340.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4621', N'29', N'22800.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4622', N'29', N'22800.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4623', N'29', N'22800.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4624', N'29', N'23500.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4625', N'30', N'16.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4626', N'30', N'53.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4627', N'30', N'53.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4628', N'30', N'53.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4629', N'31', N'4.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4630', N'31', N'12.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4631', N'31', N'12.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4632', N'31', N'12.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4633', N'32', N'1210.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4634', N'32', N'1340.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4635', N'32', N'1340.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4636', N'32', N'1340.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4637', N'33', N'1330.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4638', N'33', N'1370.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4639', N'33', N'1370.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4640', N'33', N'1370.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4641', N'34', N'693.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4642', N'34', N'693.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4643', N'34', N'693.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4644', N'34', N'716.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4645', N'35', N'794.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4646', N'35', N'794.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4647', N'35', N'794.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4648', N'35', N'804.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4649', N'36', N'16100.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4650', N'36', N'17200.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4651', N'36', N'17200.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4652', N'36', N'17200.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4653', N'37', N'1130.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4654', N'37', N'1130.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4655', N'37', N'1130.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4656', N'37', N'1182.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4657', N'38', N'1236.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4658', N'38', N'1236.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4659', N'38', N'1236.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4660', N'38', N'1288.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4661', N'39', N'876.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4662', N'39', N'876.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4663', N'39', N'876.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4664', N'39', N'933.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4665', N'40', N'2571.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4666', N'40', N'2571.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4667', N'40', N'2571.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4668', N'40', N'2788.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4669', N'41', N'2261.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4670', N'41', N'2261.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4671', N'41', N'2261.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4672', N'41', N'2416.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4673', N'42', N'3100.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4674', N'42', N'3124.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4675', N'42', N'3124.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4676', N'42', N'3124.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4677', N'43', N'4457.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4678', N'43', N'4457.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4679', N'43', N'4457.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4680', N'43', N'4457.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4681', N'44', N'3922.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4682', N'44', N'3922.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4683', N'44', N'3922.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4684', N'44', N'3943.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4685', N'45', N'4716.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4686', N'45', N'4821.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4687', N'45', N'4821.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4688', N'45', N'4821.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4689', N'46', N'1780.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4690', N'46', N'1943.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4691', N'46', N'1943.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4692', N'46', N'1943.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4693', N'47', N'1923.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4694', N'47', N'2107.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4695', N'47', N'2107.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4696', N'47', N'2107.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4697', N'48', N'2547.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4698', N'48', N'2547.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4699', N'48', N'2547.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4700', N'48', N'2804.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4701', N'49', N'1624.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4702', N'49', N'1774.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4703', N'49', N'1774.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4704', N'49', N'1774.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4705', N'50', N'1487.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4706', N'50', N'1487.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4707', N'50', N'1487.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4708', N'50', N'1627.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4709', N'51', N'1425.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4710', N'51', N'1425.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4711', N'51', N'1425.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4712', N'51', N'1552.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4713', N'52', N'1674.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4714', N'52', N'1825.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4715', N'52', N'1825.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4716', N'52', N'1825.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4717', N'53', N'3152.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4718', N'53', N'3152.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4719', N'53', N'3152.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4720', N'53', N'3257.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4721', N'54', N'1485.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4722', N'54', N'1585.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4723', N'54', N'1585.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4724', N'54', N'1585.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4725', N'55', N'1474.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4726', N'55', N'1474.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4727', N'55', N'1474.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4728', N'55', N'1560.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4729', N'56', N'1924.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4730', N'56', N'2088.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4731', N'56', N'2088.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4732', N'56', N'2088.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4733', N'57', N'2048.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4734', N'57', N'2048.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4735', N'57', N'2048.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4736', N'57', N'2229.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4737', N'58', N'1555.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4738', N'58', N'1555.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4739', N'58', N'1555.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4740', N'58', N'1597.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4741', N'59', N'1659.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4742', N'59', N'1659.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4743', N'59', N'1659.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4744', N'59', N'1705.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4745', N'60', N'2172.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4746', N'60', N'2172.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4747', N'60', N'2172.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4748', N'60', N'2286.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4749', N'61', N'1945.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4750', N'61', N'1945.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4751', N'61', N'1945.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4752', N'61', N'2053.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4753', N'62', N'1375.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4754', N'62', N'1375.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4755', N'62', N'1375.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4756', N'62', N'1478.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4757', N'63', N'1274.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4758', N'63', N'1274.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4759', N'63', N'1274.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4760', N'63', N'1362.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4761', N'64', N'1468.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4762', N'64', N'1468.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4763', N'64', N'1468.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4764', N'64', N'1507.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4765', N'65', N'544.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4766', N'65', N'544.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4767', N'65', N'544.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4768', N'65', N'546.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4769', N'66', N'975.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4770', N'66', N'975.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4771', N'66', N'975.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4772', N'66', N'1084.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4773', N'67', N'2127.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4774', N'67', N'2127.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4775', N'67', N'2127.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4776', N'67', N'2346.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4777', N'68', N'2742.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4778', N'68', N'2742.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4779', N'68', N'2742.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4780', N'68', N'3027.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4781', N'69', N'1643.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4782', N'69', N'1643.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4783', N'69', N'1643.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4784', N'69', N'1809.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4785', N'70', N'1693.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4786', N'70', N'1693.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4787', N'70', N'1693.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4788', N'70', N'1741.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4789', N'71', N'2688.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4790', N'71', N'2688.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4791', N'71', N'2688.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4792', N'71', N'2967.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4793', N'72', N'2161.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4794', N'72', N'2161.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4795', N'72', N'2161.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4796', N'72', N'2384.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4797', N'73', N'1382.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4798', N'73', N'1382.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4799', N'73', N'1382.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4800', N'73', N'1536.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4801', N'74', N'2385.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4802', N'74', N'2385.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4803', N'74', N'2385.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4804', N'74', N'2631.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4805', N'75', N'2890.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4806', N'75', N'2890.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4807', N'75', N'2890.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4808', N'75', N'3190.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4809', N'76', N'2847.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4810', N'76', N'2847.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4811', N'76', N'2847.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4812', N'76', N'3143.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4813', N'77', N'2290.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4814', N'77', N'2290.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4815', N'77', N'2290.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4816', N'77', N'2526.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4817', N'78', N'2794.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4818', N'78', N'2794.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4819', N'78', N'2794.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4820', N'78', N'3085.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4821', N'79', N'2473.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4822', N'79', N'2473.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4823', N'79', N'2473.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4824', N'79', N'2729.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4825', N'80', N'2350.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4826', N'80', N'2350.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4827', N'80', N'2350.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4828', N'80', N'2592.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4829', N'81', N'2274.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4830', N'81', N'2274.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4831', N'81', N'2274.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4832', N'81', N'2280.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4833', N'82', N'2212.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4834', N'82', N'2212.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4835', N'82', N'2212.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4836', N'82', N'2440.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4837', N'83', N'1431.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4838', N'83', N'1431.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4839', N'83', N'1431.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4840', N'83', N'1505.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4841', N'84', N'1371.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4842', N'84', N'1371.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4843', N'84', N'1371.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4844', N'84', N'1508.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4845', N'85', N'2024.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4846', N'85', N'2024.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4847', N'85', N'2024.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4848', N'85', N'2138.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4849', N'86', N'3417.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4850', N'86', N'3417.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4851', N'86', N'3417.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4852', N'86', N'3607.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4853', N'87', N'14.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4854', N'87', N'15.30000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4855', N'87', N'15.30000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4856', N'87', N'15.30000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4857', N'88', N'95.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4858', N'88', N'106.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4859', N'88', N'106.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4860', N'88', N'106.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4861', N'89', N'38.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4862', N'89', N'40.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4863', N'89', N'40.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4864', N'89', N'40.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4865', N'90', N'1.80000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4866', N'90', N'1.80000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4867', N'90', N'1.80000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4868', N'90', N'2.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4869', N'91', N'0.64000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4870', N'91', N'0.64000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4871', N'91', N'0.64000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4872', N'91', N'3.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4873', N'92', N'0.16000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4874', N'92', N'0.16000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4875', N'92', N'0.16000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4876', N'92', N'3.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4877', N'93', N'0.55000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4878', N'93', N'0.55000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4879', N'93', N'0.55000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4880', N'93', N'3.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4881', N'94', N'3076.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4882', N'94', N'3076.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4883', N'94', N'3076.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4884', N'94', N'3245.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4885', N'95', N'26.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4886', N'95', N'28.40000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4887', N'95', N'28.40000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4888', N'95', N'28.40000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4889', N'96', N'1.35000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4890', N'96', N'1.35000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4891', N'96', N'1.35000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4892', N'96', N'3.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4893', N'97', N'1.47000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4894', N'97', N'1.47000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4895', N'97', N'1.47000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4896', N'97', N'3.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4897', N'98', N'1639.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4898', N'98', N'1639.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4899', N'98', N'1639.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4900', N'98', N'1805.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4901', N'99', N'2059.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4902', N'99', N'2059.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4903', N'99', N'2059.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4904', N'99', N'2265.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4905', N'100', N'1828.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4906', N'100', N'1828.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4907', N'100', N'1828.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4908', N'100', N'1983.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4909', N'101', N'144.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4910', N'101', N'156.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4911', N'101', N'156.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4912', N'101', N'156.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4913', N'102', N'0.23000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4914', N'102', N'0.23000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4915', N'102', N'0.23000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4916', N'102', N'3.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4917', N'103', N'1754.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4918', N'103', N'1754.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4919', N'103', N'1754.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4920', N'103', N'1888.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4921', N'104', N'1.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4922', N'104', N'1.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4923', N'104', N'1.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4924', N'104', N'2.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4925', N'105', N'88.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4926', N'105', N'89.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4927', N'105', N'89.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4928', N'105', N'89.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4929', N'106', N'118.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4930', N'106', N'118.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4931', N'106', N'118.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4932', N'106', N'130.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4933', N'107', N'7564.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4934', N'107', N'7564.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4935', N'107', N'7564.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4936', N'107', N'8077.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4937', N'108', N'3870.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4938', N'108', N'3870.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4939', N'108', N'3870.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4940', N'108', N'4083.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4941', N'109', N'4657.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4942', N'109', N'4657.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4943', N'109', N'4657.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4944', N'109', N'4786.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4945', N'110', N'13299.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4946', N'110', N'13299.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4947', N'110', N'13299.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4948', N'110', N'14560.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4949', N'111', N'4143.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4950', N'111', N'4299.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4951', N'111', N'4299.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4952', N'111', N'4299.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4953', N'112', N'7956.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4954', N'112', N'7956.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4955', N'112', N'7956.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4956', N'112', N'8502.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4957', N'113', N'3857.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4958', N'113', N'3857.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4959', N'113', N'3857.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4960', N'113', N'4490.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4961', N'114', N'3985.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4962', N'114', N'3985.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4963', N'114', N'3985.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4964', N'114', N'3985.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4965', N'115', N'11607.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4966', N'115', N'11607.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4967', N'115', N'11607.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4968', N'115', N'13214.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4969', N'116', N'11698.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4970', N'116', N'13396.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4971', N'116', N'13396.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4972', N'116', N'13396.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4973', N'117', N'5741.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4974', N'117', N'5758.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4975', N'117', N'5758.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4976', N'117', N'5758.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4977', N'118', N'1.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4978', N'118', N'1.24000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4979', N'118', N'1.24000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4980', N'118', N'1.24000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4981', N'119', N'7.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4982', N'119', N'7.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4983', N'119', N'7.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4984', N'119', N'9.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4985', N'120', N'189.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4986', N'120', N'196.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4987', N'120', N'196.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4988', N'120', N'196.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4989', N'121', N'4660.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4990', N'121', N'4750.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4991', N'121', N'4750.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4992', N'121', N'4750.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4993', N'122', N'10200.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4994', N'122', N'10900.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4995', N'122', N'10900.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4996', N'122', N'10900.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4997', N'123', N'13900.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4998', N'123', N'14400.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'4999', N'123', N'14400.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5000', N'123', N'14400.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5001', N'124', N'5820.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5002', N'124', N'6130.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5003', N'124', N'6130.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5004', N'124', N'6130.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5005', N'125', N'8590.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5006', N'125', N'10000.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5007', N'125', N'10000.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5008', N'125', N'10000.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5009', N'126', N'7370.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5010', N'126', N'7370.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5011', N'126', N'7370.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5012', N'126', N'7670.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5013', N'127', N'1750.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5014', N'127', N'1890.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5015', N'127', N'1890.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5016', N'127', N'1890.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5017', N'128', N'6290.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5018', N'128', N'7140.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5019', N'128', N'7140.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5020', N'128', N'7140.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5021', N'129', N'1470.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5022', N'129', N'1640.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5023', N'129', N'1640.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5024', N'129', N'1640.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5025', N'130', N'1400.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5026', N'130', N'1400.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5027', N'130', N'1400.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5028', N'130', N'1730.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5029', N'131', N'2.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5030', N'131', N'5.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5031', N'131', N'5.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5032', N'131', N'5.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5033', N'132', N'146.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5034', N'132', N'146.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5035', N'132', N'146.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5036', N'132', N'160.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5037', N'133', N'1760.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5038', N'133', N'1810.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5039', N'133', N'1810.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5040', N'133', N'1810.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5041', N'134', N'77.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5042', N'134', N'77.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5043', N'134', N'77.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5044', N'134', N'79.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5045', N'135', N'527.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5046', N'135', N'609.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5047', N'135', N'609.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5048', N'135', N'609.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5049', N'136', N'725.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5050', N'136', N'725.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5051', N'136', N'725.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5052', N'136', N'782.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5053', N'137', N'1980.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5054', N'137', N'2310.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5055', N'137', N'2310.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5056', N'137', N'2310.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5057', N'138', N'122.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5058', N'138', N'122.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5059', N'138', N'122.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5060', N'138', N'127.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5061', N'139', N'525.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5062', N'139', N'595.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5063', N'139', N'595.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5064', N'139', N'595.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5065', N'140', N'148.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5066', N'140', N'151.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5067', N'140', N'151.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5068', N'140', N'151.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5069', N'141', N'12400.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5070', N'141', N'14900.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5071', N'141', N'14900.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5072', N'141', N'14900.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5073', N'142', N'5560.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5074', N'142', N'6320.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5075', N'142', N'6320.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5076', N'142', N'6320.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5077', N'143', N'523.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5078', N'143', N'756.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5079', N'143', N'756.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5080', N'143', N'756.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5081', N'144', N'350.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5082', N'144', N'350.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5083', N'144', N'350.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5084', N'144', N'491.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5085', N'145', N'654.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5086', N'145', N'708.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5087', N'145', N'708.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5088', N'145', N'708.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5089', N'146', N'659.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5090', N'146', N'659.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5091', N'146', N'659.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5092', N'146', N'812.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5093', N'147', N'301.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5094', N'147', N'359.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5095', N'147', N'359.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5096', N'147', N'359.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5097', N'148', N'530.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5098', N'148', N'575.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5099', N'148', N'575.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5100', N'148', N'575.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5101', N'149', N'580.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5102', N'149', N'580.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5103', N'149', N'580.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5104', N'149', N'889.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5105', N'150', N'110.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5106', N'150', N'110.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5107', N'150', N'110.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5108', N'150', N'413.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5109', N'151', N'297.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5110', N'151', N'297.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5111', N'151', N'297.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5112', N'151', N'421.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5113', N'152', N'57.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5114', N'152', N'59.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5115', N'152', N'59.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5116', N'152', N'59.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5117', N'153', N'1870.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5118', N'153', N'1870.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5119', N'153', N'1870.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5120', N'153', N'2820.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5121', N'154', N'2800.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5122', N'154', N'2800.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5123', N'154', N'2800.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5124', N'154', N'5350.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5125', N'155', N'1500.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5126', N'155', N'1500.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5127', N'155', N'1500.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5128', N'155', N'2910.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5129', N'156', N'17400.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5130', N'156', N'17700.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5131', N'156', N'17700.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5132', N'156', N'17700.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5133', N'157', N'9710.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5134', N'157', N'10300.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5135', N'157', N'10300.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5136', N'157', N'10300.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5137', N'158', N'1.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5138', N'158', N'1.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5139', N'158', N'1.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5140', N'158', N'1.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5141', N'159', N'8.70000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5142', N'159', N'8.70000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5143', N'159', N'9.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5144', N'159', N'9.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5145', N'160', N'12.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5146', N'160', N'13.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5147', N'160', N'13.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5148', N'160', N'13.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5149', N'161', N'0.06000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5150', N'161', N'3.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5151', N'161', N'3.30000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5152', N'161', N'3.30000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5153', N'162', N'3.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5154', N'162', N'3.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5155', N'162', N'3.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5156', N'162', N'3.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5157', N'163', N'0.00600', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5158', N'163', N'0.00600', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5159', N'163', N'0.00600', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5160', N'163', N'4.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5161', N'164', N'5.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5162', N'164', N'5.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5163', N'164', N'5.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5164', N'164', N'5.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5165', N'165', N'5.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5166', N'165', N'5.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5167', N'165', N'5.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5168', N'165', N'5.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5169', N'166', N'0.43700', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5170', N'166', N'0.43700', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5171', N'166', N'0.43700', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5172', N'166', N'6.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5173', N'167', N'2.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5174', N'167', N'2.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5175', N'167', N'2.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5176', N'167', N'2.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5177', N'168', N'1.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5178', N'168', N'1.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5179', N'168', N'1.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5180', N'168', N'1.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5181', N'169', N'1.00000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5182', N'169', N'1.00000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5183', N'169', N'1.00000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5184', N'169', N'1.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5185', N'170', N'0.14080', N'0.03907', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5186', N'170', N'0.14652', N'0.04186', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5187', N'170', N'0.14836', N'0.04066', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5188', N'170', N'0.14946', N'0.04186', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5189', N'171', N'0.17819', N'0.04949', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5190', N'171', N'0.18470', N'0.05266', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5191', N'171', N'0.18659', N'0.05119', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5192', N'171', N'0.18785', N'0.05266', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5193', N'172', N'0.27224', N'0.07572', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5194', N'172', N'0.27639', N'0.07833', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5195', N'172', N'0.27807', N'0.07638', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5196', N'172', N'0.27909', N'0.07833', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5197', N'173', N'0.13721', N'0.03290', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5198', N'173', N'0.13758', N'0.03344', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5199', N'173', N'0.13931', N'0.03392', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5200', N'173', N'0.13989', N'0.03344', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5201', N'174', N'0.16496', N'0.04018', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5202', N'174', N'0.16637', N'0.03998', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5203', N'174', N'0.16716', N'0.04079', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5204', N'174', N'0.16800', N'0.04018', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5205', N'175', N'0.20419', N'0.04918', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5206', N'175', N'0.20721', N'0.05059', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5207', N'175', N'0.20859', N'0.05100', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5208', N'175', N'0.20953', N'0.05059', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5209', N'176', N'0.10150', N'0.02703', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5210', N'176', N'0.10275', N'0.02692', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5211', N'176', N'0.10332', N'0.02808', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5212', N'176', N'0.10494', N'0.02808', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5213', N'177', N'0.10698', N'0.02736', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5214', N'177', N'0.10904', N'0.02831', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5215', N'177', N'0.10957', N'0.02857', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5216', N'177', N'0.10999', N'0.02857', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5217', N'178', N'0.14480', N'0.03631', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5218', N'178', N'0.15151', N'0.03864', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5219', N'178', N'0.15244', N'0.03884', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5220', N'178', N'0.15491', N'0.03864', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5221', N'179', N'0.04416', N'0.01189', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5222', N'179', N'0.04565', N'0.01189', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5223', N'179', N'0.04637', N'0.00640', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5224', N'179', N'0.04823', N'0.01070', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5225', N'180', N'0.04416', N'0.01189', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5226', N'180', N'0.04565', N'0.01189', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5227', N'180', N'0.04637', N'0.00640', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5228', N'180', N'0.04823', N'0.01070', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5229', N'181', N'0.05550', N'0.01580', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5230', N'181', N'0.05797', N'0.01285', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5231', N'181', N'0.06066', N'0.01580', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5232', N'181', N'0.06646', N'0.00917', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5233', N'182', N'0.05255', N'0.01493', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5234', N'182', N'0.05402', N'0.01317', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5235', N'182', N'0.05568', N'0.01493', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5236', N'182', N'0.05860', N'0.01112', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5237', N'183', N'0.05255', N'0.01493', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5238', N'183', N'0.05402', N'0.01317', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5239', N'183', N'0.05568', N'0.01493', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5240', N'183', N'0.05860', N'0.01112', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5241', N'184', N'0.10148', N'0.02875', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5242', N'184', N'0.10158', N'0.02635', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5243', N'184', N'0.10492', N'0.02875', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5244', N'184', N'0.10515', N'0.02476', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5245', N'185', N'0.18217', N'0.05060', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5246', N'185', N'0.19687', N'0.05603', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5247', N'185', N'0.19987', N'0.05603', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5248', N'185', N'0.21079', N'0.05781', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5249', N'186', N'0.19594', N'0.05444', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5250', N'186', N'0.19821', N'0.05556', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5251', N'186', N'0.20461', N'0.05556', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5252', N'186', N'0.20792', N'0.05703', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5253', N'187', N'0.31306', N'0.08788', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5254', N'187', N'0.31444', N'0.08748', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5255', N'187', N'0.32607', N'0.08788', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5256', N'187', N'0.33276', N'0.09140', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5257', N'188', N'0.14189', N'0.03568', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5258', N'188', N'0.14212', N'0.03463', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5259', N'188', N'0.14670', N'0.03568', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5260', N'188', N'0.14853', N'0.03565', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5261', N'189', N'0.17405', N'0.04250', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5262', N'189', N'0.17513', N'0.04467', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5263', N'189', N'0.18315', N'0.04467', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5264', N'189', N'0.18900', N'0.04549', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5265', N'190', N'0.25346', N'0.06207', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5266', N'190', N'0.25481', N'0.06491', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5267', N'190', N'0.26529', N'0.06491', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5268', N'190', N'0.27171', N'0.06559', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5269', N'192', N'0.03612', N'0.01030', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5270', N'192', N'0.03850', N'0.00853', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5271', N'192', N'0.03955', N'0.01030', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5272', N'192', N'0.04319', N'0.00596', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5273', N'193', N'0.07660', N'0.01995', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5274', N'193', N'0.08422', N'0.01162', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5275', N'193', N'0.08967', N'0.01991', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5276', N'193', N'0.09327', N'0.01995', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5277', N'194', N'0.05459', N'0.01422', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5278', N'194', N'0.05640', N'0.01422', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5279', N'194', N'0.05932', N'0.01316', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5280', N'194', N'0.06020', N'0.00831', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5281', N'195', N'0.48058', N'0.11660', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5282', N'195', N'0.48251', N'0.11550', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5283', N'195', N'0.48562', N'0.11811', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5284', N'195', N'0.49758', N'0.11660', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5285', N'196', N'0.58692', N'0.14220', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5286', N'196', N'0.58928', N'0.14085', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5287', N'196', N'0.59277', N'0.14404', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5288', N'196', N'0.60793', N'0.14220', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5289', N'197', N'0.95752', N'0.23228', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5290', N'197', N'0.96432', N'0.23079', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5291', N'197', N'0.97436', N'0.23696', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5292', N'197', N'0.99337', N'0.23228', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5293', N'199', N'0.76647', N'0.18544', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5294', N'199', N'0.76976', N'0.18579', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5295', N'199', N'0.77574', N'0.18468', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5296', N'199', N'0.78111', N'0.18579', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5297', N'200', N'0.91265', N'0.22065', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5298', N'200', N'0.91648', N'0.22106', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5299', N'200', N'0.92367', N'0.21974', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5300', N'200', N'0.93004', N'0.22106', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5301', N'204', NULL, NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5302', N'204', NULL, NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5303', N'204', NULL, NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5304', N'204', NULL, NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5305', N'205', NULL, NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5306', N'205', NULL, NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5307', N'205', NULL, NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5308', N'205', NULL, NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5309', N'206', NULL, NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5310', N'206', NULL, NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5311', N'206', NULL, NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5312', N'206', NULL, NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5313', N'207', N'0.16391', N'0.04551', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5314', N'207', N'0.17048', N'0.04885', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5315', N'207', N'0.17430', N'0.04781', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5316', N'207', N'0.17431', N'0.04885', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5317', N'208', N'0.16843', N'0.04104', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5318', N'208', N'0.16844', N'0.04049', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5319', N'208', N'0.16983', N'0.04145', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5320', N'208', N'0.17082', N'0.04104', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5321', N'209', N'0.11558', N'0.02969', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5322', N'209', N'0.11898', N'0.03109', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5323', N'209', N'0.11952', N'0.03132', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5324', N'209', N'0.12004', N'0.03132', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5325', N'210', N'0.09349', N'0.02657', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5326', N'210', N'0.09392', N'0.02440', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5327', N'210', N'0.09694', N'0.02657', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5328', N'210', N'0.09712', N'0.02287', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5329', N'211', N'0.05140', N'0.01426', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5330', N'211', N'0.05477', N'0.01426', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5331', N'211', N'0.05480', N'0.01215', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5332', N'211', N'0.05728', N'0.00790', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5333', N'212', N'0.11337', N'0.03060', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5334', N'212', N'0.11355', N'0.03134', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5335', N'212', N'0.11355', N'0.03134', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5336', N'212', N'0.11367', N'0.02956', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5337', N'213', N'0.03546', N'0.00897', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5338', N'213', N'0.03549', N'0.00892', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5339', N'213', N'0.03549', N'0.00892', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5340', N'213', N'0.03694', N'0.00724', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5341', N'214', N'0.02750', N'0.00380', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5342', N'214', N'0.02780', N'0.00728', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5343', N'214', N'0.02781', N'0.00724', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5344', N'214', N'0.02781', N'0.00724', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5345', N'215', N'0.20369', N'0.04905', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5346', N'215', N'0.20806', N'0.05176', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5347', N'215', N'0.20826', N'0.05085', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5348', N'215', N'0.20826', N'0.05085', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5349', N'216', N'0.07718', N'0.01885', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5350', N'216', N'0.07832', N'0.01916', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5351', N'216', N'0.07856', N'0.01894', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5352', N'216', N'0.07936', N'0.01885', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5353', N'217', N'0.24430', N'0.02691', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5354', N'217', N'0.24587', N'0.02691', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5355', N'217', N'0.24587', N'0.02691', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5356', N'217', N'0.27258', N'0.02691', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5357', N'218', N'0.15353', N'0.01681', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5358', N'218', N'0.15353', N'0.01681', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5359', N'218', N'0.15553', N'0.01681', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5360', N'218', N'0.18592', N'0.01681', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5361', N'219', N'0.19085', N'0.02114', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5362', N'219', N'0.19309', N'0.02114', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5363', N'219', N'0.19309', N'0.02114', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5364', N'219', N'0.26128', N'0.02114', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5365', N'220', N'0.00000', N'0.00000', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5366', N'220', N'0.00000', N'0.00000', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5367', N'220', N'0.00000', N'0.00000', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5368', N'220', N'0.00000', N'0.00000', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5369', N'221', N'0.00000', N'0.00000', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5370', N'221', N'0.00000', N'0.00000', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5371', N'221', N'0.00000', N'0.00000', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5372', N'221', N'0.00000', N'0.00000', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5373', N'225', N'0.08277', N'0.02226', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5374', N'225', N'0.08306', N'0.02277', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5375', N'225', N'0.08306', N'0.02277', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5376', N'225', N'0.08319', N'0.02148', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5377', N'226', N'0.10086', N'0.02703', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5378', N'226', N'0.10090', N'0.02765', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5379', N'226', N'0.10090', N'0.02765', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5380', N'226', N'0.10108', N'0.02608', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5381', N'227', N'0.13237', N'0.03595', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5382', N'227', N'0.13245', N'0.03678', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5383', N'227', N'0.13245', N'0.03678', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5384', N'227', N'0.13252', N'0.03469', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5385', N'228', N'0.00446', N'0.00116', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5386', N'228', N'0.00446', N'0.00116', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5387', N'228', N'0.00446', N'0.00117', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5388', N'228', N'0.00497', N'0.00069', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5389', N'229', N'0.02860', N'0.00749', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5390', N'229', N'0.02861', N'0.00745', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5391', N'229', N'0.02861', N'0.00745', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5392', N'229', N'0.02991', N'0.00413', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5393', N'230', NULL, NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5394', N'230', NULL, NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5395', N'230', NULL, NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5396', N'230', NULL, NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5397', N'231', NULL, NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5398', N'231', NULL, NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5399', N'231', NULL, NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5400', N'231', NULL, NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5401', N'232', N'0.02684', N'0.00646', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5402', N'232', N'0.02718', N'0.00656', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5403', N'232', N'0.02732', N'0.00649', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5404', N'232', N'0.02733', N'0.00646', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5405', N'233', NULL, NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5406', N'233', NULL, NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5407', N'233', NULL, NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5408', N'233', NULL, NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5409', N'234', N'0.15353', N'0.02286', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5410', N'234', N'0.15353', N'0.02286', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5411', N'234', N'0.15553', N'0.02286', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5412', N'234', N'0.18592', N'0.02286', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5413', N'235', N'0.15102', N'0.02249', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5414', N'235', N'0.15102', N'0.02249', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5415', N'235', N'0.15298', N'0.02249', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5416', N'235', N'0.18287', N'0.02249', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5417', N'236', N'0.15102', N'0.03373', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5418', N'236', N'0.15102', N'0.03373', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5419', N'236', N'0.15298', N'0.03373', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5420', N'236', N'0.18287', N'0.03373', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5421', N'237', N'0.19085', N'0.03213', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5422', N'237', N'0.19309', N'0.03213', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5423', N'237', N'0.19309', N'0.03213', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5424', N'237', N'0.26128', N'0.03213', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5425', N'238', N'0.14615', N'0.02461', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5426', N'238', N'0.14787', N'0.02461', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5427', N'238', N'0.14787', N'0.02461', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5428', N'238', N'0.20011', N'0.02461', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5429', N'239', N'0.23385', N'0.03937', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5430', N'239', N'0.23659', N'0.03937', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5431', N'239', N'0.23659', N'0.03937', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5432', N'239', N'0.32016', N'0.03937', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5433', N'240', N'0.42385', N'0.07137', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5434', N'240', N'0.42882', N'0.07137', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5435', N'240', N'0.42882', N'0.07137', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5436', N'240', N'0.58029', N'0.07137', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5437', N'241', N'0.58462', N'0.09844', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5438', N'241', N'0.59147', N'0.09844', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5439', N'241', N'0.59147', N'0.09844', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5440', N'241', N'0.80040', N'0.09844', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5441', N'242', NULL, NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5442', N'242', NULL, NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5443', N'242', NULL, NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5444', N'242', NULL, NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5445', N'243', NULL, NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5446', N'243', NULL, NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5447', N'243', NULL, NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5448', N'243', NULL, NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5449', N'260', N'1.76300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5450', N'260', N'1.76300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5451', N'260', N'1.76300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5452', N'260', N'1.76300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5453', N'261', N'0.30000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5454', N'261', N'0.30000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5455', N'261', N'0.30000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5456', N'261', N'0.30000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5457', N'262', N'1.27300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5458', N'262', N'1.27300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5459', N'262', N'1.27300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5460', N'262', N'1.27300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5461', N'263', N'1.32900', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5462', N'263', N'1.32900', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5463', N'263', N'1.32900', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5464', N'263', N'1.32900', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5465', N'264', N'0.77400', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5466', N'264', N'0.77400', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5467', N'264', N'0.77400', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5468', N'264', N'0.77400', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5469', N'265', N'3.01900', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5470', N'265', N'3.01900', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5471', N'265', N'3.01900', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5472', N'265', N'3.01900', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5473', N'266', N'0.32900', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5474', N'266', N'0.32900', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5475', N'266', N'0.32900', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5476', N'266', N'0.32900', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5477', N'267', N'0.84100', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5478', N'267', N'0.84100', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5479', N'267', N'0.84100', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5480', N'267', N'0.84100', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5481', N'268', N'0.37700', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5482', N'268', N'0.37700', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5483', N'268', N'0.37700', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5484', N'268', N'0.37700', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5485', N'269', N'0.43500', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5486', N'269', N'0.43500', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5487', N'269', N'0.43500', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5488', N'269', N'0.43500', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5489', N'270', N'0.25300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5490', N'270', N'0.25300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5491', N'270', N'0.25300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5492', N'270', N'0.25300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5493', N'271', N'0.39600', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5494', N'271', N'0.39600', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5495', N'271', N'0.39600', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5496', N'271', N'0.39600', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5497', N'272', N'0.25900', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5498', N'272', N'0.25900', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5499', N'272', N'0.25900', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5500', N'272', N'0.25900', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5501', N'273', N'1.22800', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5502', N'273', N'1.22800', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5503', N'273', N'1.22800', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5504', N'273', N'1.22800', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5505', N'274', N'0.33000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5506', N'274', N'0.33000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5507', N'274', N'0.33000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5508', N'274', N'0.33000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5509', N'275', N'0.20900', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5510', N'275', N'0.20900', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5511', N'275', N'0.20900', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5512', N'275', N'0.20900', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5513', N'276', N'0.59200', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5514', N'276', N'0.59200', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5515', N'276', N'0.59200', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5516', N'276', N'0.59200', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5517', N'277', N'0.08100', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5518', N'277', N'0.08100', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5519', N'277', N'0.08100', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5520', N'277', N'0.08100', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5521', N'278', N'0.27200', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5522', N'278', N'0.27200', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5523', N'278', N'0.27200', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5524', N'278', N'0.27200', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5525', N'279', N'0.25300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5526', N'279', N'0.25300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5527', N'279', N'0.25300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5528', N'279', N'0.25300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5529', N'280', N'0.07900', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5530', N'280', N'0.07900', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5531', N'280', N'0.07900', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5532', N'280', N'0.07900', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5533', N'281', N'0.26800', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5534', N'281', N'0.26800', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5535', N'281', N'0.26800', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5536', N'281', N'0.26800', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5537', N'282', N'0.23200', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5538', N'282', N'0.23200', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5539', N'282', N'0.23200', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5540', N'282', N'0.23200', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5541', N'283', N'0.09500', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5542', N'283', N'0.09500', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5543', N'283', N'0.09500', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5544', N'283', N'0.09500', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5545', N'284', N'0.29200', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5546', N'284', N'0.29200', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5547', N'284', N'0.29200', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5548', N'284', N'0.29200', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5549', N'285', N'0.25700', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5550', N'285', N'0.25700', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5551', N'285', N'0.25700', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5552', N'285', N'0.25700', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5553', N'286', N'0.14100', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5554', N'286', N'0.14100', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5555', N'286', N'0.14100', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5556', N'286', N'0.14100', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5557', N'287', N'0.14700', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5558', N'287', N'0.14700', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5559', N'287', N'0.14700', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5560', N'287', N'0.14700', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5561', N'288', N'0.24800', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5562', N'288', N'0.24800', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5563', N'288', N'0.24800', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5564', N'288', N'0.24800', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5565', N'289', N'0.17700', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5566', N'289', N'0.17700', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5567', N'289', N'0.17700', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5568', N'289', N'0.17700', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5569', N'290', N'0.92300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5570', N'290', N'0.92300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5571', N'290', N'0.92300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5572', N'290', N'0.92300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5573', N'291', N'0.72200', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5574', N'291', N'0.72200', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5575', N'291', N'0.72200', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5576', N'291', N'0.72200', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5577', N'292', N'0.74200', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5578', N'292', N'0.74200', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5579', N'292', N'0.74200', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5580', N'292', N'0.74200', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5581', N'293', N'1.38900', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5582', N'293', N'1.38900', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5583', N'293', N'1.38900', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5584', N'293', N'1.38900', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5585', N'294', N'0.34300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5586', N'294', N'0.34300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5587', N'294', N'0.34300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5588', N'294', N'0.34300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5589', N'295', N'1.79100', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5590', N'295', N'1.79100', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5591', N'295', N'1.79100', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5592', N'295', N'1.79100', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5593', N'296', N'0.42600', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5594', N'296', N'0.42600', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5595', N'296', N'0.42600', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5596', N'296', N'0.42600', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5597', N'297', N'0.45500', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5598', N'297', N'0.45500', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5599', N'297', N'0.45500', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5600', N'297', N'0.45500', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5601', N'298', N'0.17500', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5602', N'298', N'0.17500', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5603', N'298', N'0.17500', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5604', N'298', N'0.17500', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5605', N'299', N'0.05700', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5606', N'299', N'0.05700', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5607', N'299', N'0.05700', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5608', N'299', N'0.05700', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5609', N'300', N'0.05600', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5610', N'300', N'0.05600', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5611', N'300', N'0.05600', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5612', N'300', N'0.05600', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5613', N'301', N'0.08400', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5614', N'301', N'0.08400', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5615', N'301', N'0.08400', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5616', N'301', N'0.08400', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5617', N'302', N'0.08500', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5618', N'302', N'0.08500', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5619', N'302', N'0.08500', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5620', N'302', N'0.08500', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5621', N'303', N'0.07000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5622', N'303', N'0.07000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5623', N'303', N'0.07000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5624', N'303', N'0.07000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5625', N'304', N'0.10300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5626', N'304', N'0.10300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5627', N'304', N'0.10300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5628', N'304', N'0.10300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5629', N'305', N'0.04300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5630', N'305', N'0.04300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5631', N'305', N'0.04300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5632', N'305', N'0.04300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5633', N'306', N'0.20900', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5634', N'306', N'0.20900', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5635', N'306', N'0.20900', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5636', N'306', N'0.20900', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5637', N'307', N'0.09300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5638', N'307', N'0.09300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5639', N'307', N'0.09300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5640', N'307', N'0.09300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5641', N'308', N'0.05900', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5642', N'308', N'0.05900', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5643', N'308', N'0.05900', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5644', N'308', N'0.05900', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5645', N'309', N'0.13800', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5646', N'309', N'0.13800', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5647', N'309', N'0.13800', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5648', N'309', N'0.13800', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5649', N'310', N'0.06400', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5650', N'310', N'0.06400', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5651', N'310', N'0.06400', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5652', N'310', N'0.06400', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5653', N'311', N'0.10400', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5654', N'311', N'0.10400', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5655', N'311', N'0.10400', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5656', N'311', N'0.10400', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5657', N'312', N'0.11700', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5658', N'312', N'0.11700', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5659', N'312', N'0.11700', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5660', N'312', N'0.11700', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5661', N'313', N'1.38700', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5662', N'313', N'1.38700', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5663', N'313', N'1.38700', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5664', N'313', N'1.38700', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5665', N'314', N'0.20400', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5666', N'314', N'0.20400', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5667', N'314', N'0.20400', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5668', N'314', N'0.20400', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5669', N'315', N'0.09100', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5670', N'315', N'0.09100', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5671', N'315', N'0.09100', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5672', N'315', N'0.09100', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5673', N'316', N'0.17200', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5674', N'316', N'0.17200', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5675', N'316', N'0.17200', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5676', N'316', N'0.17200', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5677', N'317', N'0.17000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5678', N'317', N'0.17000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5679', N'317', N'0.17000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5680', N'317', N'0.17000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5681', N'318', N'0.16400', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5682', N'318', N'0.16400', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5683', N'318', N'0.16400', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5684', N'318', N'0.16400', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5685', N'319', N'0.07400', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5686', N'319', N'0.07400', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5687', N'319', N'0.07400', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5688', N'319', N'0.07400', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5689', N'320', N'0.38000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5690', N'320', N'0.38000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5691', N'320', N'0.38000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5692', N'320', N'0.38000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5693', N'321', N'0.18500', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5694', N'321', N'0.18500', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5695', N'321', N'0.18500', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5696', N'321', N'0.18500', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5697', N'322', N'0.22500', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5698', N'322', N'0.22500', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5699', N'322', N'0.22500', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5700', N'322', N'0.22500', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5701', N'323', N'0.15300', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5702', N'323', N'0.15300', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5703', N'323', N'0.15300', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5704', N'323', N'0.15300', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5705', N'324', N'0.02200', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5706', N'324', N'0.02200', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5707', N'324', N'0.02200', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5708', N'324', N'0.02200', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5709', N'325', N'0.43400', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5710', N'325', N'0.43400', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5711', N'325', N'0.43400', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5712', N'325', N'0.43400', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5713', N'326', N'0.24106', N'0.02719', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5714', N'326', N'0.24106', N'0.02719', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5715', N'326', N'0.24107', N'0.02719', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5716', N'326', N'0.24107', N'0.02719', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5717', N'327', N'0.20227', N'0.04282', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5718', N'327', N'0.20267', N'0.04282', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5719', N'327', N'0.20297', N'0.04282', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5720', N'327', N'0.20374', N'0.04282', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5721', N'328', N'0.20386', N'0.07055', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5722', N'328', N'0.20420', N'0.07055', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5723', N'328', N'0.20431', N'0.07055', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5724', N'328', N'0.20449', N'0.07055', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5725', N'329', N'0.23030', N'0.02719', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5726', N'329', N'0.23031', N'0.02719', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5727', N'329', N'0.23031', N'0.02719', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5728', N'329', N'0.23032', N'0.02719', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5729', N'330', N'0.20227', N'0.03021', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5730', N'330', N'0.20227', N'0.03446', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5731', N'330', N'0.20267', N'0.03021', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5732', N'330', N'0.20267', N'0.03446', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5733', N'330', N'0.20297', N'0.03021', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5734', N'330', N'0.20297', N'0.03446', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5735', N'330', N'0.20374', N'0.03021', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5736', N'330', N'0.20374', N'0.03446', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5737', N'331', N'0.20386', N'0.03446', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5738', N'331', N'0.20420', N'0.03446', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5739', N'331', N'0.20431', N'0.03446', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5740', N'331', N'0.20449', N'0.03446', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5741', N'332', N'0.19917', N'0.02352', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5742', N'332', N'0.19917', N'0.02352', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5743', N'332', N'0.19917', N'0.02352', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5744', N'332', N'0.20094', N'0.02352', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5745', N'333', N'0.23257', N'0.02719', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5746', N'333', N'0.23257', N'0.02719', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5747', N'333', N'0.23258', N'0.02719', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5748', N'333', N'0.23258', N'0.02719', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5749', N'334', N'0.25658', N'0.06552', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5750', N'334', N'0.25658', N'0.06552', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5751', N'334', N'0.25666', N'0.06552', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5752', N'334', N'0.25805', N'0.06552', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5753', N'335', N'0.26061', N'0.05400', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5754', N'335', N'0.26086', N'0.05400', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5755', N'335', N'0.26086', N'0.05400', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5756', N'335', N'0.26086', N'0.05400', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5757', N'336', N'0.25964', N'0.05400', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5758', N'336', N'0.25975', N'0.05400', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5759', N'336', N'0.25975', N'0.05400', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5760', N'336', N'0.25975', N'0.05400', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5761', N'337', N'0.25165', N'0.06109', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5762', N'337', N'0.25409', N'0.06109', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5763', N'337', N'0.25568', N'0.06109', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5764', N'337', N'0.25631', N'0.06109', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5765', N'338', N'0.26802', N'0.06264', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5766', N'338', N'0.26891', N'0.06264', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5767', N'338', N'0.26939', N'0.06264', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5768', N'338', N'0.26955', N'0.06264', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5769', N'339', N'0.28484', N'0.06264', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5770', N'339', N'0.28523', N'0.06264', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5771', N'339', N'0.28526', N'0.06264', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5772', N'339', N'0.28527', N'0.06264', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5773', N'340', N'0.27288', N'0.06264', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5774', N'340', N'0.27310', N'0.06264', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5775', N'340', N'0.27318', N'0.06264', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5776', N'340', N'0.27319', N'0.06264', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5777', N'341', N'0.28100', N'0.07280', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5778', N'341', N'0.28104', N'0.07280', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5779', N'341', N'0.28105', N'0.07280', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5780', N'341', N'0.28131', N'0.07280', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5781', N'342', N'0.24891', N'0.05076', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5782', N'342', N'0.24895', N'0.05076', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5783', N'342', N'0.24895', N'0.05076', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5784', N'342', N'0.24898', N'0.05076', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5785', N'343', N'0.23397', N'0.06774', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5786', N'343', N'0.23961', N'0.06774', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5787', N'343', N'0.24164', N'0.06774', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5788', N'343', N'0.24227', N'0.06774', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5789', N'344', N'0.25390', N'0.06552', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5790', N'344', N'0.25428', N'0.06552', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5791', N'344', N'0.25430', N'0.06552', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5792', N'344', N'0.25444', N'0.06552', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5793', N'345', N'0.28484', N'0.07384', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5794', N'345', N'0.28523', N'0.07384', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5795', N'345', N'0.28526', N'0.07384', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5796', N'345', N'0.28527', N'0.07384', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5797', N'346', N'0.27288', N'0.07010', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5798', N'346', N'0.27310', N'0.07010', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5799', N'346', N'0.27318', N'0.07010', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5800', N'346', N'0.27319', N'0.07010', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5801', N'347', N'0.25961', N'0.03058', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5802', N'347', N'0.25965', N'0.03058', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5803', N'347', N'0.25966', N'0.03058', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5804', N'347', N'0.25966', N'0.03058', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5805', N'348', N'0.27459', N'0.07029', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5806', N'348', N'0.27494', N'0.07029', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5807', N'348', N'0.27503', N'0.07029', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5808', N'348', N'0.27503', N'0.07029', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5809', N'349', N'0.27445', N'0.06264', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5810', N'349', N'0.27485', N'0.06264', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5811', N'349', N'0.27485', N'0.06264', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5812', N'349', N'0.27485', N'0.06264', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5813', N'350', N'0.27869', N'0.06264', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5814', N'350', N'0.27911', N'0.06264', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5815', N'350', N'0.27911', N'0.06264', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5816', N'350', N'0.27937', N'0.06264', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5817', N'351', N'0.33726', N'0.05571', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5818', N'351', N'0.33960', N'0.05571', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5819', N'351', N'0.34064', N'0.05571', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5820', N'351', N'0.34172', N'0.05571', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5821', N'352', N'0.33333', N'0.05571', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5822', N'352', N'0.33407', N'0.05571', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5823', N'352', N'0.33706', N'0.05571', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5824', N'352', N'0.33824', N'0.05571', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5825', N'353', N'0.36276', N'0.05571', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5826', N'353', N'0.36276', N'0.05571', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5827', N'353', N'0.36276', N'0.05571', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5828', N'353', N'0.36549', N'0.05571', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5829', N'354', N'0.37675', N'0.05571', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5830', N'354', N'0.37681', N'0.05571', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5831', N'354', N'0.37682', N'0.05571', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5832', N'354', N'0.38358', N'0.05571', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5833', N'355', N'0.35887', N'0.04231', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5834', N'355', N'0.35890', N'0.04231', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5835', N'355', N'0.35890', N'0.04231', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5836', N'355', N'0.36006', N'0.04231', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5837', N'356', N'0.33333', N'0.05571', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5838', N'356', N'0.33407', N'0.05571', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5839', N'356', N'0.33706', N'0.05571', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5840', N'356', N'0.33824', N'0.05571', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5842', N'360', N'0.57060', N'0.13962', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5843', N'361', N'0.09696', N'0.02346', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5844', N'362', N'0.02779', N'0.00691', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5845', N'363', N'1.66816', N'0.20515', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5846', N'364', N'1.09903', N'0.13516', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5847', N'365', N'0.01321', N'0.00300', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5848', N'360', N'0.57871', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5849', N'361', N'0.10614', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5850', N'362', N'0.02782', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5851', N'363', N'2.30229', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5852', N'364', N'1.01890', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5853', N'365', N'0.01323', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5854', N'360', N'0.60261', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5855', N'361', N'0.10749', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5856', N'362', N'0.02782', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5857', N'363', N'2.30229', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5858', N'364', N'1.01890', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5859', N'365', N'0.01323', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5860', N'360', N'0.61628', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5861', N'361', N'0.10650', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5862', N'362', N'0.02556', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5863', N'363', N'2.20946', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5864', N'364', N'1.13382', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5865', N'365', N'0.01323', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5867', N'1', N'0.37800', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5868', N'2', N'0.20707', N'0.04590', N'0.01792', N'0.00397', N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5869', N'198', N'0.82313', N'0.20019', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5870', N'201', N'0.90644', N'0.21916', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5871', N'202', N'2.09747', N'0.58094', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5872', N'203', N'2.51206', N'0.61101', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5873', N'244', N'21.28081', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5874', N'245', N'1.23401', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5875', N'246', N'497.04471', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5876', N'247', N'700.20988', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5877', N'248', N'646.60659', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5878', N'249', N'655.98717', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5879', N'250', N'520.33474', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5880', N'251', N'1.23401', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5881', N'252', N'5.91332', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5882', N'253', N'8.88413', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5883', N'254', N'19.51734', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5884', N'255', N'71.95000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5885', N'256', N'925.24450', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5886', N'257', N'8.88413', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5887', N'258', N'496.68331', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5888', N'259', N'1164.39042', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5890', N'1', N'0.42100', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5891', N'2', N'0.19338', N'0.04625', N'0.01769', N'0.00423', N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5892', N'198', N'0.69215', N'0.19479', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5893', N'201', N'0.65630', N'0.21962', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5894', N'202', N'2.16185', N'0.61328', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5895', N'203', N'2.55784', N'0.60986', NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5896', N'244', N'21.28019', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5897', N'245', N'1.23376', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5898', N'246', N'446.20411', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5899', N'247', N'626.85615', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5900', N'248', N'578.94041', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5901', N'249', N'587.32567', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5902', N'250', N'467.00838', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5903', N'251', N'1.23376', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5904', N'252', N'5.91308', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5905', N'253', N'8.88327', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5906', N'254', N'17.57714', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5907', N'255', N'71.95000', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5908', N'256', N'828.01354', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5909', N'257', N'8.88327', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5910', N'258', N'444.92469', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5911', N'259', N'1041.78497', NULL, NULL, NULL, N'2022', N'3', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5912', N'1', N'0.42100', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5913', N'2', N'0.21233', N'0.05529', N'0.01879', N'0.00489', N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5914', N'198', N'0.66441', N'0.19479', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5915', N'201', N'0.64913', N'0.21962', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5916', N'202', N'2.19352', N'0.61328', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5917', N'203', N'2.51233', N'0.60986', NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5918', N'244', N'21.29357', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5919', N'245', N'1.23931', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5920', N'246', N'446.24150', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5921', N'247', N'626.87487', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5922', N'248', N'578.95913', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5923', N'249', N'587.34439', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5924', N'250', N'467.04580', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5925', N'251', N'1.23931', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5926', N'252', N'5.91843', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5927', N'253', N'8.90199', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5928', N'254', N'17.58269', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5929', N'255', N'71.95000', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5930', N'256', N'828.03227', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5931', N'257', N'8.90199', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5932', N'258', N'444.94341', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5933', N'259', N'1041.80369', NULL, NULL, NULL, N'2021', N'4', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5934', N'1', N'1.05200', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5935', N'2', N'0.23314', N'0.03217', N'0.02005', N'0.00277', N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5936', N'198', N'0.66604', N'0.19172', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5937', N'201', N'0.65191', N'0.21785', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5938', N'202', N'2.16802', N'0.59344', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5939', N'203', N'2.54603', N'0.61015', NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5940', N'244', N'21.31670', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5941', N'245', N'1.24890', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5942', N'246', N'437.37190', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5943', N'247', N'626.90730', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5944', N'248', N'578.99160', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5945', N'249', N'587.37680', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5946', N'250', N'458.17630', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5947', N'251', N'1.24890', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5948', N'252', N'5.92770', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5949', N'253', N'8.93440', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5950', N'254', N'17.59230', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5951', N'255', N'71.95000', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5952', N'256', N'828.06470', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5953', N'257', N'8.98640', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5954', N'258', N'444.97590', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5955', N'259', N'1041.83610', NULL, NULL, NULL, N'2020', N'5', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5956', N'357', N'0.03106', N'0.00689', N'0.00269', N'0.00060', N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5957', N'358', N'1.02894', N'0.15337', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'5958', N'359', N'1.31873', N'0.27415', NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6059', N'3', N'0.20264', N'0.03021', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6060', N'3', N'0.20264', N'0.03446', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6061', N'4', N'1.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6062', N'5', N'28.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6063', N'6', N'265.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6064', N'7', N'12400.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6065', N'8', N'677.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6066', N'9', N'116.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6067', N'10', N'3170.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6068', N'11', N'1120.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6069', N'12', N'1300.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6070', N'13', N'328.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6071', N'14', N'4800.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6072', N'15', N'138.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6073', N'16', N'3350.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6074', N'17', N'8060.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6075', N'18', N'858.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6076', N'19', N'1650.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6077', N'20', N'6630.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6078', N'21', N'11100.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6079', N'22', N'8900.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6080', N'23', N'9540.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6081', N'24', N'9200.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6082', N'25', N'8550.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6083', N'26', N'7910.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6084', N'27', N'7190.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6085', N'28', N'9200.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6086', N'29', N'23500.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6087', N'30', N'16.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6088', N'31', N'4.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6089', N'32', N'1210.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6090', N'33', N'1330.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6091', N'34', N'716.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6092', N'35', N'804.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6093', N'36', N'16100.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6094', N'37', N'1130.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6095', N'38', N'1236.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6096', N'39', N'876.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6097', N'40', N'2571.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6098', N'41', N'2261.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6099', N'42', N'3100.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6100', N'43', N'4457.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6101', N'44', N'3943.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6102', N'45', N'4821.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6103', N'46', N'1780.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6104', N'47', N'1923.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6105', N'48', N'2547.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6106', N'49', N'1624.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6107', N'50', N'1487.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6108', N'51', N'1425.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6109', N'52', N'1674.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6110', N'53', N'3257.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6111', N'54', N'1485.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6112', N'55', N'1474.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6113', N'56', N'1924.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6114', N'57', N'2048.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6115', N'58', N'1555.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6116', N'59', N'1659.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6117', N'60', N'2172.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6118', N'61', N'1945.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6119', N'62', N'1375.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6120', N'63', N'1274.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6121', N'64', N'1468.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6122', N'65', N'544.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6123', N'66', N'975.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6124', N'67', N'2127.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6125', N'68', N'2742.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6126', N'69', N'1643.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6127', N'70', N'1693.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6128', N'71', N'2688.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6129', N'72', N'2161.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6130', N'73', N'1382.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6131', N'74', N'2385.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6132', N'75', N'2890.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6133', N'76', N'2847.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6134', N'77', N'2290.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6135', N'78', N'2794.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6136', N'79', N'2473.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6137', N'80', N'2350.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6138', N'81', N'2274.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6139', N'82', N'2212.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6140', N'83', N'1431.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6141', N'84', N'1371.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6142', N'85', N'2024.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6143', N'86', N'3417.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6144', N'87', N'15.30000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6145', N'88', N'106.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6146', N'89', N'40.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6147', N'90', N'1.80000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6148', N'91', N'0.64000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6149', N'92', N'0.16000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6150', N'93', N'0.55000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6151', N'94', N'3076.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6152', N'95', N'28.40000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6153', N'96', N'1.35000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6154', N'97', N'1.47000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6155', N'98', N'1639.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6156', N'99', N'2059.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6157', N'100', N'1828.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6158', N'101', N'156.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6159', N'102', N'0.23000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6160', N'103', N'1754.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6161', N'104', N'1.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6162', N'105', N'89.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6163', N'106', N'118.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6164', N'107', N'7564.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6165', N'108', N'3870.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6166', N'109', N'4786.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6167', N'110', N'13299.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6168', N'111', N'4299.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6169', N'112', N'7956.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6170', N'113', N'3857.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6171', N'114', N'3985.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6172', N'115', N'11607.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6173', N'116', N'11698.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6174', N'117', N'5758.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6175', N'118', N'1.24000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6176', N'119', N'7.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6177', N'120', N'196.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6178', N'121', N'4660.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6179', N'122', N'10200.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6180', N'123', N'13900.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6181', N'124', N'5820.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6182', N'125', N'8590.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6183', N'126', N'7670.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6184', N'127', N'1750.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6185', N'128', N'6290.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6186', N'129', N'1470.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6187', N'130', N'1730.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6188', N'131', N'2.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6189', N'132', N'160.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6190', N'133', N'1760.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6191', N'134', N'79.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6192', N'135', N'527.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6193', N'136', N'782.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6194', N'137', N'1980.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6195', N'138', N'127.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6196', N'139', N'525.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6197', N'140', N'148.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6198', N'141', N'12400.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6199', N'142', N'5560.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6200', N'143', N'523.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6201', N'144', N'491.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6202', N'145', N'654.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6203', N'146', N'812.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6204', N'147', N'301.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6205', N'148', N'530.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6206', N'149', N'889.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6207', N'150', N'413.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6208', N'151', N'421.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6209', N'152', N'57.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6210', N'153', N'2820.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6211', N'154', N'5350.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6212', N'155', N'2910.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6213', N'156', N'17400.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6214', N'157', N'9710.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6215', N'158', N'1.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6216', N'159', N'9.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6217', N'160', N'12.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6218', N'161', N'0.06000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6219', N'162', N'3.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6220', N'163', N'0.00600', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6221', N'164', N'5.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6222', N'165', N'5.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6223', N'166', N'0.43700', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6224', N'167', N'2.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6225', N'168', N'1.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6226', N'169', N'1.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6227', N'170', N'0.14370', N'0.04015', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6228', N'171', N'0.17726', N'0.04957', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6229', N'172', N'0.26885', N'0.07528', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6230', N'173', N'0.13994', N'0.03409', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6231', N'174', N'0.16807', N'0.04103', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6232', N'175', N'0.20729', N'0.05070', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6233', N'176', N'0.11274', N'0.03026', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6234', N'177', N'0.11490', N'0.02998', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6235', N'178', N'0.15486', N'0.03961', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6236', N'179', N'0.04284', N'0.00948', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6237', N'180', N'0.04284', N'0.00948', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6238', N'181', N'0.04925', N'0.01088', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6239', N'182', N'0.06078', N'0.01520', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6240', N'183', N'0.06078', N'0.01520', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6241', N'184', N'0.11923', N'0.03221', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6242', N'185', N'0.20071', N'0.05614', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6243', N'186', N'0.21709', N'0.06074', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6244', N'187', N'0.34923', N'0.09783', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6245', N'188', N'0.15356', N'0.03746', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6246', N'189', N'0.18832', N'0.04602', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6247', N'190', N'0.27365', N'0.06706', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6248', N'192', N'0.04254', N'0.00943', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6249', N'193', N'0.06556', N'0.01454', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6250', N'194', N'0.08929', N'0.01979', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6251', N'195', N'0.48733', N'0.11851', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6252', N'196', N'0.59495', N'0.14453', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6253', N'197', N'0.97698', N'0.23756', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6254', N'199', N'0.76642', N'0.18538', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6255', N'200', N'0.91247', N'0.22058', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6256', N'204', NULL, NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6257', N'205', NULL, NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6258', N'206', NULL, NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6259', N'207', N'0.16450', N'0.04599', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6260', N'208', N'0.16984', N'0.04146', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6261', N'209', N'0.12607', N'0.03315', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6262', N'210', N'0.10853', N'0.02934', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6263', N'211', N'0.04745', N'0.01049', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6264', N'212', N'0.11367', N'0.02956', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6265', N'213', N'0.03546', N'0.00897', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6266', N'214', N'0.02780', N'0.00728', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6267', N'215', N'0.20805', N'0.05176', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6268', N'216', N'0.07447', N'0.01821', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6269', N'217', N'0.27257', N'0.02691', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6270', N'218', N'0.18592', N'0.01681', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6271', N'219', N'0.26128', N'0.02114', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6272', N'220', N'0.00000', N'0.00000', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6273', N'221', N'0.00000', N'0.00000', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6274', N'225', N'0.08319', N'0.02148', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6275', N'226', N'0.10107', N'0.02608', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6276', N'227', N'0.13252', N'0.03469', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6277', N'228', N'0.00446', N'0.00117', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6278', N'229', N'0.02860', N'0.00749', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6279', N'230', NULL, NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6280', N'231', NULL, NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6281', N'232', N'0.02717', N'0.00656', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6282', N'233', NULL, NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6283', N'234', N'0.18592', N'0.02286', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6284', N'235', N'0.18287', N'0.02249', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6285', N'236', N'0.18287', N'0.03373', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6286', N'237', N'0.26128', N'0.03213', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6287', N'238', N'0.20011', N'0.02461', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6288', N'239', N'0.32015', N'0.03937', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6289', N'240', N'0.58028', N'0.07137', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6290', N'241', N'0.80040', N'0.09844', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6291', N'242', NULL, NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6292', N'243', NULL, NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6293', N'260', N'1.76300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6294', N'261', N'0.30000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6295', N'262', N'1.27300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6296', N'263', N'1.32900', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6297', N'264', N'0.77400', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6298', N'265', N'3.01900', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6299', N'266', N'0.32900', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6300', N'267', N'0.84100', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6301', N'268', N'0.37700', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6302', N'269', N'0.43500', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6303', N'270', N'0.25300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6304', N'271', N'0.39600', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6305', N'272', N'0.25900', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6306', N'273', N'1.22800', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6307', N'274', N'0.33000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6308', N'275', N'0.20900', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6309', N'276', N'0.59200', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6310', N'277', N'0.08100', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6311', N'278', N'0.27200', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6312', N'279', N'0.25300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6313', N'280', N'0.07900', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6314', N'281', N'0.26800', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6315', N'282', N'0.23200', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6316', N'283', N'0.09500', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6317', N'284', N'0.29200', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6318', N'285', N'0.25700', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6319', N'286', N'0.14100', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6320', N'287', N'0.14700', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6321', N'288', N'0.24800', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6322', N'289', N'0.17700', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6323', N'290', N'0.92300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6324', N'291', N'0.72200', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6325', N'292', N'0.74200', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6326', N'293', N'1.38900', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6327', N'294', N'0.34300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6328', N'295', N'1.79100', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6329', N'296', N'0.42600', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6330', N'297', N'0.45500', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6331', N'298', N'0.17500', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6332', N'299', N'0.05700', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6333', N'300', N'0.05600', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6334', N'301', N'0.08400', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6335', N'302', N'0.08500', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6336', N'303', N'0.07000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6337', N'304', N'0.10300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6338', N'305', N'0.04300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6339', N'306', N'0.20900', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6340', N'307', N'0.09300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6341', N'308', N'0.05900', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6342', N'309', N'0.13800', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6343', N'310', N'0.06400', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6344', N'311', N'0.10400', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6345', N'312', N'0.11700', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6346', N'313', N'1.38700', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6347', N'314', N'0.20400', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6348', N'315', N'0.09100', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6349', N'316', N'0.17200', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6350', N'317', N'0.17000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6351', N'318', N'0.16400', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6352', N'319', N'0.07400', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6353', N'320', N'0.38000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6354', N'321', N'0.18500', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6355', N'322', N'0.22500', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6356', N'323', N'0.15300', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6357', N'324', N'0.02200', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6358', N'325', N'0.43400', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6359', N'326', N'0.24106', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6360', N'327', N'0.20264', N'0.04282', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6361', N'328', N'0.20440', N'0.07055', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6362', N'329', N'0.23031', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6363', N'330', N'0.20264', N'0.03021', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6364', N'330', N'0.20264', N'0.03446', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6365', N'331', N'0.20440', N'0.03446', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6366', N'332', N'0.19917', N'0.02352', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6367', N'333', N'0.23257', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6368', N'334', N'0.25666', N'0.06552', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6369', N'335', N'0.26061', N'0.05400', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6370', N'336', N'0.25975', N'0.05400', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6371', N'337', N'0.25403', N'0.06109', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6372', N'338', N'0.26808', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6373', N'339', N'0.28523', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6374', N'340', N'0.27287', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6375', N'341', N'0.28100', N'0.07280', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6376', N'342', N'0.24891', N'0.05076', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6377', N'343', N'0.23240', N'0.06774', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6378', N'344', N'0.25460', N'0.06552', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6379', N'345', N'0.28523', N'0.07384', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6380', N'346', N'0.27287', N'0.07010', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6381', N'347', N'0.25961', N'0.03058', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6382', N'348', N'0.27458', N'0.07029', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6383', N'349', N'0.27446', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6384', N'350', N'0.27869', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6385', N'351', N'0.34002', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6386', N'352', N'0.33368', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6387', N'353', N'0.36549', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6388', N'354', N'0.37675', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6389', N'355', N'0.35886', N'0.04231', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6390', N'356', N'0.33368', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6391', N'371', N'0.24382', N'0.06552', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6392', N'369', N'2.33116', N'0.06552', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6393', N'370', N'3193.69480', N'0.06552', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6394', N'372', N'0.24758', N'0.05400', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6395', N'373', N'2.54269', N'0.05400', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6396', N'374', N'3178.36520', N'0.05400', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6397', N'375', N'0.24677', N'0.05400', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6398', N'376', N'2.54015', N'0.05400', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6399', N'377', N'3165.04181', N'0.05400', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6400', N'378', N'0.22241', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6401', N'379', N'1.74532', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6402', N'380', N'3033.38067', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6403', N'381', N'0.18290', N'0.04282', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6404', N'382', N'0.44942', N'0.04282', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6405', N'383', N'2568.16441', N'0.04282', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6406', N'384', N'0.34721', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6407', N'385', N'2904.95234', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6408', N'386', N'0.31699', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6409', N'387', N'2258.58670', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6410', N'388', N'0.31699', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6411', N'389', N'2262.11448', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6412', N'390', N'0.32302', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6413', N'391', N'2399.43994', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6414', N'392', N'0.35790', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6415', N'393', N'3164.65002', N'0.05571', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6416', N'394', N'0.25197', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6417', N'395', N'2.66155', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6418', N'396', N'3203.91143', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6419', N'397', N'0.23902', N'0.06109', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6420', N'398', N'2.51279', N'0.06109', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6421', N'399', N'3014.09462', N'0.06109', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6422', N'400', N'0.26814', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6423', N'401', N'3.17493', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6424', N'402', N'3228.89019', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6425', N'403', N'0.25649', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6426', N'404', N'2.75541', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6427', N'405', N'3226.57859', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6428', N'406', N'0.18449', N'0.07055', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6429', N'407', N'1.17216', N'0.07055', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6430', N'408', N'2590.46441', N'0.07055', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6431', N'409', N'0.21450', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6432', N'410', N'1.55713', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6433', N'411', N'2939.36095', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6434', N'412', N'0.26414', N'0.07280', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6435', N'413', N'2.74934', N'0.07280', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6436', N'414', N'3180.99992', N'0.07280', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6437', N'415', N'0.26196', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6438', N'416', N'3.10202', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6439', N'417', N'3154.75334', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6440', N'418', N'0.25798', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6441', N'419', N'2.77139', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6442', N'420', N'3245.30441', N'0.06264', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6443', N'421', N'0.23647', N'0.05076', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6444', N'422', N'2.11894', N'0.05076', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6445', N'423', N'3142.37890', N'0.05076', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6446', N'425', N'2.04542', N'0.03021', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6447', N'424', N'0.18290', N'0.03021', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6448', N'426', N'2568.16441', N'0.03021', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6449', N'428', N'2.06318', N'0.03446', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6450', N'427', N'0.18449', N'0.03446', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6451', N'429', N'2590.46441', N'0.03446', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6452', N'430', N'0.18323', N'0.02352', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6453', N'431', N'0.94441', N'0.02352', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6454', N'432', N'2578.24647', N'0.02352', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6455', N'433', N'0.24186', N'0.06552', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6456', N'434', N'2.35372', N'0.06552', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6457', N'435', N'3154.08213', N'0.06552', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6458', N'436', N'0.22013', N'0.06774', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6459', N'437', N'2.08440', N'0.06774', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6460', N'438', N'2778.52935', N'0.06774', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6461', N'439', N'0.34092', N'0.04231', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6462', N'440', N'3386.57168', N'0.04231', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6463', N'441', N'0.25649', N'0.07010', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6464', N'442', N'2.75541', N'0.07010', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6465', N'443', N'3226.57859', N'0.07010', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6466', N'444', N'0.26814', N'0.07384', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6467', N'445', N'3.17493', N'0.07384', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6468', N'446', N'3228.89019', N'0.07384', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6469', N'447', N'0.21411', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6470', N'448', N'1.54357', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6471', N'449', N'2997.63233', N'0.02719', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6472', N'451', N'0.24662', N'0.03058', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6473', N'450', N'0.00000', N'0.03058', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6474', N'452', N'2944.32093', N'0.03058', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6475', N'453', N'0.25641', N'0.07029', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6476', N'454', N'0.27458', N'0.07029', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6477', N'455', N'2.74923', N'0.07029', NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6478', N'457', N'10.40000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6479', N'458', N'11.50000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6480', N'459', N'35.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6481', N'460', N'12.20000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6482', N'461', N'8.70000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6483', N'462', N'7.40000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6484', N'463', N'27.60000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6485', N'464', N'53.50000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6486', N'465', N'14.70000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6487', N'466', N'4.70000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6488', N'467', N'44.20000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6489', N'468', N'6.70000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6490', N'469', N'13.20000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6491', N'470', N'51.50000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6492', N'471', N'58.90000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6493', N'472', N'62.70000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6494', N'473', N'14.30000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6495', N'474', N'39.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6496', N'475', N'68.90000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6497', N'476', N'55.80000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6498', N'477', N'61.50000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6499', N'478', N'152.20000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6500', N'479', N'19.30000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6501', N'480', N'14.80000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6502', N'481', N'90.30000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6503', N'482', N'54.30000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6504', N'483', N'19.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6505', N'484', N'86.20000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6506', N'485', N'24.20000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6507', N'486', N'106.40000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6508', N'487', N'24.50000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6509', N'488', N'51.40000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6510', N'489', N'7.00000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6511', N'490', N'6.60000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6512', N'491', N'43.40000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6513', N'492', N'32.10000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6514', N'493', N'63.80000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6515', N'494', N'16.10000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6516', N'495', N'38.50000', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6517', N'457', N'10.40000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6518', N'458', N'11.50000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6519', N'459', N'35.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6520', N'460', N'12.20000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6521', N'461', N'8.70000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6522', N'462', N'7.40000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6523', N'463', N'27.60000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6524', N'464', N'53.50000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6525', N'465', N'14.70000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6526', N'466', N'4.70000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6527', N'467', N'44.20000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6528', N'468', N'6.70000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6529', N'469', N'13.20000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6530', N'470', N'51.50000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6531', N'471', N'58.90000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6532', N'472', N'62.70000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6533', N'473', N'14.30000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6534', N'474', N'39.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6535', N'475', N'68.90000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6536', N'476', N'55.80000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6537', N'477', N'61.50000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6538', N'478', N'152.20000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6539', N'479', N'19.30000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6540', N'480', N'14.80000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6541', N'481', N'90.30000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6542', N'482', N'54.30000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6543', N'483', N'19.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6544', N'484', N'86.20000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6545', N'485', N'24.20000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6546', N'486', N'106.40000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6547', N'487', N'24.50000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6548', N'488', N'51.40000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6549', N'489', N'7.00000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6550', N'490', N'6.60000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6551', N'491', N'43.40000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6552', N'492', N'32.10000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6553', N'493', N'63.80000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6554', N'494', N'16.10000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6555', N'495', N'38.50000', NULL, NULL, NULL, N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6559', N'498', N'0.05213', N'0.01157', N'0.00331', N'0.01487', N'2023', N'2', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6560', N'498', N'0.05213', N'0.01157', N'0.00331', N'0.01487', N'2024', N'9', N'1')
GO

INSERT INTO [Emissions].[EmissionFactor] ([id], [activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active]) VALUES (N'6561', N'1', N'0.15311', NULL, NULL, NULL, N'2024', N'9', N'1')
GO

SET IDENTITY_INSERT [Emissions].[EmissionFactor] OFF
GO


-- ----------------------------
-- Table structure for EmissionProfile
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[EmissionProfile]') AND type IN ('U'))
	DROP TABLE [Emissions].[EmissionProfile]
GO

CREATE TABLE [Emissions].[EmissionProfile] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NOT NULL,
  [year] int  NULL,
  [defaultProfileId] int  NULL
)
GO

ALTER TABLE [Emissions].[EmissionProfile] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of EmissionProfile
-- ----------------------------
SET IDENTITY_INSERT [Emissions].[EmissionProfile] ON
GO

INSERT INTO [Emissions].[EmissionProfile] ([id], [name], [description], [active], [year], [defaultProfileId]) VALUES (N'1', N'UAE 2022', NULL, N'0', N'2022', N'3')
GO

INSERT INTO [Emissions].[EmissionProfile] ([id], [name], [description], [active], [year], [defaultProfileId]) VALUES (N'2', N'BEIS / DEFRA 2023', NULL, N'1', N'2023', NULL)
GO

INSERT INTO [Emissions].[EmissionProfile] ([id], [name], [description], [active], [year], [defaultProfileId]) VALUES (N'3', N'BEIS / DEFRA 2022', NULL, N'0', N'2022', NULL)
GO

INSERT INTO [Emissions].[EmissionProfile] ([id], [name], [description], [active], [year], [defaultProfileId]) VALUES (N'4', N'BEIS / DEFRA 2021', NULL, N'0', N'2021', NULL)
GO

INSERT INTO [Emissions].[EmissionProfile] ([id], [name], [description], [active], [year], [defaultProfileId]) VALUES (N'5', N'BEIS / DEFRA 2020', NULL, N'0', N'2020', NULL)
GO

INSERT INTO [Emissions].[EmissionProfile] ([id], [name], [description], [active], [year], [defaultProfileId]) VALUES (N'6', N'UAE 2023', NULL, N'1', N'2023', N'2')
GO

INSERT INTO [Emissions].[EmissionProfile] ([id], [name], [description], [active], [year], [defaultProfileId]) VALUES (N'7', N'UAE 2021', NULL, N'0', N'2021', N'4')
GO

INSERT INTO [Emissions].[EmissionProfile] ([id], [name], [description], [active], [year], [defaultProfileId]) VALUES (N'8', N'UAE 2020', NULL, N'0', N'2020', N'5')
GO

INSERT INTO [Emissions].[EmissionProfile] ([id], [name], [description], [active], [year], [defaultProfileId]) VALUES (N'9', N'BEIS / DEFRA 2024', NULL, N'1', N'2024', NULL)
GO

SET IDENTITY_INSERT [Emissions].[EmissionProfile] OFF
GO


-- ----------------------------
-- Table structure for FactorsbyCategory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[FactorsbyCategory]') AND type IN ('U'))
	DROP TABLE [Emissions].[FactorsbyCategory]
GO

CREATE TABLE [Emissions].[FactorsbyCategory] (
  [ID] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Scope] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Level 1] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Level 2] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Level 3] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Level 4] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Column Text] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [UOM] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [GHG/Unit] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [GHG Conversion Factor 2024] decimal(15,5)  NULL
)
GO

ALTER TABLE [Emissions].[FactorsbyCategory] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of FactorsbyCategory
-- ----------------------------

-- ----------------------------
-- Table structure for FuelPrices
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[FuelPrices]') AND type IN ('U'))
	DROP TABLE [Emissions].[FuelPrices]
GO

CREATE TABLE [Emissions].[FuelPrices] (
  [country] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [weekDate] datetime2(7)  NULL,
  [petrolPrice] decimal(10,2)  NULL,
  [dieselPrice] decimal(10,2)  NULL
)
GO

ALTER TABLE [Emissions].[FuelPrices] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of FuelPrices
-- ----------------------------
INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-06-09 00:00:00.0000000', N'74.59', N'76.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-06-16 00:00:00.0000000', N'74.47', N'76.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-06-23 00:00:00.0000000', N'74.42', N'76.62')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-06-30 00:00:00.0000000', N'74.35', N'76.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-07-07 00:00:00.0000000', N'74.28', N'76.46')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-07-14 00:00:00.0000000', N'74.21', N'76.41')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-07-21 00:00:00.0000000', N'75.07', N'76.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-07-28 00:00:00.0000000', N'75.10', N'76.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-08-04 00:00:00.0000000', N'75.12', N'76.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-08-11 00:00:00.0000000', N'75.44', N'77.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-08-18 00:00:00.0000000', N'75.81', N'77.44')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-08-26 00:00:00.0000000', N'76.05', N'77.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-09-01 00:00:00.0000000', N'76.13', N'77.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-09-08 00:00:00.0000000', N'76.23', N'77.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-09-15 00:00:00.0000000', N'76.20', N'77.63')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-09-22 00:00:00.0000000', N'76.15', N'77.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-09-29 00:00:00.0000000', N'76.08', N'77.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-10-06 00:00:00.0000000', N'76.43', N'77.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-10-13 00:00:00.0000000', N'75.90', N'77.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-10-20 00:00:00.0000000', N'76.05', N'77.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-10-27 00:00:00.0000000', N'76.00', N'77.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-11-03 00:00:00.0000000', N'76.00', N'77.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-11-10 00:00:00.0000000', N'75.94', N'77.47')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-11-17 00:00:00.0000000', N'75.93', N'77.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-11-24 00:00:00.0000000', N'76.02', N'77.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-12-01 00:00:00.0000000', N'76.00', N'77.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-12-08 00:00:00.0000000', N'75.97', N'77.63')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-12-15 00:00:00.0000000', N'75.96', N'77.62')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-12-22 00:00:00.0000000', N'75.92', N'77.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2003-12-29 00:00:00.0000000', N'75.94', N'77.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-01-05 00:00:00.0000000', N'75.88', N'77.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-01-12 00:00:00.0000000', N'75.90', N'77.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-01-19 00:00:00.0000000', N'76.36', N'78.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-01-26 00:00:00.0000000', N'76.44', N'78.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-02-02 00:00:00.0000000', N'76.48', N'78.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-02-09 00:00:00.0000000', N'76.50', N'77.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-02-16 00:00:00.0000000', N'76.44', N'78.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-02-23 00:00:00.0000000', N'76.38', N'77.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-03-01 00:00:00.0000000', N'76.32', N'77.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-03-08 00:00:00.0000000', N'76.73', N'78.25')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-03-15 00:00:00.0000000', N'77.39', N'78.80')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-03-22 00:00:00.0000000', N'77.44', N'78.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-03-29 00:00:00.0000000', N'77.59', N'79.01')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-04-05 00:00:00.0000000', N'77.86', N'79.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-04-12 00:00:00.0000000', N'77.88', N'79.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-04-19 00:00:00.0000000', N'78.04', N'79.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-04-26 00:00:00.0000000', N'78.40', N'79.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-05-04 00:00:00.0000000', N'79.28', N'80.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-05-10 00:00:00.0000000', N'80.30', N'81.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-05-17 00:00:00.0000000', N'81.49', N'82.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-05-24 00:00:00.0000000', N'82.13', N'83.48')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-05-31 00:00:00.0000000', N'82.35', N'83.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-06-07 00:00:00.0000000', N'82.44', N'83.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-06-14 00:00:00.0000000', N'81.54', N'82.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-06-21 00:00:00.0000000', N'81.04', N'82.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-06-28 00:00:00.0000000', N'80.41', N'81.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-07-05 00:00:00.0000000', N'79.87', N'80.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-07-12 00:00:00.0000000', N'80.34', N'81.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-07-19 00:00:00.0000000', N'80.84', N'81.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-07-26 00:00:00.0000000', N'80.87', N'81.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-08-02 00:00:00.0000000', N'80.86', N'81.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-08-09 00:00:00.0000000', N'81.18', N'82.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-08-16 00:00:00.0000000', N'81.25', N'82.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-08-23 00:00:00.0000000', N'81.51', N'82.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-08-31 00:00:00.0000000', N'81.53', N'82.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-09-06 00:00:00.0000000', N'81.37', N'82.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-09-13 00:00:00.0000000', N'81.31', N'82.91')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-09-20 00:00:00.0000000', N'81.28', N'83.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-09-27 00:00:00.0000000', N'81.63', N'83.46')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-10-04 00:00:00.0000000', N'82.05', N'83.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-10-11 00:00:00.0000000', N'83.11', N'85.01')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-10-18 00:00:00.0000000', N'83.35', N'85.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-10-25 00:00:00.0000000', N'83.94', N'86.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-11-01 00:00:00.0000000', N'84.27', N'86.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-11-08 00:00:00.0000000', N'84.34', N'86.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-11-15 00:00:00.0000000', N'84.26', N'86.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-11-22 00:00:00.0000000', N'81.46', N'85.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-11-29 00:00:00.0000000', N'84.17', N'86.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-12-06 00:00:00.0000000', N'84.06', N'86.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-12-13 00:00:00.0000000', N'82.73', N'85.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-12-20 00:00:00.0000000', N'81.46', N'85.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2004-12-27 00:00:00.0000000', N'81.20', N'85.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-01-03 00:00:00.0000000', N'81.17', N'85.12')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-01-10 00:00:00.0000000', N'79.84', N'84.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-01-17 00:00:00.0000000', N'78.93', N'83.94')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-01-24 00:00:00.0000000', N'78.93', N'83.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-01-31 00:00:00.0000000', N'79.54', N'84.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-02-07 00:00:00.0000000', N'79.84', N'84.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-02-14 00:00:00.0000000', N'80.03', N'84.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-02-21 00:00:00.0000000', N'80.15', N'84.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-02-28 00:00:00.0000000', N'80.45', N'84.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-03-07 00:00:00.0000000', N'81.16', N'85.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-03-14 00:00:00.0000000', N'81.64', N'86.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-03-21 00:00:00.0000000', N'82.70', N'87.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-03-28 00:00:00.0000000', N'83.40', N'87.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-04-04 00:00:00.0000000', N'83.91', N'88.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-04-11 00:00:00.0000000', N'85.61', N'89.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-04-18 00:00:00.0000000', N'85.63', N'89.80')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-04-25 00:00:00.0000000', N'85.51', N'89.62')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-05-02 00:00:00.0000000', N'85.44', N'89.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-05-09 00:00:00.0000000', N'85.36', N'89.46')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-05-16 00:00:00.0000000', N'85.27', N'89.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-05-23 00:00:00.0000000', N'84.77', N'89.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-05-30 00:00:00.0000000', N'84.18', N'88.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-06-06 00:00:00.0000000', N'84.01', N'88.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-06-13 00:00:00.0000000', N'84.99', N'88.96')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-06-20 00:00:00.0000000', N'85.52', N'89.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-06-27 00:00:00.0000000', N'86.73', N'90.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-07-04 00:00:00.0000000', N'87.49', N'91.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-07-11 00:00:00.0000000', N'87.73', N'91.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-07-18 00:00:00.0000000', N'88.55', N'92.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-07-25 00:00:00.0000000', N'89.00', N'93.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-08-01 00:00:00.0000000', N'89.25', N'93.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-08-08 00:00:00.0000000', N'89.67', N'93.63')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-08-15 00:00:00.0000000', N'90.56', N'94.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-08-22 00:00:00.0000000', N'90.77', N'94.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-08-29 00:00:00.0000000', N'91.42', N'95.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-09-05 00:00:00.0000000', N'94.37', N'97.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-09-12 00:00:00.0000000', N'95.07', N'97.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-09-19 00:00:00.0000000', N'94.41', N'97.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-09-26 00:00:00.0000000', N'93.33', N'96.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-10-03 00:00:00.0000000', N'93.51', N'96.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-10-10 00:00:00.0000000', N'94.25', N'97.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-10-17 00:00:00.0000000', N'94.14', N'97.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-10-24 00:00:00.0000000', N'93.47', N'96.80')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-10-31 00:00:00.0000000', N'92.79', N'96.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-11-07 00:00:00.0000000', N'92.47', N'96.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-11-14 00:00:00.0000000', N'90.53', N'94.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-11-21 00:00:00.0000000', N'88.61', N'93.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-11-28 00:00:00.0000000', N'87.35', N'91.80')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-12-05 00:00:00.0000000', N'87.35', N'91.80')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-12-12 00:00:00.0000000', N'87.20', N'91.48')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-12-19 00:00:00.0000000', N'87.56', N'91.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2005-12-26 00:00:00.0000000', N'87.88', N'92.12')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-01-02 00:00:00.0000000', N'88.03', N'92.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-01-09 00:00:00.0000000', N'88.56', N'92.94')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-01-16 00:00:00.0000000', N'89.01', N'93.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-01-23 00:00:00.0000000', N'89.55', N'93.62')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-01-30 00:00:00.0000000', N'89.88', N'93.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-02-06 00:00:00.0000000', N'89.73', N'93.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-02-13 00:00:00.0000000', N'89.65', N'93.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-02-20 00:00:00.0000000', N'89.60', N'93.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-02-27 00:00:00.0000000', N'89.51', N'93.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-03-06 00:00:00.0000000', N'89.37', N'93.63')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-03-13 00:00:00.0000000', N'89.55', N'93.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-03-20 00:00:00.0000000', N'90.19', N'94.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-03-27 00:00:00.0000000', N'91.16', N'94.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-04-03 00:00:00.0000000', N'91.78', N'95.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-04-10 00:00:00.0000000', N'92.77', N'96.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-04-18 00:00:00.0000000', N'94.23', N'97.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-04-24 00:00:00.0000000', N'95.35', N'98.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-05-01 00:00:00.0000000', N'96.13', N'98.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-05-08 00:00:00.0000000', N'96.46', N'98.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-05-15 00:00:00.0000000', N'96.39', N'98.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-05-22 00:00:00.0000000', N'96.10', N'98.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-05-29 00:00:00.0000000', N'95.36', N'97.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-06-05 00:00:00.0000000', N'95.24', N'97.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-06-12 00:00:00.0000000', N'95.49', N'97.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-06-19 00:00:00.0000000', N'95.44', N'97.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-06-26 00:00:00.0000000', N'94.97', N'97.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-07-03 00:00:00.0000000', N'95.27', N'97.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-07-10 00:00:00.0000000', N'95.69', N'97.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-07-17 00:00:00.0000000', N'96.88', N'98.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-07-24 00:00:00.0000000', N'97.78', N'99.41')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-07-31 00:00:00.0000000', N'97.83', N'99.41')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-08-07 00:00:00.0000000', N'98.05', N'99.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-08-14 00:00:00.0000000', N'97.82', N'99.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-08-21 00:00:00.0000000', N'95.74', N'97.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-08-28 00:00:00.0000000', N'94.40', N'96.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-09-04 00:00:00.0000000', N'92.88', N'95.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-09-11 00:00:00.0000000', N'91.48', N'95.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-09-18 00:00:00.0000000', N'89.78', N'94.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-09-25 00:00:00.0000000', N'88.20', N'93.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-10-02 00:00:00.0000000', N'86.95', N'92.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-10-09 00:00:00.0000000', N'86.60', N'91.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-10-16 00:00:00.0000000', N'85.91', N'91.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-10-23 00:00:00.0000000', N'85.74', N'91.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-10-30 00:00:00.0000000', N'85.60', N'91.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-11-06 00:00:00.0000000', N'85.54', N'91.12')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-11-13 00:00:00.0000000', N'85.49', N'91.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-11-20 00:00:00.0000000', N'85.45', N'91.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-11-27 00:00:00.0000000', N'85.47', N'91.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-12-04 00:00:00.0000000', N'85.46', N'91.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-12-11 00:00:00.0000000', N'87.44', N'92.96')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-12-18 00:00:00.0000000', N'87.70', N'93.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2006-12-25 00:00:00.0000000', N'87.90', N'93.41')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-01-01 00:00:00.0000000', N'87.85', N'93.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-01-08 00:00:00.0000000', N'87.66', N'93.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-01-15 00:00:00.0000000', N'87.10', N'91.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-01-22 00:00:00.0000000', N'86.28', N'90.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-01-29 00:00:00.0000000', N'85.66', N'89.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-02-05 00:00:00.0000000', N'85.62', N'89.63')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-02-12 00:00:00.0000000', N'86.12', N'90.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-02-19 00:00:00.0000000', N'86.60', N'90.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-02-26 00:00:00.0000000', N'87.07', N'91.02')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-03-05 00:00:00.0000000', N'87.74', N'91.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-03-12 00:00:00.0000000', N'88.48', N'92.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-03-19 00:00:00.0000000', N'88.93', N'92.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-03-26 00:00:00.0000000', N'89.32', N'92.91')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-04-02 00:00:00.0000000', N'90.47', N'93.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-04-10 00:00:00.0000000', N'91.18', N'94.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-04-16 00:00:00.0000000', N'91.99', N'94.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-04-23 00:00:00.0000000', N'92.93', N'95.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-04-30 00:00:00.0000000', N'93.45', N'95.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-05-07 00:00:00.0000000', N'94.43', N'96.12')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-05-14 00:00:00.0000000', N'95.07', N'96.47')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-05-21 00:00:00.0000000', N'95.71', N'96.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-05-28 00:00:00.0000000', N'96.16', N'96.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-06-04 00:00:00.0000000', N'96.51', N'97.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-06-11 00:00:00.0000000', N'96.61', N'97.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-06-18 00:00:00.0000000', N'96.56', N'97.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-06-25 00:00:00.0000000', N'96.54', N'97.12')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-07-02 00:00:00.0000000', N'96.36', N'96.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-07-09 00:00:00.0000000', N'96.20', N'96.78')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-07-16 00:00:00.0000000', N'96.21', N'96.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-07-23 00:00:00.0000000', N'96.23', N'96.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-07-30 00:00:00.0000000', N'96.20', N'96.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-08-06 00:00:00.0000000', N'96.15', N'96.72')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-08-13 00:00:00.0000000', N'96.00', N'96.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-08-20 00:00:00.0000000', N'95.31', N'96.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-08-27 00:00:00.0000000', N'95.00', N'96.37')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-09-03 00:00:00.0000000', N'94.80', N'96.37')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-09-10 00:00:00.0000000', N'94.63', N'96.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-09-17 00:00:00.0000000', N'94.65', N'96.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-09-24 00:00:00.0000000', N'94.91', N'96.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-10-01 00:00:00.0000000', N'96.39', N'98.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-10-08 00:00:00.0000000', N'97.14', N'99.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-10-15 00:00:00.0000000', N'97.19', N'99.18')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-10-22 00:00:00.0000000', N'97.81', N'99.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-10-29 00:00:00.0000000', N'98.26', N'100.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-11-05 00:00:00.0000000', N'99.36', N'102.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-11-12 00:00:00.0000000', N'100.74', N'104.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-11-19 00:00:00.0000000', N'101.47', N'105.28')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-11-26 00:00:00.0000000', N'102.13', N'106.25')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-12-03 00:00:00.0000000', N'102.58', N'107.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-12-10 00:00:00.0000000', N'102.67', N'107.47')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-12-17 00:00:00.0000000', N'102.60', N'107.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-12-24 00:00:00.0000000', N'102.53', N'107.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2007-12-31 00:00:00.0000000', N'102.66', N'107.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-01-07 00:00:00.0000000', N'103.37', N'108.29')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-01-14 00:00:00.0000000', N'103.82', N'108.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-01-21 00:00:00.0000000', N'104.22', N'109.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-01-28 00:00:00.0000000', N'104.22', N'109.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-02-04 00:00:00.0000000', N'104.03', N'108.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-02-11 00:00:00.0000000', N'103.67', N'108.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-02-18 00:00:00.0000000', N'103.70', N'108.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-02-25 00:00:00.0000000', N'104.65', N'110.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-03-03 00:00:00.0000000', N'105.24', N'110.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-03-10 00:00:00.0000000', N'105.96', N'112.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-03-17 00:00:00.0000000', N'106.41', N'113.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-03-24 00:00:00.0000000', N'106.90', N'114.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-03-31 00:00:00.0000000', N'107.10', N'114.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-04-07 00:00:00.0000000', N'107.24', N'115.47')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-04-14 00:00:00.0000000', N'107.61', N'116.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-04-21 00:00:00.0000000', N'108.57', N'118.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-04-28 00:00:00.0000000', N'109.50', N'119.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-05-05 00:00:00.0000000', N'110.30', N'120.37')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-05-12 00:00:00.0000000', N'111.04', N'121.49')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-05-19 00:00:00.0000000', N'112.96', N'124.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-05-26 00:00:00.0000000', N'114.79', N'127.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-06-02 00:00:00.0000000', N'116.03', N'128.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-06-09 00:00:00.0000000', N'116.86', N'129.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-06-16 00:00:00.0000000', N'117.69', N'130.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-06-23 00:00:00.0000000', N'118.44', N'131.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-06-30 00:00:00.0000000', N'118.84', N'132.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-07-07 00:00:00.0000000', N'119.28', N'132.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-07-14 00:00:00.0000000', N'119.44', N'132.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-07-21 00:00:00.0000000', N'119.40', N'132.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-07-28 00:00:00.0000000', N'116.91', N'130.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-08-04 00:00:00.0000000', N'115.06', N'128.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-08-11 00:00:00.0000000', N'113.92', N'126.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-08-18 00:00:00.0000000', N'112.22', N'124.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-08-25 00:00:00.0000000', N'112.02', N'123.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-09-01 00:00:00.0000000', N'112.20', N'123.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-09-08 00:00:00.0000000', N'112.55', N'124.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-09-15 00:00:00.0000000', N'112.51', N'124.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-09-22 00:00:00.0000000', N'110.81', N'122.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-09-29 00:00:00.0000000', N'109.85', N'121.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-10-06 00:00:00.0000000', N'109.45', N'121.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-10-13 00:00:00.0000000', N'107.04', N'118.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-10-20 00:00:00.0000000', N'102.66', N'114.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-10-27 00:00:00.0000000', N'98.62', N'111.01')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-11-03 00:00:00.0000000', N'97.40', N'109.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-11-10 00:00:00.0000000', N'95.89', N'109.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-11-17 00:00:00.0000000', N'94.83', N'108.73')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-11-24 00:00:00.0000000', N'92.79', N'107.78')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-12-01 00:00:00.0000000', N'91.47', N'106.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-12-08 00:00:00.0000000', N'90.16', N'104.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-12-15 00:00:00.0000000', N'89.07', N'101.24')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-12-22 00:00:00.0000000', N'88.01', N'99.94')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2008-12-29 00:00:00.0000000', N'87.34', N'99.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-01-05 00:00:00.0000000', N'85.42', N'97.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-01-12 00:00:00.0000000', N'86.02', N'98.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-01-19 00:00:00.0000000', N'86.19', N'98.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-01-26 00:00:00.0000000', N'87.42', N'99.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-02-02 00:00:00.0000000', N'88.16', N'99.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-02-09 00:00:00.0000000', N'89.28', N'100.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-02-16 00:00:00.0000000', N'90.12', N'100.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-02-23 00:00:00.0000000', N'90.33', N'100.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-03-02 00:00:00.0000000', N'90.28', N'100.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-03-09 00:00:00.0000000', N'90.15', N'100.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-03-16 00:00:00.0000000', N'90.16', N'99.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-03-23 00:00:00.0000000', N'90.16', N'99.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-03-30 00:00:00.0000000', N'91.35', N'99.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-04-06 00:00:00.0000000', N'93.72', N'102.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-04-13 00:00:00.0000000', N'94.11', N'102.44')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-04-20 00:00:00.0000000', N'94.62', N'102.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-04-27 00:00:00.0000000', N'95.13', N'102.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-05-04 00:00:00.0000000', N'95.60', N'102.80')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-05-11 00:00:00.0000000', N'96.59', N'103.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-05-18 00:00:00.0000000', N'97.54', N'103.37')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-05-25 00:00:00.0000000', N'98.90', N'103.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-06-01 00:00:00.0000000', N'99.39', N'103.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-06-08 00:00:00.0000000', N'100.59', N'103.78')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-06-15 00:00:00.0000000', N'101.98', N'104.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-06-22 00:00:00.0000000', N'102.81', N'104.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-06-29 00:00:00.0000000', N'103.30', N'105.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-07-06 00:00:00.0000000', N'103.57', N'105.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-07-13 00:00:00.0000000', N'102.78', N'104.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-07-20 00:00:00.0000000', N'102.22', N'102.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-07-27 00:00:00.0000000', N'102.17', N'102.91')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-08-03 00:00:00.0000000', N'102.36', N'103.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-08-10 00:00:00.0000000', N'103.01', N'103.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-08-17 00:00:00.0000000', N'103.96', N'104.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-08-24 00:00:00.0000000', N'104.70', N'105.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-08-31 00:00:00.0000000', N'105.11', N'105.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-09-07 00:00:00.0000000', N'106.85', N'107.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-09-14 00:00:00.0000000', N'106.43', N'107.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-09-21 00:00:00.0000000', N'105.96', N'106.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-09-28 00:00:00.0000000', N'105.44', N'106.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-10-05 00:00:00.0000000', N'104.87', N'105.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-10-12 00:00:00.0000000', N'104.71', N'105.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-10-19 00:00:00.0000000', N'105.08', N'106.28')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-10-26 00:00:00.0000000', N'106.76', N'107.78')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-11-02 00:00:00.0000000', N'107.43', N'108.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-11-09 00:00:00.0000000', N'108.10', N'109.35')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-11-16 00:00:00.0000000', N'108.48', N'109.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-11-23 00:00:00.0000000', N'108.73', N'109.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-11-30 00:00:00.0000000', N'108.79', N'109.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-12-07 00:00:00.0000000', N'108.64', N'109.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-12-14 00:00:00.0000000', N'108.50', N'109.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-12-21 00:00:00.0000000', N'107.47', N'109.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2009-12-28 00:00:00.0000000', N'107.44', N'109.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-01-04 00:00:00.0000000', N'109.34', N'111.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-01-11 00:00:00.0000000', N'110.72', N'112.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-01-18 00:00:00.0000000', N'111.60', N'113.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-01-25 00:00:00.0000000', N'111.87', N'113.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-02-01 00:00:00.0000000', N'111.91', N'113.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-02-08 00:00:00.0000000', N'111.95', N'113.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-02-15 00:00:00.0000000', N'111.89', N'113.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-02-22 00:00:00.0000000', N'111.56', N'112.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-03-01 00:00:00.0000000', N'112.42', N'113.41')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-03-08 00:00:00.0000000', N'113.71', N'114.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-03-15 00:00:00.0000000', N'115.46', N'116.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-03-22 00:00:00.0000000', N'116.59', N'117.28')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-03-29 00:00:00.0000000', N'117.28', N'118.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-04-05 00:00:00.0000000', N'119.29', N'120.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-04-12 00:00:00.0000000', N'119.94', N'121.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-04-19 00:00:00.0000000', N'120.55', N'121.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-04-26 00:00:00.0000000', N'120.99', N'122.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-05-03 00:00:00.0000000', N'121.18', N'122.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-05-10 00:00:00.0000000', N'121.31', N'122.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-05-17 00:00:00.0000000', N'121.30', N'122.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-05-24 00:00:00.0000000', N'119.93', N'121.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-05-31 00:00:00.0000000', N'118.54', N'120.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-06-07 00:00:00.0000000', N'118.20', N'120.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-06-14 00:00:00.0000000', N'117.87', N'120.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-06-21 00:00:00.0000000', N'117.80', N'120.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-06-28 00:00:00.0000000', N'117.88', N'120.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-07-05 00:00:00.0000000', N'117.91', N'120.44')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-07-12 00:00:00.0000000', N'117.39', N'119.78')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-07-19 00:00:00.0000000', N'116.85', N'119.24')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-07-26 00:00:00.0000000', N'116.61', N'119.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-08-02 00:00:00.0000000', N'116.51', N'119.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-08-09 00:00:00.0000000', N'116.35', N'118.94')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-08-16 00:00:00.0000000', N'116.34', N'118.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-08-23 00:00:00.0000000', N'115.64', N'117.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-08-30 00:00:00.0000000', N'114.98', N'117.37')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-09-06 00:00:00.0000000', N'114.59', N'117.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-09-13 00:00:00.0000000', N'114.66', N'117.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-09-20 00:00:00.0000000', N'115.06', N'117.72')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-09-27 00:00:00.0000000', N'115.39', N'118.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-10-04 00:00:00.0000000', N'116.01', N'118.97')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-10-11 00:00:00.0000000', N'116.78', N'119.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-10-18 00:00:00.0000000', N'117.28', N'120.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-10-25 00:00:00.0000000', N'117.74', N'121.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-11-01 00:00:00.0000000', N'118.18', N'121.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-11-08 00:00:00.0000000', N'118.67', N'122.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-11-15 00:00:00.0000000', N'118.80', N'122.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-11-22 00:00:00.0000000', N'118.99', N'122.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-11-29 00:00:00.0000000', N'119.21', N'123.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-12-06 00:00:00.0000000', N'120.54', N'124.62')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-12-13 00:00:00.0000000', N'121.68', N'125.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-12-20 00:00:00.0000000', N'122.31', N'126.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2010-12-27 00:00:00.0000000', N'123.44', N'127.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-01-03 00:00:00.0000000', N'124.85', N'129.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-01-10 00:00:00.0000000', N'127.40', N'131.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-01-17 00:00:00.0000000', N'127.87', N'132.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-01-24 00:00:00.0000000', N'128.35', N'133.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-01-31 00:00:00.0000000', N'128.55', N'133.25')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-02-07 00:00:00.0000000', N'128.64', N'133.47')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-02-14 00:00:00.0000000', N'128.73', N'133.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-02-21 00:00:00.0000000', N'128.92', N'134.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-02-28 00:00:00.0000000', N'129.72', N'135.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-03-07 00:00:00.0000000', N'131.28', N'136.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-03-14 00:00:00.0000000', N'132.18', N'138.25')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-03-21 00:00:00.0000000', N'133.11', N'139.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-03-28 00:00:00.0000000', N'132.44', N'139.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-04-04 00:00:00.0000000', N'132.81', N'139.46')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-04-11 00:00:00.0000000', N'133.68', N'140.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-04-18 00:00:00.0000000', N'135.06', N'141.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-04-25 00:00:00.0000000', N'135.62', N'142.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-05-02 00:00:00.0000000', N'136.29', N'142.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-05-09 00:00:00.0000000', N'137.05', N'143.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-05-16 00:00:00.0000000', N'136.40', N'141.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-05-23 00:00:00.0000000', N'136.11', N'140.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-05-30 00:00:00.0000000', N'135.57', N'139.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-06-06 00:00:00.0000000', N'135.62', N'139.58')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-06-13 00:00:00.0000000', N'135.86', N'139.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-06-20 00:00:00.0000000', N'136.03', N'140.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-06-27 00:00:00.0000000', N'134.86', N'138.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-07-04 00:00:00.0000000', N'133.43', N'137.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-07-11 00:00:00.0000000', N'134.18', N'138.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-07-18 00:00:00.0000000', N'134.97', N'139.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-07-25 00:00:00.0000000', N'135.66', N'139.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-08-01 00:00:00.0000000', N'136.07', N'140.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-08-08 00:00:00.0000000', N'136.46', N'140.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-08-15 00:00:00.0000000', N'135.95', N'140.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-08-22 00:00:00.0000000', N'134.56', N'139.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-08-29 00:00:00.0000000', N'134.32', N'138.72')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-09-05 00:00:00.0000000', N'134.62', N'138.96')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-09-12 00:00:00.0000000', N'135.00', N'139.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-09-19 00:00:00.0000000', N'135.40', N'139.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-09-26 00:00:00.0000000', N'135.65', N'140.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-10-03 00:00:00.0000000', N'135.02', N'139.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-10-10 00:00:00.0000000', N'134.47', N'139.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-10-17 00:00:00.0000000', N'134.49', N'139.73')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-10-24 00:00:00.0000000', N'134.66', N'140.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-10-31 00:00:00.0000000', N'134.73', N'140.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-11-07 00:00:00.0000000', N'134.41', N'140.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-11-14 00:00:00.0000000', N'133.68', N'140.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-11-21 00:00:00.0000000', N'133.38', N'141.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-11-28 00:00:00.0000000', N'133.17', N'141.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-12-05 00:00:00.0000000', N'132.78', N'140.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-12-12 00:00:00.0000000', N'132.53', N'140.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-12-19 00:00:00.0000000', N'132.49', N'140.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2011-12-26 00:00:00.0000000', N'132.41', N'140.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-01-02 00:00:00.0000000', N'132.40', N'140.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-01-09 00:00:00.0000000', N'132.68', N'141.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-01-16 00:00:00.0000000', N'133.29', N'141.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-01-23 00:00:00.0000000', N'133.72', N'142.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-01-30 00:00:00.0000000', N'134.10', N'142.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-02-06 00:00:00.0000000', N'134.25', N'142.24')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-02-13 00:00:00.0000000', N'134.90', N'142.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-02-20 00:00:00.0000000', N'135.21', N'143.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-02-27 00:00:00.0000000', N'136.21', N'143.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-03-05 00:00:00.0000000', N'137.30', N'144.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-03-12 00:00:00.0000000', N'137.90', N'145.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-03-19 00:00:00.0000000', N'138.96', N'146.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-03-26 00:00:00.0000000', N'139.48', N'146.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-04-02 00:00:00.0000000', N'140.99', N'147.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-04-09 00:00:00.0000000', N'141.97', N'148.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-04-16 00:00:00.0000000', N'142.17', N'148.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-04-23 00:00:00.0000000', N'141.76', N'147.96')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-04-30 00:00:00.0000000', N'141.00', N'147.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-05-07 00:00:00.0000000', N'140.14', N'146.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-05-14 00:00:00.0000000', N'138.29', N'144.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-05-21 00:00:00.0000000', N'135.77', N'141.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-05-28 00:00:00.0000000', N'134.37', N'140.49')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-06-04 00:00:00.0000000', N'134.06', N'139.96')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-06-11 00:00:00.0000000', N'133.67', N'139.58')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-06-18 00:00:00.0000000', N'131.99', N'137.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-06-25 00:00:00.0000000', N'131.55', N'137.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-07-02 00:00:00.0000000', N'130.50', N'135.91')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-07-09 00:00:00.0000000', N'131.06', N'136.44')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-07-16 00:00:00.0000000', N'131.49', N'136.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-07-23 00:00:00.0000000', N'132.21', N'137.72')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-07-30 00:00:00.0000000', N'132.78', N'138.25')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-08-06 00:00:00.0000000', N'133.39', N'138.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-08-13 00:00:00.0000000', N'134.27', N'139.46')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-08-20 00:00:00.0000000', N'135.72', N'140.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-08-27 00:00:00.0000000', N'137.10', N'142.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-09-03 00:00:00.0000000', N'138.03', N'142.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-09-10 00:00:00.0000000', N'138.91', N'143.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-09-17 00:00:00.0000000', N'139.42', N'144.18')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-09-24 00:00:00.0000000', N'139.54', N'144.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-10-01 00:00:00.0000000', N'138.43', N'143.28')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-10-08 00:00:00.0000000', N'138.24', N'143.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-10-15 00:00:00.0000000', N'138.35', N'143.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-10-22 00:00:00.0000000', N'138.29', N'143.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-10-29 00:00:00.0000000', N'136.98', N'143.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-11-05 00:00:00.0000000', N'136.43', N'142.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-11-12 00:00:00.0000000', N'135.09', N'141.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-11-19 00:00:00.0000000', N'134.56', N'141.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-11-26 00:00:00.0000000', N'134.38', N'141.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-12-03 00:00:00.0000000', N'133.05', N'140.91')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-12-10 00:00:00.0000000', N'132.55', N'140.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-12-17 00:00:00.0000000', N'131.98', N'140.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-12-24 00:00:00.0000000', N'131.95', N'139.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2012-12-31 00:00:00.0000000', N'131.92', N'139.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-01-07 00:00:00.0000000', N'131.86', N'139.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-01-14 00:00:00.0000000', N'132.00', N'139.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-01-21 00:00:00.0000000', N'132.21', N'139.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-01-28 00:00:00.0000000', N'132.95', N'140.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-02-04 00:00:00.0000000', N'134.38', N'141.91')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-02-11 00:00:00.0000000', N'135.56', N'143.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-02-18 00:00:00.0000000', N'136.86', N'144.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-02-25 00:00:00.0000000', N'138.50', N'145.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-03-04 00:00:00.0000000', N'139.47', N'146.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-03-11 00:00:00.0000000', N'140.00', N'146.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-03-18 00:00:00.0000000', N'137.58', N'144.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-03-25 00:00:00.0000000', N'137.09', N'144.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-04-01 00:00:00.0000000', N'137.30', N'143.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-04-08 00:00:00.0000000', N'137.31', N'143.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-04-15 00:00:00.0000000', N'137.11', N'141.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-04-22 00:00:00.0000000', N'135.68', N'140.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-04-29 00:00:00.0000000', N'134.66', N'139.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-05-06 00:00:00.0000000', N'133.42', N'138.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-05-13 00:00:00.0000000', N'133.12', N'138.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-05-20 00:00:00.0000000', N'133.17', N'138.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-05-27 00:00:00.0000000', N'133.64', N'138.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-06-03 00:00:00.0000000', N'134.04', N'139.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-06-10 00:00:00.0000000', N'134.30', N'139.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-06-17 00:00:00.0000000', N'134.46', N'139.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-06-24 00:00:00.0000000', N'134.52', N'139.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-07-01 00:00:00.0000000', N'133.44', N'138.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-07-08 00:00:00.0000000', N'133.77', N'138.73')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-07-15 00:00:00.0000000', N'134.95', N'139.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-07-22 00:00:00.0000000', N'136.04', N'140.72')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-07-29 00:00:00.0000000', N'136.87', N'141.44')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-08-05 00:00:00.0000000', N'137.02', N'141.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-08-12 00:00:00.0000000', N'137.13', N'141.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-08-19 00:00:00.0000000', N'137.00', N'141.73')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-08-28 00:00:00.0000000', N'136.83', N'141.78')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-09-02 00:00:00.0000000', N'137.14', N'142.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-09-09 00:00:00.0000000', N'137.60', N'142.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-09-16 00:00:00.0000000', N'137.47', N'142.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-09-23 00:00:00.0000000', N'136.95', N'142.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-09-30 00:00:00.0000000', N'133.40', N'140.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-10-07 00:00:00.0000000', N'131.62', N'138.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-10-14 00:00:00.0000000', N'131.67', N'139.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-10-21 00:00:00.0000000', N'131.53', N'138.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-10-28 00:00:00.0000000', N'131.42', N'138.88')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-11-04 00:00:00.0000000', N'129.92', N'137.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-11-11 00:00:00.0000000', N'129.71', N'137.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-11-18 00:00:00.0000000', N'129.89', N'137.47')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-11-25 00:00:00.0000000', N'130.03', N'137.72')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-12-02 00:00:00.0000000', N'130.25', N'137.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-12-09 00:00:00.0000000', N'130.76', N'138.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-12-16 00:00:00.0000000', N'130.96', N'138.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-12-23 00:00:00.0000000', N'130.05', N'138.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2013-12-30 00:00:00.0000000', N'130.03', N'137.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-01-06 00:00:00.0000000', N'130.26', N'138.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-01-13 00:00:00.0000000', N'130.36', N'138.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-01-20 00:00:00.0000000', N'129.37', N'137.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-01-27 00:00:00.0000000', N'129.02', N'136.94')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-02-03 00:00:00.0000000', N'128.85', N'136.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-02-10 00:00:00.0000000', N'128.81', N'136.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-02-17 00:00:00.0000000', N'129.16', N'136.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-02-24 00:00:00.0000000', N'129.20', N'136.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-03-03 00:00:00.0000000', N'129.36', N'137.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-03-10 00:00:00.0000000', N'129.39', N'137.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-03-17 00:00:00.0000000', N'128.76', N'136.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-03-24 00:00:00.0000000', N'128.57', N'136.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-03-31 00:00:00.0000000', N'128.76', N'135.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-04-07 00:00:00.0000000', N'128.71', N'136.01')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-04-14 00:00:00.0000000', N'128.89', N'136.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-04-21 00:00:00.0000000', N'129.11', N'136.12')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-04-28 00:00:00.0000000', N'129.09', N'135.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-05-05 00:00:00.0000000', N'129.27', N'136.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-05-12 00:00:00.0000000', N'129.50', N'136.37')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-05-19 00:00:00.0000000', N'129.42', N'136.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-05-26 00:00:00.0000000', N'129.51', N'136.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-06-02 00:00:00.0000000', N'129.63', N'136.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-06-09 00:00:00.0000000', N'129.69', N'136.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-06-16 00:00:00.0000000', N'129.88', N'135.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-06-23 00:00:00.0000000', N'130.14', N'135.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-06-30 00:00:00.0000000', N'130.69', N'136.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-07-07 00:00:00.0000000', N'131.10', N'136.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-07-14 00:00:00.0000000', N'131.11', N'136.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-07-21 00:00:00.0000000', N'131.04', N'135.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-07-28 00:00:00.0000000', N'130.83', N'135.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-08-04 00:00:00.0000000', N'129.63', N'134.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-08-11 00:00:00.0000000', N'129.41', N'133.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-08-18 00:00:00.0000000', N'129.29', N'133.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-08-25 00:00:00.0000000', N'128.34', N'133.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-09-01 00:00:00.0000000', N'128.01', N'132.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-09-08 00:00:00.0000000', N'128.34', N'133.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-09-15 00:00:00.0000000', N'128.43', N'133.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-09-22 00:00:00.0000000', N'128.62', N'133.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-09-29 00:00:00.0000000', N'128.59', N'133.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-10-06 00:00:00.0000000', N'126.78', N'131.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-10-13 00:00:00.0000000', N'126.50', N'131.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-10-20 00:00:00.0000000', N'125.40', N'130.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-10-27 00:00:00.0000000', N'125.11', N'129.72')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-11-03 00:00:00.0000000', N'123.94', N'128.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-11-10 00:00:00.0000000', N'122.94', N'127.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-11-17 00:00:00.0000000', N'122.50', N'127.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-11-24 00:00:00.0000000', N'122.29', N'127.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-12-01 00:00:00.0000000', N'121.18', N'126.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-12-08 00:00:00.0000000', N'119.83', N'124.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-12-15 00:00:00.0000000', N'116.30', N'122.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-12-22 00:00:00.0000000', N'113.66', N'120.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2014-12-29 00:00:00.0000000', N'113.16', N'120.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-01-05 00:00:00.0000000', N'111.06', N'117.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-01-12 00:00:00.0000000', N'108.87', N'116.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-01-19 00:00:00.0000000', N'106.83', N'114.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-01-26 00:00:00.0000000', N'106.32', N'113.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-02-02 00:00:00.0000000', N'106.04', N'113.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-02-09 00:00:00.0000000', N'106.35', N'113.91')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-02-16 00:00:00.0000000', N'107.26', N'114.73')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-02-23 00:00:00.0000000', N'108.34', N'115.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-03-02 00:00:00.0000000', N'109.20', N'116.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-03-09 00:00:00.0000000', N'110.07', N'117.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-03-16 00:00:00.0000000', N'111.04', N'118.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-03-23 00:00:00.0000000', N'111.65', N'118.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-03-30 00:00:00.0000000', N'112.06', N'118.97')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-04-06 00:00:00.0000000', N'112.37', N'119.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-04-13 00:00:00.0000000', N'112.52', N'119.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-04-20 00:00:00.0000000', N'112.87', N'119.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-04-27 00:00:00.0000000', N'113.55', N'119.58')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-05-04 00:00:00.0000000', N'114.27', N'120.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-05-11 00:00:00.0000000', N'115.10', N'120.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-05-18 00:00:00.0000000', N'115.74', N'121.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-05-25 00:00:00.0000000', N'116.02', N'121.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-06-01 00:00:00.0000000', N'116.13', N'121.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-06-08 00:00:00.0000000', N'116.26', N'121.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-06-15 00:00:00.0000000', N'116.39', N'121.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-06-22 00:00:00.0000000', N'116.60', N'121.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-06-29 00:00:00.0000000', N'116.55', N'120.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-07-06 00:00:00.0000000', N'116.34', N'120.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-07-13 00:00:00.0000000', N'116.41', N'118.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-07-20 00:00:00.0000000', N'116.79', N'118.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-07-27 00:00:00.0000000', N'116.44', N'116.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-08-03 00:00:00.0000000', N'116.12', N'115.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-08-10 00:00:00.0000000', N'115.48', N'114.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-08-17 00:00:00.0000000', N'114.58', N'112.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-08-24 00:00:00.0000000', N'113.23', N'111.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-08-31 00:00:00.0000000', N'111.21', N'109.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-09-07 00:00:00.0000000', N'110.90', N'109.78')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-09-14 00:00:00.0000000', N'110.60', N'109.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-09-21 00:00:00.0000000', N'110.61', N'110.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-09-28 00:00:00.0000000', N'109.47', N'110.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-10-05 00:00:00.0000000', N'108.94', N'110.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-10-12 00:00:00.0000000', N'108.97', N'110.78')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-10-19 00:00:00.0000000', N'109.01', N'111.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-10-26 00:00:00.0000000', N'108.04', N'110.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-11-02 00:00:00.0000000', N'107.21', N'110.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-11-09 00:00:00.0000000', N'107.14', N'110.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-11-16 00:00:00.0000000', N'107.36', N'110.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-11-23 00:00:00.0000000', N'107.29', N'110.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-11-30 00:00:00.0000000', N'106.97', N'110.01')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-12-07 00:00:00.0000000', N'106.75', N'109.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-12-14 00:00:00.0000000', N'104.00', N'108.07')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-12-21 00:00:00.0000000', N'102.33', N'107.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2015-12-28 00:00:00.0000000', N'102.11', N'106.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-01-04 00:00:00.0000000', N'102.00', N'106.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-01-11 00:00:00.0000000', N'101.89', N'103.41')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-01-18 00:00:00.0000000', N'101.80', N'102.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-01-25 00:00:00.0000000', N'101.42', N'101.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-02-01 00:00:00.0000000', N'101.36', N'100.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-02-08 00:00:00.0000000', N'101.51', N'101.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-02-15 00:00:00.0000000', N'101.45', N'101.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-02-22 00:00:00.0000000', N'101.39', N'101.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-02-29 00:00:00.0000000', N'101.42', N'101.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-03-07 00:00:00.0000000', N'101.46', N'101.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-03-14 00:00:00.0000000', N'101.71', N'102.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-03-21 00:00:00.0000000', N'102.58', N'103.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-03-28 00:00:00.0000000', N'103.40', N'104.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-04-04 00:00:00.0000000', N'104.51', N'105.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-04-11 00:00:00.0000000', N'105.39', N'105.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-04-18 00:00:00.0000000', N'106.41', N'106.97')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-04-25 00:00:00.0000000', N'107.14', N'107.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-05-02 00:00:00.0000000', N'107.82', N'108.58')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-05-09 00:00:00.0000000', N'108.19', N'109.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-05-16 00:00:00.0000000', N'108.53', N'109.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-05-23 00:00:00.0000000', N'109.12', N'109.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-05-30 00:00:00.0000000', N'109.79', N'110.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-06-06 00:00:00.0000000', N'110.40', N'111.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-06-13 00:00:00.0000000', N'111.03', N'111.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-06-20 00:00:00.0000000', N'111.22', N'112.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-06-27 00:00:00.0000000', N'111.44', N'112.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-07-04 00:00:00.0000000', N'111.65', N'112.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-07-11 00:00:00.0000000', N'111.89', N'113.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-07-18 00:00:00.0000000', N'111.92', N'113.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-07-25 00:00:00.0000000', N'111.69', N'112.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-08-01 00:00:00.0000000', N'111.05', N'112.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-08-08 00:00:00.0000000', N'109.75', N'111.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-08-15 00:00:00.0000000', N'109.28', N'111.02')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-08-22 00:00:00.0000000', N'109.63', N'111.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-08-29 00:00:00.0000000', N'110.43', N'112.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-09-05 00:00:00.0000000', N'110.97', N'113.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-09-12 00:00:00.0000000', N'111.31', N'113.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-09-19 00:00:00.0000000', N'111.29', N'113.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-09-26 00:00:00.0000000', N'111.36', N'113.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-10-03 00:00:00.0000000', N'111.65', N'113.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-10-10 00:00:00.0000000', N'112.35', N'114.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-10-17 00:00:00.0000000', N'113.72', N'116.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-10-24 00:00:00.0000000', N'115.20', N'117.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-10-31 00:00:00.0000000', N'116.02', N'118.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-11-07 00:00:00.0000000', N'116.56', N'119.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-11-14 00:00:00.0000000', N'116.50', N'118.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-11-21 00:00:00.0000000', N'114.71', N'117.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-11-28 00:00:00.0000000', N'113.72', N'116.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-12-05 00:00:00.0000000', N'113.66', N'116.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-12-12 00:00:00.0000000', N'114.23', N'117.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-12-19 00:00:00.0000000', N'115.00', N'118.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2016-12-26 00:00:00.0000000', N'115.45', N'119.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-01-02 00:00:00.0000000', N'117.00', N'120.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-01-09 00:00:00.0000000', N'117.98', N'121.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-01-16 00:00:00.0000000', N'118.63', N'122.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-01-23 00:00:00.0000000', N'119.43', N'122.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-01-30 00:00:00.0000000', N'120.01', N'123.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-02-06 00:00:00.0000000', N'120.18', N'123.25')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-02-13 00:00:00.0000000', N'120.15', N'123.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-02-20 00:00:00.0000000', N'120.20', N'123.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-02-27 00:00:00.0000000', N'120.12', N'123.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-03-06 00:00:00.0000000', N'120.02', N'122.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-03-13 00:00:00.0000000', N'119.80', N'122.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-03-20 00:00:00.0000000', N'118.95', N'121.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-03-27 00:00:00.0000000', N'118.03', N'121.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-04-03 00:00:00.0000000', N'116.93', N'119.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-04-10 00:00:00.0000000', N'117.02', N'119.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-04-17 00:00:00.0000000', N'117.54', N'120.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-04-24 00:00:00.0000000', N'118.15', N'120.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-05-01 00:00:00.0000000', N'118.08', N'120.78')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-05-08 00:00:00.0000000', N'117.06', N'119.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-05-15 00:00:00.0000000', N'115.60', N'117.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-05-22 00:00:00.0000000', N'115.67', N'117.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-05-29 00:00:00.0000000', N'115.79', N'117.88')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-06-05 00:00:00.0000000', N'115.82', N'117.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-06-12 00:00:00.0000000', N'115.69', N'117.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-06-19 00:00:00.0000000', N'115.12', N'117.18')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-06-26 00:00:00.0000000', N'114.43', N'116.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-07-03 00:00:00.0000000', N'113.74', N'115.63')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-07-10 00:00:00.0000000', N'113.58', N'115.29')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-07-17 00:00:00.0000000', N'113.89', N'115.58')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-07-24 00:00:00.0000000', N'113.99', N'115.73')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-07-31 00:00:00.0000000', N'114.16', N'115.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-08-07 00:00:00.0000000', N'114.78', N'116.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-08-14 00:00:00.0000000', N'115.53', N'117.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-08-21 00:00:00.0000000', N'116.04', N'118.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-08-28 00:00:00.0000000', N'116.40', N'118.24')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-09-04 00:00:00.0000000', N'116.95', N'118.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-09-11 00:00:00.0000000', N'118.14', N'119.94')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-09-18 00:00:00.0000000', N'118.85', N'120.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-09-25 00:00:00.0000000', N'118.87', N'120.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-10-02 00:00:00.0000000', N'118.13', N'120.37')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-10-09 00:00:00.0000000', N'117.16', N'120.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-10-16 00:00:00.0000000', N'117.01', N'120.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-10-23 00:00:00.0000000', N'117.04', N'120.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-10-30 00:00:00.0000000', N'117.06', N'120.63')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-11-06 00:00:00.0000000', N'117.57', N'121.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-11-13 00:00:00.0000000', N'118.91', N'122.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-11-20 00:00:00.0000000', N'119.67', N'123.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-11-27 00:00:00.0000000', N'120.13', N'123.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-12-04 00:00:00.0000000', N'119.75', N'123.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-12-11 00:00:00.0000000', N'119.91', N'123.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-12-18 00:00:00.0000000', N'119.98', N'123.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2017-12-25 00:00:00.0000000', N'120.00', N'123.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-01-01 00:00:00.0000000', N'120.19', N'123.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-01-08 00:00:00.0000000', N'120.52', N'123.97')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-01-15 00:00:00.0000000', N'120.96', N'124.58')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-01-22 00:00:00.0000000', N'121.50', N'125.07')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-01-29 00:00:00.0000000', N'121.69', N'125.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-02-05 00:00:00.0000000', N'121.73', N'125.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-02-12 00:00:00.0000000', N'121.58', N'125.02')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-02-19 00:00:00.0000000', N'120.52', N'124.18')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-02-26 00:00:00.0000000', N'119.55', N'123.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-03-05 00:00:00.0000000', N'119.29', N'122.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-03-12 00:00:00.0000000', N'119.11', N'122.96')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-03-19 00:00:00.0000000', N'119.17', N'122.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-03-26 00:00:00.0000000', N'119.23', N'122.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-04-02 00:00:00.0000000', N'119.43', N'123.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-04-09 00:00:00.0000000', N'119.96', N'123.58')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-04-16 00:00:00.0000000', N'120.56', N'124.29')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-04-23 00:00:00.0000000', N'121.44', N'125.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-04-30 00:00:00.0000000', N'122.22', N'126.01')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-05-07 00:00:00.0000000', N'123.27', N'126.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-05-14 00:00:00.0000000', N'124.32', N'128.28')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-05-21 00:00:00.0000000', N'125.93', N'130.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-05-28 00:00:00.0000000', N'127.58', N'131.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-06-04 00:00:00.0000000', N'128.43', N'132.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-06-11 00:00:00.0000000', N'128.61', N'132.62')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-06-18 00:00:00.0000000', N'127.92', N'131.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-06-25 00:00:00.0000000', N'127.18', N'131.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-07-02 00:00:00.0000000', N'126.54', N'130.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-07-09 00:00:00.0000000', N'126.97', N'131.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-07-16 00:00:00.0000000', N'127.47', N'131.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-07-23 00:00:00.0000000', N'127.50', N'131.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-07-30 00:00:00.0000000', N'127.54', N'131.94')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-08-06 00:00:00.0000000', N'128.02', N'132.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-08-13 00:00:00.0000000', N'128.39', N'132.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-08-20 00:00:00.0000000', N'128.79', N'132.97')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-08-27 00:00:00.0000000', N'129.18', N'133.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-09-03 00:00:00.0000000', N'129.76', N'133.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-09-10 00:00:00.0000000', N'130.24', N'134.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-09-17 00:00:00.0000000', N'130.59', N'134.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-09-24 00:00:00.0000000', N'130.59', N'134.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-10-01 00:00:00.0000000', N'129.98', N'134.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-10-08 00:00:00.0000000', N'130.15', N'135.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-10-15 00:00:00.0000000', N'130.81', N'136.63')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-10-22 00:00:00.0000000', N'130.98', N'136.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-10-29 00:00:00.0000000', N'130.64', N'136.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-11-05 00:00:00.0000000', N'130.11', N'137.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-11-12 00:00:00.0000000', N'128.94', N'137.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-11-19 00:00:00.0000000', N'127.40', N'136.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-11-26 00:00:00.0000000', N'125.77', N'135.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-12-03 00:00:00.0000000', N'124.30', N'134.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-12-10 00:00:00.0000000', N'122.37', N'132.50')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-12-17 00:00:00.0000000', N'121.02', N'131.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-12-24 00:00:00.0000000', N'120.61', N'130.91')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2018-12-31 00:00:00.0000000', N'120.18', N'130.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-01-07 00:00:00.0000000', N'120.27', N'130.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-01-14 00:00:00.0000000', N'119.53', N'129.47')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-01-21 00:00:00.0000000', N'119.12', N'128.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-01-28 00:00:00.0000000', N'119.29', N'129.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-02-04 00:00:00.0000000', N'119.13', N'129.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-02-11 00:00:00.0000000', N'118.97', N'129.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-02-18 00:00:00.0000000', N'119.05', N'129.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-02-25 00:00:00.0000000', N'119.22', N'129.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-03-04 00:00:00.0000000', N'119.72', N'130.25')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-03-11 00:00:00.0000000', N'120.10', N'130.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-03-18 00:00:00.0000000', N'120.48', N'130.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-03-25 00:00:00.0000000', N'120.83', N'131.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-04-01 00:00:00.0000000', N'121.70', N'131.48')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-04-08 00:00:00.0000000', N'122.66', N'132.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-04-15 00:00:00.0000000', N'124.06', N'132.96')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-04-22 00:00:00.0000000', N'125.43', N'133.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-04-29 00:00:00.0000000', N'126.36', N'134.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-05-06 00:00:00.0000000', N'127.50', N'135.41')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-05-13 00:00:00.0000000', N'127.97', N'135.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-05-20 00:00:00.0000000', N'128.51', N'135.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-05-27 00:00:00.0000000', N'129.14', N'136.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-06-03 00:00:00.0000000', N'129.41', N'136.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-06-10 00:00:00.0000000', N'128.89', N'135.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-06-17 00:00:00.0000000', N'127.66', N'133.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-06-24 00:00:00.0000000', N'126.66', N'131.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-07-01 00:00:00.0000000', N'126.49', N'131.55')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-07-08 00:00:00.0000000', N'126.86', N'131.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-07-15 00:00:00.0000000', N'127.13', N'131.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-07-22 00:00:00.0000000', N'127.81', N'132.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-07-29 00:00:00.0000000', N'128.03', N'132.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-08-05 00:00:00.0000000', N'128.37', N'132.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-08-12 00:00:00.0000000', N'128.36', N'132.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-08-19 00:00:00.0000000', N'128.17', N'132.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-08-26 00:00:00.0000000', N'128.22', N'132.51')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-09-02 00:00:00.0000000', N'127.86', N'132.29')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-09-09 00:00:00.0000000', N'127.79', N'131.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-09-16 00:00:00.0000000', N'126.92', N'131.35')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-09-23 00:00:00.0000000', N'126.78', N'131.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-09-30 00:00:00.0000000', N'126.92', N'131.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-10-07 00:00:00.0000000', N'126.87', N'131.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-10-14 00:00:00.0000000', N'126.91', N'131.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-10-21 00:00:00.0000000', N'126.40', N'131.28')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-10-28 00:00:00.0000000', N'125.77', N'130.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-11-04 00:00:00.0000000', N'125.56', N'130.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-11-11 00:00:00.0000000', N'125.59', N'130.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-11-18 00:00:00.0000000', N'125.58', N'130.35')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-11-25 00:00:00.0000000', N'125.32', N'130.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-12-02 00:00:00.0000000', N'124.81', N'129.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-12-09 00:00:00.0000000', N'124.75', N'129.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-12-16 00:00:00.0000000', N'124.33', N'129.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-12-23 00:00:00.0000000', N'124.16', N'129.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2019-12-30 00:00:00.0000000', N'124.96', N'130.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-01-06 00:00:00.0000000', N'126.09', N'131.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-01-13 00:00:00.0000000', N'127.17', N'132.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-01-20 00:00:00.0000000', N'127.18', N'132.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-01-27 00:00:00.0000000', N'127.33', N'132.88')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-02-03 00:00:00.0000000', N'125.85', N'131.48')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-02-10 00:00:00.0000000', N'124.73', N'129.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-02-17 00:00:00.0000000', N'123.80', N'128.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-02-24 00:00:00.0000000', N'123.45', N'127.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-03-02 00:00:00.0000000', N'122.43', N'126.62')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-03-09 00:00:00.0000000', N'122.24', N'126.25')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-03-16 00:00:00.0000000', N'120.33', N'124.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-03-23 00:00:00.0000000', N'119.64', N'123.41')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-03-30 00:00:00.0000000', N'112.45', N'118.60')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-04-06 00:00:00.0000000', N'110.23', N'116.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-04-13 00:00:00.0000000', N'109.27', N'116.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-04-20 00:00:00.0000000', N'108.63', N'115.73')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-04-27 00:00:00.0000000', N'107.88', N'115.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-05-04 00:00:00.0000000', N'107.56', N'114.94')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-05-11 00:00:00.0000000', N'107.45', N'114.83')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-05-18 00:00:00.0000000', N'105.09', N'112.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-05-25 00:00:00.0000000', N'104.87', N'111.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-06-01 00:00:00.0000000', N'105.17', N'111.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-06-08 00:00:00.0000000', N'105.74', N'111.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-06-15 00:00:00.0000000', N'106.37', N'112.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-06-22 00:00:00.0000000', N'107.13', N'112.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-06-29 00:00:00.0000000', N'108.31', N'114.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-07-06 00:00:00.0000000', N'109.43', N'115.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-07-13 00:00:00.0000000', N'111.24', N'116.75')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-07-20 00:00:00.0000000', N'112.23', N'117.35')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-07-27 00:00:00.0000000', N'112.66', N'117.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-08-03 00:00:00.0000000', N'112.91', N'117.97')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-08-10 00:00:00.0000000', N'113.02', N'118.01')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-08-17 00:00:00.0000000', N'113.04', N'118.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-08-24 00:00:00.0000000', N'113.22', N'118.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-08-31 00:00:00.0000000', N'113.29', N'118.18')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-09-07 00:00:00.0000000', N'113.37', N'118.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-09-14 00:00:00.0000000', N'113.32', N'118.18')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-09-21 00:00:00.0000000', N'113.31', N'118.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-09-28 00:00:00.0000000', N'113.30', N'118.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-10-05 00:00:00.0000000', N'113.26', N'118.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-10-12 00:00:00.0000000', N'113.19', N'118.05')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-10-19 00:00:00.0000000', N'113.18', N'118.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-10-26 00:00:00.0000000', N'113.14', N'118.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-11-02 00:00:00.0000000', N'113.11', N'118.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-11-09 00:00:00.0000000', N'112.50', N'117.28')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-11-16 00:00:00.0000000', N'112.35', N'117.07')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-11-23 00:00:00.0000000', N'112.42', N'117.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-11-30 00:00:00.0000000', N'112.61', N'117.41')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-12-07 00:00:00.0000000', N'113.17', N'117.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-12-14 00:00:00.0000000', N'113.82', N'118.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-12-21 00:00:00.0000000', N'114.43', N'119.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2020-12-28 00:00:00.0000000', N'114.91', N'119.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-01-04 00:00:00.0000000', N'115.39', N'119.97')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-01-11 00:00:00.0000000', N'116.14', N'120.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-01-18 00:00:00.0000000', N'116.93', N'121.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-01-25 00:00:00.0000000', N'118.10', N'122.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-02-01 00:00:00.0000000', N'119.14', N'123.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-02-08 00:00:00.0000000', N'119.67', N'124.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-02-15 00:00:00.0000000', N'120.53', N'125.01')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-02-22 00:00:00.0000000', N'121.27', N'125.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-03-01 00:00:00.0000000', N'122.17', N'126.62')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-03-08 00:00:00.0000000', N'122.94', N'127.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-03-15 00:00:00.0000000', N'123.90', N'128.24')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-03-22 00:00:00.0000000', N'124.57', N'129.02')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-03-29 00:00:00.0000000', N'125.13', N'129.32')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-04-05 00:00:00.0000000', N'125.24', N'129.35')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-04-12 00:00:00.0000000', N'125.40', N'129.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-04-19 00:00:00.0000000', N'125.48', N'129.49')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-04-26 00:00:00.0000000', N'125.80', N'129.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-05-03 00:00:00.0000000', N'126.09', N'130.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-05-10 00:00:00.0000000', N'126.53', N'130.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-05-17 00:00:00.0000000', N'127.19', N'131.03')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-05-24 00:00:00.0000000', N'127.89', N'131.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-05-31 00:00:00.0000000', N'128.15', N'131.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-06-07 00:00:00.0000000', N'128.69', N'132.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-06-14 00:00:00.0000000', N'129.47', N'133.17')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-06-21 00:00:00.0000000', N'130.10', N'133.69')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-06-28 00:00:00.0000000', N'130.73', N'134.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-07-05 00:00:00.0000000', N'131.70', N'134.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-07-12 00:00:00.0000000', N'132.47', N'135.29')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-07-19 00:00:00.0000000', N'133.20', N'135.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-07-26 00:00:00.0000000', N'133.48', N'136.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-08-02 00:00:00.0000000', N'134.21', N'136.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-08-09 00:00:00.0000000', N'134.70', N'137.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-08-16 00:00:00.0000000', N'134.70', N'136.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-08-23 00:00:00.0000000', N'134.68', N'137.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-08-30 00:00:00.0000000', N'134.66', N'137.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-09-06 00:00:00.0000000', N'134.76', N'137.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-09-13 00:00:00.0000000', N'134.75', N'137.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-09-20 00:00:00.0000000', N'134.86', N'137.35')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-09-27 00:00:00.0000000', N'135.19', N'137.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-10-04 00:00:00.0000000', N'136.10', N'139.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-10-11 00:00:00.0000000', N'137.17', N'140.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-10-18 00:00:00.0000000', N'139.46', N'143.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-10-25 00:00:00.0000000', N'141.81', N'145.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-11-01 00:00:00.0000000', N'143.70', N'147.48')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-11-08 00:00:00.0000000', N'144.90', N'148.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-11-15 00:00:00.0000000', N'145.87', N'149.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-11-22 00:00:00.0000000', N'146.89', N'150.73')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-11-29 00:00:00.0000000', N'147.53', N'151.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-12-06 00:00:00.0000000', N'146.89', N'150.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-12-13 00:00:00.0000000', N'146.22', N'149.88')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-12-20 00:00:00.0000000', N'145.16', N'148.89')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2021-12-27 00:00:00.0000000', N'144.92', N'148.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-01-03 00:00:00.0000000', N'145.04', N'148.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-01-10 00:00:00.0000000', N'144.82', N'148.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-01-17 00:00:00.0000000', N'144.80', N'148.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-01-24 00:00:00.0000000', N'144.87', N'148.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-01-31 00:00:00.0000000', N'145.74', N'149.68')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-02-07 00:00:00.0000000', N'146.33', N'150.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-02-14 00:00:00.0000000', N'146.95', N'151.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-02-21 00:00:00.0000000', N'147.77', N'151.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-02-28 00:00:00.0000000', N'149.22', N'153.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-03-07 00:00:00.0000000', N'152.95', N'158.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-03-14 00:00:00.0000000', N'159.96', N'169.48')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-03-21 00:00:00.0000000', N'165.37', N'177.47')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-03-28 00:00:00.0000000', N'162.65', N'176.44')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-04-04 00:00:00.0000000', N'161.91', N'176.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-04-11 00:00:00.0000000', N'161.78', N'176.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-04-18 00:00:00.0000000', N'161.67', N'175.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-04-25 00:00:00.0000000', N'161.84', N'176.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-05-02 00:00:00.0000000', N'162.48', N'177.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-05-09 00:00:00.0000000', N'163.68', N'178.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-05-16 00:00:00.0000000', N'165.09', N'179.67')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-05-23 00:00:00.0000000', N'167.59', N'181.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-05-30 00:00:00.0000000', N'170.36', N'182.25')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-06-06 00:00:00.0000000', N'174.99', N'184.94')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-06-13 00:00:00.0000000', N'182.53', N'190.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-06-20 00:00:00.0000000', N'186.85', N'194.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-06-27 00:00:00.0000000', N'190.93', N'198.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-07-04 00:00:00.0000000', N'191.55', N'199.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-07-11 00:00:00.0000000', N'190.63', N'198.74')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-07-18 00:00:00.0000000', N'188.92', N'197.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-07-25 00:00:00.0000000', N'186.60', N'195.88')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-08-01 00:00:00.0000000', N'182.77', N'193.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-08-08 00:00:00.0000000', N'177.64', N'188.49')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-08-15 00:00:00.0000000', N'174.19', N'185.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-08-22 00:00:00.0000000', N'171.14', N'182.92')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-08-29 00:00:00.0000000', N'170.12', N'183.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-09-05 00:00:00.0000000', N'168.93', N'182.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-09-12 00:00:00.0000000', N'167.61', N'182.22')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-09-19 00:00:00.0000000', N'165.47', N'181.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-09-26 00:00:00.0000000', N'164.00', N'180.46')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-10-03 00:00:00.0000000', N'162.67', N'180.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-10-10 00:00:00.0000000', N'162.09', N'180.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-10-17 00:00:00.0000000', N'162.81', N'181.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-10-24 00:00:00.0000000', N'164.62', N'187.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-10-31 00:00:00.0000000', N'165.87', N'189.77')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-11-07 00:00:00.0000000', N'165.62', N'189.79')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-11-14 00:00:00.0000000', N'164.40', N'188.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-11-21 00:00:00.0000000', N'163.28', N'187.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-11-28 00:00:00.0000000', N'161.13', N'185.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-12-05 00:00:00.0000000', N'159.20', N'183.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-12-12 00:00:00.0000000', N'155.97', N'179.91')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-12-19 00:00:00.0000000', N'154.07', N'177.62')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2022-12-26 00:00:00.0000000', N'151.94', N'175.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-01-02 00:00:00.0000000', N'150.90', N'174.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-01-09 00:00:00.0000000', N'149.97', N'173.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-01-16 00:00:00.0000000', N'148.79', N'171.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-01-23 00:00:00.0000000', N'148.21', N'170.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-01-30 00:00:00.0000000', N'148.18', N'170.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-02-06 00:00:00.0000000', N'148.34', N'170.36')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-02-13 00:00:00.0000000', N'147.98', N'169.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-02-20 00:00:00.0000000', N'147.86', N'169.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-02-27 00:00:00.0000000', N'147.55', N'168.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-03-06 00:00:00.0000000', N'147.12', N'167.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-03-13 00:00:00.0000000', N'146.97', N'167.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-03-20 00:00:00.0000000', N'146.62', N'166.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-03-27 00:00:00.0000000', N'146.21', N'165.18')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-04-03 00:00:00.0000000', N'145.72', N'163.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-04-10 00:00:00.0000000', N'145.82', N'162.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-04-17 00:00:00.0000000', N'145.93', N'162.11')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-04-24 00:00:00.0000000', N'145.84', N'161.34')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-05-01 00:00:00.0000000', N'145.71', N'160.35')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-05-08 00:00:00.0000000', N'145.30', N'158.12')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-05-15 00:00:00.0000000', N'144.65', N'155.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-05-22 00:00:00.0000000', N'143.64', N'151.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-05-29 00:00:00.0000000', N'142.94', N'147.87')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-06-05 00:00:00.0000000', N'142.90', N'146.43')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-06-12 00:00:00.0000000', N'142.71', N'145.48')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-06-19 00:00:00.0000000', N'142.95', N'145.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-06-26 00:00:00.0000000', N'143.43', N'145.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-07-03 00:00:00.0000000', N'143.40', N'145.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-07-10 00:00:00.0000000', N'142.87', N'144.73')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-07-17 00:00:00.0000000', N'142.77', N'144.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-07-24 00:00:00.0000000', N'142.96', N'145.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-07-31 00:00:00.0000000', N'144.13', N'145.95')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-08-07 00:00:00.0000000', N'146.18', N'148.23')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-08-14 00:00:00.0000000', N'147.77', N'150.37')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-08-21 00:00:00.0000000', N'149.40', N'152.14')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-08-28 00:00:00.0000000', N'150.73', N'153.52')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-09-04 00:00:00.0000000', N'151.71', N'154.65')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-09-11 00:00:00.0000000', N'153.10', N'156.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-09-18 00:00:00.0000000', N'154.06', N'158.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-09-25 00:00:00.0000000', N'155.41', N'160.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-10-02 00:00:00.0000000', N'156.02', N'162.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-10-09 00:00:00.0000000', N'155.94', N'162.49')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-10-16 00:00:00.0000000', N'155.09', N'162.31')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-10-23 00:00:00.0000000', N'154.63', N'162.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-10-30 00:00:00.0000000', N'153.97', N'161.76')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-11-06 00:00:00.0000000', N'153.20', N'160.86')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-11-13 00:00:00.0000000', N'152.39', N'160.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-11-20 00:00:00.0000000', N'150.50', N'158.44')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-11-27 00:00:00.0000000', N'147.99', N'156.18')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-12-04 00:00:00.0000000', N'145.71', N'154.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-12-11 00:00:00.0000000', N'143.80', N'152.01')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-12-18 00:00:00.0000000', N'141.51', N'150.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2023-12-25 00:00:00.0000000', N'140.33', N'149.24')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-01-01 00:00:00.0000000', N'140.78', N'148.66')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-01-08 00:00:00.0000000', N'139.72', N'148.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-01-15 00:00:00.0000000', N'139.49', N'147.93')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-01-22 00:00:00.0000000', N'139.39', N'147.96')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-01-29 00:00:00.0000000', N'139.91', N'148.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-02-05 00:00:00.0000000', N'140.55', N'149.35')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-02-12 00:00:00.0000000', N'141.28', N'150.28')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-02-19 00:00:00.0000000', N'142.86', N'152.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-02-26 00:00:00.0000000', N'143.96', N'153.29')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-03-04 00:00:00.0000000', N'144.73', N'154.53')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-03-11 00:00:00.0000000', N'144.70', N'154.29')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-03-18 00:00:00.0000000', N'144.73', N'153.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-03-25 00:00:00.0000000', N'145.06', N'153.90')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-04-01 00:00:00.0000000', N'146.25', N'156.00')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-04-08 00:00:00.0000000', N'146.91', N'156.29')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-04-15 00:00:00.0000000', N'148.49', N'157.46')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-04-22 00:00:00.0000000', N'149.21', N'157.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-04-29 00:00:00.0000000', N'149.49', N'157.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-05-06 00:00:00.0000000', N'149.54', N'157.64')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-05-13 00:00:00.0000000', N'149.23', N'157.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-05-20 00:00:00.0000000', N'148.83', N'156.21')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-05-27 00:00:00.0000000', N'147.65', N'154.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-06-03 00:00:00.0000000', N'147.27', N'153.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-06-10 00:00:00.0000000', N'146.25', N'151.99')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-06-17 00:00:00.0000000', N'145.09', N'150.70')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-06-24 00:00:00.0000000', N'144.43', N'150.12')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-07-01 00:00:00.0000000', N'144.28', N'150.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-07-08 00:00:00.0000000', N'144.45', N'150.39')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-07-15 00:00:00.0000000', N'144.60', N'150.56')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-07-22 00:00:00.0000000', N'144.69', N'150.59')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-07-29 00:00:00.0000000', N'144.19', N'150.16')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-08-05 00:00:00.0000000', N'143.42', N'149.10')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-08-12 00:00:00.0000000', N'142.91', N'148.48')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-08-19 00:00:00.0000000', N'141.96', N'147.42')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-08-26 00:00:00.0000000', N'141.01', N'146.15')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-09-02 00:00:00.0000000', N'139.96', N'145.19')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-09-09 00:00:00.0000000', N'138.10', N'143.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-09-16 00:00:00.0000000', N'136.49', N'141.61')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-09-23 00:00:00.0000000', N'135.26', N'140.02')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-09-30 00:00:00.0000000', N'134.17', N'138.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-10-07 00:00:00.0000000', N'133.59', N'138.46')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-10-14 00:00:00.0000000', N'133.86', N'139.08')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-10-21 00:00:00.0000000', N'133.99', N'139.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-10-28 00:00:00.0000000', N'134.41', N'139.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-11-04 00:00:00.0000000', N'134.41', N'139.84')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-11-11 00:00:00.0000000', N'134.59', N'140.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-11-18 00:00:00.0000000', N'134.85', N'140.49')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-11-25 00:00:00.0000000', N'135.37', N'141.40')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-12-02 00:00:00.0000000', N'135.93', N'142.04')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-12-09 00:00:00.0000000', N'136.23', N'142.49')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-12-16 00:00:00.0000000', N'136.39', N'142.71')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-12-23 00:00:00.0000000', N'136.39', N'142.85')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2024-12-30 00:00:00.0000000', N'136.49', N'142.98')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-01-06 00:00:00.0000000', N'136.60', N'143.30')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-01-13 00:00:00.0000000', N'136.51', N'143.33')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-01-20 00:00:00.0000000', N'136.97', N'144.27')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-01-27 00:00:00.0000000', N'138.36', N'145.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-02-03 00:00:00.0000000', N'138.74', N'146.13')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-02-10 00:00:00.0000000', N'139.02', N'146.29')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-02-17 00:00:00.0000000', N'139.22', N'146.45')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-02-24 00:00:00.0000000', N'139.62', N'146.82')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-03-03 00:00:00.0000000', N'139.61', N'146.88')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-03-10 00:00:00.0000000', N'139.42', N'146.58')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-03-17 00:00:00.0000000', N'137.97', N'145.38')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-03-24 00:00:00.0000000', N'135.61', N'143.07')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-03-31 00:00:00.0000000', N'134.91', N'142.26')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-04-07 00:00:00.0000000', N'135.25', N'142.54')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-04-14 00:00:00.0000000', N'134.85', N'141.97')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-04-21 00:00:00.0000000', N'134.26', N'141.44')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-04-28 00:00:00.0000000', N'133.84', N'140.81')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-06-02 00:00:00.0000000', N'131.45', N'138.09')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', NULL, NULL, NULL)
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-05-05 00:00:00.0000000', N'133.18', N'140.06')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-05-12 00:00:00.0000000', N'132.32', N'139.20')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-05-19 00:00:00.0000000', N'132.07', N'138.57')
GO

INSERT INTO [Emissions].[FuelPrices] ([country], [weekDate], [petrolPrice], [dieselPrice]) VALUES (N'UK', N'2025-05-26 00:00:00.0000000', N'131.99', N'138.37')
GO


-- ----------------------------
-- View structure for vEmissionFactors
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[vEmissionFactors]') AND type IN ('V'))
	DROP VIEW [Emissions].[vEmissionFactors]
GO

CREATE VIEW [Emissions].[vEmissionFactors] AS SELECT a.id as [activityId], a.name as [activityName], ef.ef, ef.wtt, ef.tnd, ef.tndWtt, ef.emissionProfileId
FROM Emissions.EmissionActivity a
LEFT JOIN Emissions.EmissionFactor ef on ef.activityId = a.id
WHERE a.active = 1 AND ef.active = 1
GO


-- ----------------------------
-- function structure for fnFuelPrices_AmountToLiters
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[fnFuelPrices_AmountToLiters]') AND type IN ('FN', 'FS', 'FT', 'IF', 'TF'))
	DROP FUNCTION[Emissions].[fnFuelPrices_AmountToLiters]
GO

CREATE FUNCTION [Emissions].[fnFuelPrices_AmountToLiters]
(
    @fuelType NVARCHAR(10),        -- 'PETROL' or 'DIESEL'
    @amount DECIMAL(10, 2),        -- amount in local currency
    @country NVARCHAR(15)
)
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @avgPrice DECIMAL(10, 4);
    DECLARE @latestWeekDate DATETIME2(7);

    -- Step 1: Get latest available week for the country
    SELECT @latestWeekDate = MAX(weekDate)
    FROM [Emissions].[FuelPrices]
    WHERE country = @country;

    -- Step 2: Compute 52-week average price based on fuel type
    IF UPPER(@fuelType) = 'PETROL'
    BEGIN
        SELECT @avgPrice = AVG(petrolPrice)
        FROM [Emissions].[FuelPrices]
        WHERE country = @country
          AND weekDate >= DATEADD(WEEK, -52, @latestWeekDate);
    END
    ELSE IF UPPER(@fuelType) = 'DIESEL'
    BEGIN
        SELECT @avgPrice = AVG(dieselPrice)
        FROM [Emissions].[FuelPrices]
        WHERE country = @country
          AND weekDate >= DATEADD(WEEK, -52, @latestWeekDate);
    END
    ELSE
    BEGIN
        RETURN NULL; -- Invalid fuel type
    END

    -- Step 3: Convert pence to pounds if UK
    IF UPPER(@country) = 'UK'
    BEGIN
        SET @avgPrice = @avgPrice / 100;
    END

    -- Step 4: Calculate and return litres
    RETURN CASE 
        WHEN @avgPrice > 0 THEN ROUND(@amount / @avgPrice, 2)
        ELSE NULL 
    END;
END;
GO


-- ----------------------------
-- procedure structure for spConvertAmountTo
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[spConvertAmountTo]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Emissions].[spConvertAmountTo]
GO

CREATE PROCEDURE [Emissions].[spConvertAmountTo]
  @dataUnit NVARCHAR(100),
  @amount decimal(10,2),
  @country NVARCHAR(15)='UK'
AS
BEGIN

  if(UPPER(@dataUnit) = 'AMOUNT SPEND - PETROL')
    begin 
      SELECT [Emissions].[fnFuelPrices_AmountToLiters]('PETROL', @amount, @country) AS [value], 'No of litre - Petrol' as dataUnit;
    end
  else if(UPPER(@dataUnit) = 'AMOUNT SPEND - DIESEL')
    begin 
      SELECT [Emissions].[fnFuelPrices_AmountToLiters]('DIESEL', @amount, @country) AS [value], 'No of litre - Diesel' as dataUnit;
    end
  else
    select null as [value], null as dataUnit;
END
GO


-- ----------------------------
-- procedure structure for spEmissionsDataImport
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[spEmissionsDataImport]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Emissions].[spEmissionsDataImport]
GO

CREATE PROCEDURE [Emissions].[spEmissionsDataImport]
  @emissionProfileId int
AS
BEGIN
 /* ================= STEPS For Data Import ==============================
  1. download flat file from https://www.gov.uk/government/publications/greenhouse-gas-reporting-conversion-factors-2024 [change year in link for the period]
  2. import flat file data in FactorsbyCategory table
  3. verify all mapped activity data are ok (there are some activities having factors fixed and will not be available in flat file, mostly activities of Purchased Goods and Services form)
  4. create record in EmissionProfile table
  5. run exec emissions.spEmissionsDataImport EmissionProfileID
 */

  declare @emissionProfileYear int;
  select @emissionProfileYear = [year] from emissions.EmissionProfile where id = @emissionProfileId;
  
  CREATE TABLE #EmissionFactorSourceData (
    [activityId] int  NOT NULL,
    [ef] decimal(10,5)  NULL,
    [wtt] decimal(10,5)  NULL,
    [tnd] decimal(10,5)  NULL,
    [tndWtt] decimal(10,5)  NULL,
    [year] int  NULL,
    [emissionProfileId] int  NULL,
    [active] bit DEFAULT 1 NOT NULL
  );
  
  Insert into #EmissionFactorSourceData (activityId, ef, wtt, tnd, tndwtt, [year], emissionProfileId)
  Select EF.activityId, EF.FactorValue as EF, WTT.FactorValue as WTT, TND.FactorValue as TND, TNDWTT.FactorValue as TNDWTT, @emissionProfileYear, @emissionProfileId
  FROM
  (
    Select EASM.activityId, FC.[GHG Conversion Factor 2024] as FactorValue
    from emissions.EmissionActivitySourceMapping as EASM 
    INNER JOIN Emissions.FactorsbyCategory as FC on (EASM.srcId=FC.ID and EASM.factorType='EF')
  ) as EF LEFT JOIN
  (
    Select EASM.activityId, FC.[GHG Conversion Factor 2024] as FactorValue
    from emissions.EmissionActivitySourceMapping as EASM 
    INNER JOIN Emissions.FactorsbyCategory as FC on (EASM.srcId=FC.ID and EASM.factorType='WTT')
  ) as WTT on (EF.activityId = WTT.activityId)
  LEFT JOIN
  (
    Select EASM.activityId, FC.[GHG Conversion Factor 2024] as FactorValue
    from emissions.EmissionActivitySourceMapping as EASM 
    INNER JOIN Emissions.FactorsbyCategory as FC on (EASM.srcId=FC.ID and EASM.factorType='TND')
  ) as TND on (EF.activityId = TND.activityId)
  LEFT JOIN
  (
    Select EASM.activityId, FC.[GHG Conversion Factor 2024] as FactorValue
    from emissions.EmissionActivitySourceMapping as EASM 
    INNER JOIN Emissions.FactorsbyCategory as FC on (EASM.srcId=FC.ID and EASM.factorType='TNDWTT')
  ) as TNDWTT on (EF.activityId = TNDWTT.activityId)
  ORDER BY EF.activityId;
  
  MERGE INTO emissions.EmissionFactor AS target
  USING #EmissionFactorSourceData AS source
  ON target.activityId = source.activityId and target.emissionProfileId = source.emissionProfileId
  WHEN MATCHED THEN
      UPDATE SET target.ef = source.ef,
                 target.wtt = source.wtt,
                 target.tnd = source.tnd,
                 target.tndwtt = source.tndwtt,
                 target.year = source.year
  WHEN NOT MATCHED THEN
      INSERT ([activityId], [ef], [wtt], [tnd], [tndWtt], [year], [emissionProfileId], [active])
      VALUES (source.[activityId], source.[ef], source.[wtt], source.[tnd], source.[tndWtt], source.[year], source.[emissionProfileId], source.[active]);


END
GO


-- ----------------------------
-- procedure structure for spEmissionFactor_Select
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[spEmissionFactor_Select]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Emissions].[spEmissionFactor_Select]
GO

CREATE PROCEDURE [Emissions].[spEmissionFactor_Select] 
	@submissionid BIGINT,
	@emissionProfileId INT = 1
AS
BEGIN

	-- EXEC [DataModel].[spBAQ_DataOutput] 5913355162935174087

	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, ef, wtt, tnd, tndwtt)
	EXEC [DataModel].[spBAQ_DataOutputWithBenchmarks] @submissionid, @emissionProfileId;

	--SELECT * from #BAQDataWithBM;

	DROP TABLE #BAQDataWithBM;

END
GO


-- ----------------------------
-- procedure structure for spFuelPrice_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Emissions].[spFuelPrice_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Emissions].[spFuelPrice_Save]
GO

CREATE PROCEDURE [Emissions].[spFuelPrice_Save]
    @json NVARCHAR(MAX),
    @country NVARCHAR(15) = 'UK'
AS
BEGIN
    SET NOCOUNT ON;

    -- Parse JSON into a table variable
    DECLARE @parsed TABLE (
        weekDate DATETIME2(7),
        petrolPrice DECIMAL(10,2),
        dieselPrice DECIMAL(10,2)
    );

    INSERT INTO @parsed (weekDate, petrolPrice, dieselPrice)
    SELECT weekDate, petrolPrice, dieselPrice
    FROM OPENJSON(@json) WITH (
        weekDate DATETIME2(7) '$.weekDate',
        petrolPrice DECIMAL(10,2) '$.petrolPrice',
        dieselPrice DECIMAL(10,2) '$.dieselPrice'
    );

    -- Merge data into main table
    MERGE [Emissions].[FuelPrices] AS TARGET
    USING @parsed AS SOURCE
    ON TARGET.weekDate = SOURCE.weekDate AND TARGET.country = @country
    WHEN MATCHED THEN
        UPDATE SET 
            TARGET.petrolPrice = SOURCE.petrolPrice,
            TARGET.dieselPrice = SOURCE.dieselPrice
    WHEN NOT MATCHED BY TARGET THEN
        INSERT (country, weekDate, petrolPrice, dieselPrice)
        VALUES (@country, SOURCE.weekDate, SOURCE.petrolPrice, SOURCE.dieselPrice);
END;
GO


-- ----------------------------
-- Auto increment value for EmissionActivity
-- ----------------------------
DBCC CHECKIDENT ('[Emissions].[EmissionActivity]', RESEED, 498)
GO


-- ----------------------------
-- Primary Key structure for table EmissionActivity
-- ----------------------------
ALTER TABLE [Emissions].[EmissionActivity] ADD CONSTRAINT [PK__Emission__3213E83F861BA3E9] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Uniques structure for table EmissionActivitySourceMapping
-- ----------------------------
ALTER TABLE [Emissions].[EmissionActivitySourceMapping] ADD CONSTRAINT [uniqueKey] UNIQUE NONCLUSTERED ([activityId] ASC, [factorType] ASC)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for EmissionCategory
-- ----------------------------
DBCC CHECKIDENT ('[Emissions].[EmissionCategory]', RESEED, 3)
GO


-- ----------------------------
-- Primary Key structure for table EmissionCategory
-- ----------------------------
ALTER TABLE [Emissions].[EmissionCategory] ADD CONSTRAINT [PK__Emission__3213E83F776E5952] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for EmissionFactor
-- ----------------------------
DBCC CHECKIDENT ('[Emissions].[EmissionFactor]', RESEED, 6561)
GO


-- ----------------------------
-- Primary Key structure for table EmissionFactor
-- ----------------------------
ALTER TABLE [Emissions].[EmissionFactor] ADD CONSTRAINT [PK__Emission__3213E83F535CEFF0] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for EmissionProfile
-- ----------------------------
DBCC CHECKIDENT ('[Emissions].[EmissionProfile]', RESEED, 9)
GO


-- ----------------------------
-- Primary Key structure for table EmissionProfile
-- ----------------------------
ALTER TABLE [Emissions].[EmissionProfile] ADD CONSTRAINT [PK__Emission__3213E83F8D8A935E] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

