/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Forms

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 11:14:24
*/


-- ----------------------------
-- Table structure for BlueAwardQuestionnaire
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[BlueAwardQuestionnaire]') AND type IN ('U'))
	DROP TABLE [Forms].[BlueAwardQuestionnaire]
GO

CREATE TABLE [Forms].[BlueAwardQuestionnaire] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [key] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [value] nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dataType] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Forms].[BlueAwardQuestionnaire] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for GoldAwardQuestionnaire
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[GoldAwardQuestionnaire]') AND type IN ('U'))
	DROP TABLE [Forms].[GoldAwardQuestionnaire]
GO

CREATE TABLE [Forms].[GoldAwardQuestionnaire] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [key] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [value] nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dataType] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Forms].[GoldAwardQuestionnaire] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for JotformRawResponse
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[JotformRawResponse]') AND type IN ('U'))
	DROP TABLE [Forms].[JotformRawResponse]
GO

CREATE TABLE [Forms].[JotformRawResponse] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [formId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [data] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [processFlag] bit DEFAULT 0 NOT NULL,
  [createdDate] datetime DEFAULT getdate() NOT NULL
)
GO

ALTER TABLE [Forms].[JotformRawResponse] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for JotformSubmission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[JotformSubmission]') AND type IN ('U'))
	DROP TABLE [Forms].[JotformSubmission]
GO

CREATE TABLE [Forms].[JotformSubmission] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [submissionDate] datetime DEFAULT getdate() NOT NULL,
  [managementBasedDecision] bit  NULL,
  [optedIn] bit  NULL,
  [createdDate] datetime DEFAULT getdate() NULL
)
GO

ALTER TABLE [Forms].[JotformSubmission] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for NczForm
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[NczForm]') AND type IN ('U'))
	DROP TABLE [Forms].[NczForm]
GO

CREATE TABLE [Forms].[NczForm] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [category] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Forms].[NczForm] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Response
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Forms].[Response]') AND type IN ('U'))
	DROP TABLE [Forms].[Response]
GO

CREATE TABLE [Forms].[Response] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] int  NOT NULL,
  [questionId] int  NOT NULL,
  [value] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [Forms].[Response] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Auto increment value for BlueAwardQuestionnaire
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[BlueAwardQuestionnaire]', RESEED, 7466)
GO


-- ----------------------------
-- Primary Key structure for table BlueAwardQuestionnaire
-- ----------------------------
ALTER TABLE [Forms].[BlueAwardQuestionnaire] ADD CONSTRAINT [PK__BlueAwar__3213E83F656A430F] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for GoldAwardQuestionnaire
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[GoldAwardQuestionnaire]', RESEED, 1531)
GO


-- ----------------------------
-- Primary Key structure for table GoldAwardQuestionnaire
-- ----------------------------
ALTER TABLE [Forms].[GoldAwardQuestionnaire] ADD CONSTRAINT [PK__GoldAwar__3213E83F33A016B9] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for JotformRawResponse
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[JotformRawResponse]', RESEED, 12412)
GO


-- ----------------------------
-- Primary Key structure for table JotformRawResponse
-- ----------------------------
ALTER TABLE [Forms].[JotformRawResponse] ADD CONSTRAINT [PK__JotformR__3213E83FEB1C18D9] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for JotformSubmission
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[JotformSubmission]', RESEED, 6533)
GO


-- ----------------------------
-- Primary Key structure for table JotformSubmission
-- ----------------------------
ALTER TABLE [Forms].[JotformSubmission] ADD CONSTRAINT [PK__Submissi__3213E83F2D059005] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for NczForm
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[NczForm]', RESEED, 1)
GO


-- ----------------------------
-- Primary Key structure for table NczForm
-- ----------------------------
ALTER TABLE [Forms].[NczForm] ADD CONSTRAINT [PK__NczForm__3213E83FD60B8860] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Response
-- ----------------------------
DBCC CHECKIDENT ('[Forms].[Response]', RESEED, 245363)
GO


-- ----------------------------
-- Primary Key structure for table Response
-- ----------------------------
ALTER TABLE [Forms].[Response] ADD CONSTRAINT [PK__Response__3213E83F7EA76B37] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

