/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Documents

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 10:40:52
*/


-- ----------------------------
-- Table structure for Document
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[Document]') AND type IN ('U'))
	DROP TABLE [Documents].[Document]
GO

CREATE TABLE [Documents].[Document] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [parentEntityId] int  NOT NULL,
  [parentEntityType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [customerId] int  NULL,
  [container] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [blobName] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [title] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [singleInstance] bit DEFAULT 0 NULL,
  [canEmbed] bit DEFAULT 0 NULL,
  [modifiedDate] bigint  NULL,
  [mimeType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [activeTo] bigint  NULL,
  [size] int DEFAULT 0 NOT NULL,
  [userAccountId] int  NULL
)
GO

ALTER TABLE [Documents].[Document] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- procedure structure for spDocument_Delete
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_Delete]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_Delete]
GO

CREATE PROCEDURE [Documents].[spDocument_Delete]
    @id INT
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @now bigint = [utilities].DateToEpoch(null);
	UPDATE [documents].[Document] SET [activeTo] = @now WHERE [id] = @id;

END
GO


-- ----------------------------
-- procedure structure for spDocument_CreateVersion
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_CreateVersion]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_CreateVersion]
GO

CREATE PROCEDURE [Documents].[spDocument_CreateVersion]
   @documentId int
	,@parentDocId int
	,@uid nvarchar(50) = NULL
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @now BIGINT = utilities.DatetoEpoch(GetDate());
	DECLARE @version int = (SELECT ISNULL([version], 0) FROM [documents].[DocumentVersion] WHERE [documentId] = @parentDocId)
	
	DECLARE @userACcountId INT = NULL
	IF @uid IS NOT NULL 
		SET @userAccountId = (SELECT [id] FROM [registrations].[UserAccount] WHERE [uid] = @uid)

	INSERT INTO [documents].[DocumentVersion] (
			[documentId]
			,[parentDocId]
			,[version]
			,[createdDate]
			,[createdBy]
		) VALUES (
			@documentId
			,@parentDocId
			,ISNULL(@version, 0) + 1
			,@now
			,@userACcountId
		)

	RETURN 1;

END
GO


-- ----------------------------
-- procedure structure for spDocument_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_Save]
GO

CREATE PROCEDURE [Documents].[spDocument_Save]
        @parentEntityId INT
        ,@parentEntityType NVARCHAR(100)
        ,@customerId INT = null
        ,@container NVARCHAR(100)
        ,@blobName NVARCHAR(500) = null
        ,@title NVARCHAR(100)
        ,@mimeType [nvarchar](100)
        ,@singleInstance BIT = NULL
        ,@canEmbed BIT -- we can embed image types for instance
        ,@size INT = NULL
        ,@uid nvarchar(50) = NULL
        ,@ownerName nvarchar(100) = NULL
        ,@reviewDate bigint = NULL
		,@reference nvarchar(50) = NULL
AS
BEGIN

	SET NOCOUNT ON;
  
	DECLARE @id int = NULL
	IF @singleInstance = 1 
	BEGIN
		SELECT TOP 1 @id = [id] FROM [documents].[document] WHERE [parentEntityId] = @parentEntityId AND [parentEntityType] = @parentEntityType
	END
	
	DECLARE @userACcountId INT = NULL
	IF @uid IS NOT NULL 
		SET @userAccountId = (SELECT [id] FROM [registrations].[UserAccount] WHERE [uid] = @uid)

	DECLARE @now BIGINT = utilities.DatetoEpoch(GetDate());
	IF @id IS NULL
	BEGIN
		INSERT INTO [documents].[Document] (
			 [parentEntityId]
			,[parentEntityType]
			,[customerId] 
			,[container]
			,[blobName]
			,[title]
			,[mimeType]
			,[singleInstance]
			,[canEmbed]
			,[modifiedDate]
			,[size]
			,[userAccountId]
		) VALUES (
			 @parentEntityId
			,@parentEntityType
			,@customerId
			,@container
			,@blobName
			,@title
			,@mimeType
			,@singleInstance
			,@canEmbed
			,@now
			,ISNULL(@size, 0)
			,@userAccountId
		)
		SET @id = (SCOPE_IDENTITY())
		IF @ownerName IS NOT NULL OR @reviewDate IS NOT NULL OR @reference IS NOT NULL
		BEGIN
			INSERT INTO [documents].[DocumentInfo] ([documentId], [owner], [reviewDate], [reference]) VALUES (@id, @ownerName, @reviewDate, @reference)
		END
	END
	ELSE
		UPDATE [documents].[Document]
		   SET [modifiedDate] = @now
				,[title] = @title
				,[container] = @container
				,[blobName] = @blobName
				,[size] = ISNULL(@size, 0)
				,[userAccountId] = @userAccountId
		 WHERE [id] = @id
	
	SELECT *
	  FROM [documents].[Document]
	 WHERE [id] = @id
END
GO


-- ----------------------------
-- procedure structure for spDocument_Get
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_Get]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_Get]
GO

CREATE PROCEDURE [Documents].[spDocument_Get]
   @documentId int
AS
BEGIN
	SET NOCOUNT ON;
  
	SELECT d.* FROM [documents].[document] d
  WHERE d.[id] = @documentId AND d.[activeTo] IS NULL;

END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectByBlobName
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectByBlobName]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_SelectByBlobName]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectByBlobName]
    @blobName nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT TOP 1 d.*
			,ISNULL(f.sectionId, d.parentEntityId) as sectionId --When there is no folder, we use sectionId as parentEntityId
	  FROM [documents].[document] d
 LEFT JOIN [documents].[Folder] f on f.id = d.parentEntityId AND d.parentEntityType = 'folder'
	 WHERE [blobName] = @blobName;

END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectByIds
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectByIds]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_SelectByIds]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectByIds]
   @ids NVARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT d.*
		,u.displayName as [userDisplayName]
		,u.picture as [userPicture]
		,u.email as [userEmail]
		,di.owner as [ownerName]
		,di.reviewDate
	  FROM [documents].[document] d
	LEFT JOIN [registrations].[UserAccount] u on u.[id] = d.[userAccountId]
	LEFT JOIN [documents].[DocumentInfo] di on di.[documentId] = d.[id]
	 WHERE d.[id] in (SELECT [value] FROM STRING_SPLIT(@ids, ','))
		 AND d.[activeTo] IS NULL
		ORDER BY d.[modifiedDate] DESC
END
GO


-- ----------------------------
-- procedure structure for spDocumentsByContainer
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocumentsByContainer]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocumentsByContainer]
GO

CREATE PROCEDURE [Documents].[spDocumentsByContainer]
  @container NVARCHAR(100) 
AS
BEGIN
	SELECT d.[id]
        ,d.[blobName]
        ,d.[title]
        ,d.[modifiedDate]
        ,d.[mimeType]
        ,df.[name] as [folderName]
        ,dpf.[name] as [parentFolderName]
     FROM [documents].[Document] d 
     LEFT JOIN [documents].[Folder] df ON d.[parentEntityId] = df.[id] AND d.[parentEntityType] = 'folder'
     LEFT JOIN [documents].[Folder] dpf ON df.[parentFolderId] = dpf.[id]
     WHERE d.[container] = @container
     AND d.[activeTo] IS NULL
     AND d.[mimeType] NOT LIKE 'image%'
END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectVersions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectVersions]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_SelectVersions]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectVersions]	
	@documentId INT
AS
BEGIN
  	
	SET NOCOUNT ON;
	
	;With docs as
		(
			SELECT [documentId], [parentDocId] FROM [documents].[DocumentVersion]
			 WHERE [documentId] = @documentId
			 UNION ALL
			SELECT dv.[documentId], dv.[parentDocId] FROM [documents].[DocumentVersion] dv
			 -- Will allow matching to all documents in the upstream hieracrhy
			 INNER JOIN docs d ON dv.[documentId] = d.[parentDocId]
		)

		SELECT d.*
				,u.displayName as [userDisplayName]
				,u.picture as [userPicture]
				,u.email as [userEmail]
	  FROM [documents].[document] d
	LEFT JOIN [registrations].[UserAccount] u on u.[id] = d.[userAccountId]
	 WHERE d.[id] in (select [parentDocId] FROM docs)
		ORDER BY d.[modifiedDate] DESC

END
GO


-- ----------------------------
-- procedure structure for spDocument_SelectForEntity
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Documents].[spDocument_SelectForEntity]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Documents].[spDocument_SelectForEntity]
GO

CREATE PROCEDURE [Documents].[spDocument_SelectForEntity]
    @parentEntityId INT
   ,@parentEntityType NVARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT d.*
                ,u.displayName as [userDisplayName]
                ,u.picture as [userPicture]
                ,u.email as [userEmail]
                ,di.owner as [ownerName]
                ,di.reviewDate
	  FROM [documents].[document] d
	LEFT JOIN [registrations].[UserAccount] u on u.[id] = d.[userAccountId]
	LEFT JOIN [documents].[DocumentInfo] di on di.[documentId] = d.[id]
	 WHERE d.[parentEntityId] = @parentEntityId 
	   AND d.[parentEntityType] = @parentEntityType
		 AND d.[activeTo] IS NULL
		ORDER BY d.[modifiedDate] DESC
END
GO


-- ----------------------------
-- Auto increment value for Document
-- ----------------------------
DBCC CHECKIDENT ('[Documents].[Document]', RESEED, 30)
GO


-- ----------------------------
-- Indexes structure for table Document
-- ----------------------------
CREATE NONCLUSTERED INDEX [IDX_Document_parent]
ON [Documents].[Document] (
  [parentEntityId] ASC,
  [parentEntityType] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table Document
-- ----------------------------
ALTER TABLE [Documents].[Document] ADD CONSTRAINT [PK__Document__3213E83F31DADF25] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

