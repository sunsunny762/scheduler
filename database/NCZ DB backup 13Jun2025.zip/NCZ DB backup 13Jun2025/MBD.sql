/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : MBD

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 11:17:14
*/


-- ----------------------------
-- Table structure for ElectricityConsumption
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[MBD].[ElectricityConsumption]') AND type IN ('U'))
	DROP TABLE [MBD].[ElectricityConsumption]
GO

CREATE TABLE [MBD].[ElectricityConsumption] (
  [MinSQM] int  NULL,
  [MaxSQM] int  NULL,
  [KWHPerSQM] int  NULL,
  [activeFrom] date  NULL,
  [activeTo] date  NULL
)
GO

ALTER TABLE [MBD].[ElectricityConsumption] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of ElectricityConsumption
-- ----------------------------
INSERT INTO [MBD].[ElectricityConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'0', N'49', N'83', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[ElectricityConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'50', N'100', N'55', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[ElectricityConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'101', N'250', N'41', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[ElectricityConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'251', N'1000', N'38', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[ElectricityConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'1001', N'5000', N'40', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[ElectricityConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'5001', NULL, N'44', N'2020-01-01', NULL)
GO


-- ----------------------------
-- Table structure for GasConsumption
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[MBD].[GasConsumption]') AND type IN ('U'))
	DROP TABLE [MBD].[GasConsumption]
GO

CREATE TABLE [MBD].[GasConsumption] (
  [MinSQM] int  NULL,
  [MaxSQM] int  NULL,
  [KWHPerSQM] int  NULL,
  [activeFrom] date  NULL,
  [activeTo] date  NULL
)
GO

ALTER TABLE [MBD].[GasConsumption] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of GasConsumption
-- ----------------------------
INSERT INTO [MBD].[GasConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'0', N'49', N'463', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[GasConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'50', N'100', N'219', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[GasConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'101', N'250', N'135', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[GasConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'251', N'500', N'94', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[GasConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'501', N'1000', N'80', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[GasConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'1001', N'5000', N'69', N'2020-01-01', NULL)
GO

INSERT INTO [MBD].[GasConsumption] ([MinSQM], [MaxSQM], [KWHPerSQM], [activeFrom], [activeTo]) VALUES (N'5001', NULL, N'68', N'2020-01-01', NULL)
GO

