/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : portal

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 11:20:55
*/


-- ----------------------------
-- Table structure for ApplicationUserGrant
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationUserGrant]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationUserGrant]
GO

CREATE TABLE [portal].[ApplicationUserGrant] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [userAccountId] int  NOT NULL,
  [applicationFeatureOptionId] int  NOT NULL,
  [assignedByUserAccountId] int  NULL,
  [assignedDate] datetime DEFAULT getdate() NULL,
  [available] bit  NOT NULL,
  [assignable] bit  NOT NULL
)
GO

ALTER TABLE [portal].[ApplicationUserGrant] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for ApplicationUserRoleGrant
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ApplicationUserRoleGrant]') AND type IN ('U'))
	DROP TABLE [portal].[ApplicationUserRoleGrant]
GO

CREATE TABLE [portal].[ApplicationUserRoleGrant] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [applicationRoleId] int  NOT NULL,
  [userAccountId] int  NOT NULL,
  [assignedByUserAccountId] int  NULL
)
GO

ALTER TABLE [portal].[ApplicationUserRoleGrant] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for BlueAwardSubmissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[BlueAwardSubmissions]') AND type IN ('U'))
	DROP TABLE [portal].[BlueAwardSubmissions]
GO

CREATE TABLE [portal].[BlueAwardSubmissions] (
  [bluesubmissionId] int  IDENTITY(1,1) NOT NULL,
  [jotformId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [status] int  NULL,
  [notes] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dateSubmitted] datetime2(7)  NULL,
  [isProcessed] bit DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[BlueAwardSubmissions] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'status list from dropdownitems',
'SCHEMA', N'portal',
'TABLE', N'BlueAwardSubmissions',
'COLUMN', N'status'
GO


-- ----------------------------
-- Table structure for CertFormSubmissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[CertFormSubmissions]') AND type IN ('U'))
	DROP TABLE [portal].[CertFormSubmissions]
GO

CREATE TABLE [portal].[CertFormSubmissions] (
  [certsubmissionId] int  IDENTITY(1,1) NOT NULL,
  [certId] int  NULL,
  [jotformId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
  [dateSubmitted] datetime2(7)  NULL,
  [userId] int DEFAULT 0 NULL,
  [locationId] int DEFAULT 0 NULL,
  [notes] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
  [isProcessed] bit DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[CertFormSubmissions] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'jotform submission Id',
'SCHEMA', N'portal',
'TABLE', N'CertFormSubmissions',
'COLUMN', N'submissionId'
GO


-- ----------------------------
-- Table structure for Certification
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Certification]') AND type IN ('U'))
	DROP TABLE [portal].[Certification]
GO

CREATE TABLE [portal].[Certification] (
  [certId] int  IDENTITY(1,1) NOT NULL,
  [companyId] int  NULL,
  [progId] int  NULL,
  [startDate] datetime2(7)  NULL,
  [endDate] datetime2(7)  NULL,
  [status] int  NULL,
  [description] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [clickupTaskId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [certYear] int  NULL,
  [isDeleted] bit DEFAULT 0 NULL,
  [dateUpdated] datetime2(7) DEFAULT getdate() NULL,
  [refNumber] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[Certification] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Company
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Company]') AND type IN ('U'))
	DROP TABLE [portal].[Company]
GO

CREATE TABLE [portal].[Company] (
  [companyId] int  IDENTITY(1,1) NOT NULL,
  [companyName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [email] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [registrationNumber] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [phone] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [address] nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [industryType] int  NULL,
  [website] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [status] int  NOT NULL,
  [logo] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [clickupTaskId] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dateCreated] datetime2(7)  NULL,
  [dateUpdated] datetime2(7)  NULL,
  [isDeleted] bit DEFAULT 0 NULL,
  [industryTypeOther] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
  [contactName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [jobTitle] nvarchar(75) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [countryId] int  NULL,
  [nczCustomerDirectory] bit DEFAULT 1 NULL,
  [linkedInPage] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(300) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [portal].[Company] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'dropdownItems groupId=3',
'SCHEMA', N'portal',
'TABLE', N'Company',
'COLUMN', N'countryId'
GO

EXEC sp_addextendedproperty
'MS_Description', N'Show in NCZ Customer Directory',
'SCHEMA', N'portal',
'TABLE', N'Company',
'COLUMN', N'nczCustomerDirectory'
GO


-- ----------------------------
-- Table structure for Location
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Location]') AND type IN ('U'))
	DROP TABLE [portal].[Location]
GO

CREATE TABLE [portal].[Location] (
  [locationId] int  IDENTITY(1,1) NOT NULL,
  [companyId] int  NULL,
  [locationName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isDeleted] bit DEFAULT 0 NULL,
  [dateUpdated] datetime2(7)  NULL
)
GO

ALTER TABLE [portal].[Location] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for NCZDirectory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[NCZDirectory]') AND type IN ('U'))
	DROP TABLE [portal].[NCZDirectory]
GO

CREATE TABLE [portal].[NCZDirectory] (
  [dirItemId] int  IDENTITY(1,1) NOT NULL,
  [companyId] int  NULL,
  [salesName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [salesEmail] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [salesPhone] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [esgName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [esgEmail] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [esgPhone] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [website] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [linkedinPage] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [facebookPage] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [instagramPage] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [logo] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [emissionOffset] nvarchar(5) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [industryType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [companyDescription] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [offersDiscounts] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [customerReference] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [companyName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [certTaskId] nvarchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isVisible] bit DEFAULT 0 NULL,
  [submissionId] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [dateUpdated] datetime2(7) DEFAULT getdate() NULL
)
GO

ALTER TABLE [portal].[NCZDirectory] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for ProgrammeDocuments
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[ProgrammeDocuments]') AND type IN ('U'))
	DROP TABLE [portal].[ProgrammeDocuments]
GO

CREATE TABLE [portal].[ProgrammeDocuments] (
  [progId] int  NOT NULL,
  [documentId] int  NULL,
  [displayName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [displayOrder] smallint DEFAULT 0 NULL,
  [isDeleted] bit DEFAULT 0 NULL
)
GO

ALTER TABLE [portal].[ProgrammeDocuments] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'documents.document.id',
'SCHEMA', N'portal',
'TABLE', N'ProgrammeDocuments',
'COLUMN', N'documentId'
GO


-- ----------------------------
-- Table structure for Users
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[portal].[Users]') AND type IN ('U'))
	DROP TABLE [portal].[Users]
GO

CREATE TABLE [portal].[Users] (
  [userId] int  IDENTITY(1,1) NOT NULL,
  [companyId] int DEFAULT 0 NULL,
  [fullName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [email] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [status] int  NULL,
  [uId] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isDeleted] bit DEFAULT 0 NULL,
  [dateUpdated] datetime2(7)  NULL,
  [phone] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [isEmailVerified] bit DEFAULT 0 NULL,
  [guId] uniqueidentifier DEFAULT newid() NULL
)
GO

ALTER TABLE [portal].[Users] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Auto increment value for ApplicationUserGrant
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationUserGrant]', RESEED, 1)
GO


-- ----------------------------
-- Auto increment value for ApplicationUserRoleGrant
-- ----------------------------
DBCC CHECKIDENT ('[portal].[ApplicationUserRoleGrant]', RESEED, 61)
GO


-- ----------------------------
-- Auto increment value for BlueAwardSubmissions
-- ----------------------------
DBCC CHECKIDENT ('[portal].[BlueAwardSubmissions]', RESEED, 17)
GO


-- ----------------------------
-- Primary Key structure for table BlueAwardSubmissions
-- ----------------------------
ALTER TABLE [portal].[BlueAwardSubmissions] ADD CONSTRAINT [PK__BlueAwar__2D1A9A2BCB09E96C] PRIMARY KEY CLUSTERED ([bluesubmissionId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for CertFormSubmissions
-- ----------------------------
DBCC CHECKIDENT ('[portal].[CertFormSubmissions]', RESEED, 76)
GO


-- ----------------------------
-- Primary Key structure for table CertFormSubmissions
-- ----------------------------
ALTER TABLE [portal].[CertFormSubmissions] ADD CONSTRAINT [PK__Submissi__B1DEEF52892BFE63] PRIMARY KEY CLUSTERED ([certsubmissionId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Certification
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Certification]', RESEED, 19)
GO


-- ----------------------------
-- Primary Key structure for table Certification
-- ----------------------------
ALTER TABLE [portal].[Certification] ADD CONSTRAINT [PK__Certific__D2C93639D8E81FBD] PRIMARY KEY CLUSTERED ([certId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Company
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Company]', RESEED, 50)
GO


-- ----------------------------
-- Primary Key structure for table Company
-- ----------------------------
ALTER TABLE [portal].[Company] ADD CONSTRAINT [PK__Company__AD545990B7F019E0] PRIMARY KEY CLUSTERED ([companyId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Location
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Location]', RESEED, 19)
GO


-- ----------------------------
-- Primary Key structure for table Location
-- ----------------------------
ALTER TABLE [portal].[Location] ADD CONSTRAINT [PK__Location__30646B6EC3CED846] PRIMARY KEY CLUSTERED ([locationId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for NCZDirectory
-- ----------------------------
DBCC CHECKIDENT ('[portal].[NCZDirectory]', RESEED, 99)
GO


-- ----------------------------
-- Primary Key structure for table NCZDirectory
-- ----------------------------
ALTER TABLE [portal].[NCZDirectory] ADD CONSTRAINT [PK__NCZDirec__50A58BBE9C5DB8D3] PRIMARY KEY CLUSTERED ([dirItemId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Users
-- ----------------------------
DBCC CHECKIDENT ('[portal].[Users]', RESEED, 66)
GO


-- ----------------------------
-- Primary Key structure for table Users
-- ----------------------------
ALTER TABLE [portal].[Users] ADD CONSTRAINT [PK__Users__CB9A1CFFF5B6B40D] PRIMARY KEY CLUSTERED ([userId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

