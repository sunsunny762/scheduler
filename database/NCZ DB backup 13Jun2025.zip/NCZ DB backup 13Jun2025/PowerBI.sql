/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : PowerBI

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 11:22:29
*/


-- ----------------------------
-- Table structure for PowerBIExportLog
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[PowerBIExportLog]') AND type IN ('U'))
	DROP TABLE [PowerBI].[PowerBIExportLog]
GO

CREATE TABLE [PowerBI].[PowerBIExportLog] (
  [Id] int  IDENTITY(1,1) NOT NULL,
  [submissionId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [exportId] nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [emailTo] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [resourceLocation] nvarchar(300) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [reportPDFFileName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [status] int DEFAULT 0 NULL,
  [statusUpdatedOn] datetime  NULL,
  [companyName] nvarchar(60) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [productName] nvarchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [hasError] int DEFAULT NULL NULL,
  [errorDetails] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
  [documentId] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [customerId] int  NULL
)
GO

ALTER TABLE [PowerBI].[PowerBIExportLog] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- View structure for vCertificationTasks
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[vCertificationTasks]') AND type IN ('V'))
	DROP VIEW [PowerBI].[vCertificationTasks]
GO

CREATE VIEW [PowerBI].[vCertificationTasks] AS SELECT t.id
			,t.name
			,ef.id as [emissionProfileId]
			,ef.name as [emissionProfile]
FROM [clickup].[Task] t
JOIN [Emissions].[EmissionProfile] ef on ef.active = 1
WHERE t.listId in ('901200207978','901205502657','901205524266','901206607383','901206788692','901206788699','901206788725','901206501310')
	AND t.parentId IS NULL 
	AND (t.activeTo > [Utilities].[DateToEpoch](GetDate()) OR t.activeTo is NULL);
GO


-- ----------------------------
-- View structure for vCompany
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[vCompany]') AND type IN ('V'))
	DROP VIEW [PowerBI].[vCompany]
GO

CREATE VIEW [PowerBI].[vCompany] AS SELECT 
			submissionId, 
			BAQ_CompanyName,
			IIf (BAQ_CompanyLogo is null, 
            'https://nczdocsprod.blob.core.windows.net/customer-logo/blank_powerbi.png', 
            Concat(BAQ_CompanyLogo, '?apiKey=964f4219f34a79448399110d86da47f4')
          ) as BAQ_CompanyLogo
FROM (
    SELECT submissionid, [key], [value]
    FROM Forms.BlueAwardQuestionnaire
) AS SourceTable
PIVOT (
    MAX([value])
    FOR [key] IN (
			BAQ_CompanyName,
			BAQ_CompanyLogo
	)
) AS PivotTable;
GO


-- ----------------------------
-- View structure for vSilverCertifications_Portal
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[vSilverCertifications_Portal]') AND type IN ('V'))
	DROP VIEW [PowerBI].[vSilverCertifications_Portal]
GO

CREATE VIEW [PowerBI].[vSilverCertifications_Portal] AS Select DISTINCT C.companyName, P.progName, Cert.certId as certificationId, CFS.submissionId,
      CONCAT(
            ProgName, ' (',  ISNULL(Cert.refNumber, CAST(Cert.certYear AS VARCHAR)),  ')'
          ) AS CertificationInfo,
      ef.id as emissionProfileId, ef.name as emissionProfile,
      IIf (C.logo is null, 
            'https://nczdocsprod.blob.core.windows.net/customer-logo/blank_powerbi.png', 
            IIF(C.logo like '%app.neutralcarbonzone.com%',
                Concat(C.logo, '?apiKey=964f4219f34a79448399110d86da47f4'),
                C.logo
               )
          ) as logo
From portal.Certification as Cert 
INNER JOIN portal.Programme as P on (P.progId = Cert.progId and Cert.isDeleted=0)
INNER JOIN portal.Company as C on (C.companyId = Cert.companyId and C.status=1 and C.isDeleted=0)
INNER JOIN portal.CertFormSubmissions as CFS on (Cert.certId = CFS.certId and CFS.jotformId='241290444812856' and Cert.progId=2 and CFS.isProcessed=1)
INNER JOIN [Emissions].[EmissionProfile] ef on (ef.active = 1)
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Add
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Add]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[PowerBI].[spPowerBIExportQueue_Add]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Add]
	 @submissionId nvarchar (25)
	,@emailTo nvarchar (255)
	,@companyName nvarchar(60)
	,@productName nvarchar(30)
AS
BEGIN
	SET NOCOUNT ON;

  IF Not Exists (SELECT * FROM PowerBI.PowerBIExportLog where submissionId=@submissionId)
  BEGIN
    Declare @customerId int = (Select  top 1 id from Dimension.Customer where name = @companyName ORDER BY active desc);
    Set @productName = (Select Case @productName When 'Blue Award' then 'BLUE' When 'Silver Certification' then 'SILVER' When 'Gold Certification' then 'GOLD' end);
    
    INSERT into PowerBI.PowerBIExportLog (customerId, submissionId, emailTo, companyName, productName, statusUpdatedOn) 
    VALUES (@customerId, @submissionId, @emailTo, @companyName, @productName, GETDATE());
  END

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Completed
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Completed]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[PowerBI].[spPowerBIExportQueue_Completed]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Completed]
	 @submissionId nvarchar (25)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog set status = 1, statusUpdatedOn = GETDATE(), hasError = 0
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Downloaded
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Downloaded]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[PowerBI].[spPowerBIExportQueue_Downloaded]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Downloaded]
	 @submissionId nvarchar (25)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog set status = 4, statusUpdatedOn = GETDATE(), hasError = 0
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Error
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Error]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[PowerBI].[spPowerBIExportQueue_Error]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Error]
	 @submissionId nvarchar (25),
   @errorDetails nvarchar(500)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog set hasError = 1, errorDetails = @errorDetails
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Generated
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Generated]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[PowerBI].[spPowerBIExportQueue_Generated]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Generated]
	 @submissionId nvarchar (25)
	,@resourceLocation nvarchar (300)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog 
    set resourceLocation = @resourceLocation, 
        reportPDFFileName = concat('BAQ_',FORMAT(GETDATE(), 'dd.MM.yyyy', 'en-UK'),'_',submissionId,'.pdf'),
        -- reportPDFFileName = concat(SUBSTRING(REPLACE(companyName, ' ','_'),0,20), '-', submissionId, '.pdf'),
        status = 3, statusUpdatedOn = GETDATE(), hasError = 0
  WHERE submissionId = @submissionId;
  
  Select * from PowerBI.PowerBIExportLog WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_GetList
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_GetList]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[PowerBI].[spPowerBIExportQueue_GetList]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_GetList]
AS
BEGIN
	SET NOCOUNT ON;
  
      -- Reset Generated(3) reports to Pending(0), if not downloaded(3) within 24 hours
      Update PowerBI.PowerBIExportLog 
        Set status = 0
      Where status = 3 And CAST(statusUpdatedOn as DATE) <= CAST(DATEADD(day, -1, GETDATE()) as DATE);
  
      -- Get List of incomplete export jobs, (Pending(0) requests should have 24 hours passed)
      Select * from PowerBI.PowerBIExportLog 
      Where 
         ((status = 0 and CAST(statusUpdatedOn as DATE) <= CAST(DATEADD(day, -1, GETDATE()) as DATE)) OR (status > 1))
      ORDER BY status, statusUpdatedOn;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Requested
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Requested]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[PowerBI].[spPowerBIExportQueue_Requested]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Requested]
	 @submissionId nvarchar (25)
	,@exportId nvarchar (200)
AS
BEGIN
	SET NOCOUNT ON;
	
  UPDATE PowerBI.PowerBIExportLog set exportId = @exportId, status = 2, statusUpdatedOn = GETDATE(), hasError = 0
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- procedure structure for spPowerBIExportQueue_Uploaded
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[PowerBI].[spPowerBIExportQueue_Uploaded]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[PowerBI].[spPowerBIExportQueue_Uploaded]
GO

CREATE PROCEDURE [PowerBI].[spPowerBIExportQueue_Uploaded]
	 @submissionId nvarchar (25),
   @documentId nvarchar(25)
AS
BEGIN
	SET NOCOUNT ON;
	-- File uploaded on storage space
  UPDATE PowerBI.PowerBIExportLog set status = 5, statusUpdatedOn = GETDATE(), hasError = 0,
        documentId = @documentId
  WHERE submissionId = @submissionId;

END
GO


-- ----------------------------
-- Auto increment value for PowerBIExportLog
-- ----------------------------
DBCC CHECKIDENT ('[PowerBI].[PowerBIExportLog]', RESEED, 82)
GO


-- ----------------------------
-- Primary Key structure for table PowerBIExportLog
-- ----------------------------
ALTER TABLE [PowerBI].[PowerBIExportLog] ADD CONSTRAINT [PK__PowerBIE__3214EC0771B2CC9B] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

