/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : DataModel

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 10:38:12
*/


-- ----------------------------
-- Table structure for Commissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[Commissions]') AND type IN ('U'))
	DROP TABLE [DataModel].[Commissions]
GO

CREATE TABLE [DataModel].[Commissions] (
  [id] int  NOT NULL,
  [productId] int  NULL,
  [name] nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [commission] decimal(5,4)  NULL,
  [validFrom] date  NULL,
  [validTo] date  NULL
)
GO

ALTER TABLE [DataModel].[Commissions] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for PeopleSnapshot
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[PeopleSnapshot]') AND type IN ('U'))
	DROP TABLE [DataModel].[PeopleSnapshot]
GO

CREATE TABLE [DataModel].[PeopleSnapshot] (
  [SnapshotDate] date  NULL,
  [status] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [category] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [groupName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [assignee] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [TaskCount] int  NULL,
  [Overdue] int  NULL,
  [OverdueValue] numeric(10,2)  NULL,
  [TotalValue] numeric(10,2)  NULL,
  [AvgValue] numeric(10,2)  NULL,
  [MissingInfo] int  NULL
)
GO

ALTER TABLE [DataModel].[PeopleSnapshot] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for ProductCosts
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[ProductCosts]') AND type IN ('U'))
	DROP TABLE [DataModel].[ProductCosts]
GO

CREATE TABLE [DataModel].[ProductCosts] (
  [id] int  NOT NULL,
  [productId] int  NULL,
  [costName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [amount] numeric(10,2)  NULL,
  [validFrom] date  NULL,
  [validTo] date  NULL
)
GO

ALTER TABLE [DataModel].[ProductCosts] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Products
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[Products]') AND type IN ('U'))
	DROP TABLE [DataModel].[Products]
GO

CREATE TABLE [DataModel].[Products] (
  [id] int  NOT NULL,
  [name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [minPrice] numeric(10,2)  NULL,
  [rrp] numeric(10,2)  NULL,
  [validFrom] date  NULL,
  [validTo] date  NULL
)
GO

ALTER TABLE [DataModel].[Products] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for ReportCategory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[ReportCategory]') AND type IN ('U'))
	DROP TABLE [DataModel].[ReportCategory]
GO

CREATE TABLE [DataModel].[ReportCategory] (
  [categoryId] int  NOT NULL,
  [categoryName] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [formId] int  NULL
)
GO

ALTER TABLE [DataModel].[ReportCategory] SET (LOCK_ESCALATION = TABLE)
GO

EXEC sp_addextendedproperty
'MS_Description', N'id from dimension.Form, if null then Global Category',
'SCHEMA', N'DataModel',
'TABLE', N'ReportCategory',
'COLUMN', N'formId'
GO

EXEC sp_addextendedproperty
'MS_Description', N'For Report, Emission activities grouping under a category',
'SCHEMA', N'DataModel',
'TABLE', N'ReportCategory'
GO


-- ----------------------------
-- Table structure for ReportCategoryMapping
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[ReportCategoryMapping]') AND type IN ('U'))
	DROP TABLE [DataModel].[ReportCategoryMapping]
GO

CREATE TABLE [DataModel].[ReportCategoryMapping] (
  [categoryId] int  NOT NULL,
  [emissionActivityId] int  NULL
)
GO

ALTER TABLE [DataModel].[ReportCategoryMapping] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- View structure for BenchmarksByCategory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[BenchmarksByCategory]') AND type IN ('V'))
	DROP VIEW [DataModel].[BenchmarksByCategory]
GO

CREATE VIEW [DataModel].[BenchmarksByCategory] AS WITH CET_INPUT_TOTALS_BY_ACTIVITY
	AS (
		SELECT
				CONVERT(DATE,GETDATE()) AS Date,
				formName,  
				PercentageOfTotal,
				e.EF, 
				e.WTT, 
				e.TND, 
				e.TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = 2
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY
	AS (
				SELECT
				CONVERT(DATE,GETDATE()) AS Date,
				formName AS Category,  
				SUM(PercentageOfTotal*ef) AS EF,
				SUM(PercentageOfTotal*wtt) AS WTT,
				SUM(PercentageOfTotal*tnd) AS TND,
				SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CET_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	
	SELECT *
	FROM CTE_BENCHMARKS_BY_CATEGORY;
GO


-- ----------------------------
-- View structure for BlueAwardSubmissionData
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[BlueAwardSubmissionData]') AND type IN ('V'))
	DROP VIEW [DataModel].[BlueAwardSubmissionData]
GO

CREATE VIEW [DataModel].[BlueAwardSubmissionData] AS SELECT 
			submissionId, 
      BAQ_uniqueId,
			BAQ_YourName, 
			BAQ_Email, 
      BAQ_Phone,
			BAQ_CompanyName,
			BAQ_CompanyWebsite,
			BAQ_CompanyCountry,
			BAQ_CompanyRegistration,
			BAQ_CompanyDescription,
			BAQ_JobTitle,
			BAQ_CompanyIndustry,
      BAQ_OtherIndustry,
			BAQ_CompanyLinkedin,
			BAQ_CompanyLogo,
			BAQ_ReportStartDate,
			BAQ_TotalHeadcount,
			BAQ_OfficeHeadcount,
			BAQ_CompanyRevenue,
			BAQ_Currency,
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office,
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other,
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office,
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other,
			BAQ_WorkingDaysAndCommuting_AvgDistance_Office,
			BAQ_WorkingDaysAndCommuting_AvgDistance_Other,
			BAQ_OfficeStaffPublicTransport,
			BAQ_OtherStaffPublicTransport,
			BAQ_TotalSpend,
			BAQ_PercentageSpendOnServices,
			BAQ_CompanyVehiclesMileage_Cars,
			BAQ_CompanyVehiclesMileage_Vans,
			BAQ_CompanyVehiclesMileage_HGVs,
			BAQ_BusinessTravel_Domestic_Daily,
			BAQ_BusinessTravel_International_Daily,
			BAQ_BusinessTravel_Domestic_Weekly,
			BAQ_BusinessTravel_International_Weekly,
			BAQ_BusinessTravel_Domestic_Monthly,
			BAQ_BusinessTravel_International_Monthly,
			BAQ_BusinessTravel_Domestic_Quarterly,
			BAQ_BusinessTravel_International_Quarterly,
			[BAQ_BusinessTravel_Domestic_Bi-annually],
			[BAQ_BusinessTravel_International_Bi-annually],
			BAQ_GoodsReceived_International_Daily,
			BAQ_GoodsReceived_International_Monthly,
			BAQ_GoodsReceived_International_Quarterly,
			BAQ_GoodsReceived_International_Weekly,
			BAQ_GoodsReceived_Local_Daily,
			BAQ_GoodsReceived_Local_Monthly,
			BAQ_GoodsReceived_Local_Quarterly,
			BAQ_GoodsReceived_Local_Weekly,
			BAQ_GoodsReceived_National_Daily,
			BAQ_GoodsReceived_National_Monthly,
			BAQ_GoodsReceived_National_Quarterly,
			BAQ_GoodsReceived_National_Weekly,
			BAQ_GoodsReceived_Unknown_Daily,
			BAQ_GoodsReceived_Unknown_Monthly,
			BAQ_GoodsReceived_Unknown_Quarterly,
			BAQ_GoodsReceived_Unknown_Weekly,
			BAQ_GoodsSent_International_Daily,
			BAQ_GoodsSent_International_Monthly,
			BAQ_GoodsSent_International_Quarterly,
			BAQ_GoodsSent_International_Weekly,
			BAQ_GoodsSent_Local_Daily,
			BAQ_GoodsSent_Local_Monthly,
			BAQ_GoodsSent_Local_Quarterly,
			BAQ_GoodsSent_Local_Weekly,
			BAQ_GoodsSent_National_Daily,
			BAQ_GoodsSent_National_Monthly,
			BAQ_GoodsSent_National_Quarterly,
			BAQ_GoodsSent_National_Weekly,
			BAQ_GoodsSent_Unknown_Daily,
			BAQ_GoodsSent_Unknown_Monthly,
			BAQ_GoodsSent_Unknown_Quarterly,
			BAQ_GoodsSent_Unknown_Weekly

FROM (
    SELECT submissionid, [key], [value]
    FROM Forms.BlueAwardQuestionnaire
) AS SourceTable
PIVOT (
    MAX([value])
    FOR [key] IN (
      BAQ_uniqueId,
			BAQ_YourName, 
			BAQ_Email, 
      BAQ_Phone,
			BAQ_CompanyName,
			BAQ_CompanyWebsite,
			BAQ_CompanyCountry,
			BAQ_CompanyRegistration,
			BAQ_CompanyDescription,
			BAQ_JobTitle,
			BAQ_CompanyIndustry,
      BAQ_OtherIndustry,
			BAQ_CompanyLinkedin,
			BAQ_CompanyLogo,
			BAQ_ReportStartDate,
			BAQ_TotalHeadcount,
			BAQ_OfficeHeadcount,
			BAQ_CompanyRevenue,
			BAQ_Currency,
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office,
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other,
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office,
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other,
			BAQ_WorkingDaysAndCommuting_AvgDistance_Office,
			BAQ_WorkingDaysAndCommuting_AvgDistance_Other,
			BAQ_OfficeStaffPublicTransport,
			BAQ_OtherStaffPublicTransport,
			BAQ_TotalSpend,
			BAQ_PercentageSpendOnServices,
			BAQ_CompanyVehiclesMileage_Cars,
			BAQ_CompanyVehiclesMileage_Vans,
			BAQ_CompanyVehiclesMileage_HGVs,
			BAQ_BusinessTravel_Domestic_Daily,
			BAQ_BusinessTravel_International_Daily,
			BAQ_BusinessTravel_Domestic_Weekly,
			BAQ_BusinessTravel_International_Weekly,
			BAQ_BusinessTravel_Domestic_Monthly,
			BAQ_BusinessTravel_International_Monthly,
			BAQ_BusinessTravel_Domestic_Quarterly,
			BAQ_BusinessTravel_International_Quarterly,
			[BAQ_BusinessTravel_Domestic_Bi-annually],
			[BAQ_BusinessTravel_International_Bi-annually],
			BAQ_GoodsReceived_International_Daily,
			BAQ_GoodsReceived_International_Monthly,
			BAQ_GoodsReceived_International_Quarterly,
			BAQ_GoodsReceived_International_Weekly,
			BAQ_GoodsReceived_Local_Daily,
			BAQ_GoodsReceived_Local_Monthly,
			BAQ_GoodsReceived_Local_Quarterly,
			BAQ_GoodsReceived_Local_Weekly,
			BAQ_GoodsReceived_National_Daily,
			BAQ_GoodsReceived_National_Monthly,
			BAQ_GoodsReceived_National_Quarterly,
			BAQ_GoodsReceived_National_Weekly,
			BAQ_GoodsReceived_Unknown_Daily,
			BAQ_GoodsReceived_Unknown_Monthly,
			BAQ_GoodsReceived_Unknown_Quarterly,
			BAQ_GoodsReceived_Unknown_Weekly,
			BAQ_GoodsSent_International_Daily,
			BAQ_GoodsSent_International_Monthly,
			BAQ_GoodsSent_International_Quarterly,
			BAQ_GoodsSent_International_Weekly,
			BAQ_GoodsSent_Local_Daily,
			BAQ_GoodsSent_Local_Monthly,
			BAQ_GoodsSent_Local_Quarterly,
			BAQ_GoodsSent_Local_Weekly,
			BAQ_GoodsSent_National_Daily,
			BAQ_GoodsSent_National_Monthly,
			BAQ_GoodsSent_National_Quarterly,
			BAQ_GoodsSent_National_Weekly,
			BAQ_GoodsSent_Unknown_Daily,
			BAQ_GoodsSent_Unknown_Monthly,
			BAQ_GoodsSent_Unknown_Quarterly,
			BAQ_GoodsSent_Unknown_Weekly
	)
) AS PivotTable;
GO


-- ----------------------------
-- View structure for BlueAwardSubmissionDetails
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[BlueAwardSubmissionDetails]') AND type IN ('V'))
	DROP VIEW [DataModel].[BlueAwardSubmissionDetails]
GO

CREATE VIEW [DataModel].[BlueAwardSubmissionDetails] AS SELECT 
			submissionId, 
      BAQ_uniqueId,
			BAQ_YourName AS 'Submitted by', 
			BAQ_Email AS 'Email', 
      BAQ_Phone as 'Phone',
			BAQ_JobTitle AS 'Job Title',
			BAQ_CompanyName AS 'Company Name',
			BAQ_CompanyCountry AS 'Country',
			BAQ_CompanyRegistration AS 'Company Registration Number',
			BAQ_CompanyDescription as 'Company Description',
			BAQ_CompanyIndustry AS 'Industry',
			BAQ_CompanyWebsite AS 'Company Website',
			BAQ_CompanyLinkedin AS 'Company LinkedIn',
			BAQ_CompanyLogo AS 'Company Logo',
			FORMAT(DATEADD(MONTH, -11, CAST(BAQ_ReportStartDate AS DATETIME)), 'yyyy-MM-dd') AS 'Report Start Date',
			FORMAT(CAST(BAQ_ReportStartDate AS DATETIME), 'yyyy-MM-dd') AS 'Report End Date',
			CASE WHEN BAQ_TotalHeadcount IS NULL OR BAQ_TotalHeadcount = 0 THEN 1 ELSE BAQ_TotalHeadcount END AS 'Total Headcount',
			BAQ_OfficeHeadcount AS 'Office Headcount',
			CONVERT(BIGINT,BAQ_TotalHeadcount)-CONVERT(BIGINT,BAQ_OfficeHeadcount) AS 'Other Headcount',
			CASE WHEN BAQ_CompanyRevenue IS NULL OR BAQ_CompanyRevenue = '0' THEN '1' ELSE BAQ_CompanyRevenue END AS 'Company Revenue',
			BAQ_Currency as 'Currency',
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office AS 'Office Staff Avg Working Days',
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other AS 'Other Staff Avg Working Days',
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office AS 'Office Staff Avg Commuting Days',
			BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other AS 'Other Staff Avg Commuting Days',
			BAQ_WorkingDaysAndCommuting_AvgDistance_Office AS 'Office Staff Avg Commuting Distance',
			BAQ_WorkingDaysAndCommuting_AvgDistance_Other AS 'Other Staff Avg Commuting Distance',
			BAQ_OfficeStaffPublicTransport AS 'Percentage of Office Staff Commuting via Public Transport',
			BAQ_OtherStaffPublicTransport AS 'Percentage of Other Staff Commuting via Public Transport',
			BAQ_TotalSpend AS 'Total Spend',
			BAQ_PercentageSpendOnServices AS 'Percentage of Spend on Services',
			100-CONVERT(BIGINT,BAQ_PercentageSpendOnServices) AS 'Percentage of Spend on Goods',
			BAQ_CompanyVehiclesMileage_Cars AS 'Company Car Mileage',
			BAQ_CompanyVehiclesMileage_Vans AS 'Company Van Mileage',
			BAQ_CompanyVehiclesMileage_HGVs AS 'Company HGV Mileage',
			BAQ_BusinessTravel_Domestic_Daily AS 'Daily Domestic Travel',
			BAQ_BusinessTravel_International_Daily AS 'Daily International Travel',
			BAQ_BusinessTravel_Domestic_Weekly AS 'Weekly Domestic Travel',
			BAQ_BusinessTravel_International_Weekly AS 'Weekly International Travel',
			BAQ_BusinessTravel_Domestic_Monthly AS 'Monthly Domestic Travel',
			BAQ_BusinessTravel_International_Monthly AS 'Monthly International Travel',
			BAQ_BusinessTravel_Domestic_Quarterly AS 'Quarterly Domestic Travel',
			BAQ_BusinessTravel_International_Quarterly AS 'Quarterly International Travel',
			[BAQ_BusinessTravel_Domestic_Bi-annually] AS 'Bi-annual Domestic Travel',
			[BAQ_BusinessTravel_International_Bi-annually] AS 'Bi-annual International Travel'
FROM [DataModel].[BlueAwardSubmissionData]
GO


-- ----------------------------
-- View structure for BlueAwardSubmissionIDs
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[BlueAwardSubmissionIDs]') AND type IN ('V'))
	DROP VIEW [DataModel].[BlueAwardSubmissionIDs]
GO

CREATE VIEW [DataModel].[BlueAwardSubmissionIDs] AS SELECT [submissionId] as [SubmissionId]
	FROM [Forms].[JotformRawResponse] 
 WHERE [formId] = '241290444812856'
GO


-- ----------------------------
-- View structure for CertificationList
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[CertificationList]') AND type IN ('V'))
	DROP VIEW [DataModel].[CertificationList]
GO

CREATE VIEW [DataModel].[CertificationList] AS WITH CTE_LIST
	 AS
	 (
	 SELECT --TOP 10 
			c.name AS Task,
			c.status AS TaskStatus,
			CONVERT(NUMERIC(10,2),cf_taskvalue.taskvalue) AS TaskValue,
			CASE WHEN cf_contractstart.contractstart IS NULL THEN NULL ELSE CONVERT(DATE,utilities.EpochToDate(cf_contractstart.contractstart)) END AS ContractStart,
			CASE WHEN c.duedate IS NULL THEN NULL ELSE CONVERT(DATE,utilities.EpochToDate(c.duedate)) END AS DueDate,
			b.name AS Buyer,
			cf_industry.industry AS Industry,
			u.name AS Seller,
			cf_leadsource.leadsource AS LeadSource,
			cf_product.product AS Product,
			Utilities.GetProductCosts(CONVERT(DATE,utilities.EpochToDate(cf_contractstart.contractstart)),cf_product.product,'NCZ Fee') AS NCZFee,
			Utilities.GetProductCosts(CONVERT(DATE,utilities.EpochToDate(cf_contractstart.contractstart)),cf_product.product,NULL) AS AllCosts--,
			--CONVERT(NUMERIC(10,2),cf_taskvalue.taskvalue) - Utilities.GetProductCosts(CONVERT(DATE,utilities.EpochToDate(cf_contractstart.contractstart)),cf_product.product,NULL) AS Profit


		FROM clickup.Task t
   LEFT JOIN clickup.CertificationBuyer cb ON t.id = cb.certificationTaskId
   LEFT	JOIN clickup.Task c ON c.id = ISNULL(cb.certificationTaskId,t.id)
   LEFT JOIN clickup.Task b ON b.id = cb.buyerTaskId
   LEFT JOIN clickup.Assignee a ON a.taskId = b.id
   LEFT JOIN clickup.[User] u ON u.id = a.userid
   	   OUTER APPLY (
	SELECT [value] as [TaskValue]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = c.[id] AND cf.[name] = 'Current Task Value'
) as cf_taskvalue(taskvalue)
	OUTER APPLY (
	SELECT [value] as [ContractStart]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = c.[id] AND cf.[name] = 'Contract Start'
) as cf_contractstart(contractstart)
	OUTER APPLY (
	SELECT [value] as [Product]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = c.[id] AND cf.[name] = 'Product' --change to product
) as cf_product(product)
	OUTER APPLY (
	SELECT [value] as [LeadSource]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = b.[id] AND cf.[name] = 'Lead Source'
) as cf_leadsource(leadsource)
	OUTER APPLY (
	SELECT [value] as [Product]
		FROM [clickup].[CustomField] cf 
	WHERE cf.[taskId] = c.[id] AND cf.[name] = 'Industry' 
) as cf_industry(industry)
WHERE t.listId = 901200207978
AND t.parentiD IS NULL
AND t.activeTo IS NULL
)
SELECT Task,
		TaskStatus,
		TaskValue,
		ContractStart,
		DueDate,
		Buyer,
		Industry,
		Seller,
		LeadSource,
		Product,
		AllCosts-NCZFee AS Costs,
		NCZFee,
		(TaskValue-AllCosts) AS Profit,
		--Profit + CASE WHEN (TaskValue-AllCosts) < 0 THEN NCZMargin ELSE 0 END AS Profit,
		--CASE WHEN (TaskValue-AllCosts) < 0 THEN 0 ELSE NCZMargin END AS NCZMargin,
		CASE WHEN Utilities.GetCommissionCosts(ISNULL(ContractStart,GETDATE()),Product,'Salesperson',(TaskValue-AllCosts)) < 0 THEN 0 ELSE Utilities.GetCommissionCosts(ISNULL(ContractStart,GETDATE()),Product,'Salesperson',(TaskValue-AllCosts)) END AS SalesCommission,
		CASE WHEN Utilities.GetCommissionCosts(ISNULL(ContractStart,GETDATE()),Product,'Referrer',(TaskValue-AllCosts)) < 0 THEN 0 ELSE Utilities.GetCommissionCosts(ISNULL(ContractStart,GETDATE()),Product,'Referrer',(TaskValue-AllCosts)) END AS ReferralFee,
		CASE WHEN Utilities.GetCommissionCosts(ISNULL(ContractStart,GETDATE()),Product,'Ops',(TaskValue-AllCosts)) < 0 THEN 0 ELSE Utilities.GetCommissionCosts(ISNULL(ContractStart,GETDATE()),Product,'Ops',(TaskValue-AllCosts)) END AS OpsCommission,
		CASE WHEN Utilities.GetCommissionCosts(ISNULL(ContractStart,GETDATE()),Product,'Tech',(TaskValue-AllCosts)) < 0 THEN 0 ELSE Utilities.GetCommissionCosts(ISNULL(ContractStart,GETDATE()),Product,'Tech',(TaskValue-AllCosts)) END AS TechCommission

FROM CTE_LIST
GO


-- ----------------------------
-- View structure for GoldAwardSubmissionData
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[GoldAwardSubmissionData]') AND type IN ('V'))
	DROP VIEW [DataModel].[GoldAwardSubmissionData]
GO

CREATE VIEW [DataModel].[GoldAwardSubmissionData] AS SELECT 
			submissionId, 
      BAQ_uniqueId,
			BAQ_YourName, 
			BAQ_Email, 
      BAQ_Phone,
			BAQ_CompanyName,
			BAQ_CompanyWebsite,
			BAQ_CompanyCountry,
			BAQ_CompanyRegistration,
			BAQ_CompanyDescription,
			BAQ_JobTitle,
			BAQ_CompanyIndustry,
      BAQ_OtherIndustry,
			BAQ_CompanyLinkedin,
			BAQ_CompanyLogo,
			BAQ_ReportStartDate,
			BAQ_TotalHeadcount,
			BAQ_OfficeHeadcount,
			BAQ_CompanyRevenue,
			BAQ_Currency
FROM (
    SELECT submissionid, [key], [value]
    FROM Forms.GoldAwardQuestionnaire
) AS SourceTable
PIVOT (
    MAX([value])
    FOR [key] IN (
      BAQ_uniqueId,
			BAQ_YourName, 
			BAQ_Email, 
      BAQ_Phone,
			BAQ_CompanyName,
			BAQ_CompanyWebsite,
			BAQ_CompanyCountry,
			BAQ_CompanyRegistration,
			BAQ_CompanyDescription,
			BAQ_JobTitle,
			BAQ_CompanyIndustry,
      BAQ_OtherIndustry,
			BAQ_CompanyLinkedin,
			BAQ_CompanyLogo,
			BAQ_ReportStartDate,
			BAQ_TotalHeadcount,
			BAQ_OfficeHeadcount,
			BAQ_CompanyRevenue,
			BAQ_Currency
	)
) AS PivotTable;
GO


-- ----------------------------
-- View structure for InputTotalsByActivity
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[InputTotalsByActivity]') AND type IN ('V'))
	DROP VIEW [DataModel].[InputTotalsByActivity]
GO

CREATE VIEW [DataModel].[InputTotalsByActivity] AS WITH CTE_SUMBYFORM
AS
(
SELECT CASE 
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId NOT IN (357,358,359) THEN 'Commuting'
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId IN (357,358,359) THEN 'Home Working'
			WHEN formName = 'Business Travel'
				AND emissionactivityId IN (228,234,235,236,237,238,239,240,241) AND dataUnit in ('Kilometers (KM)', 'Miles (M)') THEN 'Business Travel - International (KM)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Business Travel - Domestic (KM)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'Currency' THEN 'Business Travel - Domestic (Currency)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Diesel' THEN 'Business Travel - Domestic (No of litre - Diesel)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Petrol' THEN 'Business Travel - Domestic (No of litre - Petrol)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of Nights' THEN 'Business Travel - Domestic (Hotel Stay)'
			WHEN formName = 'Company Vehicles' AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Company Vehicles (KM)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'Currency' THEN 'Company Vehicles (Currency)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Diesel' THEN 'Company Vehicles (No of litre - Diesel)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Petrol' THEN 'Company Vehicles (No of litre - Petrol)'
			ELSE formName END AS formname,
	SUM(userInput*conversionFactor) input
  FROM [DataModel].[vCertificationSubsmissions]
  WHERE (ISNULL(dataUnit,'abc') <> 'Currency' OR formname = 'Purchased Goods and Services')
  GROUP BY CASE 
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId NOT IN (357,358,359) THEN 'Commuting'
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId IN (357,358,359) THEN 'Home Working'
			WHEN formName = 'Business Travel'
				AND emissionactivityId IN (228,234,235,236,237,238,239,240,241) AND dataUnit in ('Kilometers (KM)', 'Miles (M)') THEN 'Business Travel - International (KM)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Business Travel - Domestic (KM)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'Currency' THEN 'Business Travel - Domestic (Currency)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Diesel' THEN 'Business Travel - Domestic (No of litre - Diesel)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Petrol' THEN 'Business Travel - Domestic (No of litre - Petrol)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of Nights' THEN 'Business Travel - Domestic (Hotel Stay)'
			WHEN formName = 'Company Vehicles' AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Company Vehicles (KM)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'Currency' THEN 'Company Vehicles (Currency)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Diesel' THEN 'Company Vehicles (No of litre - Diesel)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Petrol' THEN 'Company Vehicles (No of litre - Petrol)'
			ELSE formName END
 ),
 CTE_SUM_BYACTIVITY
 AS
 (
SELECT CASE 
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId NOT IN (357,358,359) THEN 'Commuting'
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId IN (357,358,359) THEN 'Home Working'
			WHEN formName = 'Business Travel'
				AND emissionactivityId IN (228,234,235,236,237,238,239,240,241) AND dataUnit in ('Kilometers (KM)', 'Miles (M)') THEN 'Business Travel - International (KM)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Business Travel - Domestic (KM)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'Currency' THEN 'Business Travel - Domestic (Currency)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Diesel' THEN 'Business Travel - Domestic (No of litre - Diesel)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Petrol' THEN 'Business Travel - Domestic (No of litre - Petrol)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of Nights' THEN 'Business Travel - Domestic (Hotel Stay)'
			WHEN formName = 'Company Vehicles' AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Company Vehicles (KM)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'Currency' THEN 'Company Vehicles (Currency)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Diesel' THEN 'Company Vehicles (No of litre - Diesel)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Petrol' THEN 'Company Vehicles (No of litre - Petrol)'
			ELSE formName END AS formname,emissionActivityName,emissionActivityId,SUM(userInput*conversionFactor) input 
  FROM [DataModel].[vCertificationSubsmissions]
  GROUP BY CASE 
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId NOT IN (357,358,359) THEN 'Commuting'
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId IN (357,358,359) THEN 'Home Working'
			WHEN formName = 'Business Travel'
				AND emissionactivityId IN (228,234,235,236,237,238,239,240,241) AND dataUnit in ('Kilometers (KM)', 'Miles (M)') THEN 'Business Travel - International (KM)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Business Travel - Domestic (KM)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'Currency' THEN 'Business Travel - Domestic (Currency)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Diesel' THEN 'Business Travel - Domestic (No of litre - Diesel)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Petrol' THEN 'Business Travel - Domestic (No of litre - Petrol)'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of Nights' THEN 'Business Travel - Domestic (Hotel Stay)'
			WHEN formName = 'Company Vehicles' AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Company Vehicles (KM)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'Currency' THEN 'Company Vehicles (Currency)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Diesel' THEN 'Company Vehicles (No of litre - Diesel)'
			WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Petrol' THEN 'Company Vehicles (No of litre - Petrol)'
			ELSE formName END,emissionActivityName,emissionActivityId
 )
,
 CTE_FINAL
 AS 
 (
 SELECT a.formName, a.emissionActivityName, a.emissionActivityId, a.input AS activityTotal, f.input AS categoryTotal, NULLIF(a.input,0) / NULLIF(f.input,0) AS PercentageOfTotal
 FROM CTE_SUM_BYACTIVITY a
 JOIN CTE_SUMBYFORM f ON a.formName = f.formName
 )
 SELECT F.* --, Utilities.GetEF(F.emissionActivityId, 1) as ef, EF.wtt, EF.tnd, EF.tndWtt
 FROM CTE_FINAL F
 --LEFT JOIN Emissions.EmissionFactor EF ON EF.activityId = F.emissionActivityId AND EF.emissionProfileId = 1 --UK 2022
 --LEFT JOIN Emissions.EmissionProfile EP ON EP.id = EF.emissionProfileId
GO


-- ----------------------------
-- View structure for InputTotalsByActivity_RM
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[InputTotalsByActivity_RM]') AND type IN ('V'))
	DROP VIEW [DataModel].[InputTotalsByActivity_RM]
GO

CREATE VIEW [DataModel].[InputTotalsByActivity_RM] AS WITH CTE_SUMBYFORM
AS
(
SELECT CASE 
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId NOT IN (357,358,359) THEN 'Commuting'
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId IN (357,358,359) THEN 'Home Working'
			WHEN formName = 'Business Travel'
				AND emissionactivityId IN (228,234,235,236,237,238,239,240,241) THEN 'Business Travel - International'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) THEN 'Business Travel - Domestic'
			ELSE formName END AS formname,
	SUM(userInput*conversionFactor) input
  FROM [DataModel].[vCertificationSubsmissions]
  WHERE (ISNULL(dataUnit,'abc') <> 'Currency' OR formname = 'Purchased Goods and Services')
  GROUP BY CASE 
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId NOT IN (357,358,359) THEN 'Commuting'
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId IN (357,358,359) THEN 'Home Working'
			WHEN formName = 'Business Travel'
				AND emissionactivityId IN (228,234,235,236,237,238,239,240,241) THEN 'Business Travel - International'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) THEN 'Business Travel - Domestic'
			ELSE formName END
 ),
 CTE_SUM_BYACTIVITY
 AS
 (
SELECT CASE 
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId NOT IN (357,358,359) THEN 'Commuting'
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId IN (357,358,359) THEN 'Home Working'
			WHEN formName = 'Business Travel'
				AND emissionactivityId IN (228,234,235,236,237,238,239,240,241) THEN 'Business Travel - International'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) THEN 'Business Travel - Domestic'
			ELSE formName END AS formname,emissionActivityName,emissionActivityId,SUM(userInput*conversionFactor) input 
  FROM [DataModel].[vCertificationSubsmissions]
  GROUP BY CASE 
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId NOT IN (357,358,359) THEN 'Commuting'
			WHEN formName = 'Commuting & Home Working'
				AND emissionactivityId IN (357,358,359) THEN 'Home Working'
			WHEN formName = 'Business Travel'
				AND emissionactivityId IN (228,234,235,236,237,238,239,240,241) THEN 'Business Travel - International'
			WHEN formName = 'Business Travel'
				AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) THEN 'Business Travel - Domestic'
			ELSE formName END,emissionActivityName,emissionActivityId
 )
,
 CTE_FINAL
 AS 
 (
 SELECT a.formName, a.emissionActivityName, a.emissionActivityId, a.input AS activityTotal, f.input AS categoryTotal, NULLIF(a.input,0) / NULLIF(f.input,0) AS PercentageOfTotal
 FROM CTE_SUM_BYACTIVITY a
 JOIN CTE_SUMBYFORM f ON a.formName = f.formName
 )
 SELECT F.*,EF.ef, EF.wtt, EF.tnd, EF.tndWtt
 FROM CTE_FINAL F
 LEFT JOIN Emissions.EmissionFactor EF ON EF.activityId = F.emissionActivityId AND EF.emissionProfileId = 1 --UK 2022
 --LEFT JOIN Emissions.EmissionProfile EP ON EP.id = EF.emissionProfileId
GO


-- ----------------------------
-- View structure for OperationsHistory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[OperationsHistory]') AND type IN ('V'))
	DROP VIEW [DataModel].[OperationsHistory]
GO

CREATE VIEW [DataModel].[OperationsHistory] AS SELECT t.Name, 
		t.status AS CurrentStatus, 
		Utilities.EpochToDate(t.dateCreated) AS TaskCreated, 
		Utilities.EpochToDate(t.dueDate) AS DueDate,
		h.status AS history_Status,
		Utilities.EpochToDate(h.dateCreated) AS History_Created, 
		h.durationInMinutes AS History_TimeInStatusMinutes

  FROM [clickup].[StatusHistory] h
  JOIN clickup.Task t ON t.id = h.taskId
  WHERE t.listId = 901200207978
  --AND Utilities.EpochToDate(t.dateCreated) >= '2023-06-01'
  AND parentid IS NULL
  AND t.id  NOT IN ('86943kawc','86943kaza','8694174h3')
  AND t.activeTo IS NULL
GO


-- ----------------------------
-- View structure for PeopleList
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[PeopleList]') AND type IN ('V'))
	DROP VIEW [DataModel].[PeopleList]
GO

CREATE VIEW [DataModel].[PeopleList] AS SELECT 
			status,
			category,
			groupname,
			assignee,
			name,
			title,
			companyName,
			leadSource,
			product,
			CONVERT(NUMERIC,taskValue) AS LeadValue,
			CreatedDate,
			DueDate,
			CASE WHEN DueDate < GETDATE() THEN 1 ELSE 0 END AS Overdue,
			ExceptionCount AS MissingInfo

	FROM clickup.vPeople
GO


-- ----------------------------
-- View structure for vCertificationSubmissionsWithCalcs
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[vCertificationSubmissionsWithCalcs]') AND type IN ('V'))
	DROP VIEW [DataModel].[vCertificationSubmissionsWithCalcs]
GO

CREATE VIEW [DataModel].[vCertificationSubmissionsWithCalcs] AS SELECT cp.id as [customerProfileId]
			,cp.reference as [customerReference]
			,c.id as [customerId]
			,c.name as [customerName]
			,f.id as [formId]
			,f.name as [formName]
			,fc.name as [formCategory]
			,cp.periodStart
			,cp.periodEnd
			,ea.id as [emissionActivityId]
			,ea.name as [emissionActivityName]
			,ef.ef as [ef_P1]
			,ef.wtt as [wtt_P1]
			,ef.tnd as [tnd_P1]
			,ef.tndWtt as [tndWtt_P1]
			,r.id as [reportingFrequencyId]
			,r.name as [reportingFrequency]
			,e.submissionId
			,e.[month]
			,e.userInput
			,e.conversionFactor
			,e.dataUnit
			,js.submissionId as [JotformSubmissionId]
			,js.submissionDate
			,[Utilities].[CalculateEf](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalEf_P1]
			,[Utilities].[CalculateWtt](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalWtt_P1]
			,[Utilities].[CalculateTnd](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalTnd_P1]
			,[Utilities].[CalculateTndWtt](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalTndWtt_P1]
			,[Utilities].[CalculateTotalEmission](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalEmission_P1]
	FROM Fact.Emission e
INNER JOIN Dimension.Submission s on s.id = e.submissionId
LEFT JOIN Dimension.CustomerProfile cp on cp.id = e.entityId AND e.entityTypeId = 1
LEFT JOIN Dimension.customer c on c.id = e.entityId AND e.entityTypeId = 4
INNER JOIN Dimension.Form f on f.id = s.formId
INNER JOIN Emissions.EmissionActivity ea on ea.id = e.emissionActivityId
LEFT JOIN Emissions.EmissionFactor ef on ef.activityId = ea.id AND ef.emissionProfileId = 9
LEFT JOIN Lookups.ReportingFrequency r on r.id = e.reportingFrequencyId
LEFT JOIN Lookups.FormCategory fc on fc.id = f.categoryId
LEFT JOIN Forms.JotformSubmission js on js.id = s.sourceId AND s.dataSourceId = 1
WHERE e.active = 1 AND e.entityTypeId in (1, 4)
GO


-- ----------------------------
-- View structure for vCertificationSubsmissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[vCertificationSubsmissions]') AND type IN ('V'))
	DROP VIEW [DataModel].[vCertificationSubsmissions]
GO

CREATE VIEW [DataModel].[vCertificationSubsmissions] AS SELECT cp.id as [customerProfileId]
			,cp.reference as [customerReference]
			,f.id as [formId]
			,f.name as [formName]
			,fc.name as [formCategory]
			,cp.periodStart
			,cp.periodEnd
			,ea.id as [emissionActivityId]
			,ea.name as [emissionActivityName]
			,r.id as [reportingFrequencyId]
			,r.name as [reportingFrequency]
			,e.submissionId
			,e.[month]
			,e.userInput
			,e.conversionFactor
			,e.dataUnit
	FROM Fact.Emission e
INNER JOIN Dimension.Submission s on s.id = e.submissionId
INNER JOIN Dimension.CustomerProfile cp on cp.id = e.entityId AND e.entityTypeId = 1
INNER JOIN Dimension.Form f on f.id = s.formId
INNER JOIN Emissions.EmissionActivity ea on ea.id = e.emissionActivityId
LEFT JOIN Lookups.ReportingFrequency r on r.id = e.reportingFrequencyId
LEFT JOIN Lookups.FormCategory fc on fc.id = f.categoryId
WHERE e.active = 1  AND e.entityTypeId in (1, 4)
GO


-- ----------------------------
-- View structure for vEvents
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[vEvents]') AND type IN ('V'))
	DROP VIEW [DataModel].[vEvents]
GO

CREATE VIEW [DataModel].[vEvents] AS SELECT [id]
      ,[title]
      ,[reference]
      ,[type]
      ,[organiserName]
      ,[organiserEmail]
      ,[companyName]
      ,[location]
      ,[locationType]
      ,[startDateTime]
      ,[endDateTime]
      ,[noOfAttendees]
      ,[active]
  FROM [Dimension].[Event]
GO


-- ----------------------------
-- View structure for vEventSubmissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[vEventSubmissions]') AND type IN ('V'))
	DROP VIEW [DataModel].[vEventSubmissions]
GO

CREATE VIEW [DataModel].[vEventSubmissions] AS SELECT ev.id as [eventId]
			,ev.reference as [eventReference]
			--,ev.title as [eventTitle]
			--,ev.startDateTime
			--,ev.endDateTime
			--,ev.noOfAttendees as attendees
			,f.id as [formId]
			,f.name as [formName]
			,fc.name as [formCategory]
			,ec.id as [categoryId]
			,ec.name as [categoryName]
			,ea.id as [emissionActivityId]
			,ea.name as [emissionActivityName]
			,e.submissionId
			,e.[month]
			,e.userInput
			,e.conversionFactor
			,e.dataUnit
			,(SELECT [value] FROM Forms.Response r WHERE r.submissionId = e.submissionId AND r.questionId = 128) as [userName]
			,(SELECT [value] FROM Forms.Response r WHERE r.submissionId = e.submissionId AND r.questionId = 129) as [userEmail]
	FROM Fact.Emission e
INNER JOIN Dimension.Submission s on s.id = e.submissionId
INNER JOIN Dimension.Event ev on ev.id = e.entityId AND e.entityTypeId = 2
INNER JOIN Dimension.Form f on f.id = s.formId
INNER JOIN Emissions.EmissionActivity ea on ea.id = e.emissionActivityId
LEFT JOIN Lookups.FormCategory fc on fc.id = f.categoryId
LEFT JOIN Emissions.EmissionCategory ec on ec.id = ea.parentId
GO


-- ----------------------------
-- View structure for vEventSubmissionsWithCalcs
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[vEventSubmissionsWithCalcs]') AND type IN ('V'))
	DROP VIEW [DataModel].[vEventSubmissionsWithCalcs]
GO

CREATE VIEW [DataModel].[vEventSubmissionsWithCalcs] AS SELECT ev.id as [eventId]
			,ev.reference as [eventReference]
			--,ev.title as [eventTitle]
			--,ev.startDateTime
			--,ev.endDateTime
			--,ev.noOfAttendees as attendees
			,f.id as [formId]
			,f.name as [formName]
			,fc.name as [formCategory]
			,ec.id as [categoryId]
			,ec.name as [categoryName]
			,ea.id as [emissionActivityId]
			,ea.name as [emissionActivityName]
			,ef.ef as [ef_P1]
			,ef.wtt as [wtt_P1]
			,ef.tnd as [tnd_P1]
			,e.submissionId
			,e.[month]
			,e.userInput
			,e.conversionFactor
			,e.dataUnit
			,js.submissionDate
			,(SELECT [value] FROM Forms.Response r WHERE r.submissionId = e.submissionId AND r.questionId = 128) as [userName]
			,(SELECT [value] FROM Forms.Response r WHERE r.submissionId = e.submissionId AND r.questionId = 129) as [userEmail]
			,[Utilities].[CalculateEf](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalEf_P1]
			,[Utilities].[CalculateWtt](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalWtt_P1]
			,[Utilities].[CalculateTnd](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalTnd_P1]
			,[Utilities].[CalculateTndWtt](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalTndWtt_P1]
			,[Utilities].[CalculateTotalEmission](e.emissionActivityId, 1, e.userInput, e.conversionFactor) as [totalEmission_P1]
	FROM Fact.Emission e
INNER JOIN Dimension.Submission s on s.id = e.submissionId
INNER JOIN Dimension.Event ev on ev.id = e.entityId AND e.entityTypeId = 2
INNER JOIN Dimension.Form f on f.id = s.formId
INNER JOIN Emissions.EmissionActivity ea on ea.id = e.emissionActivityId
LEFT JOIN Emissions.EmissionFactor ef on ef.activityId = ea.id AND ef.emissionProfileId = 1
LEFT JOIN Lookups.FormCategory fc on fc.id = f.categoryId
LEFT JOIN Emissions.EmissionCategory ec on ec.id = ea.parentId
LEFT JOIN Forms.JotformSubmission js on js.id = s.sourceId AND s.dataSourceId = 1
GO


-- ----------------------------
-- View structure for vSilverSubmissions
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[vSilverSubmissions]') AND type IN ('V'))
	DROP VIEW [DataModel].[vSilverSubmissions]
GO

CREATE VIEW [DataModel].[vSilverSubmissions] AS SELECT cp.id as [customerProfileId]
			,cp.reference as [customerReference]
			,c.id as [customerId]
			,c.name as [customerName]
      ,cmp.companyId as [companyId]
      ,cmp.companyName as [companyName]
			,f.id as [formId]
			,f.name as [formName]
			,ea.id as [emissionActivityId]
			,ea.name as [emissionActivityName]
			,e.submissionId
			,e.[month]
			,e.userInput
			,e.conversionFactor
			,e.dataUnit
			,js.submissionId as [JotformSubmissionId]
			,js.submissionDate
	FROM Fact.Emission e
INNER JOIN Dimension.Submission s on s.id = e.submissionId
LEFT JOIN Dimension.CustomerProfile cp on cp.id = e.entityId AND e.entityTypeId = 1
LEFT JOIN Dimension.customer c on c.id = e.entityId AND e.entityTypeId = 4
LEFT JOIN portal.Company as cmp on cmp.companyId = e.entityId and e.entityTypeId = 5
INNER JOIN Dimension.Form f on f.id = s.formId
INNER JOIN Emissions.EmissionActivity ea on ea.id = e.emissionActivityId
LEFT JOIN Lookups.ReportingFrequency r on r.id = e.reportingFrequencyId
LEFT JOIN Lookups.FormCategory fc on fc.id = f.categoryId
LEFT JOIN Forms.JotformSubmission js on js.id = s.sourceId AND s.dataSourceId = 1
WHERE e.active = 1 AND e.entityTypeId in (1, 4, 5)
GO


-- ----------------------------
-- View structure for vSilverSubmissions_11Jun2025
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[vSilverSubmissions_11Jun2025]') AND type IN ('V'))
	DROP VIEW [DataModel].[vSilverSubmissions_11Jun2025]
GO

CREATE VIEW [DataModel].[vSilverSubmissions_11Jun2025] AS SELECT cp.id as [customerProfileId]
			,cp.reference as [customerReference]
			,c.id as [customerId]
			,c.name as [customerName]
			,f.id as [formId]
			,f.name as [formName]
			,ea.id as [emissionActivityId]
			,ea.name as [emissionActivityName]
			,e.submissionId
			,e.[month]
			,e.userInput
			,e.conversionFactor
			,e.dataUnit
			,js.submissionId as [JotformSubmissionId]
			,js.submissionDate
	FROM Fact.Emission e
INNER JOIN Dimension.Submission s on s.id = e.submissionId
LEFT JOIN Dimension.CustomerProfile cp on cp.id = e.entityId AND e.entityTypeId = 1
LEFT JOIN Dimension.customer c on c.id = e.entityId AND e.entityTypeId = 4
INNER JOIN Dimension.Form f on f.id = s.formId
INNER JOIN Emissions.EmissionActivity ea on ea.id = e.emissionActivityId
LEFT JOIN Lookups.ReportingFrequency r on r.id = e.reportingFrequencyId
LEFT JOIN Lookups.FormCategory fc on fc.id = f.categoryId
LEFT JOIN Forms.JotformSubmission js on js.id = s.sourceId AND s.dataSourceId = 1
WHERE e.active = 1 AND e.entityTypeId in (1, 4)
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputWrapper_11Dec2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputWrapper_11Dec2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputWrapper_11Dec2024]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputWrapper_11Dec2024] 
	@certificationTaskId nvarchar(50),
	@emissionProfileId INT
AS
BEGIN
	
	DECLARE @BAQSubmissionId bigint;
	DECLARE @SilverSubmissionIds nvarchar(max);
	
  SET @BAQSubmissionId = (SELECT TOP 1 [submissionId] FROM [clickup].[vParentTasks] WHERE [formId] = '241290444812856' AND id = @certificationTaskId ORDER BY [dateUpdated] DESC)
	SET @SilverSubmissionIds = (SELECT STRING_AGG([submissionId], ',') FROM [clickup].[vTasks] WHERE [formId] != '241290444812856' AND id = @certificationTaskId)
	
  IF @BAQSubmissionId IS NULL
	BEGIN
		SELECT 'Could not find BAQ submissionId' as [error]
		RETURN 0;
	END
	
	IF @SilverSubmissionIds IS NULL
	BEGIN
		SELECT 'Could not find Silver submissionIds' as [error]
	END
	-- select @BAQSubmissionId, @SilverSubmissionIds;
	EXEC DataModel.spBAQ_DataOutputByScope		@BAQSubmissionid = @BAQSubmissionId, @silverSubmissionIds = @SilverSubmissionIds, @emissionProfileId = @emissionProfileId
	
END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputDetailed
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputDetailed]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputDetailed]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputDetailed] 
	@silverSubmissionIds nvarchar(max),
	@emissionProfileId INT
AS
BEGIN
-- Silver report, detailed CO2 generation by sub category

	;WITH CTE_SILVER_DATA
	AS (
		SELECT   e.formId, RC.categoryId,
             MIN(e.[formName]) as mainCategoryName,
             IsNull(Min(RC.categoryName), MIN(emissionActivityName)) as subCategoryName,
						 SUM(userInput * conversionFactor) as [userInput],
						 SUM([Utilities].[CalculateEf](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalEf],
						 SUM([Utilities].[CalculateWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalWtt],
						 SUM([Utilities].[CalculateTnd](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalTnd],
						 SUM([Utilities].[CalculateTndWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalTndWtt]
			FROM [DataModel].[vSilverSubmissions] e 
      LEFT JOIN ( Select RC.formId, RC.categoryId, RC.categoryName, RCM.emissionActivityId
                  from [DataModel].ReportCategory as RC INNER JOIN [DataModel].ReportCategoryMapping as RCM on (RC.categoryId = RCM.categoryId)
                ) as RC on (RC.formId = e.formId and RC.emissionActivityId=e.emissionActivityId)
      WHERE [JotformSubmissionId] in (SELECT value FROM STRING_SPLIT(@silverSubmissionIds, ','))
      GROUP BY e.[formId], RC.categoryId
	)
	
		-- SELECT * FROM CTE_SILVER_DATA ORDER BY formId, categoryName;
	
		SELECT  [mainCategoryName] as [Category],
            [subCategoryName] as [SubCategory],
            totalEf as TotalEF, 
            totalWtt as TotalWTT,
            totalTnd as TotalTND, 
            TotalTndWtt as TotalTNDWTT,
            (totalEf+totalWtt+totalTnd+TotalTndWtt) as TotalKgCO2,
            ((totalEf+totalWtt+totalTnd+TotalTndWtt)/ SDF.TotalFormKgCO2)*100 as TotalPercentCO2
		FROM CTE_SILVER_DATA as SD INNER JOIN
          ( Select formId, Sum((totalEf+totalWtt+totalTnd+TotalTndWtt)) TotalFormKgCO2 
            from CTE_SILVER_DATA
            GROUP BY formId
          ) as SDF on (SD.formId=SDF.formId)
    WHERE (totalEf+totalWtt+totalTnd+TotalTndWtt) > 0
    ORDER BY SD.formId, SubCategory; --, EmissionActivity;
		
END
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutputByScope_07Nov2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutputByScope_07Nov2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutputByScope_07Nov2024]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutputByScope_07Nov2024] 
	@submissionid BIGINT,
	@emissionProfileId INT = 1
AS
BEGIN
	
	-- EXEC [DataModel].[spBAQ_DataOutputByScope] 5913355162935174087
	CREATE TABLE #BAQData (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2)
	);

	INSERT INTO #BAQData (category, total, dataUnit, bmCategory, [order])
	EXEC [DataModel].[spBAQ_DataOutput] @submissionid;


	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(1000),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	-- Totals by activity from our data collection
	WITH CTE_INPUT_TOTALS_BY_ACTIVITY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName,  
						PercentageOfTotal,
						Utilities.GetEF(t.emissionActivityId, @emissionProfileId) as EF,
						Utilities.GetWTT(t.emissionActivityId, @emissionProfileId) as WTT, 
						Utilities.GetTND(t.emissionActivityId, @emissionProfileId) as TND, 
						Utilities.GetTNDWTT(t.emissionActivityId, @emissionProfileId) as TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = @emissionProfileId
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName AS Category,  
						SUM(PercentageOfTotal*ef) AS EF,
						SUM(PercentageOfTotal*wtt) AS WTT,
						SUM(PercentageOfTotal*tnd) AS TND,
						SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CTE_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	,CTE_FINAL AS (
		 SELECT baq.category, 
						baq.total, 
						baq.dataunit, 
						baq.bmCategory, 
						baq.[order],
						bm.EF, 	
						bm.WTT, 
						bm.TND, 
						bm.TNDWTT
			 FROM #BAQData baq
	LEFT JOIN [CTE_BENCHMARKS_BY_CATEGORY] bm ON baq.bmCategory = bm.category
 )
	
-- BAQ data group by category.
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, [order], ef, wtt, tnd, tndwtt)
	SELECT  STRING_AGG([Category], ', ') as [Sub Categories],
				SUM(total) as [Total],
				MAX(dataUnit) as [dataUnit],
				bmCategory,
				MAX([order]) as [Order],
				SUM(total * ef) as TotalEF, 
				SUM(total * wtt) as TotalWTT,
				SUM(total * tnd) as TotalTND, 
				SUM(total * tndwtt) as TotalTNDWTT
		FROM CTE_FINAL 
		GROUP BY bmCategory;


-- Get the silver submission data
	CREATE TABLE #SilverData (
			formName NVARCHAR(255),
			category NVARCHAR(255),
			TotalEF DECIMAL(18, 2),
			TotalWTT DECIMAL(18, 2),
			TotalTND DECIMAL(18, 2),
			TotalTNDWTT DECIMAL(18, 2)
		);
		
-- 	INSERT INTO #SilverData (formName, category, TotalEF, TotalWTT, TotalTND, TotalTNDWTT)
-- 	EXEC [DataModel].[spSilver_DataOutput] @submissionid, @emissionProfileId
-- 
	
	DECLARE @scope1Categories NVARCHAR(MAX) = 'Natural Gas,Company Vehicles (KM)';
	DECLARE @scope2Categories NVARCHAR(MAX) = 'Electricity';
	DECLARE @scope3Categories NVARCHAR(MAX) = 'Business Travel - Domestic (KM),Business Travel - International (KM),Commuting,Home Working,Waste and Recycling,Water,Upstream Deliveries,Downstream Deliveries,Purchased Goods and Services';

	DECLARE @totalScope1 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ',')));
	
	DECLARE @totalScope2 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ',')));
																				 
	DECLARE @totalScope3EF DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ',')));
	
	DECLARE @totalScope3WTT DECIMAL(18,2) =  (SELECT SUM(COALESCE(s.totalWTT, b.WTT)) + SUM(COALESCE(s.totalTND, b.TND)) + SUM(COALESCE(s.totalTNDWTT, b.TNDWTT))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE NULLIF(b.bmCategory, '') IS NOT NULL);
	
	DECLARE @totalScope3 DECIMAL(10,2) = @totalScope3EF + @totalScope3WTT;
	DECLARE @company nvarchar(500), @headCount INT, @revenue nvarchar(50), @submissionDate nvarchar(50), @name nvarchar(100), @email nvarchar(100), @jobtitle nvarchar(100), @startDate nvarchar(100), @companyLogo nvarchar(500), @totalSpend nvarchar(50);
	SELECT @company = [BAQ_CompanyName], @headCount = [BAQ_TotalHeadCount], @revenue = BAQ_CompanyRevenue, @submissionDate = jr.createdDate, 
				 @name = BAQ_YourName, @email = BAQ_Email, @jobtitle = BAQ_JobTitle, @startDate = CAST(BAQ_ReportStartDate as date), @companyLogo = BAQ_CompanyLogo, @totalSpend = BAQ_TotalSpend
		FROM [DataModel].[BlueAwardSubmissionData] bas
		INNER JOIN [Forms].[JotformRawResponse] jr on jr.submissionId = bas.submissionId
		WHERE bas.submissionId = @submissionid;
		

	DECLARE @Currency nvarchar(10) = (SELECT TOP 1 [value] FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_Currency' AND submissionId = @submissionId);
	DECLARE @CurrencyRate decimal(10,2) = (SELECT TOP 1 rate FROM currency.CurrencyRate WHERE [currency] = @Currency);
	DECLARE @totalSpendUSD DECIMAL(18,2) = CONVERT(DECIMAL(18,2), @totalSpend) * (1/@CurrencyRate); --TODO Check its not devide by zero / NULL
	--DECLARE @revenueUSD DECIMAL(18,2) = CONVERT(DECIMAL(18,2), @revenue) * (1/@CurrencyRate); --TODO Check its not devide by zero / NULL
	 

	--SCOPE BASED CALCULATIONS

SELECT MAX(id) as [ID], MAX([order]) as [Order], @submissionId as [Submission Id], @submissionDate as [Submission Date], @company as [Company], @headCount as [Head Count], @revenue as [Revenue],
			 [Scope], [Category], STRING_AGG([Sub Category], ', ') as [Sub Categories], SUM([Total Kg CO2e]) as [Total Kg CO2e], 
			 SUM([% of total emissions scope wise]) as [% of total emissions scope wise], @name as [Name], @email as [Email], @jobtitle as [Job Title], @startDate as [Report Start Date], @companyLogo as [Company Logo], @totalSpend as [Total Spend], @Currency as [Currency], @totalSpendUSD as [Total Spend USD]
 FROM (
	-- SCOPE 1 Calculations
	SELECT 1 as [id], 
				[order],
				'Scope-1' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category], 
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope1 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope1) * 100 
						ELSE (s.totalEF / @totalScope1) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ','))

	UNION
	
	SELECT 2 as [id], '100', 'Total Scope-1' as [Scope], '', '', @totalScope1, '100' 
	
	UNION

	-- SCOPE 2 Calculations
	SELECT 3 as [id], 
				[order],
				'Scope-2' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category],
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope2 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope2) * 100 
						ELSE (s.totalEF / @totalScope2) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ','))

	UNION
	
	SELECT 4 as [id], '100', 'Total Scope-2' ,'', '',  @totalScope2 , '100' 
	
	UNION

	-- SCOPE 3 Calculations
	SELECT 5 as [id], 
					[order],
					'Scope-3', 
					b.bmCategory, 
					b.category, 
					(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN ((b.EF) / @totalScope3) * 100 
							ELSE (s.totalEF / @totalScope3) * 100 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
			FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ','))
	
	UNION

	-- SCOPE 3 WTT Calculations
	SELECT 6 as [id], 
					b.[order],
					'Scope-3' as Scope, 
					CONCAT('WTT-',b.bmCategory), 
					CONCAT('WTT-',b.category),
					(CASE WHEN s.Category IS NULL THEN CAST(((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) as DECIMAL(18,2)) 
						 ELSE CAST(((ISNULL(TotalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) as DECIMAL(18,2))
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN CAST((((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2))
							ELSE CAST((((ISNULL(totalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2)) 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
		LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE NULLIF(bmCategory, '') IS NOT NULL AND bmCategory NOT IN ('Purchased Goods and Services','Waste and Recycling')
	
	UNION
	
	SELECT 7 as [id], '100', 'Total Scope-3','', '', @totalScope3, '100'

) as tbl 	
	GROUP BY [Scope], [Category]
	ORDER BY [id], [order]

	DROP TABLE #BAQData;
	DROP TABLE #BAQDataWithBM;
	DROP TABLE #SilverData;

END
GO


-- ----------------------------
-- procedure structure for operations_completedforms
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[operations_completedforms]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[operations_completedforms]
GO

CREATE PROCEDURE [DataModel].[operations_completedforms]
AS
SELECT p.name AS customer,
		c.name AS form, 
		CONVERT(DATE,[Utilities].[EpochToDate](c.dateCreated)) AS completedDate,
		DATEADD(dd, 0 - (@@DATEFIRST + 5 + DATEPART(dw, CONVERT(DATE,[Utilities].[EpochToDate](c.dateCreated)))) % 7, CONVERT(DATE,[Utilities].[EpochToDate](c.dateCreated))) AS WeekCommencing
FROM clickup.Task c
JOIN clickup.Task p ON p.id = c.parentid
WHERE c.listid = 901200207978 --need correct list id 
AND c.parentId IS NOT NULL
AND CONVERT(DATE,[Utilities].[EpochToDate](c.dateCreated)) >= '2024-03-11'
GO


-- ----------------------------
-- procedure structure for spPeopleSnapshot_Refresh
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spPeopleSnapshot_Refresh]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spPeopleSnapshot_Refresh]
GO

CREATE PROCEDURE [DataModel].[spPeopleSnapshot_Refresh]
AS
BEGIN
   INSERT INTO DataModel.PeopleSnapshot (SnapshotDate, status,category,groupName,assignee,TaskCount,Overdue,OverdueValue,TotalValue,AvgValue,MissingInfo)
	SELECT 
			CAST(GETDATE() AS DATE) AS SnapshotDate,
			status,
			category,
			groupname,
			assignee, 
			COUNT(*) AS TaskCount,
			SUM(CASE WHEN DueDate < GETDATE() THEN 1 ELSE 0 END) AS Overdue,
			SUM(CASE WHEN DueDate < GETDATE() THEN CONVERT(NUMERIC,taskValue) ELSE 0 END) AS OverdueValue,
			SUM(CONVERT(NUMERIC,taskValue)) AS TotalValue,
			AVG(CONVERT(NUMERIC,ISNULL(taskValue,0))) AS AvgValue,
			SUM(ExceptionCount) AS MissingInfo
	
	FROM clickup.vPeople
	WHERE NOT EXISTS (
			SELECT 1 
			FROM DataModel.PeopleSnapshot 
			WHERE SnapshotDate = CAST(GETDATE() AS DATE)
	)
    AND status <> 'Active Customer'
	GROUP BY category,assignee,status,groupname
	ORDER BY assignee

END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputDetailedWrapper_11Dec2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputDetailedWrapper_11Dec2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputDetailedWrapper_11Dec2024]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputDetailedWrapper_11Dec2024] 
	@certificationTaskId nvarchar(50),
	@emissionProfileId INT
AS
BEGIN
	
	DECLARE @SilverSubmissionIds nvarchar(max);
	
	SET @SilverSubmissionIds = (SELECT STRING_AGG([submissionId], ',') FROM [clickup].[vTasks] WHERE [formId] != '241290444812856' AND id = @certificationTaskId)
	
	IF @SilverSubmissionIds IS NULL
	BEGIN
		SELECT 'Could not find Silver submissionIds' as [error]
	END

	EXEC DataModel.spSilver_DataOutputDetailed	@silverSubmissionIds = @SilverSubmissionIds, @emissionProfileId = @emissionProfileId
	
END
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutput_06Nov2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutput_06Nov2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutput_06Nov2024]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutput_06Nov2024] 
	@submissionid BIGINT
AS
-- Declare variables for the specified fields
-- EXEC [DataModel].[spBAQ_DataOutput] 5913355162935174087
DECLARE @BAQ_TotalHeadcount NUMERIC(10,2),
        @BAQ_OfficeHeadcount NUMERIC(10,2),
        @BAQ_CompanyRevenue MONEY,
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDistance_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDistance_Other NUMERIC(10,2),
        @BAQ_OfficeStaffPublicTransport NUMERIC(10,2),
        @BAQ_OtherStaffPublicTransport NUMERIC(10,2),
        @BAQ_TotalSpend MONEY,
				@BAQ_TotalSpendUSD MONEY = 0,
        @BAQ_PercentageSpendOnServices NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_Cars NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_Vans NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_HGVs NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Daily NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Daily NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Weekly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Weekly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Monthly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Monthly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Quarterly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Quarterly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Biannually NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Biannually NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Annually NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Annually NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_National_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_International_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Quarterly NUMERIC(10,2),
		--calculated variables
		@CALC_WeeksInYear NUMERIC(10,2),
		@CALC_HoursPerDay NUMERIC(10,2),
		@CALC_OtherHeadcount NUMERIC(10,2),
		@CALC_TotalSpendOnServices MONEY,
		@CALC_TotalSpendOnProducts MONEY,
		@CALC_AnnualDaysWorked_Office NUMERIC(10,2),
		@CALC_AnnualDaysWorked_Other NUMERIC(10,2),
		@CALC_AnnualDaysCommute_Office NUMERIC(10,2),
		@CALC_AnnualDaysCommute_Other NUMERIC(10,2),
		@CALC_AnnualDistance_Office NUMERIC(10,2),
		@CALC_AnnualDistance_Other NUMERIC(10,2),
		@CALC_AnnualDaysHomeWorking_Office NUMERIC(10,2),
		@CALC_AnnualDaysHomeWorking_Other NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Other_Private NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Other_Public NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Office_Private NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Office_Public NUMERIC(10,2),
		@CALC_AnnualBusinessTravel_Domestic NUMERIC(10,2),
		@CALC_AnnualBusinessTravel_International NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_Local NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_National NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_International NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_Unknown NUMERIC(10,2),
		@CALC_AnnualGoodsSent_Local NUMERIC(10,2),
		@CALC_AnnualGoodsSent_National NUMERIC(10,2),
		@CALC_AnnualGoodsSent_International NUMERIC(10,2),
		@CALC_AnnualGoodsSent_Unknown NUMERIC(10,2),
		@CALC_AnnualElectric_Office NUMERIC(10,2),
		@CALC_AnnualGas_Office NUMERIC(10,2),
		@CALC_AnnualWater_Office NUMERIC(10,2),
		@CALC_OfficeWaste_Recycling NUMERIC(10,2),
		@CALC_OfficeWaste_Refuse NUMERIC(10,2),
		@CALC_TotalSQM NUMERIC(10,2),
		--Management Based Decisions
		@MBD_SQM_PER_PERSON NUMERIC(10,2),
		@MBD_ELEC_KWH_PER_SQM NUMERIC(10,2),
		@MBD_GAS_KWH_PER_SQM NUMERIC(10,2),
		@MBD_WATER_LITRES_PER_DAY NUMERIC(10,2),
		@MBD_WASTE_REFUSE_KG_PER_DAY NUMERIC(10,2),
		@MBD_WASTE_RECYCLING_KG_PER_DAY NUMERIC(10,2),
		@MBD_DELIVERY_LOCAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_NATIONAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_INTERNATIONAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_UNKNOWN_KMS NUMERIC(10,2)
		;


-- Assign values to each variable
SELECT @CALC_WeeksInYear = 46
SELECT @MBD_SQM_PER_PERSON = 4.6
SELECT @MBD_WATER_LITRES_PER_DAY = 50
SELECT @MBD_WASTE_RECYCLING_KG_PER_DAY = 0.892
SELECT @MBD_WASTE_REFUSE_KG_PER_DAY = 1.108 
SELECT @MBD_DELIVERY_LOCAL_KMS = 40.0
SELECT @MBD_DELIVERY_NATIONAL_KMS = 200.0
SELECT @MBD_DELIVERY_INTERNATIONAL_KMS = 500.0
SELECT @MBD_DELIVERY_UNKNOWN_KMS = 200.0
SELECT @CALC_HoursPerDay = 8.0
--SELECT @MBD_REFRIGERANT_KG_PER_PERSON = 0.0002  --TODO make dyanamic
--SELECT @MBD_OTHER_FUEL_KG_PER_PERSON = 0.002 --TODO make dyanamic


--Company
SELECT @BAQ_TotalHeadcount = CONVERT(INT, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_TotalHeadcount' AND submissionId = @submissionId;
SELECT @BAQ_OfficeHeadcount = CONVERT(INT, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OfficeHeadcount' AND submissionId = @submissionId;
SELECT @CALC_OtherHeadcount = (@BAQ_TotalHeadcount-@BAQ_OfficeHeadcount)
SELECT @BAQ_CompanyRevenue = CONVERT(MONEY, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyRevenue' AND submissionId = @submissionId;
SELECT @BAQ_TotalSpend = CONVERT(MONEY, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_TotalSpend' AND submissionId = @submissionId;
DECLARE @Currency nvarchar(10) = (SELECT TOP 1 [value] FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_Currency' AND submissionId = @submissionId);
DECLARE @CurrencyRate decimal(10,2) = (SELECT TOP 1 rate FROM currency.CurrencyRate WHERE [currency] = @Currency);
SELECT @BAQ_TotalSpendUSD = @BAQ_TotalSpend * (1/@CurrencyRate); --TODO Check its not devide by zero / NULL
SELECT @BAQ_PercentageSpendOnServices = CONVERT(INT, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_PercentageSpendOnServices' AND submissionId = @submissionId;
SELECT @CALC_TotalSpendOnServices = (@BAQ_TotalSpendUSD*(@BAQ_PercentageSpendOnServices/100.0))
SELECT @CALC_TotalSpendOnProducts = (@BAQ_TotalSpendUSD-@CALC_TotalSpendOnServices)
SELECT @CALC_TotalSQM = (@MBD_SQM_PER_PERSON * @BAQ_OfficeHeadcount)

SELECT @MBD_ELEC_KWH_PER_SQM = KWHPerSQM
	 FROM MBD.ElectricityConsumption
	WHERE @CALC_TotalSQM BETWEEN MinSQM AND ISNULL(MaxSQM, @CALC_TotalSQM);


SELECT @MBD_GAS_KWH_PER_SQM = KWHPerSQM
	 FROM MBD.GasConsumption
	WHERE @CALC_TotalSQM BETWEEN MinSQM AND ISNULL(MaxSQM, @CALC_TotalSQM);

--Electricity
SELECT @CALC_AnnualElectric_Office = @CALC_TotalSQM * @MBD_ELEC_KWH_PER_SQM
--Gas
SELECT @CALC_AnnualGas_Office = @CALC_TotalSQM * @MBD_GAS_KWH_PER_SQM

--Office/Other Commuting
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDistance_Office = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDistance_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDistance_Other = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDistance_Other' AND submissionId = @submissionId;
SELECT @BAQ_OfficeStaffPublicTransport = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OfficeStaffPublicTransport' AND submissionId = @submissionId;
SELECT @BAQ_OtherStaffPublicTransport = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OtherStaffPublicTransport' AND submissionId = @submissionId;

--Office Calcs
SELECT @CALC_AnnualDaysWorked_Office = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear * @BAQ_OfficeHeadcount
SELECT @CALC_AnnualDaysCommute_Office = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office * @CALC_WeeksInYear * @BAQ_OfficeHeadcount
SELECT @CALC_AnnualDistance_Office = @BAQ_WorkingDaysAndCommuting_AvgDistance_Office * 2 * @CALC_AnnualDaysCommute_Office
SELECT @CALC_AnnualDaysHomeWorking_Office = @CALC_AnnualDaysWorked_Office-@CALC_AnnualDaysCommute_Office
SELECT @CALC_AnnualCommutingDistance_Office_Public = @CALC_AnnualDistance_Office*(@BAQ_OfficeStaffPublicTransport/100.0)
SELECT @CALC_AnnualCommutingDistance_Office_Private = @CALC_AnnualDistance_Office-@CALC_AnnualCommutingDistance_Office_Public

--Waste
SELECT @CALC_OfficeWaste_Recycling = (@CALC_AnnualDaysCommute_Office * @MBD_WASTE_RECYCLING_KG_PER_DAY) / 1000
SELECT @CALC_OfficeWaste_Refuse = (@CALC_AnnualDaysCommute_Office * @MBD_WASTE_REFUSE_KG_PER_DAY) / 1000

--Water
SELECT @CALC_AnnualWater_Office = (@CALC_AnnualDaysCommute_Office * @MBD_WATER_LITRES_PER_DAY)/1000

--Other Calcs
SELECT @CALC_AnnualDaysWorked_Other = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDaysCommute_Other = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDistance_Other = @BAQ_WorkingDaysAndCommuting_AvgDistance_Other * 2 * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDaysHomeWorking_Other = @CALC_AnnualDaysWorked_Other-@CALC_AnnualDaysCommute_Other
SELECT @CALC_AnnualCommutingDistance_Other_Public = @CALC_AnnualDistance_Other*(@BAQ_OtherStaffPublicTransport/100.0)
SELECT @CALC_AnnualCommutingDistance_Other_Private = @CALC_AnnualDistance_Other-@CALC_AnnualCommutingDistance_Other_Public

--Company Vehicles
SELECT @BAQ_CompanyVehiclesMileage_Cars = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_Cars' AND submissionId = @submissionId;
SELECT @BAQ_CompanyVehiclesMileage_Vans = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_Vans' AND submissionId = @submissionId;
SELECT @BAQ_CompanyVehiclesMileage_HGVs = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_HGVs' AND submissionId = @submissionId;

--Business Travel
SELECT @BAQ_BusinessTravel_Domestic_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Daily' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Biannually = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Bi-annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Biannually = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Bi-annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Annually = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Annually = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Annually' AND submissionId = @submissionId;

--Annual Business Travel
--Domestic
SELECT @CALC_AnnualBusinessTravel_Domestic = ISNULL((@BAQ_BusinessTravel_Domestic_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear), 0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Weekly * @CALC_WeeksInYear),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Monthly * 12),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Quarterly * 4),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Biannually * 2),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Annually),0)

--International
SELECT @CALC_AnnualBusinessTravel_International = ISNULL((@BAQ_BusinessTravel_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear), 0) 
											+ ISNULL((@BAQ_BusinessTravel_International_Weekly * @CALC_WeeksInYear), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Monthly * 12), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Quarterly * 4), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Biannually * 2), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Annually), 0)

-- Goods Received
SELECT @BAQ_GoodsReceived_Local_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Quarterly' AND submissionId = @submissionId;

--Annual Goods Received
--Local
SELECT @CALC_AnnualGoodsReceived_Local = ((@BAQ_GoodsReceived_Local_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Local_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Local_Monthly * 12)
										+ (@BAQ_GoodsReceived_Local_Quarterly *4))
										* @MBD_DELIVERY_LOCAL_KMS
										/1000
--National
SELECT @CALC_AnnualGoodsReceived_National = ((@BAQ_GoodsReceived_National_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_National_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_National_Monthly * 12)
										+ (@BAQ_GoodsReceived_National_Quarterly *4))
										* @MBD_DELIVERY_NATIONAL_KMS
										/1000
--International
SELECT @CALC_AnnualGoodsReceived_International = ((@BAQ_GoodsReceived_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_International_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_International_Monthly * 12)
										+ (@BAQ_GoodsReceived_International_Quarterly *4))
										* @MBD_DELIVERY_INTERNATIONAL_KMS
										/1000
--Unknown
SELECT @CALC_AnnualGoodsReceived_Unknown = ((@BAQ_GoodsReceived_Unknown_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Unknown_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Unknown_Monthly * 12)
										+ (@BAQ_GoodsReceived_Unknown_Quarterly *4))
										* @MBD_DELIVERY_UNKNOWN_KMS
										/1000
-- Goods Sent
SELECT @BAQ_GoodsSent_Local_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Quarterly' AND submissionId = @submissionId;

--Annual Goods Sent
--Local
SELECT @CALC_AnnualGoodsSent_Local = ((@BAQ_GoodsSent_Local_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Local_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Local_Monthly * 12)
										+ (@BAQ_GoodsSent_Local_Quarterly *4))
										* @MBD_DELIVERY_LOCAL_KMS
										/1000
--National
SELECT @CALC_AnnualGoodsSent_National = ((@BAQ_GoodsSent_National_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_National_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_National_Monthly * 12)
										+ (@BAQ_GoodsSent_National_Quarterly *4))
										* @MBD_DELIVERY_NATIONAL_KMS
										/1000
--International
SELECT @CALC_AnnualGoodsSent_International = ((@BAQ_GoodsSent_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_International_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_International_Monthly * 12)
										+ (@BAQ_GoodsSent_International_Quarterly *4))
										* @MBD_DELIVERY_INTERNATIONAL_KMS
										/1000
--Unknown
SELECT @CALC_AnnualGoodsSent_Unknown = ((@BAQ_GoodsSent_Unknown_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Unknown_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Unknown_Monthly * 12)
										+ (@BAQ_GoodsSent_Unknown_Quarterly *4))
										* @MBD_DELIVERY_UNKNOWN_KMS
										/1000


SELECT 'Spend on services' AS category, @CALC_TotalSpendOnServices AS total, 'currency' AS dataunit, 'Purchased Goods and Services' as bmCategory, 12 as [order]
UNION
SELECT 'Spend on products', @CALC_TotalSpendOnProducts, 'currency', 'Purchased Goods and Services', 12
UNION
SELECT 'Homeworking hours', (@CALC_AnnualDaysHomeWorking_Office+@CALC_AnnualDaysHomeWorking_Other)*@CALC_HoursPerDay, 'hours', 'Home Working', 7.5
UNION
SELECT 'Office commuting distance public transport', @CALC_AnnualCommutingDistance_Office_Public, 'km', 'Commuting', 7
UNION
SELECT 'Office commuting distance private transport', @CALC_AnnualCommutingDistance_Office_Private, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance public transport', @CALC_AnnualCommutingDistance_Other_Public, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance private transport', @CALC_AnnualCommutingDistance_Other_Private, 'km', 'Commuting', 7
UNION 
SELECT 'Company vehicle distance cars', @BAQ_CompanyVehiclesMileage_Cars, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance vans', @BAQ_CompanyVehiclesMileage_Vans, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance HGVs', @BAQ_CompanyVehiclesMileage_HGVs, 'km', 'Company Vehicles (KM)', 4
UNION	
SELECT 'Goods received local', @CALC_AnnualGoodsReceived_Local, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received national', @CALC_AnnualGoodsReceived_National, 't-km', 'Downstream Deliveries', 11
UNION
SELECT 'Goods received international', @CALC_AnnualGoodsReceived_International, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received unknown', @CALC_AnnualGoodsReceived_Unknown, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods sent local', @CALC_AnnualGoodsSent_Local, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent national', @CALC_AnnualGoodsSent_National, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent international', @CALC_AnnualGoodsSent_International, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent unknown', @CALC_AnnualGoodsSent_Unknown, 't-km', 'Upstream Deliveries', 10
UNION 
SELECT 'Business travel domestic', @CALC_AnnualBusinessTravel_Domestic, 'days', 'Business Travel - Domestic (KM)', 6
UNION 
SELECT 'Business travel international', @CALC_AnnualBusinessTravel_International, 'days', 'Business Travel - International (KM)', 6
UNION
SELECT 'Electricity usage office', @CALC_AnnualElectric_Office, 'kWh', 'Electricity', 5
UNION
SELECT 'Gas usage office', @CALC_AnnualGas_Office, 'kWh', 'Natural Gas', 1
UNION
SELECT 'Water usage office', @CALC_AnnualWater_Office, 'Cubic Meters', 'Water', 9
UNION 
SELECT 'Office recycling', @CALC_OfficeWaste_Recycling, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office refuse', @CALC_OfficeWaste_Refuse, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office headcount', @BAQ_OfficeHeadcount, 'person', '', 13
UNION 
SELECT 'Other headcount', @CALC_OtherHeadcount, 'person', '', 13
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutput
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutput]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutput]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutput] 
	@submissionid BIGINT
AS
-- Declare variables for the specified fields
-- EXEC [DataModel].[spBAQ_DataOutput] 5913355162935174087
DECLARE @BAQ_TotalHeadcount NUMERIC(10,2),
        @BAQ_OfficeHeadcount NUMERIC(10,2),
        @BAQ_CompanyRevenue MONEY,
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDistance_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDistance_Other NUMERIC(10,2),
        @BAQ_OfficeStaffPublicTransport NUMERIC(10,2),
        @BAQ_OtherStaffPublicTransport NUMERIC(10,2),
        @BAQ_TotalSpend MONEY,
				@BAQ_TotalSpendUSD MONEY = 0,
        @BAQ_PercentageSpendOnServices NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_Cars NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_Vans NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_HGVs NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Daily NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Daily NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Weekly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Weekly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Monthly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Monthly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Quarterly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Quarterly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Biannually NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Biannually NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Annually NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Annually NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_National_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_International_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Quarterly NUMERIC(10,2),
		--calculated variables
		@CALC_WeeksInYear NUMERIC(10,2),
		@CALC_HoursPerDay NUMERIC(10,2),
		@CALC_OtherHeadcount NUMERIC(10,2),
		@CALC_TotalSpendOnServices MONEY,
		@CALC_TotalSpendOnProducts MONEY,
		@CALC_AnnualDaysWorked_Office NUMERIC(10,2),
		@CALC_AnnualDaysWorked_Other NUMERIC(10,2),
		@CALC_AnnualDaysCommute_Office NUMERIC(10,2),
		@CALC_AnnualDaysCommute_Other NUMERIC(10,2),
		@CALC_AnnualDistance_Office NUMERIC(10,2),
		@CALC_AnnualDistance_Other NUMERIC(10,2),
		@CALC_AnnualDaysHomeWorking_Office NUMERIC(10,2),
		@CALC_AnnualDaysHomeWorking_Other NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Other_Private NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Other_Public NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Office_Private NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Office_Public NUMERIC(10,2),
		@CALC_AnnualBusinessTravel_Domestic NUMERIC(10,2),
		@CALC_AnnualBusinessTravel_International NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_Local NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_National NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_International NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_Unknown NUMERIC(10,2),
		@CALC_AnnualGoodsSent_Local NUMERIC(10,2),
		@CALC_AnnualGoodsSent_National NUMERIC(10,2),
		@CALC_AnnualGoodsSent_International NUMERIC(10,2),
		@CALC_AnnualGoodsSent_Unknown NUMERIC(10,2),
		@CALC_AnnualElectric_Office NUMERIC(10,2),
		@CALC_AnnualGas_Office NUMERIC(10,2),
		@CALC_AnnualWater_Office NUMERIC(10,2),
		@CALC_OfficeWaste_Recycling NUMERIC(10,2),
		@CALC_OfficeWaste_Refuse NUMERIC(10,2),
		@CALC_TotalSQM NUMERIC(10,2),
    @CALC_TotalRefrigerant NUMERIC(10,2),
    @CALC_TotalOtherFuel NUMERIC(10,2),
		--Management Based Decisions
		@MBD_SQM_PER_PERSON NUMERIC(10,2),
		@MBD_ELEC_KWH_PER_SQM NUMERIC(10,2),
		@MBD_GAS_KWH_PER_SQM NUMERIC(10,2),
		@MBD_WATER_LITRES_PER_DAY NUMERIC(10,2),
		@MBD_WASTE_REFUSE_KG_PER_DAY NUMERIC(10,2),
		@MBD_WASTE_RECYCLING_KG_PER_DAY NUMERIC(10,2),
		@MBD_DELIVERY_LOCAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_NATIONAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_INTERNATIONAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_UNKNOWN_KMS NUMERIC(10,2),
    @MBD_REFRIGERANT_KG_PER_PERSON NUMERIC(10,2),
    @MBD_OTHER_FUEL_PER_PERSON NUMERIC(10,2)
		;


-- Assign values to each variable
SELECT @CALC_WeeksInYear = 46
SELECT @MBD_SQM_PER_PERSON = 4.6
SELECT @MBD_WATER_LITRES_PER_DAY = 50
SELECT @MBD_WASTE_RECYCLING_KG_PER_DAY = 0.892
SELECT @MBD_WASTE_REFUSE_KG_PER_DAY = 1.108 
SELECT @MBD_DELIVERY_LOCAL_KMS = 40.0
SELECT @MBD_DELIVERY_NATIONAL_KMS = 200.0
SELECT @MBD_DELIVERY_INTERNATIONAL_KMS = 500.0
SELECT @MBD_DELIVERY_UNKNOWN_KMS = 200.0
SELECT @CALC_HoursPerDay = 8.0
Select @MBD_REFRIGERANT_KG_PER_PERSON = 0.226;
Select @MBD_OTHER_FUEL_PER_PERSON = 0.357;

--Company
SELECT @BAQ_TotalHeadcount = CONVERT(INT,  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_TotalHeadcount' AND submissionId = @submissionId;
SELECT @BAQ_OfficeHeadcount = CONVERT(INT,  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OfficeHeadcount' AND submissionId = @submissionId;
SELECT @CALC_OtherHeadcount = (@BAQ_TotalHeadcount-@BAQ_OfficeHeadcount)
SELECT @BAQ_CompanyRevenue = CONVERT(MONEY,  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyRevenue' AND submissionId = @submissionId;
SELECT @BAQ_TotalSpend = CONVERT(MONEY,  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_TotalSpend' AND submissionId = @submissionId;
DECLARE @Currency nvarchar(10) = (SELECT TOP 1 [value] FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_Currency' AND submissionId = @submissionId);
DECLARE @CurrencyRate decimal(10,2) = (SELECT TOP 1 rate FROM currency.CurrencyRate WHERE [currency] = @Currency);
SELECT @BAQ_TotalSpendUSD = @BAQ_TotalSpend * (1/@CurrencyRate); --TODO Check its not devide by zero / NULL
SELECT @BAQ_PercentageSpendOnServices = CONVERT(INT,  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_PercentageSpendOnServices' AND submissionId = @submissionId;
SELECT @CALC_TotalSpendOnServices = (@BAQ_TotalSpendUSD*(@BAQ_PercentageSpendOnServices/100.0))
SELECT @CALC_TotalSpendOnProducts = (@BAQ_TotalSpendUSD-@CALC_TotalSpendOnServices)
SELECT @CALC_TotalSQM = (@MBD_SQM_PER_PERSON * @BAQ_OfficeHeadcount)
SELECT @CALC_TotalRefrigerant = (@MBD_REFRIGERANT_KG_PER_PERSON * @BAQ_OfficeHeadcount)
SELECT @CALC_TotalOtherFuel = (@MBD_OTHER_FUEL_PER_PERSON * @BAQ_OfficeHeadcount)

SELECT @MBD_ELEC_KWH_PER_SQM = KWHPerSQM
	 FROM MBD.ElectricityConsumption
	WHERE @CALC_TotalSQM BETWEEN MinSQM AND ISNULL(MaxSQM, @CALC_TotalSQM);


SELECT @MBD_GAS_KWH_PER_SQM = KWHPerSQM
	 FROM MBD.GasConsumption
	WHERE @CALC_TotalSQM BETWEEN MinSQM AND ISNULL(MaxSQM, @CALC_TotalSQM);

--Electricity
SELECT @CALC_AnnualElectric_Office = @CALC_TotalSQM * @MBD_ELEC_KWH_PER_SQM
--Gas
SELECT @CALC_AnnualGas_Office = @CALC_TotalSQM * @MBD_GAS_KWH_PER_SQM

--Office/Other Commuting
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDistance_Office = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDistance_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDistance_Other = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDistance_Other' AND submissionId = @submissionId;
SELECT @BAQ_OfficeStaffPublicTransport = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OfficeStaffPublicTransport' AND submissionId = @submissionId;
SELECT @BAQ_OtherStaffPublicTransport = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OtherStaffPublicTransport' AND submissionId = @submissionId;

--Office Calcs
SELECT @CALC_AnnualDaysWorked_Office = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear * @BAQ_OfficeHeadcount
SELECT @CALC_AnnualDaysCommute_Office = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office * @CALC_WeeksInYear * @BAQ_OfficeHeadcount
SELECT @CALC_AnnualDistance_Office = @BAQ_WorkingDaysAndCommuting_AvgDistance_Office * 2 * @CALC_AnnualDaysCommute_Office
SELECT @CALC_AnnualDaysHomeWorking_Office = @CALC_AnnualDaysWorked_Office-@CALC_AnnualDaysCommute_Office
SELECT @CALC_AnnualCommutingDistance_Office_Public = @CALC_AnnualDistance_Office*(@BAQ_OfficeStaffPublicTransport/100.0)
SELECT @CALC_AnnualCommutingDistance_Office_Private = @CALC_AnnualDistance_Office-@CALC_AnnualCommutingDistance_Office_Public

--Waste
SELECT @CALC_OfficeWaste_Recycling = (@CALC_AnnualDaysCommute_Office * @MBD_WASTE_RECYCLING_KG_PER_DAY) / 1000
SELECT @CALC_OfficeWaste_Refuse = (@CALC_AnnualDaysCommute_Office * @MBD_WASTE_REFUSE_KG_PER_DAY) / 1000

--Water
SELECT @CALC_AnnualWater_Office = (@CALC_AnnualDaysCommute_Office * @MBD_WATER_LITRES_PER_DAY)/1000

--Other Calcs
SELECT @CALC_AnnualDaysWorked_Other = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDaysCommute_Other = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDistance_Other = @BAQ_WorkingDaysAndCommuting_AvgDistance_Other * 2 * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDaysHomeWorking_Other = @CALC_AnnualDaysWorked_Other-@CALC_AnnualDaysCommute_Other
SELECT @CALC_AnnualCommutingDistance_Other_Public = @CALC_AnnualDistance_Other*(@BAQ_OtherStaffPublicTransport/100.0)
SELECT @CALC_AnnualCommutingDistance_Other_Private = @CALC_AnnualDistance_Other-@CALC_AnnualCommutingDistance_Other_Public

--Company Vehicles
SELECT @BAQ_CompanyVehiclesMileage_Cars = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_Cars' AND submissionId = @submissionId;
SELECT @BAQ_CompanyVehiclesMileage_Vans = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_Vans' AND submissionId = @submissionId;
SELECT @BAQ_CompanyVehiclesMileage_HGVs = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_HGVs' AND submissionId = @submissionId;

--Business Travel
SELECT @BAQ_BusinessTravel_Domestic_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Daily' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Biannually = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Bi-annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Biannually = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Bi-annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Annually = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Annually = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Annually' AND submissionId = @submissionId;

--Annual Business Travel
--Domestic
SELECT @CALC_AnnualBusinessTravel_Domestic = ISNULL((@BAQ_BusinessTravel_Domestic_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear), 0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Weekly * @CALC_WeeksInYear),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Monthly * 12),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Quarterly * 4),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Biannually * 2),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Annually),0)

--International
SELECT @CALC_AnnualBusinessTravel_International = ISNULL((@BAQ_BusinessTravel_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear), 0) 
											+ ISNULL((@BAQ_BusinessTravel_International_Weekly * @CALC_WeeksInYear), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Monthly * 12), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Quarterly * 4), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Biannually * 2), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Annually), 0)

-- Goods Received
SELECT @BAQ_GoodsReceived_Local_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Quarterly' AND submissionId = @submissionId;

--Annual Goods Received
--Local
SELECT @CALC_AnnualGoodsReceived_Local = ((@BAQ_GoodsReceived_Local_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Local_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Local_Monthly * 12)
										+ (@BAQ_GoodsReceived_Local_Quarterly *4))
										* @MBD_DELIVERY_LOCAL_KMS
										/1000
--National
SELECT @CALC_AnnualGoodsReceived_National = ((@BAQ_GoodsReceived_National_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_National_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_National_Monthly * 12)
										+ (@BAQ_GoodsReceived_National_Quarterly *4))
										* @MBD_DELIVERY_NATIONAL_KMS
										/1000
--International
SELECT @CALC_AnnualGoodsReceived_International = ((@BAQ_GoodsReceived_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_International_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_International_Monthly * 12)
										+ (@BAQ_GoodsReceived_International_Quarterly *4))
										* @MBD_DELIVERY_INTERNATIONAL_KMS
										/1000
--Unknown
SELECT @CALC_AnnualGoodsReceived_Unknown = ((@BAQ_GoodsReceived_Unknown_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Unknown_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Unknown_Monthly * 12)
										+ (@BAQ_GoodsReceived_Unknown_Quarterly *4))
										* @MBD_DELIVERY_UNKNOWN_KMS
										/1000
-- Goods Sent

SELECT @BAQ_GoodsSent_Local_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Quarterly' AND submissionId = @submissionId;

--Annual Goods Sent
--Local
SELECT @CALC_AnnualGoodsSent_Local = ((@BAQ_GoodsSent_Local_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Local_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Local_Monthly * 12)
										+ (@BAQ_GoodsSent_Local_Quarterly *4))
										* @MBD_DELIVERY_LOCAL_KMS
										/1000
--National
SELECT @CALC_AnnualGoodsSent_National = ((@BAQ_GoodsSent_National_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_National_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_National_Monthly * 12)
										+ (@BAQ_GoodsSent_National_Quarterly *4))
										* @MBD_DELIVERY_NATIONAL_KMS
										/1000
--International
SELECT @CALC_AnnualGoodsSent_International = ((@BAQ_GoodsSent_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_International_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_International_Monthly * 12)
										+ (@BAQ_GoodsSent_International_Quarterly *4))
										* @MBD_DELIVERY_INTERNATIONAL_KMS
										/1000
--Unknown
SELECT @CALC_AnnualGoodsSent_Unknown = ((@BAQ_GoodsSent_Unknown_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Unknown_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Unknown_Monthly * 12)
										+ (@BAQ_GoodsSent_Unknown_Quarterly *4))
										* @MBD_DELIVERY_UNKNOWN_KMS
										/1000


SELECT 'Spend on services' AS category, @CALC_TotalSpendOnServices AS total, 'currency' AS dataunit, 'Purchased Goods and Services' as bmCategory, 12 as [order]
UNION
SELECT 'Spend on products', @CALC_TotalSpendOnProducts, 'currency', 'Purchased Goods and Services', 12
UNION
SELECT 'Homeworking hours', (@CALC_AnnualDaysHomeWorking_Office+@CALC_AnnualDaysHomeWorking_Other)*@CALC_HoursPerDay, 'hours', 'Home Working', 7.5
UNION
SELECT 'Office commuting distance public transport', @CALC_AnnualCommutingDistance_Office_Public, 'km', 'Commuting', 7
UNION
SELECT 'Office commuting distance private transport', @CALC_AnnualCommutingDistance_Office_Private, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance public transport', @CALC_AnnualCommutingDistance_Other_Public, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance private transport', @CALC_AnnualCommutingDistance_Other_Private, 'km', 'Commuting', 7
UNION 
SELECT 'Company vehicle distance cars', @BAQ_CompanyVehiclesMileage_Cars, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance vans', @BAQ_CompanyVehiclesMileage_Vans, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance HGVs', @BAQ_CompanyVehiclesMileage_HGVs, 'km', 'Company Vehicles (KM)', 4
UNION	
SELECT 'Goods received local', @CALC_AnnualGoodsReceived_Local, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received national', @CALC_AnnualGoodsReceived_National, 't-km', 'Downstream Deliveries', 11
UNION
SELECT 'Goods received international', @CALC_AnnualGoodsReceived_International, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received unknown', @CALC_AnnualGoodsReceived_Unknown, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods sent local', @CALC_AnnualGoodsSent_Local, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent national', @CALC_AnnualGoodsSent_National, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent international', @CALC_AnnualGoodsSent_International, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent unknown', @CALC_AnnualGoodsSent_Unknown, 't-km', 'Upstream Deliveries', 10
UNION 
SELECT 'Business travel domestic', @CALC_AnnualBusinessTravel_Domestic, 'days', 'Business Travel - Domestic (KM)', 6
UNION 
SELECT 'Business travel international', @CALC_AnnualBusinessTravel_International, 'days', 'Business Travel - International (KM)', 6
UNION
SELECT 'Electricity usage office', @CALC_AnnualElectric_Office, 'kWh', 'Electricity', 5
UNION
SELECT 'Refrigerent usage office', @CALC_TotalRefrigerant, 'kg', 'Refrigerents', 2
UNION
SELECT 'Other fuels usage office', @CALC_TotalOtherFuel, 'tonnes/kWh/liters', 'Other Fuels', 3
UNION
SELECT 'Gas usage office', @CALC_AnnualGas_Office, 'kWh', 'Natural Gas', 1
UNION
SELECT 'Water usage office', @CALC_AnnualWater_Office, 'Cubic Meters', 'Water', 9
UNION 
SELECT 'Office recycling', @CALC_OfficeWaste_Recycling, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office refuse', @CALC_OfficeWaste_Refuse, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office headcount', @BAQ_OfficeHeadcount, 'person', '', 13
UNION 
SELECT 'Other headcount', @CALC_OtherHeadcount, 'person', '', 13
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutputByScope_NB_06Nov2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutputByScope_NB_06Nov2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutputByScope_NB_06Nov2024]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutputByScope_NB_06Nov2024] 
	@BAQSubmissionid BIGINT,
	@silverSubmissionIds nvarchar(MAX),
	@emissionProfileId INT = 1
AS
BEGIN
	
	-- EXEC [DataModel].[spBAQ_DataOutputByScope] 5913355162935174087
	CREATE TABLE #BAQData (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2)
	);

	INSERT INTO #BAQData (category, total, dataUnit, bmCategory, [order])
	EXEC [DataModel].[spBAQ_DataOutput] @BAQSubmissionid;


	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(1000),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	-- Totals by activity from our data collection
	WITH CTE_INPUT_TOTALS_BY_ACTIVITY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName,  
						PercentageOfTotal,
						Utilities.GetEF(t.emissionActivityId, @emissionProfileId) as EF,
						Utilities.GetWTT(t.emissionActivityId, @emissionProfileId) as WTT, 
						Utilities.GetTND(t.emissionActivityId, @emissionProfileId) as TND, 
						Utilities.GetTNDWTT(t.emissionActivityId, @emissionProfileId) as TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = @emissionProfileId
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName AS Category,  
						SUM(PercentageOfTotal*ef) AS EF,
						SUM(PercentageOfTotal*wtt) AS WTT,
						SUM(PercentageOfTotal*tnd) AS TND,
						SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CTE_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	,CTE_FINAL AS (
		 SELECT baq.category, 
						baq.total, 
						baq.dataunit, 
						baq.bmCategory, 
						baq.[order],
						bm.EF, 	
						bm.WTT, 
						bm.TND, 
						bm.TNDWTT
			 FROM #BAQData baq
	LEFT JOIN [CTE_BENCHMARKS_BY_CATEGORY] bm ON baq.bmCategory = bm.category
 )
	
-- BAQ data group by category.
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, [order], ef, wtt, tnd, tndwtt)
	SELECT  STRING_AGG([Category], ', ') as [Sub Categories],
				SUM(total) as [Total],
				MAX(dataUnit) as [dataUnit],
				bmCategory,
				MAX([order]) as [Order],
				SUM(total * ef) as TotalEF, 
				SUM(total * wtt) as TotalWTT,
				SUM(total * tnd) as TotalTND, 
				SUM(total * tndwtt) as TotalTNDWTT
		FROM CTE_FINAL 
		GROUP BY bmCategory;


-- Get the silver submission data
	CREATE TABLE #SilverData (
			formName NVARCHAR(255),
			category NVARCHAR(255),
			TotalEF DECIMAL(18, 2),
			TotalWTT DECIMAL(18, 2),
			TotalTND DECIMAL(18, 2),
			TotalTNDWTT DECIMAL(18, 2)
		);
		
	INSERT INTO #SilverData (formName, category, TotalEF, TotalWTT, TotalTND, TotalTNDWTT)
	EXEC [DataModel].[spSilver_DataOutput] @silverSubmissionIds, @emissionProfileId

	
	DECLARE @scope1Categories NVARCHAR(MAX) = 'Natural Gas,Company Vehicles (KM)';
	DECLARE @scope2Categories NVARCHAR(MAX) = 'Electricity';
	DECLARE @scope3Categories NVARCHAR(MAX) = 'Business Travel - Domestic (KM),Business Travel - International (KM),Commuting,Home Working,Waste and Recycling,Water,Upstream Deliveries,Downstream Deliveries,Purchased Goods and Services';

	DECLARE @totalScope1 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ',')));
	
	DECLARE @totalScope2 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ',')));
																				 
	DECLARE @totalScope3EF DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ',')));
	
	DECLARE @totalScope3WTT DECIMAL(18,2) =  (SELECT SUM(COALESCE(s.totalWTT, b.WTT)) + SUM(COALESCE(s.totalTND, b.TND)) + SUM(COALESCE(s.totalTNDWTT, b.TNDWTT))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE NULLIF(b.bmCategory, '') IS NOT NULL);
	
	DECLARE @totalScope3 DECIMAL(10,2) = @totalScope3EF + @totalScope3WTT;
	DECLARE @company nvarchar(500), @headCount INT, @revenue nvarchar(50), @submissionDate nvarchar(50), @name nvarchar(100), @email nvarchar(100), @jobtitle nvarchar(100), @startDate nvarchar(100);
	SELECT @company = [BAQ_CompanyName], @headCount = [BAQ_TotalHeadCount], @revenue = BAQ_CompanyRevenue, @submissionDate = jr.createdDate, 
				 @name = BAQ_YourName, @email = BAQ_Email, @jobtitle = BAQ_JobTitle, @startDate = CAST(BAQ_ReportStartDate as date)
		FROM [DataModel].[BlueAwardSubmissionData] bas
		INNER JOIN [Forms].[JotformRawResponse] jr on jr.submissionId = bas.submissionId
		WHERE bas.submissionId = @BAQSubmissionid;
 

	--SCOPE BASED CALCULATIONS

SELECT MAX(id) as [ID], MAX([order]) as [Order], @BAQSubmissionid as [Submission Id], @submissionDate as [Submission Date], @company as [Company], @headCount as [Head Count], @revenue as [Revenue],
			 [Scope], [Category], STRING_AGG([Sub Category], ', ') as [Sub Categories], SUM([Total Kg CO2e]) as [Total Kg CO2e], 
			 SUM([% of total emissions scope wise]) as [% of total emissions scope wise], @name as [Name], @email as [Email], @jobtitle as [Job Title], @startDate as [Report Start Date]
 FROM (
	-- SCOPE 1 Calculations
	SELECT 1 as [id], 
				[order],
				'Scope-1' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category], 
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope1 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope1) * 100 
						ELSE (s.totalEF / @totalScope1) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ','))

	UNION
	
	SELECT 2 as [id], '100', 'Total Scope-1' as [Scope], '', '', @totalScope1, '100' 
	
	UNION

	-- SCOPE 2 Calculations
	SELECT 3 as [id], 
				[order],
				'Scope-2' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category],
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope2 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope2) * 100 
						ELSE (s.totalEF / @totalScope2) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ','))

	UNION
	
	SELECT 4 as [id], '100', 'Total Scope-2' ,'', '',  @totalScope2 , '100' 
	
	UNION

	-- SCOPE 3 Calculations
	SELECT 5 as [id], 
					[order],
					'Scope-3', 
					b.bmCategory, 
					b.category, 
					(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN ((b.EF) / @totalScope3) * 100 
							ELSE (s.totalEF / @totalScope3) * 100 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
			FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ','))
	
	UNION

	-- SCOPE 3 WTT Calculations
	SELECT 6 as [id], 
					b.[order],
					'Scope-3' as Scope, 
					CONCAT('WTT-',b.bmCategory), 
					CONCAT('WTT-',b.category),
					(CASE WHEN s.Category IS NULL THEN CAST(((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) as DECIMAL(18,2)) 
						 ELSE CAST(((ISNULL(TotalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) as DECIMAL(18,2))
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN CAST((((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2))
							ELSE CAST((((ISNULL(totalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2)) 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
		LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE NULLIF(bmCategory, '') IS NOT NULL AND bmCategory NOT IN ('Purchased Goods and Services','Waste and Recycling')
	
	UNION
	
	SELECT 7 as [id], '100', 'Total Scope-3','', '', @totalScope3, '100'

) as tbl 	
	GROUP BY [Scope], [Category]
	ORDER BY [id], [order]

	SELECT * FROM #BAQData;
	SELECT * FROM #SilverData;
	SELECT * FROM #BAQDataWithBM;
	SELECT @totalScope3EF as totalScope3EF, @totalScope3WTT as totalScope3WTT;
	
	DROP TABLE #BAQData;
	DROP TABLE #BAQDataWithBM;
	DROP TABLE #SilverData;

END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputDetailedWrapper_06Nov2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputDetailedWrapper_06Nov2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputDetailedWrapper_06Nov2024]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputDetailedWrapper_06Nov2024] 
	@certificationTaskId nvarchar(50),
	@emissionProfileId INT
AS
BEGIN
	
	DECLARE @SilverSubmissionIds nvarchar(max);
	
	SET @SilverSubmissionIds = (SELECT STRING_AGG([submissionId], ',') FROM [clickup].[vTasks] WHERE [formId] != '241290444812856' AND id = @certificationTaskId)
	
	IF @SilverSubmissionIds IS NULL
	BEGIN
		SELECT 'Could not find Silver submissionIds' as [error]
	END

	EXEC DataModel.spSilver_DataOutputDetailed	@silverSubmissionIds = @SilverSubmissionIds, @emissionProfileId = @emissionProfileId
	
END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputDetailed_07Nov2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputDetailed_07Nov2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputDetailed_07Nov2024]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputDetailed_07Nov2024] 
	@silverSubmissionIds nvarchar(max),
	@emissionProfileId INT
AS
BEGIN
-- Silver report, detailed CO2 generation by sub category

	;WITH CTE_SILVER_DATA
	AS (
		SELECT   e.formId, MIN(e.[formName]) as formName,
             IsNull(RC.categoryName, MIN(emissionActivityName)) as categoryName,
						 -- [emissionActivityName],
						 -- [dataUnit], 
						 SUM(userInput * conversionFactor) as [userInput],
						 SUM([Utilities].[CalculateEf](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalEf],
						 SUM([Utilities].[CalculateWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalWtt],
						 SUM([Utilities].[CalculateTnd](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalTnd],
						 SUM([Utilities].[CalculateTndWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalTndWtt]
			FROM [DataModel].[vSilverSubmissions] e 
      LEFT JOIN ( Select RC.formId, RC.categoryName, RCM.emissionActivityId
                  from [DataModel].ReportCategory as RC INNER JOIN [DataModel].ReportCategoryMapping as RCM 
                  on (RC.categoryId = RCM.categoryId)) as RC on (RC.formId = e.formId and RC.emissionActivityId=e.emissionActivityId)
      WHERE [JotformSubmissionId] in (SELECT value FROM STRING_SPLIT(@silverSubmissionIds, ','))
      GROUP BY e.[formId], RC.categoryName --, [emissionActivityName] --, [dataUnit]
	)
	
		-- SELECT * FROM CTE_SILVER_DATA ORDER BY formId, categoryName;
	
		SELECT [formName] as [FormName],
				[categoryName] as [Category],
				totalEf as TotalEF, 
				totalWtt as TotalWTT,
				totalTnd as TotalTND, 
				TotalTndWtt as TotalTNDWTT,
        (totalEf+totalWtt+totalTnd+TotalTndWtt) as TotalKgCO2,
        ((totalEf+totalWtt+totalTnd+TotalTndWtt)/ SDF.TotalFormKgCO2)*100 as TotalPercentCO2
		FROM CTE_SILVER_DATA as SD INNER JOIN (
        Select formId, Sum((totalEf+totalWtt+totalTnd+TotalTndWtt)) TotalFormKgCO2 
        from CTE_SILVER_DATA
        GROUP BY formId
      ) as SDF on (SD.formId=SDF.formId)
    ORDER BY SD.formId, Category; --, EmissionActivity;
		
END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputWrapper_07Nov2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputWrapper_07Nov2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputWrapper_07Nov2024]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputWrapper_07Nov2024] 
	@certificationTaskId nvarchar(50),
	@emissionProfileId INT
AS
BEGIN
	
	DECLARE @BAQSubmissionId bigint;
	DECLARE @SilverSubmissionIds nvarchar(max);
	
  SET @BAQSubmissionId = (SELECT TOP 1 [submissionId] FROM [clickup].[vTasks] WHERE [formId] = '241290444812856' AND id = @certificationTaskId ORDER BY [dateUpdated] DESC)
	SET @SilverSubmissionIds = (SELECT STRING_AGG([submissionId], ',') FROM [clickup].[vTasks] WHERE [formId] != '241290444812856' AND id = @certificationTaskId)
	
  IF @BAQSubmissionId IS NULL
	BEGIN
		SELECT 'Could not find BAQ submissionId' as [error]
		RETURN 0;
	END
	
	IF @SilverSubmissionIds IS NULL
	BEGIN
		SELECT 'Could not find Silver submissionIds' as [error]
	END
	-- select @BAQSubmissionId, @SilverSubmissionIds;
	EXEC DataModel.spBAQ_DataOutputByScope_NB		@BAQSubmissionid = @BAQSubmissionId, @silverSubmissionIds = @SilverSubmissionIds, @emissionProfileId = @emissionProfileId
	
END
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutputByScope_PD
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutputByScope_PD]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutputByScope_PD]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutputByScope_PD] 
	--@submissionid BIGINT,
	@companyName NVARCHAR(255),
	@emissionProfileId INT = 1
AS
BEGIN
	
	DECLARE @submissionid BIGINT = (SELECT TOP 1 submissionid FROM DataModel.BlueAwardSubmissionData WHERE BAQ_CompanyName = @companyName);
	-- EXEC [DataModel].[spBAQ_DataOutputByScope] 5913355162935174087
	CREATE TABLE #BAQData (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2)
	);

	INSERT INTO #BAQData (category, total, dataUnit, bmCategory, [order])
	EXEC [DataModel].[spBAQ_DataOutput] @submissionid;


	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(1000),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	-- Totals by activity from our data collection
	WITH CTE_INPUT_TOTALS_BY_ACTIVITY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName,  
						PercentageOfTotal,
						Utilities.GetEF(t.emissionActivityId, @emissionProfileId) as EF,
						Utilities.GetWTT(t.emissionActivityId, @emissionProfileId) as WTT, 
						Utilities.GetTND(t.emissionActivityId, @emissionProfileId) as TND, 
						Utilities.GetTNDWTT(t.emissionActivityId, @emissionProfileId) as TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = @emissionProfileId
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName AS Category,  
						SUM(PercentageOfTotal*ef) AS EF,
						SUM(PercentageOfTotal*wtt) AS WTT,
						SUM(PercentageOfTotal*tnd) AS TND,
						SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CTE_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	,CTE_FINAL AS (
		 SELECT baq.category, 
						baq.total, 
						baq.dataunit, 
						baq.bmCategory, 
						baq.[order],
						bm.EF, 	
						bm.WTT, 
						bm.TND, 
						bm.TNDWTT
			 FROM #BAQData baq
	LEFT JOIN [CTE_BENCHMARKS_BY_CATEGORY] bm ON baq.bmCategory = bm.category
 )
	
-- BAQ data group by category.
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, [order], ef, wtt, tnd, tndwtt)
	SELECT  STRING_AGG([Category], ', ') as [Sub Categories],
				SUM(total) as [Total],
				MAX(dataUnit) as [dataUnit],
				bmCategory,
				MAX([order]) as [Order],
				SUM(total * ef) as TotalEF, 
				SUM(total * wtt) as TotalWTT,
				SUM(total * tnd) as TotalTND, 
				SUM(total * tndwtt) as TotalTNDWTT
		FROM CTE_FINAL 
		GROUP BY bmCategory;


-- Get the silver submission data
	CREATE TABLE #SilverData (
			formName NVARCHAR(255),
			category NVARCHAR(255),
			TotalEF DECIMAL(18, 2),
			TotalWTT DECIMAL(18, 2),
			TotalTND DECIMAL(18, 2),
			TotalTNDWTT DECIMAL(18, 2)
		);
		
-- 	INSERT INTO #SilverData (formName, category, TotalEF, TotalWTT, TotalTND, TotalTNDWTT)
-- 	EXEC [DataModel].[spSilver_DataOutput] @submissionid, @emissionProfileId
-- 
	
	DECLARE @scope1Categories NVARCHAR(MAX) = 'Natural Gas,Company Vehicles (KM)';
	DECLARE @scope2Categories NVARCHAR(MAX) = 'Electricity';
	DECLARE @scope3Categories NVARCHAR(MAX) = 'Business Travel - Domestic (KM),Business Travel - International (KM),Commuting,Home Working,Waste and Recycling,Water,Upstream Deliveries,Downstream Deliveries,Purchased Goods and Services';

	DECLARE @totalScope1 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ',')));
	
	DECLARE @totalScope2 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ',')));
																				 
	DECLARE @totalScope3EF DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ',')));
	
	DECLARE @totalScope3WTT DECIMAL(18,2) =  (SELECT SUM(COALESCE(s.totalWTT, b.WTT)) + SUM(COALESCE(s.totalTND, b.TND)) + SUM(COALESCE(s.totalTNDWTT, b.TNDWTT))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE NULLIF(b.bmCategory, '') IS NOT NULL);
	
	DECLARE @totalScope3 DECIMAL(10,2) = @totalScope3EF + @totalScope3WTT;
	DECLARE @company nvarchar(500), @headCount INT, @revenue nvarchar(50), @submissionDate nvarchar(50), @name nvarchar(100), @email nvarchar(100), @jobtitle nvarchar(100), @startDate nvarchar(100), @companyLogo nvarchar(500);
	SELECT @company = [BAQ_CompanyName], @headCount = [BAQ_TotalHeadCount], @revenue = BAQ_CompanyRevenue, @submissionDate = jr.createdDate, 
				 @name = BAQ_YourName, @email = BAQ_Email, @jobtitle = BAQ_JobTitle, @startDate = CAST(BAQ_ReportStartDate as date), @companyLogo = BAQ_CompanyLogo
		FROM [DataModel].[BlueAwardSubmissionData] bas
		INNER JOIN [Forms].[JotformRawResponse] jr on jr.submissionId = bas.submissionId
		WHERE bas.submissionId = @submissionid;
 

	--SCOPE BASED CALCULATIONS

SELECT MAX(id) as [ID], MAX([order]) as [Order], @submissionId as [Submission Id], @submissionDate as [Submission Date], @company as [Company], @headCount as [Head Count], @revenue as [Revenue],
			 [Scope], [Category], STRING_AGG([Sub Category], ', ') as [Sub Categories], SUM([Total Kg CO2e]) as [Total Kg CO2e], 
			 SUM([% of total emissions scope wise]) as [% of total emissions scope wise], @name as [Name], @email as [Email], @jobtitle as [Job Title], @startDate as [Report Start Date], @companyLogo as [Company Logo]
 FROM (
	-- SCOPE 1 Calculations
	SELECT 1 as [id], 
				[order],
				'Scope-1' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category], 
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope1 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope1) * 100 
						ELSE (s.totalEF / @totalScope1) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ','))

	UNION
	
	SELECT 2 as [id], '100', 'Total Scope-1' as [Scope], '', '', @totalScope1, '100' 
	
	UNION

	-- SCOPE 2 Calculations
	SELECT 3 as [id], 
				[order],
				'Scope-2' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category],
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope2 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope2) * 100 
						ELSE (s.totalEF / @totalScope2) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ','))

	UNION
	
	SELECT 4 as [id], '100', 'Total Scope-2' ,'', '',  @totalScope2 , '100' 
	
	UNION

	-- SCOPE 3 Calculations
	SELECT 5 as [id], 
					[order],
					'Scope-3', 
					b.bmCategory, 
					b.category, 
					(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN ((b.EF) / @totalScope3) * 100 
							ELSE (s.totalEF / @totalScope3) * 100 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
			FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ','))
	
	UNION

	-- SCOPE 3 WTT Calculations
	SELECT 6 as [id], 
					b.[order],
					'Scope-3' as Scope, 
					CONCAT('WTT-',b.bmCategory), 
					CONCAT('WTT-',b.category),
					(CASE WHEN s.Category IS NULL THEN CAST(((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) as DECIMAL(18,2)) 
						 ELSE CAST(((ISNULL(TotalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) as DECIMAL(18,2))
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN CAST((((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2))
							ELSE CAST((((ISNULL(totalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2)) 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
		LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE NULLIF(bmCategory, '') IS NOT NULL AND bmCategory NOT IN ('Purchased Goods and Services','Waste and Recycling')
	
	UNION
	
	SELECT 7 as [id], '100', 'Total Scope-3','', '', @totalScope3, '100'

) as tbl 	
	GROUP BY [Scope], [Category]
	ORDER BY [id], [order]

	DROP TABLE #BAQData;
	DROP TABLE #BAQDataWithBM;
	DROP TABLE #SilverData;

END
GO


-- ----------------------------
-- procedure structure for ProductCostsAndCommission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[ProductCostsAndCommission]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[ProductCostsAndCommission]
GO

CREATE PROCEDURE [DataModel].[ProductCostsAndCommission]
    @salesAmount NUMERIC(10,2), 
    @date DATE, 
    @product NVARCHAR(64), 
    @costName NVARCHAR(64) = NULL
AS
BEGIN

    -- Common Table Expression to calculate total costs
    WITH Costs AS (
        SELECT 
            pc.costName, 
            SUM(pc.amount) AS TotalCost
        FROM 
            DataModel.Products p
        LEFT JOIN 
            DataModel.ProductCosts pc ON p.id = pc.productId
        WHERE 
            @date BETWEEN pc.validFrom AND ISNULL(pc.ValidTo, @date)
            AND @date BETWEEN p.validFrom AND ISNULL(p.ValidTo, @date)
            AND p.name = @product
            AND (pc.costName = @costName OR @costName IS NULL)
        GROUP BY 
            pc.costName
    ),
    -- Calculate the net sales amount after costs
    NetSalesAmount AS (
        SELECT 
            @salesAmount - ISNULL(SUM(TotalCost), 0) AS NetAmount
        FROM 
            Costs
    )

    -- Select the cost line items
    SELECT 
        @product AS Product,
		'Costs' AS Category,
		costName AS Name, 
        TotalCost AS Amount
    FROM 
        Costs
    UNION ALL
    -- Select the commissions based on the net sales amount after costs
    SELECT 
        @product AS Product,
		'Commission' AS category,
		c.name, 
        nsa.NetAmount * c.commission AS Amount
    FROM 
        DataModel.Commissions c
    INNER JOIN 
        DataModel.Products p ON c.productId = p.id
    CROSS JOIN 
        NetSalesAmount nsa -- Get the net sales amount after costs
    WHERE 
        @date BETWEEN c.validFrom AND ISNULL(c.ValidTo, @date)
        AND @date BETWEEN p.validFrom AND ISNULL(p.ValidTo, @date)
        AND p.name = @product
        AND (c.Name = @costName OR @costName IS NULL)

END
GO


-- ----------------------------
-- procedure structure for spEmissions_SelectForCertifications
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spEmissions_SelectForCertifications]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spEmissions_SelectForCertifications]
GO

CREATE PROCEDURE [DataModel].[spEmissions_SelectForCertifications]
	 @customerReference nvarchar(50)
	,@emissionProfileId INT
	,@formId INT = NULL
AS
BEGIN

	SELECT e.* 
				,[Utilities].[CalculateEf](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalEf]
				,[Utilities].[CalculateWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalWtt]
				--,[Utilities].[CalculateTnd](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalTnd]
				--,[Utilities].[CalculateTndWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalTndWtt]
				--,[Utilities].[CalculateTotalEmission](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalEmission]
		FROM [DataModel].[vCertificationSubsmissions] e
	 WHERE [customerReference] = @customerReference
		AND ([formId] = @formId OR @formId IS NULL);
END
GO


-- ----------------------------
-- procedure structure for spEmissions_SelectForEvents
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spEmissions_SelectForEvents]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spEmissions_SelectForEvents]
GO

CREATE PROCEDURE [DataModel].[spEmissions_SelectForEvents]
	 @eventReference nvarchar(50)
	,@emissionProfileId INT
	,@formId INT = NULL
AS
BEGIN

	SELECT e.* 
				,[Utilities].[CalculateEf](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalEf]
				,[Utilities].[CalculateWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalWtt]
				,[Utilities].[CalculateTnd](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalTnd]
				,[Utilities].[CalculateTndWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalTndWtt]
				,[Utilities].[CalculateTotalEmission](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor) as [totalEmission]
		FROM [DataModel].[vEventSubmissions] e
	 WHERE [eventReference] = @eventReference
		AND ([formId] = @formId OR @formId IS NULL);
END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutput
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutput]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutput]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutput] 
	@silverSubmissionIds nvarchar(max),
	@emissionProfileId INT
AS
BEGIN

-- 	DECLARE @email nvarchar(100) = (SELECT TOP 1 email FROM DataModel.BlueAwardSubmissionDetails WHERE SubmissionId = @submissionid);
-- 	DECLARE @customerId INT = (SELECT TOP 1 c.id FROM Dimension.Customer c INNER JOIN clickup.vPeople p ON c.code = p.companyTaskId WHERE p.email = @email AND p.companyTaskId IS NOT NULL);
-- 	
-- 	IF @customerId IS NULL
-- 		RETURN;
-- 	
	;WITH CTE_SILVER_DATA
	AS (
		SELECT  [customerid], 
						[customerName], 
						[formName],
						(CASE WHEN formName = 'Commuting & Home Working' AND emissionactivityId NOT IN (357,358,359) THEN 'Commuting'
									WHEN formName = 'Commuting & Home Working' AND emissionactivityId IN (357,358,359) THEN 'Home Working' 
									WHEN formName = 'Business Travel' AND emissionactivityId IN (228,234,235,236,237,238,239,240,241) AND dataUnit in ('Kilometers (KM)', 'Miles (M)') THEN 'Business Travel - International (KM)'
									WHEN formName = 'Business Travel'
										AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Business Travel - Domestic (KM)'
									WHEN formName = 'Business Travel'
										AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'Currency' THEN 'Business Travel - Domestic (Currency)'
									WHEN formName = 'Business Travel'
										AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Diesel' THEN 'Business Travel - Domestic (No of litre - Diesel)'
									WHEN formName = 'Business Travel'
										AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of litre - Petrol' THEN 'Business Travel - Domestic (No of litre - Petrol)'
									WHEN formName = 'Business Travel'
										AND emissionactivityId NOT IN (228,234,235,236,237,238,239,240,241) AND dataUnit = 'No of Nights' THEN 'Business Travel - Domestic (Hotel Stay)'
									WHEN formName = 'Company Vehicles' AND ISNULL(dataUnit, '') in ('Kilometers (KM)', 'Miles (M)', '') THEN 'Company Vehicles (KM)'
									WHEN formName = 'Company Vehicles' AND dataUnit = 'Currency' THEN 'Company Vehicles (Currency)'
									WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Diesel' THEN 'Company Vehicles (No of litre - Diesel)'
									WHEN formName = 'Company Vehicles' AND dataUnit = 'No of litre - Petrol' THEN 'Company Vehicles (No of litre - Petrol)'
							ELSE formName END) as [category],		
						[emissionActivityName],
						[dataUnit], 
						 SUM(userInput * conversionFactor) as [userInput],
						 SUM([Utilities].[CalculateEf](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalEf],
						 SUM([Utilities].[CalculateWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalWtt],
						 SUM([Utilities].[CalculateTnd](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalTnd],
						 SUM([Utilities].[CalculateTndWtt](e.emissionActivityId, @emissionProfileId, e.userInput, e.conversionFactor)) as [totalTndWtt]
			FROM [DataModel].[vSilverSubmissions] e
		-- WHERE [customerId] = @customerId
		WHERE [JotformSubmissionId] in (SELECT value FROM STRING_SPLIT(@silverSubmissionIds, ','))
	GROUP BY [customerid], [customerName], [formName], [emissionactivityId], [emissionActivityName], [dataUnit]
	)
	
		--SELECT * FROM CTE_SILVER_DATA;
	
		SELECT Max([formName]) as [FormName],
				[category] as [Category],
				SUM(totalEf) as TotalEF, 
				SUM(totalWtt) as TotalWTT,
				SUM(totalTnd) as TotalTND, 
				SUM(TotalTndWtt) as TotalTNDWTT
		FROM CTE_SILVER_DATA 
		GROUP BY category;
		
END
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutputByScope_RB
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutputByScope_RB]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutputByScope_RB]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutputByScope_RB] 
	@BAQSubmissionid BIGINT,
	@silverSubmissionIds nvarchar(MAX) = NULL,
	@emissionProfileId INT = 1
AS
BEGIN
	
	-- EXEC [DataModel].[spBAQ_DataOutputByScope] 5913355162935174087
	CREATE TABLE #BAQData (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2)
	);

	INSERT INTO #BAQData (category, total, dataUnit, bmCategory, [order])
	EXEC [DataModel].[spBAQ_DataOutput] @BAQSubmissionid;

/*
	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(1000),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	-- Totals by activity from our data collection
	WITH CTE_INPUT_TOTALS_BY_ACTIVITY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName,  
						PercentageOfTotal,
						Utilities.GetEF(t.emissionActivityId, @emissionProfileId) as EF,
						Utilities.GetWTT(t.emissionActivityId, @emissionProfileId) as WTT, 
						Utilities.GetTND(t.emissionActivityId, @emissionProfileId) as TND, 
						Utilities.GetTNDWTT(t.emissionActivityId, @emissionProfileId) as TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = @emissionProfileId
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName AS Category,  
						SUM(PercentageOfTotal*ef) AS EF,
						SUM(PercentageOfTotal*wtt) AS WTT,
						SUM(PercentageOfTotal*tnd) AS TND,
						SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CTE_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	,CTE_FINAL AS (
		 SELECT baq.category, 
						baq.total, 
						baq.dataunit, 
						baq.bmCategory, 
						baq.[order],
						bm.EF, 	
						bm.WTT, 
						bm.TND, 
						bm.TNDWTT
			 FROM #BAQData baq
	LEFT JOIN [CTE_BENCHMARKS_BY_CATEGORY] bm ON baq.bmCategory = bm.category
 )

-- BAQ data group by category.
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, [order], ef, wtt, tnd, tndwtt)
	SELECT  STRING_AGG([Category], ', ') as [Sub Categories],
				SUM(total) as [Total],
				MAX(dataUnit) as [dataUnit],
				bmCategory,
				MAX([order]) as [Order],
				SUM(total * ef) as TotalEF, 
				SUM(total * wtt) as TotalWTT,
				SUM(total * tnd) as TotalTND, 
				SUM(total * tndwtt) as TotalTNDWTT
		FROM CTE_FINAL 
		GROUP BY bmCategory;


-- Get the silver submission data
	CREATE TABLE #SilverData (
			formName NVARCHAR(255),
			category NVARCHAR(255),
			TotalEF DECIMAL(18, 2),
			TotalWTT DECIMAL(18, 2),
			TotalTND DECIMAL(18, 2),
			TotalTNDWTT DECIMAL(18, 2)
		);
		
	INSERT INTO #SilverData (formName, category, TotalEF, TotalWTT, TotalTND, TotalTNDWTT)
	EXEC [DataModel].[spSilver_DataOutput] @silverSubmissionIds, @emissionProfileId

	
	DECLARE @scope1Categories NVARCHAR(MAX) = 'Natural Gas,Company Vehicles (KM),Refrigerents,Other Fuels';
	DECLARE @scope2Categories NVARCHAR(MAX) = 'Electricity';
	DECLARE @scope3Categories NVARCHAR(MAX) = 'Business Travel - Domestic (KM),Business Travel - International (KM),Commuting,Home Working,Waste and Recycling,Water,Upstream Deliveries,Downstream Deliveries,Purchased Goods and Services';

	DECLARE @totalScope1 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ',')));
	
	DECLARE @totalScope2 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ',')));
																				 
	DECLARE @totalScope3EF DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ',')));
	
	DECLARE @totalScope3WTT DECIMAL(18,2) =  (SELECT SUM(COALESCE(s.totalWTT, b.WTT)) + SUM(COALESCE(s.totalTND, b.TND)) + SUM(COALESCE(s.totalTNDWTT, b.TNDWTT))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE NULLIF(b.bmCategory, '') IS NOT NULL);
	
	DECLARE @totalScope3 DECIMAL(10,2) = @totalScope3EF + @totalScope3WTT;
	DECLARE @company nvarchar(500), @headCount INT, @revenue nvarchar(50), @submissionDate nvarchar(50), @name nvarchar(100), @email nvarchar(100), @jobtitle nvarchar(100), @startDate nvarchar(100);
	SELECT @company = [BAQ_CompanyName], @headCount = [BAQ_TotalHeadCount], @revenue = BAQ_CompanyRevenue, @submissionDate = jr.createdDate, 
				 @name = BAQ_YourName, @email = BAQ_Email, @jobtitle = BAQ_JobTitle, @startDate = CAST(BAQ_ReportStartDate as date)
		FROM [DataModel].[BlueAwardSubmissionData] bas
		INNER JOIN [Forms].[JotformRawResponse] jr on jr.submissionId = bas.submissionId
		WHERE bas.submissionId = @BAQSubmissionid;
 

	--SCOPE BASED CALCULATIONS

SELECT MAX(id) as [ID], MAX([order]) as [Order], @BAQSubmissionid as [Submission Id], @submissionDate as [Submission Date], @company as [Company], @headCount as [Head Count], @revenue as [Revenue],
			 [Scope], [Category], STRING_AGG([Sub Category], ', ') as [Sub Categories], SUM([Total Kg CO2e]) as [Total Kg CO2e], 
			 SUM([% of total emissions scope wise]) as [% of total emissions scope wise], @name as [Name], @email as [Email], @jobtitle as [Job Title], @startDate as [Report Start Date]
 FROM (
	-- SCOPE 1 Calculations
	SELECT 1 as [id], 
				[order],
				'Scope-1' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category], 
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope1 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope1) * 100 
						ELSE (s.totalEF / @totalScope1) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ','))

	UNION
	
	SELECT 2 as [id], '100', 'Total Scope-1' as [Scope], '', '', @totalScope1, '100' 
	
	UNION

	-- SCOPE 2 Calculations
	SELECT 3 as [id], 
				[order],
				'Scope-2' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category],
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope2 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope2) * 100 
						ELSE (s.totalEF / @totalScope2) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ','))

	UNION
	
	SELECT 4 as [id], '100', 'Total Scope-2' ,'', '',  @totalScope2 , '100' 
	
	UNION

	-- SCOPE 3 Calculations
	SELECT 5 as [id], 
					[order],
					'Scope-3', 
					b.bmCategory, 
					b.category, 
					(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN ((b.EF) / @totalScope3) * 100 
							ELSE (s.totalEF / @totalScope3) * 100 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
			FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ','))
	
	UNION

	-- SCOPE 3 WTT Calculations
	SELECT 6 as [id], 
					b.[order],
					'Scope-3' as Scope, 
					CONCAT('WTT-',b.bmCategory), 
					CONCAT('WTT-',b.category),
					(CASE WHEN s.Category IS NULL THEN CAST(((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) as DECIMAL(18,2)) 
						 ELSE CAST(((ISNULL(TotalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) as DECIMAL(18,2))
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN CAST((((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2))
							ELSE CAST((((ISNULL(totalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2)) 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
		LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE NULLIF(bmCategory, '') IS NOT NULL AND bmCategory NOT IN ('Purchased Goods and Services','Waste and Recycling')
	
	UNION
	
	SELECT 7 as [id], '100', 'Total Scope-3','', '', @totalScope3, '100'

) as tbl 	
	GROUP BY [Scope], [Category]
	ORDER BY [id], [order]

-- 	SELECT * FROM #BAQData;
-- 	SELECT * FROM #SilverData;
-- 	SELECT * FROM #BAQDataWithBM;
-- 	SELECT @totalScope3EF as totalScope3EF, @totalScope3WTT as totalScope3WTT;
	
	DROP TABLE #BAQData;
	DROP TABLE #BAQDataWithBM;
	DROP TABLE #SilverData;
  */

END
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutput_25Nov2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutput_25Nov2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutput_25Nov2024]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutput_25Nov2024] 
	@submissionid BIGINT
AS
-- Declare variables for the specified fields
-- EXEC [DataModel].[spBAQ_DataOutput] 5913355162935174087
DECLARE @BAQ_TotalHeadcount NUMERIC(10,2),
        @BAQ_OfficeHeadcount NUMERIC(10,2),
        @BAQ_CompanyRevenue MONEY,
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDistance_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDistance_Other NUMERIC(10,2),
        @BAQ_OfficeStaffPublicTransport NUMERIC(10,2),
        @BAQ_OtherStaffPublicTransport NUMERIC(10,2),
        @BAQ_TotalSpend MONEY,
				@BAQ_TotalSpendUSD MONEY = 0,
        @BAQ_PercentageSpendOnServices NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_Cars NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_Vans NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_HGVs NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Daily NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Daily NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Weekly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Weekly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Monthly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Monthly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Quarterly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Quarterly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Biannually NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Biannually NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Annually NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Annually NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_National_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_International_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Quarterly NUMERIC(10,2),
		--calculated variables
		@CALC_WeeksInYear NUMERIC(10,2),
		@CALC_HoursPerDay NUMERIC(10,2),
		@CALC_OtherHeadcount NUMERIC(10,2),
		@CALC_TotalSpendOnServices MONEY,
		@CALC_TotalSpendOnProducts MONEY,
		@CALC_AnnualDaysWorked_Office NUMERIC(10,2),
		@CALC_AnnualDaysWorked_Other NUMERIC(10,2),
		@CALC_AnnualDaysCommute_Office NUMERIC(10,2),
		@CALC_AnnualDaysCommute_Other NUMERIC(10,2),
		@CALC_AnnualDistance_Office NUMERIC(10,2),
		@CALC_AnnualDistance_Other NUMERIC(10,2),
		@CALC_AnnualDaysHomeWorking_Office NUMERIC(10,2),
		@CALC_AnnualDaysHomeWorking_Other NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Other_Private NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Other_Public NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Office_Private NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Office_Public NUMERIC(10,2),
		@CALC_AnnualBusinessTravel_Domestic NUMERIC(10,2),
		@CALC_AnnualBusinessTravel_International NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_Local NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_National NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_International NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_Unknown NUMERIC(10,2),
		@CALC_AnnualGoodsSent_Local NUMERIC(10,2),
		@CALC_AnnualGoodsSent_National NUMERIC(10,2),
		@CALC_AnnualGoodsSent_International NUMERIC(10,2),
		@CALC_AnnualGoodsSent_Unknown NUMERIC(10,2),
		@CALC_AnnualElectric_Office NUMERIC(10,2),
		@CALC_AnnualGas_Office NUMERIC(10,2),
		@CALC_AnnualWater_Office NUMERIC(10,2),
		@CALC_OfficeWaste_Recycling NUMERIC(10,2),
		@CALC_OfficeWaste_Refuse NUMERIC(10,2),
		@CALC_TotalSQM NUMERIC(10,2),
    @CALC_TotalRefrigerant NUMERIC(10,2),
    @CALC_TotalOtherFuel NUMERIC(10,2),
		--Management Based Decisions
		@MBD_SQM_PER_PERSON NUMERIC(10,2),
		@MBD_ELEC_KWH_PER_SQM NUMERIC(10,2),
		@MBD_GAS_KWH_PER_SQM NUMERIC(10,2),
		@MBD_WATER_LITRES_PER_DAY NUMERIC(10,2),
		@MBD_WASTE_REFUSE_KG_PER_DAY NUMERIC(10,2),
		@MBD_WASTE_RECYCLING_KG_PER_DAY NUMERIC(10,2),
		@MBD_DELIVERY_LOCAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_NATIONAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_INTERNATIONAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_UNKNOWN_KMS NUMERIC(10,2),
    @MBD_REFRIGERANT_KG_PER_PERSON NUMERIC(10,2),
    @MBD_OTHER_FUEL_PER_PERSON NUMERIC(10,2)
		;


-- Assign values to each variable
SELECT @CALC_WeeksInYear = 46
SELECT @MBD_SQM_PER_PERSON = 4.6
SELECT @MBD_WATER_LITRES_PER_DAY = 50
SELECT @MBD_WASTE_RECYCLING_KG_PER_DAY = 0.892
SELECT @MBD_WASTE_REFUSE_KG_PER_DAY = 1.108 
SELECT @MBD_DELIVERY_LOCAL_KMS = 40.0
SELECT @MBD_DELIVERY_NATIONAL_KMS = 200.0
SELECT @MBD_DELIVERY_INTERNATIONAL_KMS = 500.0
SELECT @MBD_DELIVERY_UNKNOWN_KMS = 200.0
SELECT @CALC_HoursPerDay = 8.0
Select @MBD_REFRIGERANT_KG_PER_PERSON = 0.226;
Select @MBD_OTHER_FUEL_PER_PERSON = 0.357;

--Company
SELECT @BAQ_TotalHeadcount = CONVERT(INT, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_TotalHeadcount' AND submissionId = @submissionId;
SELECT @BAQ_OfficeHeadcount = CONVERT(INT, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OfficeHeadcount' AND submissionId = @submissionId;
SELECT @CALC_OtherHeadcount = (@BAQ_TotalHeadcount-@BAQ_OfficeHeadcount)
SELECT @BAQ_CompanyRevenue = CONVERT(MONEY, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyRevenue' AND submissionId = @submissionId;
SELECT @BAQ_TotalSpend = CONVERT(MONEY, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_TotalSpend' AND submissionId = @submissionId;
DECLARE @Currency nvarchar(10) = (SELECT TOP 1 [value] FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_Currency' AND submissionId = @submissionId);
DECLARE @CurrencyRate decimal(10,2) = (SELECT TOP 1 rate FROM currency.CurrencyRate WHERE [currency] = @Currency);
SELECT @BAQ_TotalSpendUSD = @BAQ_TotalSpend * (1/@CurrencyRate); --TODO Check its not devide by zero / NULL
SELECT @BAQ_PercentageSpendOnServices = CONVERT(INT, [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_PercentageSpendOnServices' AND submissionId = @submissionId;
SELECT @CALC_TotalSpendOnServices = (@BAQ_TotalSpendUSD*(@BAQ_PercentageSpendOnServices/100.0))
SELECT @CALC_TotalSpendOnProducts = (@BAQ_TotalSpendUSD-@CALC_TotalSpendOnServices)
SELECT @CALC_TotalSQM = (@MBD_SQM_PER_PERSON * @BAQ_OfficeHeadcount)
SELECT @CALC_TotalRefrigerant = (@MBD_REFRIGERANT_KG_PER_PERSON * @BAQ_OfficeHeadcount)
SELECT @CALC_TotalOtherFuel = (@MBD_OTHER_FUEL_PER_PERSON * @BAQ_OfficeHeadcount)

SELECT @MBD_ELEC_KWH_PER_SQM = KWHPerSQM
	 FROM MBD.ElectricityConsumption
	WHERE @CALC_TotalSQM BETWEEN MinSQM AND ISNULL(MaxSQM, @CALC_TotalSQM);


SELECT @MBD_GAS_KWH_PER_SQM = KWHPerSQM
	 FROM MBD.GasConsumption
	WHERE @CALC_TotalSQM BETWEEN MinSQM AND ISNULL(MaxSQM, @CALC_TotalSQM);

--Electricity
SELECT @CALC_AnnualElectric_Office = @CALC_TotalSQM * @MBD_ELEC_KWH_PER_SQM
--Gas
SELECT @CALC_AnnualGas_Office = @CALC_TotalSQM * @MBD_GAS_KWH_PER_SQM

--Office/Other Commuting
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDistance_Office = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDistance_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDistance_Other = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDistance_Other' AND submissionId = @submissionId;
SELECT @BAQ_OfficeStaffPublicTransport = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OfficeStaffPublicTransport' AND submissionId = @submissionId;
SELECT @BAQ_OtherStaffPublicTransport = CONVERT(NUMERIC(10,2), NULLIF([value], '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OtherStaffPublicTransport' AND submissionId = @submissionId;

--Office Calcs
SELECT @CALC_AnnualDaysWorked_Office = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear * @BAQ_OfficeHeadcount
SELECT @CALC_AnnualDaysCommute_Office = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office * @CALC_WeeksInYear * @BAQ_OfficeHeadcount
SELECT @CALC_AnnualDistance_Office = @BAQ_WorkingDaysAndCommuting_AvgDistance_Office * 2 * @CALC_AnnualDaysCommute_Office
SELECT @CALC_AnnualDaysHomeWorking_Office = @CALC_AnnualDaysWorked_Office-@CALC_AnnualDaysCommute_Office
SELECT @CALC_AnnualCommutingDistance_Office_Public = @CALC_AnnualDistance_Office*(@BAQ_OfficeStaffPublicTransport/100.0)
SELECT @CALC_AnnualCommutingDistance_Office_Private = @CALC_AnnualDistance_Office-@CALC_AnnualCommutingDistance_Office_Public

--Waste
SELECT @CALC_OfficeWaste_Recycling = (@CALC_AnnualDaysCommute_Office * @MBD_WASTE_RECYCLING_KG_PER_DAY) / 1000
SELECT @CALC_OfficeWaste_Refuse = (@CALC_AnnualDaysCommute_Office * @MBD_WASTE_REFUSE_KG_PER_DAY) / 1000

--Water
SELECT @CALC_AnnualWater_Office = (@CALC_AnnualDaysCommute_Office * @MBD_WATER_LITRES_PER_DAY)/1000

--Other Calcs
SELECT @CALC_AnnualDaysWorked_Other = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDaysCommute_Other = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDistance_Other = @BAQ_WorkingDaysAndCommuting_AvgDistance_Other * 2 * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDaysHomeWorking_Other = @CALC_AnnualDaysWorked_Other-@CALC_AnnualDaysCommute_Other
SELECT @CALC_AnnualCommutingDistance_Other_Public = @CALC_AnnualDistance_Other*(@BAQ_OtherStaffPublicTransport/100.0)
SELECT @CALC_AnnualCommutingDistance_Other_Private = @CALC_AnnualDistance_Other-@CALC_AnnualCommutingDistance_Other_Public

--Company Vehicles
SELECT @BAQ_CompanyVehiclesMileage_Cars = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_Cars' AND submissionId = @submissionId;
SELECT @BAQ_CompanyVehiclesMileage_Vans = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_Vans' AND submissionId = @submissionId;
SELECT @BAQ_CompanyVehiclesMileage_HGVs = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_HGVs' AND submissionId = @submissionId;

--Business Travel
SELECT @BAQ_BusinessTravel_Domestic_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Daily' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Biannually = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Bi-annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Biannually = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Bi-annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Annually = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Annually = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Annually' AND submissionId = @submissionId;

--Annual Business Travel
--Domestic
SELECT @CALC_AnnualBusinessTravel_Domestic = ISNULL((@BAQ_BusinessTravel_Domestic_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear), 0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Weekly * @CALC_WeeksInYear),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Monthly * 12),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Quarterly * 4),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Biannually * 2),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Annually),0)

--International
SELECT @CALC_AnnualBusinessTravel_International = ISNULL((@BAQ_BusinessTravel_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear), 0) 
											+ ISNULL((@BAQ_BusinessTravel_International_Weekly * @CALC_WeeksInYear), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Monthly * 12), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Quarterly * 4), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Biannually * 2), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Annually), 0)

-- Goods Received
SELECT @BAQ_GoodsReceived_Local_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Quarterly' AND submissionId = @submissionId;

--Annual Goods Received
--Local
SELECT @CALC_AnnualGoodsReceived_Local = ((@BAQ_GoodsReceived_Local_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Local_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Local_Monthly * 12)
										+ (@BAQ_GoodsReceived_Local_Quarterly *4))
										* @MBD_DELIVERY_LOCAL_KMS
										/1000
--National
SELECT @CALC_AnnualGoodsReceived_National = ((@BAQ_GoodsReceived_National_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_National_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_National_Monthly * 12)
										+ (@BAQ_GoodsReceived_National_Quarterly *4))
										* @MBD_DELIVERY_NATIONAL_KMS
										/1000
--International
SELECT @CALC_AnnualGoodsReceived_International = ((@BAQ_GoodsReceived_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_International_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_International_Monthly * 12)
										+ (@BAQ_GoodsReceived_International_Quarterly *4))
										* @MBD_DELIVERY_INTERNATIONAL_KMS
										/1000
--Unknown
SELECT @CALC_AnnualGoodsReceived_Unknown = ((@BAQ_GoodsReceived_Unknown_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Unknown_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Unknown_Monthly * 12)
										+ (@BAQ_GoodsReceived_Unknown_Quarterly *4))
										* @MBD_DELIVERY_UNKNOWN_KMS
										/1000
-- Goods Sent
SELECT @BAQ_GoodsSent_Local_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Daily = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Weekly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Monthly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Quarterly = CONVERT(NUMERIC(10,2), [value]) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Quarterly' AND submissionId = @submissionId;

--Annual Goods Sent
--Local
SELECT @CALC_AnnualGoodsSent_Local = ((@BAQ_GoodsSent_Local_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Local_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Local_Monthly * 12)
										+ (@BAQ_GoodsSent_Local_Quarterly *4))
										* @MBD_DELIVERY_LOCAL_KMS
										/1000
--National
SELECT @CALC_AnnualGoodsSent_National = ((@BAQ_GoodsSent_National_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_National_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_National_Monthly * 12)
										+ (@BAQ_GoodsSent_National_Quarterly *4))
										* @MBD_DELIVERY_NATIONAL_KMS
										/1000
--International
SELECT @CALC_AnnualGoodsSent_International = ((@BAQ_GoodsSent_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_International_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_International_Monthly * 12)
										+ (@BAQ_GoodsSent_International_Quarterly *4))
										* @MBD_DELIVERY_INTERNATIONAL_KMS
										/1000
--Unknown
SELECT @CALC_AnnualGoodsSent_Unknown = ((@BAQ_GoodsSent_Unknown_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Unknown_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Unknown_Monthly * 12)
										+ (@BAQ_GoodsSent_Unknown_Quarterly *4))
										* @MBD_DELIVERY_UNKNOWN_KMS
										/1000


SELECT 'Spend on services' AS category, @CALC_TotalSpendOnServices AS total, 'currency' AS dataunit, 'Purchased Goods and Services' as bmCategory, 12 as [order]
UNION
SELECT 'Spend on products', @CALC_TotalSpendOnProducts, 'currency', 'Purchased Goods and Services', 12
UNION
SELECT 'Homeworking hours', (@CALC_AnnualDaysHomeWorking_Office+@CALC_AnnualDaysHomeWorking_Other)*@CALC_HoursPerDay, 'hours', 'Home Working', 7.5
UNION
SELECT 'Office commuting distance public transport', @CALC_AnnualCommutingDistance_Office_Public, 'km', 'Commuting', 7
UNION
SELECT 'Office commuting distance private transport', @CALC_AnnualCommutingDistance_Office_Private, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance public transport', @CALC_AnnualCommutingDistance_Other_Public, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance private transport', @CALC_AnnualCommutingDistance_Other_Private, 'km', 'Commuting', 7
UNION 
SELECT 'Company vehicle distance cars', @BAQ_CompanyVehiclesMileage_Cars, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance vans', @BAQ_CompanyVehiclesMileage_Vans, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance HGVs', @BAQ_CompanyVehiclesMileage_HGVs, 'km', 'Company Vehicles (KM)', 4
UNION	
SELECT 'Goods received local', @CALC_AnnualGoodsReceived_Local, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received national', @CALC_AnnualGoodsReceived_National, 't-km', 'Downstream Deliveries', 11
UNION
SELECT 'Goods received international', @CALC_AnnualGoodsReceived_International, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received unknown', @CALC_AnnualGoodsReceived_Unknown, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods sent local', @CALC_AnnualGoodsSent_Local, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent national', @CALC_AnnualGoodsSent_National, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent international', @CALC_AnnualGoodsSent_International, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent unknown', @CALC_AnnualGoodsSent_Unknown, 't-km', 'Upstream Deliveries', 10
UNION 
SELECT 'Business travel domestic', @CALC_AnnualBusinessTravel_Domestic, 'days', 'Business Travel - Domestic (KM)', 6
UNION 
SELECT 'Business travel international', @CALC_AnnualBusinessTravel_International, 'days', 'Business Travel - International (KM)', 6
UNION
SELECT 'Electricity usage office', @CALC_AnnualElectric_Office, 'kWh', 'Electricity', 5
UNION
SELECT 'Refrigerent usage office', @CALC_TotalRefrigerant, 'kg', 'Refrigerents', 2
UNION
SELECT 'Other fuels usage office', @CALC_TotalOtherFuel, 'tonnes/kWh/liters', 'Other Fuels', 3
UNION
SELECT 'Gas usage office', @CALC_AnnualGas_Office, 'kWh', 'Natural Gas', 1
UNION
SELECT 'Water usage office', @CALC_AnnualWater_Office, 'Cubic Meters', 'Water', 9
UNION 
SELECT 'Office recycling', @CALC_OfficeWaste_Recycling, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office refuse', @CALC_OfficeWaste_Refuse, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office headcount', @BAQ_OfficeHeadcount, 'person', '', 13
UNION 
SELECT 'Other headcount', @CALC_OtherHeadcount, 'person', '', 13
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutput_RB
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutput_RB]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutput_RB]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutput_RB] 
	@submissionid BIGINT
AS
-- Declare variables for the specified fields
-- EXEC [DataModel].[spBAQ_DataOutput] 5913355162935174087
DECLARE @BAQ_TotalHeadcount NUMERIC(10,2),
        @BAQ_OfficeHeadcount NUMERIC(10,2),
        @BAQ_CompanyRevenue MONEY,
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDistance_Office NUMERIC(10,2),
        @BAQ_WorkingDaysAndCommuting_AvgDistance_Other NUMERIC(10,2),
        @BAQ_OfficeStaffPublicTransport NUMERIC(10,2),
        @BAQ_OtherStaffPublicTransport NUMERIC(10,2),
        @BAQ_TotalSpend MONEY,
				@BAQ_TotalSpendUSD MONEY = 0,
        @BAQ_PercentageSpendOnServices NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_Cars NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_Vans NUMERIC(10,2),
        @BAQ_CompanyVehiclesMileage_HGVs NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Daily NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Daily NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Weekly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Weekly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Monthly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Monthly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Quarterly NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Quarterly NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Biannually NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Biannually NUMERIC(10,2),
        @BAQ_BusinessTravel_Domestic_Annually NUMERIC(10,2),
        @BAQ_BusinessTravel_International_Annually NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Daily NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Weekly NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Monthly NUMERIC(10,2),
        @BAQ_GoodsReceived_Local_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_National_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_International_Quarterly NUMERIC(10,2),
        @BAQ_GoodsReceived_Unknown_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_National_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_International_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Daily NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Weekly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Monthly NUMERIC(10,2),
        @BAQ_GoodsSent_Local_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_National_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_International_Quarterly NUMERIC(10,2),
        @BAQ_GoodsSent_Unknown_Quarterly NUMERIC(10,2),
		--calculated variables
		@CALC_WeeksInYear NUMERIC(10,2),
		@CALC_HoursPerDay NUMERIC(10,2),
		@CALC_OtherHeadcount NUMERIC(10,2),
		@CALC_TotalSpendOnServices MONEY,
		@CALC_TotalSpendOnProducts MONEY,
		@CALC_AnnualDaysWorked_Office NUMERIC(10,2),
		@CALC_AnnualDaysWorked_Other NUMERIC(10,2),
		@CALC_AnnualDaysCommute_Office NUMERIC(10,2),
		@CALC_AnnualDaysCommute_Other NUMERIC(10,2),
		@CALC_AnnualDistance_Office NUMERIC(10,2),
		@CALC_AnnualDistance_Other NUMERIC(10,2),
		@CALC_AnnualDaysHomeWorking_Office NUMERIC(10,2),
		@CALC_AnnualDaysHomeWorking_Other NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Other_Private NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Other_Public NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Office_Private NUMERIC(10,2),
		@CALC_AnnualCommutingDistance_Office_Public NUMERIC(10,2),
		@CALC_AnnualBusinessTravel_Domestic NUMERIC(10,2),
		@CALC_AnnualBusinessTravel_International NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_Local NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_National NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_International NUMERIC(10,2),
		@CALC_AnnualGoodsReceived_Unknown NUMERIC(10,2),
		@CALC_AnnualGoodsSent_Local NUMERIC(10,2),
		@CALC_AnnualGoodsSent_National NUMERIC(10,2),
		@CALC_AnnualGoodsSent_International NUMERIC(10,2),
		@CALC_AnnualGoodsSent_Unknown NUMERIC(10,2),
		@CALC_AnnualElectric_Office NUMERIC(10,2),
		@CALC_AnnualGas_Office NUMERIC(10,2),
		@CALC_AnnualWater_Office NUMERIC(10,2),
		@CALC_OfficeWaste_Recycling NUMERIC(10,2),
		@CALC_OfficeWaste_Refuse NUMERIC(10,2),
		@CALC_TotalSQM NUMERIC(10,2),
    @CALC_TotalRefrigerant NUMERIC(10,2),
    @CALC_TotalOtherFuel NUMERIC(10,2),
		--Management Based Decisions
		@MBD_SQM_PER_PERSON NUMERIC(10,2),
		@MBD_ELEC_KWH_PER_SQM NUMERIC(10,2),
		@MBD_GAS_KWH_PER_SQM NUMERIC(10,2),
		@MBD_WATER_LITRES_PER_DAY NUMERIC(10,2),
		@MBD_WASTE_REFUSE_KG_PER_DAY NUMERIC(10,2),
		@MBD_WASTE_RECYCLING_KG_PER_DAY NUMERIC(10,2),
		@MBD_DELIVERY_LOCAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_NATIONAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_INTERNATIONAL_KMS NUMERIC(10,2),
		@MBD_DELIVERY_UNKNOWN_KMS NUMERIC(10,2),
    @MBD_REFRIGERANT_KG_PER_PERSON NUMERIC(10,2),
    @MBD_OTHER_FUEL_PER_PERSON NUMERIC(10,2)
		;


-- Assign values to each variable
SELECT @CALC_WeeksInYear = 46
SELECT @MBD_SQM_PER_PERSON = 4.6
SELECT @MBD_WATER_LITRES_PER_DAY = 50
SELECT @MBD_WASTE_RECYCLING_KG_PER_DAY = 0.892
SELECT @MBD_WASTE_REFUSE_KG_PER_DAY = 1.108 
SELECT @MBD_DELIVERY_LOCAL_KMS = 40.0
SELECT @MBD_DELIVERY_NATIONAL_KMS = 200.0
SELECT @MBD_DELIVERY_INTERNATIONAL_KMS = 500.0
SELECT @MBD_DELIVERY_UNKNOWN_KMS = 200.0
SELECT @CALC_HoursPerDay = 8.0
Select @MBD_REFRIGERANT_KG_PER_PERSON = 0.226;
Select @MBD_OTHER_FUEL_PER_PERSON = 0.357;

--Company
SELECT @BAQ_TotalHeadcount = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_TotalHeadcount' AND submissionId = @submissionId;
SELECT @BAQ_OfficeHeadcount = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OfficeHeadcount' AND submissionId = @submissionId;
SELECT @CALC_OtherHeadcount = (@BAQ_TotalHeadcount-@BAQ_OfficeHeadcount)
SELECT @BAQ_CompanyRevenue = CONVERT(MONEY,  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyRevenue' AND submissionId = @submissionId;
SELECT @BAQ_TotalSpend = CONVERT(MONEY,  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_TotalSpend' AND submissionId = @submissionId;
DECLARE @Currency nvarchar(10) = (SELECT TOP 1 [value] FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_Currency' AND submissionId = @submissionId);
DECLARE @CurrencyRate decimal(10,2) = (SELECT TOP 1 rate FROM currency.CurrencyRate WHERE [currency] = @Currency);
SELECT @BAQ_TotalSpendUSD = @BAQ_TotalSpend * (1/@CurrencyRate); --TODO Check its not devide by zero / NULL
SELECT @BAQ_PercentageSpendOnServices = CONVERT(INT,  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_PercentageSpendOnServices' AND submissionId = @submissionId;
SELECT @CALC_TotalSpendOnServices = (@BAQ_TotalSpendUSD*(@BAQ_PercentageSpendOnServices/100.0))
SELECT @CALC_TotalSpendOnProducts = (@BAQ_TotalSpendUSD-@CALC_TotalSpendOnServices)
SELECT @CALC_TotalSQM = (@MBD_SQM_PER_PERSON * @BAQ_OfficeHeadcount)
SELECT @CALC_TotalRefrigerant = (@MBD_REFRIGERANT_KG_PER_PERSON * @BAQ_OfficeHeadcount)
SELECT @CALC_TotalOtherFuel = (@MBD_OTHER_FUEL_PER_PERSON * @BAQ_OfficeHeadcount)

SELECT @MBD_ELEC_KWH_PER_SQM = KWHPerSQM
	 FROM MBD.ElectricityConsumption
	WHERE @CALC_TotalSQM BETWEEN MinSQM AND ISNULL(MaxSQM, @CALC_TotalSQM);


SELECT @MBD_GAS_KWH_PER_SQM = KWHPerSQM
	 FROM MBD.GasConsumption
	WHERE @CALC_TotalSQM BETWEEN MinSQM AND ISNULL(MaxSQM, @CALC_TotalSQM);

--Electricity
SELECT @CALC_AnnualElectric_Office = @CALC_TotalSQM * @MBD_ELEC_KWH_PER_SQM
--Gas
SELECT @CALC_AnnualGas_Office = @CALC_TotalSQM * @MBD_GAS_KWH_PER_SQM

--Office/Other Commuting
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDistance_Office = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDistance_Office' AND submissionId = @submissionId;
SELECT @BAQ_WorkingDaysAndCommuting_AvgDistance_Other = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_WorkingDaysAndCommuting_AvgDistance_Other' AND submissionId = @submissionId;
SELECT @BAQ_OfficeStaffPublicTransport = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OfficeStaffPublicTransport' AND submissionId = @submissionId;
SELECT @BAQ_OtherStaffPublicTransport = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_OtherStaffPublicTransport' AND submissionId = @submissionId;

--Office Calcs
SELECT @CALC_AnnualDaysWorked_Office = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear * @BAQ_OfficeHeadcount
SELECT @CALC_AnnualDaysCommute_Office = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Office * @CALC_WeeksInYear * @BAQ_OfficeHeadcount
SELECT @CALC_AnnualDistance_Office = @BAQ_WorkingDaysAndCommuting_AvgDistance_Office * 2 * @CALC_AnnualDaysCommute_Office
SELECT @CALC_AnnualDaysHomeWorking_Office = @CALC_AnnualDaysWorked_Office-@CALC_AnnualDaysCommute_Office
SELECT @CALC_AnnualCommutingDistance_Office_Public = @CALC_AnnualDistance_Office*(@BAQ_OfficeStaffPublicTransport/100.0)
SELECT @CALC_AnnualCommutingDistance_Office_Private = @CALC_AnnualDistance_Office-@CALC_AnnualCommutingDistance_Office_Public

--Waste
SELECT @CALC_OfficeWaste_Recycling = (@CALC_AnnualDaysCommute_Office * @MBD_WASTE_RECYCLING_KG_PER_DAY) / 1000
SELECT @CALC_OfficeWaste_Refuse = (@CALC_AnnualDaysCommute_Office * @MBD_WASTE_REFUSE_KG_PER_DAY) / 1000

--Water
SELECT @CALC_AnnualWater_Office = (@CALC_AnnualDaysCommute_Office * @MBD_WATER_LITRES_PER_DAY)/1000
/*
--Other Calcs
SELECT @CALC_AnnualDaysWorked_Other = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Other * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDaysCommute_Other = @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekCommuting_Other * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDistance_Other = @BAQ_WorkingDaysAndCommuting_AvgDistance_Other * 2 * @CALC_WeeksInYear * @CALC_OtherHeadcount
SELECT @CALC_AnnualDaysHomeWorking_Other = @CALC_AnnualDaysWorked_Other-@CALC_AnnualDaysCommute_Other
SELECT @CALC_AnnualCommutingDistance_Other_Public = @CALC_AnnualDistance_Other*(@BAQ_OtherStaffPublicTransport/100.0)
SELECT @CALC_AnnualCommutingDistance_Other_Private = @CALC_AnnualDistance_Other-@CALC_AnnualCommutingDistance_Other_Public
*/
--Company Vehicles
SELECT @BAQ_CompanyVehiclesMileage_Cars = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_Cars' AND submissionId = @submissionId;
SELECT @BAQ_CompanyVehiclesMileage_Vans = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_Vans' AND submissionId = @submissionId;
SELECT @BAQ_CompanyVehiclesMileage_HGVs = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_CompanyVehiclesMileage_HGVs' AND submissionId = @submissionId;

--Business Travel
SELECT @BAQ_BusinessTravel_Domestic_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Daily' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Biannually = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Bi-annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Biannually = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Bi-annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_Domestic_Annually = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_Domestic_Annually' AND submissionId = @submissionId;
SELECT @BAQ_BusinessTravel_International_Annually = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_BusinessTravel_International_Annually' AND submissionId = @submissionId;

--Annual Business Travel
--Domestic
SELECT @CALC_AnnualBusinessTravel_Domestic = ISNULL((@BAQ_BusinessTravel_Domestic_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear), 0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Weekly * @CALC_WeeksInYear),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Monthly * 12),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Quarterly * 4),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Biannually * 2),0)
											+ ISNULL((@BAQ_BusinessTravel_Domestic_Annually),0)

--International
SELECT @CALC_AnnualBusinessTravel_International = ISNULL((@BAQ_BusinessTravel_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear), 0) 
											+ ISNULL((@BAQ_BusinessTravel_International_Weekly * @CALC_WeeksInYear), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Monthly * 12), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Quarterly * 4), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Biannually * 2), 0)
											+ ISNULL((@BAQ_BusinessTravel_International_Annually), 0)

-- Goods Received
SELECT @BAQ_GoodsReceived_Local_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Local_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Local_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_National_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_National_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_International_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsReceived_Unknown_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsReceived_Unknown_Quarterly' AND submissionId = @submissionId;

--Annual Goods Received
--Local
SELECT @CALC_AnnualGoodsReceived_Local = ((@BAQ_GoodsReceived_Local_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Local_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Local_Monthly * 12)
										+ (@BAQ_GoodsReceived_Local_Quarterly *4))
										* @MBD_DELIVERY_LOCAL_KMS
										/1000
--National
SELECT @CALC_AnnualGoodsReceived_National = ((@BAQ_GoodsReceived_National_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_National_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_National_Monthly * 12)
										+ (@BAQ_GoodsReceived_National_Quarterly *4))
										* @MBD_DELIVERY_NATIONAL_KMS
										/1000
--International
SELECT @CALC_AnnualGoodsReceived_International = ((@BAQ_GoodsReceived_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_International_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_International_Monthly * 12)
										+ (@BAQ_GoodsReceived_International_Quarterly *4))
										* @MBD_DELIVERY_INTERNATIONAL_KMS
										/1000
--Unknown
SELECT @CALC_AnnualGoodsReceived_Unknown = ((@BAQ_GoodsReceived_Unknown_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Unknown_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsReceived_Unknown_Monthly * 12)
										+ (@BAQ_GoodsReceived_Unknown_Quarterly *4))
										* @MBD_DELIVERY_UNKNOWN_KMS
										/1000
-- Goods Sent

SELECT @BAQ_GoodsSent_Local_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Daily = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Daily' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Weekly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Weekly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Monthly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Monthly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Local_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Local_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_National_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_National_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_International_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_International_Quarterly' AND submissionId = @submissionId;
SELECT @BAQ_GoodsSent_Unknown_Quarterly = CONVERT(NUMERIC(10,2),  NULLIF(trim([value]), '')) FROM forms.blueawardquestionnaire WHERE [key] = 'BAQ_GoodsSent_Unknown_Quarterly' AND submissionId = @submissionId;

--Annual Goods Sent
--Local
SELECT @CALC_AnnualGoodsSent_Local = ((@BAQ_GoodsSent_Local_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Local_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Local_Monthly * 12)
										+ (@BAQ_GoodsSent_Local_Quarterly *4))
										* @MBD_DELIVERY_LOCAL_KMS
										/1000
--National
SELECT @CALC_AnnualGoodsSent_National = ((@BAQ_GoodsSent_National_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_National_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_National_Monthly * 12)
										+ (@BAQ_GoodsSent_National_Quarterly *4))
										* @MBD_DELIVERY_NATIONAL_KMS
										/1000
--International
SELECT @CALC_AnnualGoodsSent_International = ((@BAQ_GoodsSent_International_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_International_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_International_Monthly * 12)
										+ (@BAQ_GoodsSent_International_Quarterly *4))
										* @MBD_DELIVERY_INTERNATIONAL_KMS
										/1000
--Unknown
SELECT @CALC_AnnualGoodsSent_Unknown = ((@BAQ_GoodsSent_Unknown_Daily * @BAQ_WorkingDaysAndCommuting_AvgDaysPerWeekWorked_Office * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Unknown_Weekly * @CALC_WeeksInYear)
										+ (@BAQ_GoodsSent_Unknown_Monthly * 12)
										+ (@BAQ_GoodsSent_Unknown_Quarterly *4))
										* @MBD_DELIVERY_UNKNOWN_KMS
										/1000


SELECT 'Spend on services' AS category, @CALC_TotalSpendOnServices AS total, 'currency' AS dataunit, 'Purchased Goods and Services' as bmCategory, 12 as [order]
UNION
SELECT 'Spend on products', @CALC_TotalSpendOnProducts, 'currency', 'Purchased Goods and Services', 12
UNION
SELECT 'Homeworking hours', (@CALC_AnnualDaysHomeWorking_Office+@CALC_AnnualDaysHomeWorking_Other)*@CALC_HoursPerDay, 'hours', 'Home Working', 7.5
UNION
SELECT 'Office commuting distance public transport', @CALC_AnnualCommutingDistance_Office_Public, 'km', 'Commuting', 7
UNION
SELECT 'Office commuting distance private transport', @CALC_AnnualCommutingDistance_Office_Private, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance public transport', @CALC_AnnualCommutingDistance_Other_Public, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance private transport', @CALC_AnnualCommutingDistance_Other_Private, 'km', 'Commuting', 7
UNION 
SELECT 'Company vehicle distance cars', @BAQ_CompanyVehiclesMileage_Cars, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance vans', @BAQ_CompanyVehiclesMileage_Vans, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance HGVs', @BAQ_CompanyVehiclesMileage_HGVs, 'km', 'Company Vehicles (KM)', 4
UNION	
SELECT 'Goods received local', @CALC_AnnualGoodsReceived_Local, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received national', @CALC_AnnualGoodsReceived_National, 't-km', 'Downstream Deliveries', 11
UNION
SELECT 'Goods received international', @CALC_AnnualGoodsReceived_International, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received unknown', @CALC_AnnualGoodsReceived_Unknown, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods sent local', @CALC_AnnualGoodsSent_Local, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent national', @CALC_AnnualGoodsSent_National, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent international', @CALC_AnnualGoodsSent_International, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent unknown', @CALC_AnnualGoodsSent_Unknown, 't-km', 'Upstream Deliveries', 10
UNION 
SELECT 'Business travel domestic', @CALC_AnnualBusinessTravel_Domestic, 'days', 'Business Travel - Domestic (KM)', 6
UNION 
SELECT 'Business travel international', @CALC_AnnualBusinessTravel_International, 'days', 'Business Travel - International (KM)', 6
UNION
SELECT 'Electricity usage office', @CALC_AnnualElectric_Office, 'kWh', 'Electricity', 5
UNION
SELECT 'Refrigerent usage office', @CALC_TotalRefrigerant, 'kg', 'Refrigerents', 2
UNION
SELECT 'Other fuels usage office', @CALC_TotalOtherFuel, 'tonnes/kWh/liters', 'Other Fuels', 3
UNION
SELECT 'Gas usage office', @CALC_AnnualGas_Office, 'kWh', 'Natural Gas', 1
UNION
SELECT 'Water usage office', @CALC_AnnualWater_Office, 'Cubic Meters', 'Water', 9
UNION 
SELECT 'Office recycling', @CALC_OfficeWaste_Recycling, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office refuse', @CALC_OfficeWaste_Refuse, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office headcount', @BAQ_OfficeHeadcount, 'person', '', 13
UNION 
SELECT 'Other headcount', @CALC_OtherHeadcount, 'person', '', 13
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutputWithBenchmarks
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutputWithBenchmarks]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutputWithBenchmarks]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutputWithBenchmarks] 
	@submissionid BIGINT,
	@emissionProfileId INT = 1
AS
BEGIN
	
		-- EXEC [DataModel].[spBAQ_DataOutputWithBenchmarks] 5913355162935174087
	CREATE TABLE #BAQData (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2)
	);

	INSERT INTO #BAQData (category, total, dataUnit, bmCategory, [order])
	EXEC [DataModel].[spBAQ_DataOutput] @submissionid;


	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	-- Totals by activity from our data collection
	WITH CTE_INPUT_TOTALS_BY_ACTIVITY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName,  
						PercentageOfTotal,
						Utilities.GetEF(t.emissionActivityId, @emissionProfileId) as EF, 
						--TODO Get below data with default profile as above
						e.WTT, 
						e.TND, 
						e.TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = @emissionProfileId
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName AS Category,  
						SUM(PercentageOfTotal*ef) AS EF,
						SUM(PercentageOfTotal*wtt) AS WTT,
						SUM(PercentageOfTotal*tnd) AS TND,
						SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CTE_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	,CTE_FINAL AS (
		 SELECT baq.category, 
						baq.total, 
						baq.dataunit, 
						baq.bmCategory, 
						baq.[order],
						bm.EF, 	
						bm.WTT, 
						bm.TND, 
						bm.TNDWTT
			 FROM #BAQData baq
	LEFT JOIN [CTE_BENCHMARKS_BY_CATEGORY] bm ON baq.bmCategory = bm.category
 )
	
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, [order], ef, wtt, tnd, tndwtt)
	SELECT * FROM CTE_FINAL

	
	DECLARE @scope1Categories NVARCHAR(MAX) = 'Company vehicle distance cars,Company vehicle distance HGVs,Company vehicle distance vans,Gas usage office';
	DECLARE @scope2Categories NVARCHAR(MAX) = 'Electricity usage office';
	DECLARE @scope3Categories NVARCHAR(MAX) = 'Business Travel - Domestic (KM),Business Travel - International (KM),Commuting,Home Working,Waste and Recycling,Water,Upstream Deliveries,Downstream Deliveries,Purchased Goods and Services';

	DECLARE @totalScope1 DECIMAL(10,2) = (SELECT SUM(total * EF) FROM #BAQDataWithBM WHERE category in (SELECT value FROM STRING_SPLIT(@scope1Categories, ',')));
	DECLARE @totalScope2 DECIMAL(10,2) = (SELECT SUM(total * EF) FROM #BAQDataWithBM WHERE category in (@scope2Categories));
	DECLARE @totalScope3EF DECIMAL(10,2) = (SELECT SUM(total * EF) FROM #BAQDataWithBM WHERE bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ',')));
	DECLARE @totalScope3WTT DECIMAL(10,2) = (SELECT SUM(total * (ISNULL(WTT, 0) + ISNULL(TND, 0) + ISNULL(TNDWTT, 0))) FROM #BAQDataWithBM WHERE NULLIF(bmCategory, '') IS NOT NULL);
	DECLARE @totalScope3 DECIMAL(10,2) = @totalScope3EF + @totalScope3WTT;
	DECLARE @company nvarchar(500), @headCount INT;
	SELECT @company = [BAQ_CompanyName], @headCount = [BAQ_TotalHeadCount] FROM [DataModel].[BlueAwardSubmissionData] WHERE submissionId = @submissionid;
 
	--SCOPE BASED CALCULATIONS

	-- SCOPE 1 Calculations
	SELECT 1 as [id], 
				[order],
				@submissionId as [Submission Id],
				@company as [Company],
				@headCount as [Head Count],
				'Scope-1' as Scope, 
				bmCategory as [Category], 
				category as [Sub Category], 
				total,
				EF,
				WTT,
				TND,
				TNDWTT,
				CAST((total * EF) as DECIMAL(18,2)) as [Total Kg CO2e], 
				CAST((((total * EF) / @totalScope1) * 100) as DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM
	 WHERE category in (SELECT value FROM STRING_SPLIT(@scope1Categories, ','))

	UNION
	
	SELECT 2 as [id], '100', @submissionId as [Submission Id], @company as [Company], @headCount as [Head Count],'Total Scope-1' as [Scope], '', '', null, null, null, null, null, @totalScope1, '100' 
	
	UNION

	-- SCOPE 2 Calculations
	SELECT 3 as [id], 
				[order],
				@submissionId as [Submission Id],
				@company as [Company],
				@headCount as [Head Count],
				'Scope-2' as Scope, 
				bmCategory as [Category], 
				category as [Sub Category], 
				total,
				EF,
				WTT,
				TND,
				TNDWTT,
				CAST((total * EF) as DECIMAL(18,2)) as [Total Kg CO2e], 
				CAST((((total * EF) / @totalScope2) * 100) as DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM
	 WHERE category in (@scope2Categories)

	UNION
	
	SELECT 4 as [id], '100', @submissionId as [Submission Id], @company as [Company], @headCount as [Head Count], 'Total Scope-2' ,'', '', null, null, null, null, null, @totalScope2 , '100' 
	
	UNION

	-- SCOPE 3 Calculations
	SELECT 5 as [id], 
					[order],
					@submissionId as [Submission Id],
					@company as [Company],
					@headCount as [Head Count],
					'Scope-3', 
					bmCategory, 
					category, 
					total,
					EF,
					WTT,
					TND,
					TNDWTT,
					CAST((total * EF) as DECIMAL(18,2)) as [Total Kg CO2e], 
					CAST((((total * EF) / @totalScope3) * 100) as DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM
	 WHERE bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ','))
	
	UNION

	-- SCOPE 3 WTT Calculations
	SELECT 6 as [id], 
					[order],
					@submissionId as [Submission Id],
					@company as [Company],
					@headCount as [Head Count],
					'Scope-3' as Scope, 
					CONCAT('WTT-',bmCategory), 
					CONCAT('WTT-',category),
					total,
					EF,
					WTT,
					TND,
					TNDWTT,
					CAST((total * (ISNULL(WTT, 0) + ISNULL(TND, 0) + ISNULL(TNDWTT, 0))) as DECIMAL(18,2)) as [Total Kg CO2e], 
					CAST((((total * (ISNULL(WTT, 0) + ISNULL(TND, 0) + ISNULL(TNDWTT, 0))) / @totalScope3) * 100) as DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM
	 WHERE NULLIF(bmCategory, '') IS NOT NULL AND bmCategory NOT IN ('Purchased Goods and Services','Waste and Recycling')
	
	UNION
	
	SELECT 7 as [id], '100', @submissionId as [Submission Id], @company as [Company], @headCount as [Head Count], 'Total Scope-3','', '',  null, null, null, null, null, @totalScope3, '100'

	ORDER BY [id], [order]

	--SELECT * FROM #BAQDataWithBM ;

	
	DROP TABLE #BAQData;
	DROP TABLE #BAQDataWithBM;


END
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutputByScope_10Dec2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutputByScope_10Dec2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutputByScope_10Dec2024]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutputByScope_10Dec2024] 
	@BAQSubmissionid BIGINT,
	@silverSubmissionIds nvarchar(MAX) = NULL,
	@emissionProfileId INT = 1
AS
BEGIN
	
	-- EXEC [DataModel].[spBAQ_DataOutputByScope] 5913355162935174087
	CREATE TABLE #BAQData (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2)
	);

	INSERT INTO #BAQData (category, total, dataUnit, bmCategory, [order])
	EXEC [DataModel].[spBAQ_DataOutput] @BAQSubmissionid;


	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(1000),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	-- Totals by activity from our data collection
	WITH CTE_INPUT_TOTALS_BY_ACTIVITY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName,  
						PercentageOfTotal,
						Utilities.GetEF(t.emissionActivityId, @emissionProfileId) as EF,
						Utilities.GetWTT(t.emissionActivityId, @emissionProfileId) as WTT, 
						Utilities.GetTND(t.emissionActivityId, @emissionProfileId) as TND, 
						Utilities.GetTNDWTT(t.emissionActivityId, @emissionProfileId) as TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = @emissionProfileId
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName AS Category,  
						SUM(PercentageOfTotal*ef) AS EF,
						SUM(PercentageOfTotal*wtt) AS WTT,
						SUM(PercentageOfTotal*tnd) AS TND,
						SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CTE_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	,CTE_FINAL AS (
		 SELECT baq.category, 
						baq.total, 
						baq.dataunit, 
						baq.bmCategory, 
						baq.[order],
						bm.EF, 	
						bm.WTT, 
						bm.TND, 
						bm.TNDWTT
			 FROM #BAQData baq
	LEFT JOIN [CTE_BENCHMARKS_BY_CATEGORY] bm ON baq.bmCategory = bm.category
 )
	
-- BAQ data group by category.
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, [order], ef, wtt, tnd, tndwtt)
	SELECT  STRING_AGG([Category], ', ') as [Sub Categories],
				SUM(total) as [Total],
				MAX(dataUnit) as [dataUnit],
				bmCategory,
				MAX([order]) as [Order],
				SUM(total * ef) as TotalEF, 
				SUM(total * wtt) as TotalWTT,
				SUM(total * tnd) as TotalTND, 
				SUM(total * tndwtt) as TotalTNDWTT
		FROM CTE_FINAL 
		GROUP BY bmCategory;


-- Get the silver submission data
	CREATE TABLE #SilverData (
			formName NVARCHAR(255),
			category NVARCHAR(255),
			TotalEF DECIMAL(18, 2),
			TotalWTT DECIMAL(18, 2),
			TotalTND DECIMAL(18, 2),
			TotalTNDWTT DECIMAL(18, 2)
		);
		
	INSERT INTO #SilverData (formName, category, TotalEF, TotalWTT, TotalTND, TotalTNDWTT)
	EXEC [DataModel].[spSilver_DataOutput] @silverSubmissionIds, @emissionProfileId

	
	DECLARE @scope1Categories NVARCHAR(MAX) = 'Natural Gas,Company Vehicles (KM),Refrigerents,Other Fuels';
	DECLARE @scope2Categories NVARCHAR(MAX) = 'Electricity';
	DECLARE @scope3Categories NVARCHAR(MAX) = 'Business Travel - Domestic (KM),Business Travel - International (KM),Commuting,Home Working,Waste and Recycling,Water,Upstream Deliveries,Downstream Deliveries,Purchased Goods and Services';

	DECLARE @totalScope1 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ',')));
	
	DECLARE @totalScope2 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ',')));
																				 
	DECLARE @totalScope3EF DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ',')));
	
	DECLARE @totalScope3WTT DECIMAL(18,2) =  (SELECT SUM(COALESCE(s.totalWTT, b.WTT)) + SUM(COALESCE(s.totalTND, b.TND)) + SUM(COALESCE(s.totalTNDWTT, b.TNDWTT))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE NULLIF(b.bmCategory, '') IS NOT NULL);
	
	DECLARE @totalScope3 DECIMAL(10,2) = @totalScope3EF + @totalScope3WTT;
	DECLARE @company nvarchar(500), @headCount INT, @revenue nvarchar(50), @submissionDate nvarchar(50), @name nvarchar(100), @email nvarchar(100), @jobtitle nvarchar(100), @startDate nvarchar(100);
	SELECT @company = [BAQ_CompanyName], @headCount = [BAQ_TotalHeadCount], @revenue = BAQ_CompanyRevenue, @submissionDate = jr.createdDate, 
				 @name = BAQ_YourName, @email = BAQ_Email, @jobtitle = BAQ_JobTitle, @startDate = CAST(BAQ_ReportStartDate as date)
		FROM [DataModel].[BlueAwardSubmissionData] bas
		INNER JOIN [Forms].[JotformRawResponse] jr on jr.submissionId = bas.submissionId
		WHERE bas.submissionId = @BAQSubmissionid;
 

	--SCOPE BASED CALCULATIONS

SELECT MAX(id) as [ID], MAX([order]) as [Order], @BAQSubmissionid as [Submission Id], @submissionDate as [Submission Date], @company as [Company], @headCount as [Head Count], @revenue as [Revenue],
			 [Scope], [Category], STRING_AGG([Sub Category], ', ') as [Sub Categories], SUM(ISNULL([Total Kg CO2e], 0)) as [Total Kg CO2e], 
			 SUM(ISNULL([% of total emissions scope wise], 0)) as [% of total emissions scope wise], @name as [Name], @email as [Email], @jobtitle as [Job Title], @startDate as [Report Start Date]
 FROM (
	-- SCOPE 1 Calculations
	SELECT 1 as [id], 
				[order],
				'Scope-1' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category], 
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope1 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope1) * 100 
						ELSE (s.totalEF / @totalScope1) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ','))

	UNION
	
	SELECT 2 as [id], '100', 'Total Scope-1' as [Scope], '', '', @totalScope1, '100' 
	
	UNION

	-- SCOPE 2 Calculations
	SELECT 3 as [id], 
				[order],
				'Scope-2' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category],
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope2 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope2) * 100 
						ELSE (s.totalEF / @totalScope2) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ','))

	UNION
	
	SELECT 4 as [id], '100', 'Total Scope-2' ,'', '',  @totalScope2 , '100' 
	
	UNION

	-- SCOPE 3 Calculations
	SELECT 5 as [id], 
					[order],
					'Scope-3', 
					b.bmCategory, 
					b.category, 
					(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN ((b.EF) / @totalScope3) * 100 
							ELSE (s.totalEF / @totalScope3) * 100 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
			FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ','))
	
	UNION

	-- SCOPE 3 WTT Calculations
	SELECT 6 as [id], 
					b.[order],
					'Scope-3' as Scope, 
					CONCAT('WTT-',b.bmCategory), 
					CONCAT('WTT-',b.category),
					(CASE WHEN s.Category IS NULL THEN CAST(((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) as DECIMAL(18,2)) 
						 ELSE CAST(((ISNULL(TotalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) as DECIMAL(18,2))
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN CAST((((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2))
							ELSE CAST((((ISNULL(totalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2)) 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
		LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE NULLIF(bmCategory, '') IS NOT NULL AND bmCategory NOT IN ('Purchased Goods and Services','Waste and Recycling')
	
	UNION
	
	SELECT 7 as [id], '100', 'Total Scope-3','', '', @totalScope3, '100'

) as tbl 	
	GROUP BY [Scope], [Category]
	ORDER BY [id], [order]

-- 	SELECT * FROM #BAQData;
-- 	SELECT * FROM #SilverData;
-- 	SELECT * FROM #BAQDataWithBM;
-- 	SELECT @totalScope3EF as totalScope3EF, @totalScope3WTT as totalScope3WTT;
	
	DROP TABLE #BAQData;
	DROP TABLE #BAQDataWithBM;
	DROP TABLE #SilverData;

END
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutputByScope
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutputByScope]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutputByScope]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutputByScope] 
	@BAQSubmissionid BIGINT,
	@silverSubmissionIds nvarchar(MAX) = NULL,
	@emissionProfileId INT = 1
AS
BEGIN
	
	-- EXEC [DataModel].[spBAQ_DataOutputByScope] 5913355162935174087
	CREATE TABLE #BAQData (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2)
	);

	INSERT INTO #BAQData (category, total, dataUnit, bmCategory, [order])
	EXEC [DataModel].[spBAQ_DataOutput] @BAQSubmissionid;


	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(1000),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	-- Totals by activity from our data collection
	WITH CTE_INPUT_TOTALS_BY_ACTIVITY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName,  
						PercentageOfTotal,
						Utilities.GetEF(t.emissionActivityId, @emissionProfileId) as EF,
						Utilities.GetWTT(t.emissionActivityId, @emissionProfileId) as WTT, 
						Utilities.GetTND(t.emissionActivityId, @emissionProfileId) as TND, 
						Utilities.GetTNDWTT(t.emissionActivityId, @emissionProfileId) as TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = @emissionProfileId
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName AS Category,  
						SUM(PercentageOfTotal*ef) AS EF,
						SUM(PercentageOfTotal*wtt) AS WTT,
						SUM(PercentageOfTotal*tnd) AS TND,
						SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CTE_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	,CTE_FINAL AS (
		 SELECT baq.category, 
						baq.total, 
						baq.dataunit, 
						baq.bmCategory, 
						baq.[order],
						bm.EF, 	
						bm.WTT, 
						bm.TND, 
						bm.TNDWTT
			 FROM #BAQData baq
	LEFT JOIN [CTE_BENCHMARKS_BY_CATEGORY] bm ON baq.bmCategory = bm.category
 )
	
-- BAQ data group by category.
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, [order], ef, wtt, tnd, tndwtt)
	SELECT  STRING_AGG([Category], ', ') as [Sub Categories],
				SUM(total) as [Total],
				MAX(dataUnit) as [dataUnit],
				bmCategory,
				MAX([order]) as [Order],
				SUM(total * ef) as TotalEF, 
				SUM(total * wtt) as TotalWTT,
				SUM(total * tnd) as TotalTND, 
				SUM(total * tndwtt) as TotalTNDWTT
		FROM CTE_FINAL 
		GROUP BY bmCategory;


-- Get the silver submission data
	CREATE TABLE #SilverData (
			formName NVARCHAR(255),
			category NVARCHAR(255),
			TotalEF DECIMAL(18, 2),
			TotalWTT DECIMAL(18, 2),
			TotalTND DECIMAL(18, 2),
			TotalTNDWTT DECIMAL(18, 2)
		);
		
	INSERT INTO #SilverData (formName, category, TotalEF, TotalWTT, TotalTND, TotalTNDWTT)
	EXEC [DataModel].[spSilver_DataOutput] @silverSubmissionIds, @emissionProfileId

	
	DECLARE @scope1Categories NVARCHAR(MAX) = 'Natural Gas,Company Vehicles (KM),Refrigerents,Other Fuels';
	DECLARE @scope2Categories NVARCHAR(MAX) = 'Electricity';
	DECLARE @scope3Categories NVARCHAR(MAX) = 'Business Travel - Domestic (KM),Business Travel - International (KM),Commuting,Home Working,Waste and Recycling,Water,Upstream Deliveries,Downstream Deliveries,Purchased Goods and Services';

	DECLARE @totalScope1 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ',')));
	
	DECLARE @totalScope2 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ',')));
																				 
	DECLARE @totalScope3EF DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ',')));
	
	DECLARE @totalScope3WTT DECIMAL(18,2) =  (SELECT SUM(COALESCE(s.totalWTT, b.WTT)) + SUM(COALESCE(s.totalTND, b.TND)) + SUM(COALESCE(s.totalTNDWTT, b.TNDWTT))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE NULLIF(b.bmCategory, '') IS NOT NULL);
	
	DECLARE @totalScope3 DECIMAL(10,2) = @totalScope3EF + @totalScope3WTT;
	DECLARE @company nvarchar(500), @headCount INT, @revenue nvarchar(50), @submissionDate nvarchar(50), @name nvarchar(100), @email nvarchar(100), @jobtitle nvarchar(100), @startDate nvarchar(25), @endDate nvarchar(25);
	SELECT @company = [BAQ_CompanyName], @headCount = [BAQ_TotalHeadCount], @revenue = BAQ_CompanyRevenue, @submissionDate = jr.createdDate, 
				 @name = BAQ_YourName, @email = BAQ_Email, @jobtitle = BAQ_JobTitle, 
         @startDate = CAST(BAQ_ReportStartDate as date), @endDate = CAST(DATEADD(DAY, -1, DATEADD(YEAR, 1, @startDate)) as date)
		FROM [DataModel].[BlueAwardSubmissionData] bas
		INNER JOIN [Forms].[JotformRawResponse] jr on jr.submissionId = bas.submissionId
		WHERE bas.submissionId = @BAQSubmissionid;
 

	--SCOPE BASED CALCULATIONS

SELECT MAX(id) as [ID], MAX([order]) as [Order], @BAQSubmissionid as [Submission Id], @submissionDate as [Submission Date], @company as [Company], @headCount as [Head Count], @revenue as [Revenue],
			 [Scope], [Category], STRING_AGG([Sub Category], ', ') as [Sub Categories], SUM(ISNULL([Total Kg CO2e], 0)) as [Total Kg CO2e], 
       SUM(ISNULL([% of total emissions scope wise], 0)) as [% of total emissions scope wise], [IsModelled],
       @name as [Name], @email as [Email], @jobtitle as [Job Title], @startDate as [Report Start Date], @endDate as [Report End Date]
 FROM (
	-- SCOPE 1 Calculations
	SELECT 1 as [id], 
				[order],
				'Scope-1' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category], 
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope1 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope1) * 100 
						ELSE (s.totalEF / @totalScope1) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise],
        (CASE 
          WHEN s.Category IS NULL THEN 1  ELSE 0 
				END) as [IsModelled]
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ','))

	UNION
	
	SELECT 2 as [id], '100', 'Total Scope-1' as [Scope], '', '', @totalScope1, '100' , 0
	
	UNION

	-- SCOPE 2 Calculations
	SELECT 3 as [id], 
				[order],
				'Scope-2' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category],
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope2 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope2) * 100 
						ELSE (s.totalEF / @totalScope2) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise],
        (CASE 
          WHEN s.Category IS NULL THEN 1  ELSE 0 
				END) as [IsModelled] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ','))

	UNION
	
	SELECT 4 as [id], '100', 'Total Scope-2' ,'', '',  @totalScope2 , '100' , 0
	
	UNION

	-- SCOPE 3 Calculations
	SELECT 5 as [id], 
					[order],
					'Scope-3', 
					b.bmCategory, 
					b.category, 
					(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN ((b.EF) / @totalScope3) * 100 
							ELSE (s.totalEF / @totalScope3) * 100 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise],
          (CASE 
            WHEN s.Category IS NULL THEN 1  ELSE 0 
          END) as [IsModelled] 
			FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ','))
	
	UNION

	-- SCOPE 3 WTT Calculations
	SELECT 6 as [id], 
					b.[order],
					'Scope-3' as Scope, 
					CONCAT('WTT-',b.bmCategory), 
					CONCAT('WTT-',b.category),
					(CASE WHEN s.Category IS NULL THEN CAST(((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) as DECIMAL(18,2)) 
						 ELSE CAST(((ISNULL(TotalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) as DECIMAL(18,2))
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN CAST((((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2))
							ELSE CAST((((ISNULL(totalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2)) 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise],
          (CASE 
            WHEN s.Category IS NULL THEN 1  ELSE 0 
          END) as [IsModelled] 
		FROM #BAQDataWithBM b
		LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE NULLIF(bmCategory, '') IS NOT NULL AND bmCategory NOT IN ('Purchased Goods and Services','Waste and Recycling')
	
	UNION
	
	SELECT 7 as [id], '100', 'Total Scope-3','', '', @totalScope3, '100', 0

) as tbl 	
	GROUP BY [Scope], [Category], [IsModelled]
	ORDER BY [id], [order]

-- 	SELECT * FROM #BAQData;
-- 	SELECT * FROM #SilverData;
-- 	SELECT * FROM #BAQDataWithBM;
-- 	SELECT @totalScope3EF as totalScope3EF, @totalScope3WTT as totalScope3WTT;
	
	DROP TABLE #BAQData;
	DROP TABLE #BAQDataWithBM;
	DROP TABLE #SilverData;

END
GO


-- ----------------------------
-- procedure structure for spGold_DataOutput
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spGold_DataOutput]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spGold_DataOutput]
GO

CREATE PROCEDURE [DataModel].[spGold_DataOutput] 
	
AS

SELECT 'Spend on services' AS category, 0 AS total, 'currency' AS dataunit, 'Purchased Goods and Services' as bmCategory, 12 as [order]
UNION
SELECT 'Spend on products', 0, 'currency', 'Purchased Goods and Services', 12
UNION
SELECT 'Homeworking hours', 0, 'hours', 'Home Working', 7.5
UNION
SELECT 'Office commuting distance public transport', 0, 'km', 'Commuting', 7
UNION
SELECT 'Office commuting distance private transport', 0, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance public transport', 0, 'km', 'Commuting', 7
UNION
SELECT 'Other commuting distance private transport', 0, 'km', 'Commuting', 7
UNION 
SELECT 'Company vehicle distance cars', 0, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance vans', 0, 'km', 'Company Vehicles (KM)', 4
UNION 	
SELECT 'Company vehicle distance HGVs', 0, 'km', 'Company Vehicles (KM)', 4
UNION	
SELECT 'Goods received local', 0, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received national', 0, 't-km', 'Downstream Deliveries', 11
UNION
SELECT 'Goods received international', 0, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods received unknown', 0, 't-km', 'Downstream Deliveries', 11
UNION	
SELECT 'Goods sent local', 0, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent national', 0, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent international', 0, 't-km', 'Upstream Deliveries', 10
UNION	
SELECT 'Goods sent unknown', 0, 't-km', 'Upstream Deliveries', 10
UNION 
SELECT 'Business travel domestic', 0, 'days', 'Business Travel - Domestic (KM)', 6
UNION 
SELECT 'Business travel international', 0, 'days', 'Business Travel - International (KM)', 6
UNION
SELECT 'Electricity usage office', 0, 'kWh', 'Electricity', 5
UNION
SELECT 'Refrigerent usage office', 0, 'kg', 'Refrigerents', 2
UNION
SELECT 'Other fuels usage office', 0, 'tonnes/kWh/liters', 'Other Fuels', 3
UNION
SELECT 'Gas usage office', 0, 'kWh', 'Natural Gas', 1
UNION
SELECT 'Water usage office', 0, 'Cubic Meters', 'Water', 9
UNION 
SELECT 'Office recycling', 0, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office refuse', 0, 'tonnes', 'Waste and Recycling', 8
UNION 
SELECT 'Office headcount', 0, 'person', '', 13
UNION 
SELECT 'Other headcount', 0, 'person', '', 13
GO


-- ----------------------------
-- procedure structure for spGold_DataOutputByScope
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spGold_DataOutputByScope]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spGold_DataOutputByScope]
GO

CREATE PROCEDURE [DataModel].[spGold_DataOutputByScope] 
	@BAQSubmissionid BIGINT,
	@silverSubmissionIds nvarchar(MAX) = NULL,
	@emissionProfileId INT = 1
AS
BEGIN
	
	CREATE TABLE #BAQData (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2)
	);

	INSERT INTO #BAQData (category, total, dataUnit, bmCategory, [order])
	EXEC [DataModel].[spGold_DataOutput] ;


	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(1000),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	-- Totals by activity from our data collection
	WITH CTE_INPUT_TOTALS_BY_ACTIVITY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName,  
						PercentageOfTotal,
						Utilities.GetEF(t.emissionActivityId, @emissionProfileId) as EF,
						Utilities.GetWTT(t.emissionActivityId, @emissionProfileId) as WTT, 
						Utilities.GetTND(t.emissionActivityId, @emissionProfileId) as TND, 
						Utilities.GetTNDWTT(t.emissionActivityId, @emissionProfileId) as TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = @emissionProfileId
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName AS Category,  
						SUM(PercentageOfTotal*ef) AS EF,
						SUM(PercentageOfTotal*wtt) AS WTT,
						SUM(PercentageOfTotal*tnd) AS TND,
						SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CTE_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	,CTE_FINAL AS (
		 SELECT baq.category, 
						baq.total, 
						baq.dataunit, 
						baq.bmCategory, 
						baq.[order],
						bm.EF, 	
						bm.WTT, 
						bm.TND, 
						bm.TNDWTT
			 FROM #BAQData baq
	LEFT JOIN [CTE_BENCHMARKS_BY_CATEGORY] bm ON baq.bmCategory = bm.category
 )
	
-- BAQ data group by category.
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, [order], ef, wtt, tnd, tndwtt)
	SELECT  STRING_AGG([Category], ', ') as [Sub Categories],
				SUM(total) as [Total],
				MAX(dataUnit) as [dataUnit],
				bmCategory,
				MAX([order]) as [Order],
				SUM(total * ef) as TotalEF, 
				SUM(total * wtt) as TotalWTT,
				SUM(total * tnd) as TotalTND, 
				SUM(total * tndwtt) as TotalTNDWTT
		FROM CTE_FINAL 
		GROUP BY bmCategory;


-- Get the silver submission data
	CREATE TABLE #SilverData (
			formName NVARCHAR(255),
			category NVARCHAR(255),
			TotalEF DECIMAL(18, 2),
			TotalWTT DECIMAL(18, 2),
			TotalTND DECIMAL(18, 2),
			TotalTNDWTT DECIMAL(18, 2)
		);
		
	INSERT INTO #SilverData (formName, category, TotalEF, TotalWTT, TotalTND, TotalTNDWTT)
	EXEC [DataModel].[spSilver_DataOutput] @silverSubmissionIds, @emissionProfileId

	
	DECLARE @scope1Categories NVARCHAR(MAX) = 'Natural Gas,Company Vehicles (KM),Refrigerents,Other Fuels';
	DECLARE @scope2Categories NVARCHAR(MAX) = 'Electricity';
	DECLARE @scope3Categories NVARCHAR(MAX) = 'Business Travel - Domestic (KM),Business Travel - International (KM),Commuting,Home Working,Waste and Recycling,Water,Upstream Deliveries,Downstream Deliveries,Purchased Goods and Services';

	DECLARE @totalScope1 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ',')));
	
	DECLARE @totalScope2 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ',')));
																				 
	DECLARE @totalScope3EF DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ',')));
	
	DECLARE @totalScope3WTT DECIMAL(18,2) =  (SELECT SUM(COALESCE(s.totalWTT, b.WTT)) + SUM(COALESCE(s.totalTND, b.TND)) + SUM(COALESCE(s.totalTNDWTT, b.TNDWTT))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE NULLIF(b.bmCategory, '') IS NOT NULL);
	
	DECLARE @totalScope3 DECIMAL(10,2) = @totalScope3EF + @totalScope3WTT;
	DECLARE @company nvarchar(500), @headCount INT, @revenue nvarchar(50), @submissionDate nvarchar(50), @name nvarchar(100), @email nvarchar(100), @jobtitle nvarchar(100), @startDate nvarchar(100);
	SELECT @company = [BAQ_CompanyName], @headCount = [BAQ_TotalHeadCount], @revenue = BAQ_CompanyRevenue, @submissionDate = jr.createdDate, 
				 @name = BAQ_YourName, @email = BAQ_Email, @jobtitle = BAQ_JobTitle, @startDate = CAST(BAQ_ReportStartDate as date)
		FROM [DataModel].[GoldAwardSubmissionData] bas
		INNER JOIN [Forms].[JotformRawResponse] jr on jr.submissionId = bas.submissionId
		WHERE bas.submissionId = @BAQSubmissionid;
 

	--SCOPE BASED CALCULATIONS

SELECT MAX(id) as [ID], MAX([order]) as [Order], @BAQSubmissionid as [Submission Id], @submissionDate as [Submission Date], @company as [Company], @headCount as [Head Count], @revenue as [Revenue],
			 [Scope], [Category], STRING_AGG([Sub Category], ', ') as [Sub Categories], SUM(ISNULL([Total Kg CO2e], 0)) as [Total Kg CO2e], 
       SUM(ISNULL([% of total emissions scope wise], 0)) as [% of total emissions scope wise], [IsModelled],
       @name as [Name], @email as [Email], @jobtitle as [Job Title], @startDate as [Report Start Date]
 FROM (
	-- SCOPE 1 Calculations
	SELECT 1 as [id], 
				[order],
				'Scope-1' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category], 
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope1 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope1) * 100 
						ELSE (s.totalEF / @totalScope1) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise],
        0 as [IsModelled]
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ','))

	UNION
	
	SELECT 2 as [id], '100', 'Total Scope-1' as [Scope], '', '', @totalScope1, '100' , 0
	
	UNION

	-- SCOPE 2 Calculations
	SELECT 3 as [id], 
				[order],
				'Scope-2' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category],
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope2 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope2) * 100 
						ELSE (s.totalEF / @totalScope2) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise],
        0 as [IsModelled] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ','))

	UNION
	
	SELECT 4 as [id], '100', 'Total Scope-2' ,'', '',  @totalScope2 , '100' , 0
	
	UNION

	-- SCOPE 3 Calculations
	SELECT 5 as [id], 
					[order],
					'Scope-3', 
					b.bmCategory, 
					b.category, 
					(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN ((b.EF) / @totalScope3) * 100 
							ELSE (s.totalEF / @totalScope3) * 100 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise],
          0 as [IsModelled] 
			FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ','))
	
	UNION

	-- SCOPE 3 WTT Calculations
	SELECT 6 as [id], 
					b.[order],
					'Scope-3' as Scope, 
					CONCAT('WTT-',b.bmCategory), 
					CONCAT('WTT-',b.category),
					(CASE WHEN s.Category IS NULL THEN CAST(((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) as DECIMAL(18,2)) 
						 ELSE CAST(((ISNULL(TotalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) as DECIMAL(18,2))
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN CAST((((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2))
							ELSE CAST((((ISNULL(totalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2)) 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise],
          0 as [IsModelled] 
		FROM #BAQDataWithBM b
		LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE NULLIF(bmCategory, '') IS NOT NULL AND bmCategory NOT IN ('Purchased Goods and Services','Waste and Recycling')
	
	UNION
	
	SELECT 7 as [id], '100', 'Total Scope-3','', '', @totalScope3, '100', 0

) as tbl 	
	GROUP BY [Scope], [Category], [IsModelled]
	ORDER BY [id], [order]

-- 	SELECT * FROM #BAQData;
-- 	SELECT * FROM #SilverData;
-- 	SELECT * FROM #BAQDataWithBM;
-- 	SELECT @totalScope3EF as totalScope3EF, @totalScope3WTT as totalScope3WTT;
	
	DROP TABLE #BAQData;
	DROP TABLE #BAQDataWithBM;
	DROP TABLE #SilverData;

END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputWrapper
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputWrapper]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputWrapper]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputWrapper] 
	@certificationTaskId nvarchar(50),
	@emissionProfileId INT
AS
BEGIN
	
	DECLARE @BAQSubmissionId bigint;
	DECLARE @SilverSubmissionIds nvarchar(max);
  DECLARE @BAQUniqueId nvarchar(25);
	
  SELECT TOP 1 @BAQSubmissionId = submissionId, @BAQUniqueId = BAQUniqueId 
  FROM [clickup].[vParentTasks] WHERE [formId] = '241290444812856' AND id = @certificationTaskId ORDER BY [dateUpdated] DESC;
	SET @SilverSubmissionIds = (SELECT STRING_AGG([submissionId], ',') FROM [clickup].[vTasks] WHERE [formId] != '241290444812856' AND id = @certificationTaskId)
	
  SET @SilverSubmissionIds = Concat_WS(',', @SilverSubmissionIds,  -- Commuting & Homeworking
                              (Select STRING_AGG(S.[submissionId], ',') from forms.Response as R 
                               INNER JOIN forms.JotformSubmission as S on (R.submissionId=S.Id)
                               INNER JOIN forms.Question as Q on (R.questionId=Q.id and Q.questionTypeId=1 and Q.formId=11 and Q.active=1)
                               Where R.[value] = @BAQUniqueId));
  
  IF @BAQSubmissionId IS NULL
	BEGIN
		SELECT 'Could not find BAQ submissionId' as [error]
		RETURN 0;
	END
	
	IF @SilverSubmissionIds IS NULL
	BEGIN
		SELECT 'Could not find Silver submissionIds' as [error]
	END
	-- select @BAQSubmissionId, @SilverSubmissionIds;
	EXEC DataModel.spBAQ_DataOutputByScope		@BAQSubmissionid = @BAQSubmissionId, @silverSubmissionIds = @SilverSubmissionIds, @emissionProfileId = @emissionProfileId
	
END
GO


-- ----------------------------
-- procedure structure for spBAQ_DataOutputByScope_11Dec2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spBAQ_DataOutputByScope_11Dec2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spBAQ_DataOutputByScope_11Dec2024]
GO

CREATE PROCEDURE [DataModel].[spBAQ_DataOutputByScope_11Dec2024] 
	@BAQSubmissionid BIGINT,
	@silverSubmissionIds nvarchar(MAX) = NULL,
	@emissionProfileId INT = 1
AS
BEGIN
	
	-- EXEC [DataModel].[spBAQ_DataOutputByScope] 5913355162935174087
	CREATE TABLE #BAQData (
    category NVARCHAR(255),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2)
	);

	INSERT INTO #BAQData (category, total, dataUnit, bmCategory, [order])
	EXEC [DataModel].[spBAQ_DataOutput] @BAQSubmissionid;


	CREATE TABLE #BAQDataWithBM (
    category NVARCHAR(1000),
    total DECIMAL(18, 2),
    dataUnit NVARCHAR(50),
    bmCategory NVARCHAR(255),
		[order] DECIMAL(5,2),
		EF DECIMAL(18, 2),
		WTT DECIMAL(18, 2),
		TND DECIMAL(18, 2),
		TNDWTT DECIMAL(18, 2)
	);

	-- Totals by activity from our data collection
	WITH CTE_INPUT_TOTALS_BY_ACTIVITY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName,  
						PercentageOfTotal,
						Utilities.GetEF(t.emissionActivityId, @emissionProfileId) as EF,
						Utilities.GetWTT(t.emissionActivityId, @emissionProfileId) as WTT, 
						Utilities.GetTND(t.emissionActivityId, @emissionProfileId) as TND, 
						Utilities.GetTNDWTT(t.emissionActivityId, @emissionProfileId) as TNDWTT
			 FROM DataModel.InputTotalsByActivity t
			 LEFT JOIN Emissions.EmissionFactor e ON e.activityId = t.emissionActivityId AND e.emissionProfileId = @emissionProfileId
	)

	-- Calculate Benchmark data
	,CTE_BENCHMARKS_BY_CATEGORY AS (
				SELECT
						CONVERT(DATE,GETDATE()) AS Date,
						formName AS Category,  
						SUM(PercentageOfTotal*ef) AS EF,
						SUM(PercentageOfTotal*wtt) AS WTT,
						SUM(PercentageOfTotal*tnd) AS TND,
						SUM(PercentageOfTotal*tndwtt) AS TNDWTT
			 FROM CTE_INPUT_TOTALS_BY_ACTIVITY
			 GROUP BY formname
	)

	,CTE_FINAL AS (
		 SELECT baq.category, 
						baq.total, 
						baq.dataunit, 
						baq.bmCategory, 
						baq.[order],
						bm.EF, 	
						bm.WTT, 
						bm.TND, 
						bm.TNDWTT
			 FROM #BAQData baq
	LEFT JOIN [CTE_BENCHMARKS_BY_CATEGORY] bm ON baq.bmCategory = bm.category
 )
	
-- BAQ data group by category.
	INSERT INTO #BAQDataWithBM (category, total, dataUnit, bmCategory, [order], ef, wtt, tnd, tndwtt)
	SELECT  STRING_AGG([Category], ', ') as [Sub Categories],
				SUM(total) as [Total],
				MAX(dataUnit) as [dataUnit],
				bmCategory,
				MAX([order]) as [Order],
				SUM(total * ef) as TotalEF, 
				SUM(total * wtt) as TotalWTT,
				SUM(total * tnd) as TotalTND, 
				SUM(total * tndwtt) as TotalTNDWTT
		FROM CTE_FINAL 
		GROUP BY bmCategory;


-- Get the silver submission data
	CREATE TABLE #SilverData (
			formName NVARCHAR(255),
			category NVARCHAR(255),
			TotalEF DECIMAL(18, 2),
			TotalWTT DECIMAL(18, 2),
			TotalTND DECIMAL(18, 2),
			TotalTNDWTT DECIMAL(18, 2)
		);
		
	INSERT INTO #SilverData (formName, category, TotalEF, TotalWTT, TotalTND, TotalTNDWTT)
	EXEC [DataModel].[spSilver_DataOutput] @silverSubmissionIds, @emissionProfileId

	
	DECLARE @scope1Categories NVARCHAR(MAX) = 'Natural Gas,Company Vehicles (KM),Refrigerents,Other Fuels';
	DECLARE @scope2Categories NVARCHAR(MAX) = 'Electricity';
	DECLARE @scope3Categories NVARCHAR(MAX) = 'Business Travel - Domestic (KM),Business Travel - International (KM),Commuting,Home Working,Waste and Recycling,Water,Upstream Deliveries,Downstream Deliveries,Purchased Goods and Services';

	DECLARE @totalScope1 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ',')));
	
	DECLARE @totalScope2 DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ',')));
																				 
	DECLARE @totalScope3EF DECIMAL(18,2) = (SELECT SUM(COALESCE(s.totalEF, b.EF))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ',')));
	
	DECLARE @totalScope3WTT DECIMAL(18,2) =  (SELECT SUM(COALESCE(s.totalWTT, b.WTT)) + SUM(COALESCE(s.totalTND, b.TND)) + SUM(COALESCE(s.totalTNDWTT, b.TNDWTT))
																					FROM #BAQDataWithBM b LEFT JOIN #SilverData s ON s.category = b.bmCategory 
																				 WHERE NULLIF(b.bmCategory, '') IS NOT NULL);
	
	DECLARE @totalScope3 DECIMAL(10,2) = @totalScope3EF + @totalScope3WTT;
	DECLARE @company nvarchar(500), @headCount INT, @revenue nvarchar(50), @submissionDate nvarchar(50), @name nvarchar(100), @email nvarchar(100), @jobtitle nvarchar(100), @startDate nvarchar(100);
	SELECT @company = [BAQ_CompanyName], @headCount = [BAQ_TotalHeadCount], @revenue = BAQ_CompanyRevenue, @submissionDate = jr.createdDate, 
				 @name = BAQ_YourName, @email = BAQ_Email, @jobtitle = BAQ_JobTitle, @startDate = CAST(BAQ_ReportStartDate as date)
		FROM [DataModel].[BlueAwardSubmissionData] bas
		INNER JOIN [Forms].[JotformRawResponse] jr on jr.submissionId = bas.submissionId
		WHERE bas.submissionId = @BAQSubmissionid;
 

	--SCOPE BASED CALCULATIONS

SELECT MAX(id) as [ID], MAX([order]) as [Order], @BAQSubmissionid as [Submission Id], @submissionDate as [Submission Date], @company as [Company], @headCount as [Head Count], @revenue as [Revenue],
			 [Scope], [Category], STRING_AGG([Sub Category], ', ') as [Sub Categories], SUM(ISNULL([Total Kg CO2e], 0)) as [Total Kg CO2e], 
			 SUM(ISNULL([% of total emissions scope wise], 0)) as [% of total emissions scope wise], @name as [Name], @email as [Email], @jobtitle as [Job Title], @startDate as [Report Start Date]
 FROM (
	-- SCOPE 1 Calculations
	SELECT 1 as [id], 
				[order],
				'Scope-1' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category], 
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope1 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope1) * 100 
						ELSE (s.totalEF / @totalScope1) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope1Categories, ','))

	UNION
	
	SELECT 2 as [id], '100', 'Total Scope-1' as [Scope], '', '', @totalScope1, '100' 
	
	UNION

	-- SCOPE 2 Calculations
	SELECT 3 as [id], 
				[order],
				'Scope-2' as Scope, 
				b.bmCategory as [Category], 
				b.category as [Sub Category],
				(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
				END) as [Total Kg CO2e], 
				CAST(CASE WHEN @totalScope2 = 0 THEN 0 ELSE 
					(CASE 
						WHEN s.Category IS NULL THEN ((b.EF) / @totalScope2) * 100 
						ELSE (s.totalEF / @totalScope2) * 100 
					END)
				END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope2Categories, ','))

	UNION
	
	SELECT 4 as [id], '100', 'Total Scope-2' ,'', '',  @totalScope2 , '100' 
	
	UNION

	-- SCOPE 3 Calculations
	SELECT 5 as [id], 
					[order],
					'Scope-3', 
					b.bmCategory, 
					b.category, 
					(CASE WHEN s.Category IS NULL THEN CAST((b.EF) as DECIMAL(18,2)) 
						 ELSE CAST((s.totalEF) as DECIMAL(18,2)) 
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN ((b.EF) / @totalScope3) * 100 
							ELSE (s.totalEF / @totalScope3) * 100 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
			FROM #BAQDataWithBM b
	LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE b.bmCategory in (SELECT value FROM STRING_SPLIT(@scope3Categories, ','))
	
	UNION

	-- SCOPE 3 WTT Calculations
	SELECT 6 as [id], 
					b.[order],
					'Scope-3' as Scope, 
					CONCAT('WTT-',b.bmCategory), 
					CONCAT('WTT-',b.category),
					(CASE WHEN s.Category IS NULL THEN CAST(((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) as DECIMAL(18,2)) 
						 ELSE CAST(((ISNULL(TotalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) as DECIMAL(18,2))
					END) as [Total Kg CO2e], 
					CAST(CASE WHEN @totalScope3 = 0 THEN 0 ELSE 
						(CASE 
							WHEN s.Category IS NULL THEN CAST((((ISNULL(b.WTT, 0) + ISNULL(b.TND, 0) + ISNULL(b.TNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2))
							ELSE CAST((((ISNULL(totalWTT, 0) + ISNULL(TotalTND, 0) + ISNULL(TotalTNDWTT, 0))) / @totalScope3) * 100 AS DECIMAL(18,2)) 
						END)
					END AS DECIMAL(18,2)) as [% of total emissions scope wise] 
		FROM #BAQDataWithBM b
		LEFT JOIN #SilverData s ON b.bmCategory = s.category
	 WHERE NULLIF(bmCategory, '') IS NOT NULL AND bmCategory NOT IN ('Purchased Goods and Services','Waste and Recycling')
	
	UNION
	
	SELECT 7 as [id], '100', 'Total Scope-3','', '', @totalScope3, '100'

) as tbl 	
	GROUP BY [Scope], [Category]
	ORDER BY [id], [order]

-- 	SELECT * FROM #BAQData;
-- 	SELECT * FROM #SilverData;
-- 	SELECT * FROM #BAQDataWithBM;
-- 	SELECT @totalScope3EF as totalScope3EF, @totalScope3WTT as totalScope3WTT;
	
	DROP TABLE #BAQData;
	DROP TABLE #BAQDataWithBM;
	DROP TABLE #SilverData;

END
GO


-- ----------------------------
-- procedure structure for spGold_DataOutputWrapper
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spGold_DataOutputWrapper]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spGold_DataOutputWrapper]
GO

CREATE PROCEDURE [DataModel].[spGold_DataOutputWrapper] 
	@certificationTaskId nvarchar(50),
	@emissionProfileId INT
AS
BEGIN
	DECLARE @GoldSubmissionId bigint;
	DECLARE @SilverSubmissionIds nvarchar(max);
  DECLARE @BAQUniqueId nvarchar(25);
	
  SELECT TOP 1 @GoldSubmissionId = submissionId, @BAQUniqueId = BAQUniqueId 
  FROM [clickup].[vParentTasks] WHERE [formId] = '250151633085854' AND id = @certificationTaskId ORDER BY [dateUpdated] DESC;
	SET @SilverSubmissionIds = (SELECT STRING_AGG([submissionId], ',') FROM [clickup].[vTasks] WHERE [formId] != '250151633085854' AND id = @certificationTaskId)
	
  SET @SilverSubmissionIds = Concat_WS(',', @SilverSubmissionIds,  -- Commuting & Homeworking
                              (Select STRING_AGG(S.[submissionId], ',') from forms.Response as R INNER JOIN forms.JotformSubmission as S on (R.submissionId=S.Id AND R.questionId = 349)
                               Where R.[value] = @BAQUniqueId));
  
  IF @GoldSubmissionId IS NULL
	BEGIN
		SELECT 'Could not find Gold submissionId' as [error]
		RETURN 0;
	END
	
	IF @SilverSubmissionIds IS NULL
	BEGIN
		SELECT 'Could not find Silver submissionIds' as [error]
	END
	-- select @GoldSubmissionId, @SilverSubmissionIds;
	EXEC DataModel.spGold_DataOutputByScope		@BAQSubmissionid = @GoldSubmissionId, @silverSubmissionIds = @SilverSubmissionIds, @emissionProfileId = @emissionProfileId
	
END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputDetailedWrapper
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputDetailedWrapper]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputDetailedWrapper]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputDetailedWrapper] 
	@certificationTaskId nvarchar(50),
	@emissionProfileId INT
AS
BEGIN
	
	DECLARE @SilverSubmissionIds nvarchar(max);
  DECLARE @BAQUniqueId nvarchar(25);
	
  SELECT TOP 1 @BAQUniqueId = BAQUniqueId 
  FROM [clickup].[vParentTasks] WHERE [formId] = '241290444812856' AND id = @certificationTaskId ORDER BY [dateUpdated] DESC;
	SET @SilverSubmissionIds = (SELECT STRING_AGG([submissionId], ',') FROM [clickup].[vTasks] WHERE [formId] != '241290444812856' AND id = @certificationTaskId)
	
  SET @SilverSubmissionIds = Concat_WS(',', @SilverSubmissionIds,  -- Commuting & Homeworking
                              (Select STRING_AGG(S.[submissionId], ',') from forms.Response as R INNER JOIN forms.JotformSubmission as S on (R.submissionId=S.Id AND R.questionId = 349)
                               Where R.[value] = @BAQUniqueId));
  
	IF @SilverSubmissionIds IS NULL
	BEGIN
		SELECT 'Could not find Silver submissionIds' as [error]
	END
  -- select @SilverSubmissionIds;
	EXEC DataModel.spSilver_DataOutputDetailed	@silverSubmissionIds = @SilverSubmissionIds, @emissionProfileId = @emissionProfileId
	
END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputDetailedWrapper_Portal
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputDetailedWrapper_Portal]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputDetailedWrapper_Portal]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputDetailedWrapper_Portal] 
	@certId int,
	@emissionProfileId INT
AS
BEGIN
	
	DECLARE @SilverSubmissionIds nvarchar(max);
  
  SET @SilverSubmissionIds = (SELECT STRING_AGG([submissionId], ',') FROM portal.CertFormSubmissions WHERE certId = @certId and isProcessed=1);
  
	IF @SilverSubmissionIds IS NULL
	BEGIN
		SELECT 'Could not find Silver submissionIds' as [error]
	END

	EXEC DataModel.spSilver_DataOutputDetailed	@silverSubmissionIds = @SilverSubmissionIds, @emissionProfileId = @emissionProfileId
	
END
GO


-- ----------------------------
-- procedure structure for spSilver_DataOutputWrapper_Portal
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[spSilver_DataOutputWrapper_Portal]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[spSilver_DataOutputWrapper_Portal]
GO

CREATE PROCEDURE [DataModel].[spSilver_DataOutputWrapper_Portal] 
	@certId int,
	@emissionProfileId INT
AS
BEGIN
	
	DECLARE @BAQSubmissionId bigint;
	DECLARE @SilverSubmissionIds nvarchar(max);
  DECLARE @BAQUniqueId nvarchar(25);
  
  SET @SilverSubmissionIds = (SELECT STRING_AGG([submissionId], ',') FROM portal.CertFormSubmissions 
                              WHERE jotformId != '241290444812856' and certId = @certId and isProcessed=1);
  
  SET @BAQSubmissionId = (SELECT [submissionId] FROM portal.CertFormSubmissions 
                              WHERE jotformId = '241290444812856' and certId = @certId and isProcessed=1);
    
  IF @BAQSubmissionId IS NULL
	BEGIN
		SELECT 'Could not find BAQ submissionId' as [error]
		RETURN 0;
	END
	
	IF @SilverSubmissionIds IS NULL
	BEGIN
		SELECT 'Could not find Silver submissionIds' as [error]
	END
	-- select @BAQSubmissionId, @SilverSubmissionIds;
	EXEC DataModel.spBAQ_DataOutputByScope		@BAQSubmissionid = @BAQSubmissionId, @silverSubmissionIds = @SilverSubmissionIds, @emissionProfileId = @emissionProfileId;
	
END
GO


-- ----------------------------
-- procedure structure for Operations
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[DataModel].[Operations]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[DataModel].[Operations]
GO

CREATE PROCEDURE [DataModel].[Operations]
AS 
BEGIN 
SELECT CASE t.listid WHEN 901200207978 THEN 'Certification Journey' WHEN 901201811970 THEN 'Renewals' END AS listName,
		t.name, 
		t.status AS currentStatus, 
		u.name AS createdBy,
		CONVERT(DATE,[Utilities].[EpochToDate](dateCreated)) AS dateCreated,
		CONVERT(DATE,[Utilities].[EpochToDate](dateUpdated)) AS dateUpdated,
		CONVERT(DATE,[Utilities].[EpochToDate](dueDate)) AS dueDate,
		(SELECT COUNT(*) FROM clickup.Task x WHERE x.parentId = t.id AND status = 'subtask complete') AS dataFormsComplete,
		((SELECT COUNT(*) FROM clickup.Task x WHERE x.parentId = t.id AND status = 'subtask complete') / 13.0) AS percComplete,
		CASE WHEN ((SELECT COUNT(*) FROM clickup.Task x WHERE x.parentId = t.id AND status = 'subtask complete') / 13.0) = 0.0 THEN 'Not yet started' ELSE 'Started' END AS startStaus,
		CASE WHEN ((SELECT COUNT(*) FROM clickup.Task x WHERE x.parentId = t.id AND status = 'subtask complete') / 13.0) >= 1.0 THEN 'Complete'
			 WHEN ((SELECT COUNT(*) FROM clickup.Task x WHERE x.parentId = t.id AND status = 'subtask complete') / 13.0) = 0.0 THEN '0%'
			 WHEN ((SELECT COUNT(*) FROM clickup.Task x WHERE x.parentId = t.id AND status = 'subtask complete') / 13.0) < 0.5 THEN '1-50%'
			 WHEN ((SELECT COUNT(*) FROM clickup.Task x WHERE x.parentId = t.id AND status = 'subtask complete') / 13.0) < 0.75 THEN '51-75%'
			 ELSE '75%+'
			 END AS percCompleteName
FROM clickup.Task t
JOIN clickup.[User] u ON t.createdBy = u.id
WHERE spaceid = 90120081374
--AND listId = 901200207978
AND parentid IS NULL
AND t.id  NOT IN ('86943kawc','86943kaza','8694174h3')
AND t.activeTo IS NULL
--AND status != 'current certificate issued'
END
GO


-- ----------------------------
-- Primary Key structure for table Commissions
-- ----------------------------
ALTER TABLE [DataModel].[Commissions] ADD CONSTRAINT [PK__Commissi__3213E83F9300B36A] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Indexes structure for table ProductCosts
-- ----------------------------
CREATE NONCLUSTERED INDEX [IDX_ProductCosts]
ON [DataModel].[ProductCosts] (
  [productId] ASC,
  [validFrom] ASC,
  [validTo] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table ProductCosts
-- ----------------------------
ALTER TABLE [DataModel].[ProductCosts] ADD CONSTRAINT [PK__ProductC__3213E83F767E3C00] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table Products
-- ----------------------------
ALTER TABLE [DataModel].[Products] ADD CONSTRAINT [PK__Products__3213E83F7373B0CB] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Primary Key structure for table ReportCategory
-- ----------------------------
ALTER TABLE [DataModel].[ReportCategory] ADD CONSTRAINT [PK__ReportCa__23CAF1D8482EC43C] PRIMARY KEY CLUSTERED ([categoryId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Foreign Keys structure for table ProductCosts
-- ----------------------------
ALTER TABLE [DataModel].[ProductCosts] ADD CONSTRAINT [FK_ProductCosts_Products] FOREIGN KEY ([productId]) REFERENCES [DataModel].[Products] ([id]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO

