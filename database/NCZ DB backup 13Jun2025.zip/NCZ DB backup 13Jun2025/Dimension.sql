/*
 Navicat Premium Dump SQL

 Source Server         : NCZ [Live]
 Source Server Type    : SQL Server
 Source Server Version : 12000601 (12.00.0601)
 Source Host           : ncz.database.windows.net:1433
 Source Catalog        : nczdev
 Source Schema         : Dimension

 Target Server Type    : SQL Server
 Target Server Version : 12000601 (12.00.0601)
 File Encoding         : 65001

 Date: 13/06/2025 10:39:47
*/


-- ----------------------------
-- Table structure for Customer
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[Customer]') AND type IN ('U'))
	DROP TABLE [Dimension].[Customer]
GO

CREATE TABLE [Dimension].[Customer] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [code] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Dimension].[Customer] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for CustomerProfile
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[CustomerProfile]') AND type IN ('U'))
	DROP TABLE [Dimension].[CustomerProfile]
GO

CREATE TABLE [Dimension].[CustomerProfile] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [reference] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [periodStart] date  NULL,
  [periodEnd] date  NULL,
  [headCount] int  NULL,
  [annualRevenue] decimal(20,2)  NULL,
  [industryType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Dimension].[CustomerProfile] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Event
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[Event]') AND type IN ('U'))
	DROP TABLE [Dimension].[Event]
GO

CREATE TABLE [Dimension].[Event] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [title] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [reference] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [type] nvarchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [organiserName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [organiserEmail] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [companyName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [location] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [locationType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [startDateTime] datetime  NULL,
  [endDateTime] datetime  NULL,
  [noOfAttendees] int  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Dimension].[Event] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Form
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[Form]') AND type IN ('U'))
	DROP TABLE [Dimension].[Form]
GO

CREATE TABLE [Dimension].[Form] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [name] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [description] nvarchar(250) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [sourceId] int  NOT NULL,
  [dataSourceId] int  NOT NULL,
  [entityTypeId] int  NOT NULL,
  [categoryId] int  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Dimension].[Form] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Person
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[Person]') AND type IN ('U'))
	DROP TABLE [Dimension].[Person]
GO

CREATE TABLE [Dimension].[Person] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [firstName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [lastName] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [mobile] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [address] nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [active] bit DEFAULT 1 NOT NULL
)
GO

ALTER TABLE [Dimension].[Person] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for Submission
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[Submission]') AND type IN ('U'))
	DROP TABLE [Dimension].[Submission]
GO

CREATE TABLE [Dimension].[Submission] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [entityId] int  NOT NULL,
  [entityTypeId] int  NOT NULL,
  [formId] int  NOT NULL,
  [sourceId] int  NOT NULL,
  [dataSourceId] int  NOT NULL
)
GO

ALTER TABLE [Dimension].[Submission] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- procedure structure for spEvent_Save
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[spEvent_Save]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Dimension].[spEvent_Save]
GO

CREATE PROCEDURE [Dimension].[spEvent_Save]
	 @title nvarchar(100)
	,@reference nvarchar(50)
	,@type nvarchar(50)
	,@organiserName nvarchar(100)
	,@organiserEmail nvarchar(100)
	,@companyName nvarchar(100)
	,@startDateTime datetime
	,@endDateTime datetime
	,@location nvarchar(250)
	,@locationType nvarchar(100)
	,@noOfAttendees int
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @eventId int = (SELECT TOP 1 [id] FROM [Dimension].[Event] WHERE [reference] = @reference AND active = 1)
	IF @eventId IS NULL 
	BEGIN
		INSERT INTO [Dimension].[Event] (title, reference, type, organiserName, organiserEmail, companyName, startDateTime, endDateTime, location, locationType, noOfAttendees) 
			VALUES (@title, @reference, @type, @organiserName, @organiserEmail, @companyName, @startDateTime, @endDateTime, @location, @locationType, @noOfAttendees);
		SET @eventId = SCOPE_IDENTITY();
	END

	SELECT * FROM [Dimension].[Event] WHERE [id] = @eventId;
	 
END
GO


-- ----------------------------
-- procedure structure for spCustomer_SelectByPersonEmail
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[spCustomer_SelectByPersonEmail]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Dimension].[spCustomer_SelectByPersonEmail]
GO

CREATE PROCEDURE [Dimension].[spCustomer_SelectByPersonEmail]
	@email nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @customerCode nvarchar(50) = 
         (SELECT top 1 [companyTaskId] FROM [clickup].[vPeople] 
          WHERE RIGHT(email, CHARINDEX('@', REVERSE(email)) - 1) = RIGHT(@email, CHARINDEX('@', REVERSE(@email)) - 1));
	IF @customerCode IS NOT NULL
	BEGIN
		SELECT TOP 1 [id] FROM [Dimension].[Customer] WHERE code = @customerCode 
	END
	
END
GO


-- ----------------------------
-- procedure structure for spCustomer_SelectByPersonEmail_19Nov2024
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[spCustomer_SelectByPersonEmail_19Nov2024]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Dimension].[spCustomer_SelectByPersonEmail_19Nov2024]
GO

CREATE PROCEDURE [Dimension].[spCustomer_SelectByPersonEmail_19Nov2024]
	@email nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @customerCode nvarchar(50) = (SELECT top 1 [companyTaskId] FROM [clickup].[vPeople] WHERE email = @email);
	IF @customerCode IS NOT NULL
	BEGIN
		SELECT TOP 1 [id] FROM [Dimension].[Customer] WHERE code = @customerCode 
	END
	
END
GO


-- ----------------------------
-- procedure structure for spCustomer_SaveProfile
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[spCustomer_SaveProfile]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Dimension].[spCustomer_SaveProfile]
GO

CREATE PROCEDURE [Dimension].[spCustomer_SaveProfile]
	 @reference nvarchar(50)
	,@name nvarchar(100)
	,@periodStart date
	,@periodEnd date
	,@headCount int
	,@annualRevenue decimal(18,2)
	,@industryType nvarchar(100)
	,@locations_JSON nvarchar(max) 
AS
BEGIN
	SET NOCOUNT ON;


	DECLARE @profileId int = (SELECT TOP 1 [id] FROM [Dimension].[CustomerProfile] WHERE [reference] = @reference AND active = 1)
	IF @profileId IS NULL 
	BEGIN
		INSERT INTO [Dimension].[CustomerProfile] (reference, name, periodStart, periodEnd, headCount, annualRevenue, industryType) 
			VALUES (@reference, @name, @periodStart, @periodEnd, @headCount, @annualRevenue, @industryType);
		SET @profileId = SCOPE_IDENTITY();
	END
	--ELSE 
	--BEGIN
		-- update?
	--END
	
	SELECT * FROM [Dimension].[CustomerProfile] WHERE [id] = @profileId;

	-- TODO: SAVE LOCATIONS HERE
	 
END
GO


-- ----------------------------
-- procedure structure for spEntity_Select
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[spEntity_Select]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Dimension].[spEntity_Select]
GO

CREATE PROCEDURE [Dimension].[spEntity_Select]
	@entityName nvarchar(50)
	,@entityTypeId int
AS
BEGIN
	SET NOCOUNT ON;
	IF @entityTypeId = 1 --Customer Profile
	BEGIN
			SELECT * 
				FROM [Dimension].[CustomerProfile]
			 WHERE [reference] = @entityName AND active=1; 
	END
	ELSE IF @entityTypeId = 2 --Events
	BEGIN
			SELECT * 
				FROM [Dimension].[Event]
			 WHERE [reference] = @entityName AND active=1; 
	END
	ELSE IF @entityTypeId = 4 --Customers
	BEGIN
			SELECT * 
				FROM [Dimension].[Customer]
			 WHERE [code] = @entityName AND active=1; 
	END
END
GO


-- ----------------------------
-- procedure structure for spCustomer_SelectByUniqueId
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[Dimension].[spCustomer_SelectByUniqueId]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[Dimension].[spCustomer_SelectByUniqueId]
GO

CREATE PROCEDURE [Dimension].[spCustomer_SelectByUniqueId]
	@BAQ_UniqueId nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
  Declare @email nvarchar(100) = 
         (Select top 1 BAQ_Email from DataModel.BlueAwardSubmissionData 
          where BAQ_UniqueId = @BAQ_UniqueId);
          
  if(@email is null)
    set @email = (Select top 1 CFE.[value] from clickup.CustomField as CFU 
                  INNER JOIN clickup.CustomField as CFE on (CFU.taskId = CFE.taskId and CFU.name='BAQ uniqueId' and CFE.name='Email') 
                  Where CFU.value = @BAQ_UniqueId);
          
	DECLARE @customerCode nvarchar(50) = 
         (SELECT top 1 [companyTaskId] FROM [clickup].[vPeople] 
          WHERE RIGHT(email, CHARINDEX('@', REVERSE(email)) - 1) = RIGHT(@email, CHARINDEX('@', REVERSE(@email)) - 1));
	IF @customerCode IS NOT NULL
	BEGIN
		SELECT TOP 1 [id] FROM [Dimension].[Customer] WHERE code = @customerCode 
	END
	
END
GO


-- ----------------------------
-- Auto increment value for Customer
-- ----------------------------
DBCC CHECKIDENT ('[Dimension].[Customer]', RESEED, 502)
GO


-- ----------------------------
-- Primary Key structure for table Customer
-- ----------------------------
ALTER TABLE [Dimension].[Customer] ADD CONSTRAINT [PK__Customer__3213E83F3E90D9B2] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for CustomerProfile
-- ----------------------------
DBCC CHECKIDENT ('[Dimension].[CustomerProfile]', RESEED, 87)
GO


-- ----------------------------
-- Primary Key structure for table CustomerProfile
-- ----------------------------
ALTER TABLE [Dimension].[CustomerProfile] ADD CONSTRAINT [PK__Customer__3213E83F328992FE] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Event
-- ----------------------------
DBCC CHECKIDENT ('[Dimension].[Event]', RESEED, 18)
GO


-- ----------------------------
-- Primary Key structure for table Event
-- ----------------------------
ALTER TABLE [Dimension].[Event] ADD CONSTRAINT [PK__Event__3213E83FA753FE3F] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Form
-- ----------------------------
DBCC CHECKIDENT ('[Dimension].[Form]', RESEED, 15)
GO


-- ----------------------------
-- Primary Key structure for table Form
-- ----------------------------
ALTER TABLE [Dimension].[Form] ADD CONSTRAINT [PK__Form__3213E83F0E34F564] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Person
-- ----------------------------
DBCC CHECKIDENT ('[Dimension].[Person]', RESEED, 1)
GO


-- ----------------------------
-- Primary Key structure for table Person
-- ----------------------------
ALTER TABLE [Dimension].[Person] ADD CONSTRAINT [PK__Customer__3213E83F014A003F] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


-- ----------------------------
-- Auto increment value for Submission
-- ----------------------------
DBCC CHECKIDENT ('[Dimension].[Submission]', RESEED, 6534)
GO


-- ----------------------------
-- Primary Key structure for table Submission
-- ----------------------------
ALTER TABLE [Dimension].[Submission] ADD CONSTRAINT [PK__Submissi__3213E83F71EDB286] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

